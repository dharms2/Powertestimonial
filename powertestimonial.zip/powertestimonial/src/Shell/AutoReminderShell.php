<?php
namespace App\Shell;

use Cake\Console\Shell;
use Cake\Core\Configure;
use Cake\Mailer\Email;
use Cake\ORM\TableRegistry;

/**
 * Simple AutoReminder Shell
 * A longer class description
 *
 */
class AutoReminderShell extends Shell
{
    
    public function initialize()
    {
        parent::initialize();
    }
    
    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
    public function main()
    {
        $this->setAutoReminder();
    }
    
    /**
     * Display help for this console.
     *
     * @return \Cake\Console\ConsoleOptionParser
     */
    public function setAutoReminder()
    {
        $usersTable = TableRegistry::get('Users');
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $customEmailTemplatesTable = TableRegistry::get('CustomEmailTemplates');
        $allIncompleteSurveyReviews = $reviewsMgmtTable->find('all', [
            'order' => [
                'ReviewsMgmt.id' => 'desc',
            ],
            'conditions' => [
                'ReviewsMgmt.survey_done IN' => Configure::read('survey_review_pending'),
                'is_deleted' => Configure::read('zero')
            ]
        ])->toArray();
        
        foreach ($allIncompleteSurveyReviews as $allIncompleteSurveyReview) {
            if ($allIncompleteSurveyReview->recipient_email != 'N/A') {
                
                if ($allIncompleteSurveyReview->user_id == $allIncompleteSurveyReview->sender_id) {
                    $user = $usersTable->findById($allIncompleteSurveyReview->sender_id)->first();
                } else {
                    $user = $usersTable->findById($allIncompleteSurveyReview->user_id)->first();
                }
                
                if ($user->group_id == 4) {
                    $parentId = $user->parent_id;
                } else if ($user->group_id == 2) {
                    $parentId = $user->id;
                }
                
                $customEmailTemplate = $customEmailTemplatesTable->findByUserId($parentId)->first();

//                $fullBaseUrl = "http://powertest.chetu.local/";
                $fullBaseUrl = "http://staging.powertestimonial.net/";
//                $fullBaseUrl = "https://powertestimonial.net/";
                $reviewLink = '<a href="'.$fullBaseUrl.'reviews-mgmt/reviewStepOne/'.base64_encode($allIncompleteSurveyReview->id).'">CLICK HERE to rate your experience</a>';

                $today = date('Y-m-d');
                $firstReminderDate = \date('Y-m-d', \strtotime($allIncompleteSurveyReview->first_reminder_dt));
                $secondReminderDate = \date('Y-m-d', \strtotime($allIncompleteSurveyReview->second_reminder_dt));

                $defaultEmailTemlate = Configure::read("emailBody");
                                
                if ($today == $firstReminderDate) {
                    if (!empty($customEmailTemplate)) {
                        if (\strpos($customEmailTemplate->first_body, '{Recipient_Name}')) {
                            $customEmailTemplate->first_body = \str_replace('{Recipient_Name}', $allIncompleteSurveyReview->recipient_first_name, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{CLICK_HERE_to_rate_your_experience}')) {
                            $customEmailTemplate->first_body = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{Sender_Name}')) {
                            $customEmailTemplate->first_body = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{Sender_Email}')) {
                            $customEmailTemplate->first_body = \str_replace('{Sender_Email}', $user->email, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{Sender_Phone}')) {
                            $customEmailTemplate->first_body = \str_replace('{Sender_Phone}', $user->phone, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{Sender_Business_Name}')) {
                            $customEmailTemplate->first_body = \str_replace('{Sender_Business_Name}', $user->business_name, $customEmailTemplate->first_body);
                        }
                        if (\strpos($customEmailTemplate->first_body, '{Sender_Name}')) {
                            $customEmailTemplate->first_body = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $customEmailTemplate->first_body);
                        }

                        $email = $this->sendEmail($allIncompleteSurveyReview, $user, $customEmailTemplate->first_body, $fullBaseUrl, $customEmailTemplate->first_subject);

                        if ($email) {
                            $reviewsMgmt = $reviewsMgmtTable->get($allIncompleteSurveyReview->id); // Return article with id 12

                            $reviewsMgmt->first_reminder_send = 1;
                            $result = $reviewsMgmtTable->save($reviewsMgmt);

                            $this->out(print_r($user->id, true));
                            $this->out(print_r('First reminder successful sent', true));
                        } else {
                            $this->out(print_r('Something went wrong', true));
                        }
                    } else {
                        if (\strpos($defaultEmailTemlate, '{Recipient_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Recipient_Name}', $allIncompleteSurveyReview->recipient_first_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{CLICK_HERE_to_rate_your_experience}')) {
                            $defaultEmailTemlate = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Email}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Email}', $user->email, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Phone}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Phone}', $user->phone, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Business_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Business_Name}', $user->business_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $defaultEmailTemlate);
                        }
                        $subject = 'Reminder Mail: Please rate your experience with '.$user->business_name;
                        
                        $email = $this->sendEmail($allIncompleteSurveyReview, $user, $defaultEmailTemlate, $fullBaseUrl, $subject);

                        if ($email) {
                            $reviewsMgmt = $reviewsMgmtTable->get($allIncompleteSurveyReview->id); // Return survey/review with id = ?

                            $reviewsMgmt->first_reminder_send = 1;
                            $result = $reviewsMgmtTable->save($reviewsMgmt);

                            $this->out(print_r($user->id, true));
                            $this->out(print_r('Default template send for this user', true));
                        } else {
                            $this->out(print_r('Something went wrong', true));
                        }
                    }
                } 

                if ($today === $secondReminderDate) {
                    if (!empty($customEmailTemplate)) {
                        if (\strpos($customEmailTemplate->second_body, '{Recipient_Name}')) {
                            $customEmailTemplate->second_body = \str_replace('{Recipient_Name}', $allIncompleteSurveyReview->recipient_first_name, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{CLICK_HERE_to_rate_your_experience}')) {
                            $customEmailTemplate->second_body = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{Sender_Name}')) {
                            $customEmailTemplate->second_body = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{Sender_Email}')) {
                            $customEmailTemplate->second_body = \str_replace('{Sender_Email}', $user->email, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{Sender_Phone}')) {
                            $customEmailTemplate->second_body = \str_replace('{Sender_Phone}', $user->phone, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{Sender_Business_Name}')) {
                            $customEmailTemplate->second_body = \str_replace('{Sender_Business_Name}', $user->business_name, $customEmailTemplate->second_body);
                        }
                        if (\strpos($customEmailTemplate->second_body, '{Sender_Name}')) {
                            $customEmailTemplate->second_body = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $customEmailTemplate->second_body);
                        }

                        $email = $this->sendEmail($allIncompleteSurveyReview, $user, $customEmailTemplate->second_body, $fullBaseUrl, $customEmailTemplate->second_subject);

                        if ($email) {
                            $reviewsMgmt = $reviewsMgmtTable->get($allIncompleteSurveyReview->id); // Return survey/review with id = ?

                            $reviewsMgmt->second_reminder_send = 1;
                            $result = $reviewsMgmtTable->save($reviewsMgmt);

                            $this->out(print_r($user->id, true));
                            $this->out(print_r('Second reminder sccessful sent', true));
                        } else {
                            $this->out(print_r('Something went wrong', true));
                        }
                    } else {
                        if (\strpos($defaultEmailTemlate, '{Recipient_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Recipient_Name}', $allIncompleteSurveyReview->recipient_first_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{CLICK_HERE_to_rate_your_experience}')) {
                            $defaultEmailTemlate = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Email}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Email}', $user->email, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Phone}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Phone}', $user->phone, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Business_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Business_Name}', $user->business_name, $defaultEmailTemlate);
                        }
                        if (\strpos($defaultEmailTemlate, '{Sender_Name}')) {
                            $defaultEmailTemlate = \str_replace('{Sender_Name}', $user->first_name . ' ' . $user->last_name, $defaultEmailTemlate);
                        }
                        $subject = 'Reminder Mail: Please rate your experience with '.$user->business_name;

                        $email = $this->sendEmail($allIncompleteSurveyReview, $user, $defaultEmailTemlate, $fullBaseUrl, $subject);

                        if ($email) {
                            $reviewsMgmt = $reviewsMgmtTable->get($allIncompleteSurveyReview->id); // Return survey/review with id = ?

                            $reviewsMgmt->second_reminder_send = 1;
                            $result = $reviewsMgmtTable->save($reviewsMgmt);

                            $this->out(print_r($user->id, true));
                            $this->out(print_r('Default template send for this user', true));
                        } else {
                            $this->out(print_r('Something went wrong', true));
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Function to send email
     *
     * @param array $postData
     * @param array|null $userDetail
     * @param string $customEmailTemplate
     * @param string $fullBaseUrl
     * 
     * @return boolean
     * 
     */
    public function sendEmail($postData = null, $userDetail = null, $customEmailTemplate = null, $fullBaseUrl = null, $subject = null) 
    {
        $template = 'review';
        $emailTo = $postData->recipient_email;
        $fromEmail = Configure::read('fromEMail');
        $fromName = $userDetail['business_name'];
        $vars = [
            'id' => $postData->id,
            'name' => $postData->recipient_first_name,
            'senderName' => $userDetail['first_name'] . ' ' . $userDetail['last_name'],
            'senderPhone' => $userDetail['phone'],
            'senderEmail' => $userDetail['email'],
            'senderBusinessName' => $userDetail['business_name'],
            'baseUrl' => $fullBaseUrl,
            'body' => $customEmailTemplate
        ];
        
        $email = new Email('default');
        $email->from([$fromEmail => $fromName])
                ->to($emailTo)
                ->subject($subject)
                ->replyTo(Configure::read('fromEMail'))
                ->emailFormat('html')
                ->viewVars($vars)
                ->template($template)
                ->send();

        return true;
    }
    
}

<?php
namespace App\Shell;

use Cake\Console\Shell;
use Cake\ORM\TableRegistry;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use App\Controller\Component\ReviewApiComponent;

/**
 * Simple AutoReminder Shell
 * A longer class description
 *
 */
class FetchGoogleReviewShell extends Shell
{
    
    public function initialize()
    {
        parent::initialize();
        $this->ReviewApi = new ReviewApiComponent(new ComponentRegistry());
    }
    
    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
    public function main()
    {
        $this->fetchGoogleReview();
    }
    
    /**
     * Display help for this console.
     * fetchGoogleReview, Method used for fetch latest online reviews of google
     *
     * @return \Cake\Console\ConsoleOptionParser
     */
    public function fetchGoogleReview()
    {
        $usersTable = TableRegistry::get('Users');
        $googleTable = TableRegistry::get('Google');
        $apiConfigurationsTable = TableRegistry::get('ApiConfigurations');
        $apiUsers = $apiConfigurationsTable->find('all', ['fields' => ['user_id']])->toArray();

        foreach ($apiUsers as $apiUser) {
            $userData = $usersTable->findById($apiUser->user_id)->first();
            if ($userData->is_active == 1) {
                
                $apiConfigurations = $apiConfigurationsTable->getApiDetails(['user_id' => $apiUser->user_id]);

                //fetch and save Google Review data into DB
                if (!empty($apiConfigurations->google_place_id)) {
                    $googlesData = $googleTable->getGoogleDataByUserId($userData->id);
                    $google = $this->ReviewApi->getGoogleApiDetails($apiConfigurations);
                    if (!empty($google) && $google->status == "OK" && $google->status != NULL) {
                        $insertData = $this->ReviewApi->insertGoogleData($google, $userData, $apiConfigurations);
                        if ($insertData && !empty($google->result->reviews)) {
                            $this->ReviewApi->insertGoogleReviewData($google, $userData, $googlesData, $apiConfigurations);
                            $this->out(print_r('Successfuly fetch google reviews', true));
                        }
                    }
                } 
                else {
                    $this->out(print_r('There is no google api configration setting found', true));
                }
            }
        }
    }
    
}

<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\Core\App;
use Twilio\Rest\Client;
use Cake\Datasource\Exception\CustomException;

/**
 * ReviewsMgmt Controller
 *
 * @property \App\Model\Table\ReviewsMgmtTable $ReviewsMgmt
 *
 * @method \App\Model\Entity\ReviewsMgmt[] paginate($object = null, array $settings = [])
 */
class ReviewsMgmtController extends AppController {

    public $components = ['CommonFunction'];

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() {
        return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $title = __('{0} power_testimonial', ['Create Review Request']);
        $this->loadModel('Users');
        $this->loadModel('CustomEmailTemplates');

        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        $emailTemplates = $this->CustomEmailTemplates->getEmailTemplateByUserId($currentUserID);

        $reviewsMgmt = $this->ReviewsMgmt->newEntity();

        if ($this->request->is('post')) {
            $data = $this->request->getData();

            if ($data['user_id'] == $data['sender_id']) {
                $userDetails = $this->Users->getUserDetails($data['sender_id']);
            } else {
                $userDetails = $this->Users->getUserDetails($data['user_id']);
            }
            
            try {
                if ($result = $this->ReviewsMgmt->addSurveyReview($data, $emailTemplates)) {
                    if (!empty($result)) {
                        $CustomEmailTemplates = $this->CustomEmailTemplates->getEmailTemplateByUserId($userDetails->company_id);

                        if (!empty($CustomEmailTemplates)) {
                            if (!empty($CustomEmailTemplates->init_subject) && !empty($CustomEmailTemplates->init_body)) {
                                $reviewLink = '<a href="' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '">CLICK HERE to rate your experience</a>';
                                $initialSubject = $CustomEmailTemplates->init_subject;

                                if (\strpos($CustomEmailTemplates->init_body, '{Recipient_Name}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Recipient_Name}', $data['recipient_first_name'], $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{CLICK_HERE_to_rate_your_experience}')) {
                                    /* @var $CustomEmailTemplates type */
                                    $CustomEmailTemplates->init_body = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{Sender_Name}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Sender_Name}', $userDetails->first_name . ' ' . $userDetails->last_name, $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{Sender_Email}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Sender_Email}', $userDetails->email, $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{Sender_Phone}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Sender_Phone}', $userDetails->phone, $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{Sender_Business_Name}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Sender_Business_Name}', $userDetails->business_name, $CustomEmailTemplates->init_body);
                                }
                                if (\strpos($CustomEmailTemplates->init_body, '{Sender_Name}')) {
                                    $CustomEmailTemplates->init_body = \str_replace('{Sender_Name}', $userDetails->first_name . ' ' . $userDetails->last_name, $CustomEmailTemplates->init_body);
                                }

                                if (in_array('email', $data['send_type'])) {
                                    $this->CommonFunction->sendEmail($result, $emailCondition = 'review', $userDetails, $CustomEmailTemplates->init_body, $initialSubject);
                                }
                            } else {
                                if (in_array('email', $data['send_type'])) {
                                    $this->CommonFunction->sendEmail($result, $emailCondition = 'init_review', $userDetails);
                                }
                            }

                            if (!empty($CustomEmailTemplates->sms_verbiage)) {
                                $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                                if (strpos($CustomEmailTemplates->sms_verbiage, '{Recipient_Name}')) {
                                    $CustomEmailTemplates->sms_verbiage = str_replace('{Recipient_Name}', $data['recipient_first_name'], $CustomEmailTemplates->sms_verbiage);
                                }
                                if (strpos($CustomEmailTemplates->sms_verbiage, '{Sender_Business_Name}')) {
                                    $CustomEmailTemplates->sms_verbiage = str_replace('{Sender_Business_Name}', $userDetails->business_name, $CustomEmailTemplates->sms_verbiage);
                                }
                                if (strpos($CustomEmailTemplates->sms_verbiage, '{Sender_Name}')) {
                                    $CustomEmailTemplates->sms_verbiage = str_replace('{Sender_Name}', $userDetails->first_name . ' ' . $userDetails->last_name, $CustomEmailTemplates->sms_verbiage);
                                }
                                if (strpos($CustomEmailTemplates->sms_verbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                                    $CustomEmailTemplates->sms_verbiage = str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $CustomEmailTemplates->sms_verbiage);
                                }

                                if (in_array('sms', $data['send_type'])) {
                                    $sms = $this->sendSms($result, $CustomEmailTemplates->sms_verbiage);
                                }
                            } else {
                                $defaultSmsVerbiage = Configure::read("SMS_VERBIAGE");
                                $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                                if (strpos($defaultSmsVerbiage, '{Recipient_Name}')) {
                                    $defaultSmsVerbiage = str_replace('{Recipient_Name}', $data['recipient_first_name'], $defaultSmsVerbiage);
                                }
                                if (strpos($defaultSmsVerbiage, '{Sender_Business_Name}')) {
                                    $defaultSmsVerbiage = str_replace('{Sender_Business_Name}', $userDetails->business_name, $defaultSmsVerbiage);
                                }
                                if (strpos($defaultSmsVerbiage, '{Sender_Name}')) {
                                    $defaultSmsVerbiage = str_replace('{Sender_Name}', $userDetails->first_name . ' ' . $userDetails->last_name, $defaultSmsVerbiage);
                                }
                                if (strpos($defaultSmsVerbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                                    $defaultSmsVerbiage = str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultSmsVerbiage);
                                }

                                if (in_array('sms', $data['send_type'])) {
                                    $sms = $this->sendSms($result, $defaultSmsVerbiage);
                                }
                            }
                        } else {
                            if (in_array('email', $data['send_type'])) {
                                $this->CommonFunction->sendEmail($result, $emailCondition = 'init_review', $userDetails);
                            }

                            $defaultSmsVerbiage = Configure::read("SMS_VERBIAGE");
                            $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                            if (strpos($defaultSmsVerbiage, '{Recipient_Name}')) {
                                $defaultSmsVerbiage = str_replace('{Recipient_Name}', $data['recipient_first_name'], $defaultSmsVerbiage);
                            }
                            if (strpos($defaultSmsVerbiage, '{Sender_Business_Name}')) {
                                $defaultSmsVerbiage = str_replace('{Sender_Business_Name}', $userDetails->business_name, $defaultSmsVerbiage);
                            }
                            if (strpos($defaultSmsVerbiage, '{Sender_Name}')) {
                                $defaultSmsVerbiage = str_replace('{Sender_Name}', $userDetails->first_name . ' ' . $userDetails->last_name, $defaultSmsVerbiage);
                            }
                            if (strpos($defaultSmsVerbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                                $defaultSmsVerbiage = str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultSmsVerbiage);
                            }

                            if (in_array('sms', $data['send_type'])) {
                                $sms = $this->sendSms($result, $defaultSmsVerbiage);
                            }
                        }
                        $this->Flash->success(__('survey_review_success'));
                        return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
                    }
                }
            } catch (\Exception $e) {
                $review = $this->ReviewsMgmt->findById($result->id)->first();
                $review->is_deleted = 1;
                $this->ReviewsMgmt->save($review);
                $this->Flash->alert(__('email_not_sent'));
            }
        }
        
        $this->loadModel('SurveyMgmt');
        $surveyMgmt = $this->SurveyMgmt->getSurveyList($userIds)->toArray();
        
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        if (!empty($allUsersData)) {
            $allAssociates = $this->Users->getAllAssociatesUserList($allUsersData);
        } else {
            $allAssociates = $this->Users->getAllAssociatesUserList($currentUserID);
        }
        
        $this->set(compact('reviewsMgmt', 'surveyMgmt', 'users', 'title', 'userImg', 'allAssociates'));
        $this->set('_serialize', ['reviewsMgmt']);
    }

    /**
     * Rating method
     *
     * @param string|null $id Reviews Mgmt id.
     * @return \Cake\Http\Response|null Redirects on successful rating, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function rating() {
        if ($this->request->is('ajax')) {
            $reviewsMgmt = $this->ReviewsMgmt->get($this->request->data('postID'));
            $reviewsMgmt->user_action = 4;
            $reviewsMgmt->survey_done = 3;
            $reviewsMgmt->ratings = $this->request->data('ratingPoints');

            if ($this->request->is('post')) {
                $reviewsMgmt = $this->ReviewsMgmt->patchEntity($reviewsMgmt, $this->request->data());
                $result = $this->ReviewsMgmt->save($reviewsMgmt);

                if ($result) {
                    $result['status'] = 'ok';
                } else {
                    $result['status'] = 'error';
                }
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * Review Step One method
     *
     * @param string|null $reviewID Reviews Mgmt id.
     * @return \Cake\Http\Response|null Redirects on successful Review Step One, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function reviewStepOne($reviewID = null) {
        $this->viewBuilder()->layout(false);
        $review_id = base64_decode($reviewID);
        if ($review_id) {
            $this->loadModel('ReviewsMgmt');
            $review = $this->ReviewsMgmt->getReviewDetails($review_id);

            if (!empty($review->user_action) && !empty($review->ratings)) {
                $this->Flash->alert(__('review_complete_first_step'));
                return $this->redirect(['controller' => 'ReviewsMgmt', 'action' => 'reviewStepTwo', base64_encode($review_id)]);
            }

            $this->loadModel('SurveyMgmt');
            $survey = $this->SurveyMgmt->getSurveyDetails($review->survey_id);

            $this->loadModel('Users');
            $userDetail = $this->Users->getUserDetails($review->user_id);

            $parentUserData = $this->Users->getUserDetails($userDetail->company_id);
            $starRatingPlanFeature = $this->CommonFunction->checkPlanFeature($parentUserData->plan_id, Configure::read('FEATURE_5_STAR_RATING_SYSTEM'));

            $this->loadModel('SurveyTemplatesQuestion');
            $surveyTemplate = $this->SurveyTemplatesQuestion->getTemplateQuestionDetails($survey->survey_template_id);

            if ($surveyTemplate->type == Configure::read('surveyType')) {
                $review->user_action = 4;
                $review->survey_done = 3;
                $this->ReviewsMgmt->save($review);
                return $this->redirect(['controller' => 'ReviewsMgmt', 'action' => 'reviewStepTwo', base64_encode($review_id)]);
            }

            $title = __('Rate US! - ' . $userDetail->business_name);
            $this->set(compact('title', 'review', 'userDetail', 'starRatingPlanFeature'));
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * Review Step Two method
     *
     * @param string|null $reviewID Reviews Mgmt id.
     * @return \Cake\Http\Response|null Redirects on successful Review Step Two, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function reviewStepTwo($reviewID = null) {
        $this->viewBuilder()->layout(false);
        $review_id = base64_decode($reviewID);
        if ($review_id) {
            $this->loadModel('ReviewsMgmt');
            $review = $this->ReviewsMgmt->getReviewDetails($review_id);
            $surveyId = $review->survey_id;

            if ($review->user_action == null) {
                return $this->redirect(['controller' => 'ReviewsMgmt', 'action' => 'reviewStepOne', base64_encode($review_id)]);
            } elseif ($review->ratings == Configure::read('fiveRatings')) {
                $review->survey_done = 3;
                $this->ReviewsMgmt->save($review);
            }

            $this->loadModel('SurveyMgmt');
            $survey = $this->SurveyMgmt->getSurveyDetails($surveyId);
            $templateId = $survey->survey_template_id;

            $this->loadModel('SurveyTemplates');
            $surveyTemplates = $this->SurveyTemplates->getTemplateDetails($templateId);

            $this->loadModel('SurveyTemplatesQuestion');
            $templateFourOption = 0;
            $surveyTemplatesQuestions = [];
            if (empty($review->ratings)) {
                $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('surveyType'), Configure::read('zero'))->toArray();
            } else if ($review->ratings === 5) {
                $reviewApps = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), 5)->toArray();
            } else if ($review->ratings === 4) {

                $reviewAppsData = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), 4)->toArray();

                if (!empty($reviewAppsData)) {
                    $templateFourOption = $reviewAppsData[0]->fouroption;

                    if ($reviewAppsData[0]->fouroption == NULL) {
                        $templateFourOption = 1;
                        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), -1)->toArray();
                    } else if ($reviewAppsData[0]->fouroption == 1) {
                        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), $review->ratings)->toArray();
                        if (empty($surveyTemplatesQuestions)) {
                            $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), -1)->toArray();
                        }
                    } else if ($reviewAppsData[0]->fouroption == 2) {
                        $reviewApps = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), 4)->toArray();
                    }
                } else {
                    $templateFourOption = 1;
                    $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), -1)->toArray();
                }
            } else {
                $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), $review->ratings)->toArray();

                if (empty($surveyTemplatesQuestions)) {
                    $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->getSurveyTemplatesQuestions($templateId, Configure::read('one'), -1)->toArray();
                } 
            }
            
            if (!empty($surveyTemplatesQuestions)) {
                if ($surveyTemplatesQuestions[0]->star == -1) {
                    $questionLists['select_qusetion_id']['-1'] = array();
                } else {
                    $questionLists['select_qusetion_id'][$review->ratings] = array();
                }
            }

            function rec_questions($data, &$name, $ques_logic_id = 0) {
                // loop through all questions
                foreach ($data as $stq_key => $stq_val) {
                    if ($stq_val->question_logic_id == $ques_logic_id) {
                        $name[$stq_val->id] = array();
                        $new_name = &$name[$stq_val->id];
                        $new_name['q'] = [
                            'id' => $stq_val->survey_question->id,
                            'questions' => $stq_val->survey_question->questions,
                            'ans_types' => $stq_val->survey_question->ans_types,
                            'ans_choices' => explode('|', $stq_val->survey_question->ans_choices),
                            'correct_ans' => $stq_val->survey_question->correct_ans,
                            'status' => $stq_val->survey_question->status,
                            'baseUrl' => Configure::read('baseUrl'),
                            'hasLogic' => $stq_val->has_question_logic,
                            'question_logic_id' => $stq_val->question_logic_id,
                            'q_level' => $stq_val->q_level,
                            'stq_id' => $stq_val->id
                        ];
                        
                        if ($stq_val->has_question_logic == 1 && !empty($stq_val->survey_templates_question_logic)) {
                            $new_ans_name = &$new_name['ans'];
                            foreach ($stq_val->survey_templates_question_logic as $ans_key => $ans_val) {
                                $tmp_ans_name = &$new_ans_name[$ans_val->ans_option];
                                rec_questions($data, $tmp_ans_name, $ans_val->id);
                            }
                        }
                    }
                }
            }
            if (!empty($surveyTemplatesQuestions)) {
                if ($surveyTemplatesQuestions[0]->star == -1) {
                    rec_questions($surveyTemplatesQuestions, $questionLists['select_qusetion_id']['-1']);
                    $questionLists = $questionLists['select_qusetion_id']['-1'];
                } else {
                    rec_questions($surveyTemplatesQuestions, $questionLists['select_qusetion_id'][$review->ratings]);
                    $questionLists = $questionLists['select_qusetion_id'][$review->ratings];
                }
            }

            $this->loadModel('Users');
            $userDetail = $this->Users->getUserDetails($review->user_id);

            $surveyAns = [];
            $this->loadModel('SurveyAns');
            $surveyAns = $this->SurveyAns->getAnswersDetails($surveyId, $review_id)->toArray();

            $title = __('Rate US! - ' . $userDetail->business_name);

            $this->set(compact('surveyAns', 'title', 'review', 'surveyQuestion', 'surveyTemplates', 'ratings', 'templateId', 'questionLists', 'userDetail', 'reviewApps', 'templateFourOption'));
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    public function getChildArray() {

        $returnArry = array();
        $newArray = array();
        if ($_POST['child'] == 0) {
            if ($_POST['isChild'] == 1) {
                $newArray = array_values($_POST['quesList']);
            } else {
                $newArray = array_values($_POST['mainList']);
            }
            $containChild = $this->getArrayByKey($newArray, 'ans');            
            if (!empty($containChild)) {
                $returnArry['ischild'] = 1;
            } else {
                $returnArry['ischild'] = 0;
            }
            $returnArry[$_POST['index']] = $newArray[$_POST['index']];
        } else {
            $child = $_POST['child'];
            $radioVal = $_POST['radioValue'];
            
            $returnArry = $this->getArrayByKey($_POST['mainList'], (int)$child);

            $returnArry = array_values($returnArry['ans'][$radioVal]);
            $containChild = $this->getArrayByKey($returnArry, 'ans');
            if (!empty($containChild)) {
                $returnArry['ischild'] = 1;
            } else {
                $returnArry['ischild'] = 0;
            }
        }

        echo json_encode($returnArry);
        die;
    }

    public function getArrayByKey($array, $search_key) 
    {
        $test = array();
        if (is_array($array)) {
            foreach ($array as $key => $val) {
                if ($key === $search_key) {
                    return $val;
                } elseif (is_array($val)) {
                    $result = $this->getArrayByKey($val, $search_key);
                    if ($result !== false) {
                        return $result;
                    }
                }
            }
        }
        return false;
    }    
    

    /**
     * Submit Survey Answer method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function submitSurveyAnswer() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $surveyAnsTable = TableRegistry::get('SurveyAns');
                    $ansData = array();
                    foreach ($this->request->data() as $surveyAnsdata) {
                        foreach ($surveyAnsdata as $data) {
                            $tmp = [];
                            $tmp['survey_done'] = 1;
                            $tmp['survey_mgmt_id'] = $data['surveyID'];
                            $tmp['user_id'] = $data['userID'];
                            $tmp['review_mgmt_id'] = $data['reviewID'];
                            $tmp['survey_qus_id'] = $data['id'];
                            $tmp['fourstaroption'] = $data['fourstaroption'];
                            $tmp['q_level'] = $data['q_level'];

                            if (is_array($data['userAnswer'])) {
                                if ($data['ans_types'] == 4) {
                                    $tmp['answers'] = $data['userAnswer'];
                                } else if ($data['ans_types'] == 5) {
                                    $tmp['answers'] = json_encode($data['userAnswer']);
                                } else {
                                    $tmp['answers'] = implode(",", $data['userAnswer']);
                                }
                            } else {
                                $tmp['answers'] = $data['userAnswer'];
                            }
                            $ansData[] = $tmp;
                        }
                    }

                    foreach ($ansData as $ans) {
                        $userId = $ans['user_id'];
                        $reviewId = $ans['review_mgmt_id'];
                    }
                    $surveyAnsData = $surveyAnsTable->find('all', [
                                'conditions' => [
                                    'user_id' => $userId,
                                    'review_mgmt_id' => $reviewId
                                ]
                            ])->toArray();
                    $result = array();
//                    echo '<pre>';
//                    print_r($surveyAnsData);
//                    print_r($ansData);
//                    die;
                    if (!empty($ansData) && empty($surveyAnsData)) {
                        foreach ($ansData as $dt) {
                            $surveyAns = $surveyAnsTable->newEntity($dt);
//                            print_r($surveyAns);die;
                            $results = $surveyAnsTable->save($surveyAns);
                            //print_r($reslts);die;
                        }
                        //$surveyAns = $surveyAnsTable->newEntities($ansData);
//                        print_r($surveyAns);die;
                        //$result = $surveyAnsTable->saveMany($surveyAns);
//                        print_r($result);die;
                        if (!empty($results)) {
                            $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
                            $reviewsMgmt = $reviewsMgmtTable->get($results->review_mgmt_id);
                            $reviewsMgmt->survey_done = 2;
                            $res = $reviewsMgmtTable->save($reviewsMgmt);
                            
                            if ($res->survey_done == 2) {
                                $usersTable = TableRegistry::get('Users');
                                $usersData = $usersTable->get($res->user_id);
                                $senderData = $usersTable->get($res->sender_id);
                                $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                                $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                                if ($senderData->group_id == 2) {
                                    $realTimeAlertsPlanFeature = $this->CommonFunction->checkPlanFeature($senderData->plan_id, Configure::read('FEATURE_REAL_TIME_ALERTS'));

                                    if ($realTimeAlertsPlanFeature && $senderData->group_id == 2) {
                                        $email = $this->CommonFunction->sendEmail($res, $emailCondition = 'completeSurvey', $usersData, $surveyMgmt);
                                    }
                                } else {
                                    $email = 1;
                                }
                            }
                        }
                        if ($results && $email) {
                            $result['status'] = 'ok';
                        } else {
                            $result['status'] = 'error';
                        }
                    } else {
                        //die('else');
                        $result['status'] = 'submited';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * check Zillow API Details method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkZillowApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);
                    if (!empty($apiData->zillow_screen_name)) {
                        $this->loadModel('Zillow');
                        $zillow = $this->Zillow->getZillowDataByScreenName($this->request->data('uid'), $apiData->zillow_screen_name);
                        if (!empty($zillow->review_write_id)) {
                            $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                            $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                            $reviewMgmt->user_action = 7;
                            $reviewMgmt->survey_done = 2;
                            $res = $reviewMgmtTable->save($reviewMgmt);

                            if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                                $usersTable = TableRegistry::get('Users');
                                $usersDetails = $usersTable->get($res->user_id);
                                $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                                $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                                $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                            } else {
                                throw new CustomException(__('not_found'));
                            }
                            $result['status'] = 'OK';
                            $result['zillowID'] = $zillow->review_write_id;
                        }
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * check Facebook API Details method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkFacebookApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);
                    if (!empty($apiData->facebook_page_name)) {
                        $this->loadModel('Facebook');
                        $facebook = $this->Facebook->getFacebookDataByPageName($this->request->data('uid'), $apiData->facebook_page_name);
                        if (!empty($facebook->page_id)) {
                            $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                            $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                            $reviewMgmt->user_action = 2;
                            $reviewMgmt->survey_done = 2;
                            $res = $reviewMgmtTable->save($reviewMgmt);

                            if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                                $usersTable = TableRegistry::get('Users');
                                $usersDetails = $usersTable->get($res->user_id);
                                $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                                $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                                $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                            } else {
                                throw new CustomException(__('not_found'));
                            }
                            $result['status'] = 'OK';
                            $result['pageUrl'] = $facebook->page_url;
                        }
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * checkGoogleApiDetails method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkGoogleApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');

                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);
                    if (!empty($apiData->google_place_id)) {
                        $this->loadModel('Google');
                        $google = $this->Google->getGoogleDataByPlaceId($this->request->data('uid'), $apiData->google_place_id);

                        if (!empty($google->place_id)) {
                            $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                            $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                            $reviewMgmt->user_action = 1;
                            $reviewMgmt->survey_done = 2;
                            $res = $reviewMgmtTable->save($reviewMgmt);

                            if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                                $usersTable = TableRegistry::get('Users');
                                $usersDetails = $usersTable->get($res->user_id);
                                $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                                $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                                $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                            } else {
                                throw new CustomException(__('not_found'));
                            }
                            $result['status'] = 'OK';
                            $result['placeID'] = $google->place_id;
                        } else {
                            $result['status'] = 'OK';
                            $result['placeID'] = $apiData->google_place_id;
                        }
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * check YelpApi Details method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkYelpApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);
                    if (!empty($apiData->yelp_business_id)) {
                        $this->loadModel('Yelp');
                        $yelp = $this->Yelp->getYelpDataByBusinessName($this->request->data('uid'), $apiData->yelp_business_id);
                        if (!empty($yelp->business_id)) {
                            $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                            $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                            $reviewMgmt->user_action = 3;
                            $reviewMgmt->survey_done = 2;
                            $res = $reviewMgmtTable->save($reviewMgmt);

                            if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                                $usersTable = TableRegistry::get('Users');
                                $usersDetails = $usersTable->get($res->user_id);
                                $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                                $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                                $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                            } else {
                                throw new CustomException(__('not_found'));
                            }
                            $result['status'] = 'OK';
                            $result['requestURL'] = $yelp->request_url;
                        }
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * check Angies List Api Details method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkAngiesListApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);

                    if (!empty($apiData->angies_business_id)) {
                        $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                        $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                        $reviewMgmt->user_action = 8;
                        $reviewMgmt->survey_done = 2;
                        $res = $reviewMgmtTable->save($reviewMgmt);

                        if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                            $usersTable = TableRegistry::get('Users');
                            $usersDetails = $usersTable->get($res->user_id);
                            $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                            $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                            $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                        } else {
                            throw new CustomException(__('not_found'));
                        }
                        $result['status'] = 'OK';
                        $result['businessId'] = $apiData->angies_business_id;
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * checkBBBApiDetails method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkBBBApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);

                    if (!empty($apiData->bbb_business_name)) {
                        $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                        $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                        $reviewMgmt->user_action = 9;
                        $reviewMgmt->survey_done = 2;
                        $res = $reviewMgmtTable->save($reviewMgmt);

                        if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                            $usersTable = TableRegistry::get('Users');
                            $usersDetails = $usersTable->get($res->user_id);
                            $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                            $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                            $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                        } else {
                            throw new CustomException(__('not_found'));
                        }
                        $result['status'] = 'OK';
                        $result['businessName'] = $apiData->bbb_business_name;
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * checkRealtorApiDetails method
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function checkRealtorApiDetails() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $this->loadModel('ApiConfigurations');
                    $apiData = $this->ApiConfigurations->getApiDetails(['user_id' => $this->request->data('uid')]);

                    if (!empty($apiData->realtor_business_name)) {
                        $reviewMgmtTable = TableRegistry::get('ReviewsMgmt');
                        $reviewMgmt = $reviewMgmtTable->getReviewDetails($this->request->data('reviewId'));
                        $reviewMgmt->user_action = 6;
                        $reviewMgmt->survey_done = 2;
                        $res = $reviewMgmtTable->save($reviewMgmt);

                        if ($res->survey_done == Configure::read('surveyDone') && ($res->ratings == Configure::read('fiveRatings') || $res->ratings == Configure::read('fourRatings'))) {
                            $usersTable = TableRegistry::get('Users');
                            $usersDetails = $usersTable->get($res->user_id);
                            $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
                            $surveyMgmt = $surveyMgmtTable->get($res->survey_id);

                            $this->CommonFunction->sendEmail($res, $emailCondition = 'completeStarRating', $usersDetails, $surveyMgmt);
                        } else {
                            throw new CustomException(__('not_found'));
                        }
                        $result['status'] = 'OK';
                        $result['businessName'] = $apiData->realtor_business_name;
                    } else {
                        $result['status'] = 'error';
                    }
                } else {
                    throw new CustomException(__('not_found'));
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

    /**
     * Delete method
     *
     * @param string|null $id Survey Mgmt id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete', 'get']);
        $reviewMgmt = $this->ReviewsMgmt->get($id);
        $reviewMgmt->is_deleted = 1;
        if ($this->ReviewsMgmt->save($reviewMgmt)) {
            $this->Flash->success(__('review_delete_success'));
        } else {
            $this->Flash->error(__('review_delete_error'));
        }
        return $this->redirect(['action' => 'index']);
    }

    /**
     * check sendSms method
     * 
     * Twilio SMS API
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function sendSms($result, $verbiage = null) {
        try {
            // Your Account SID and Auth Token from twilio.com/console
            $sid = Configure::read('TwilioAcoountSID');
            $token = Configure::read('TwilioAuthToken');

            $recipient_phone = $result->recipient_phone; // the number you'd like to send the message to
            $twilio_phone_number = Configure::read('TwilioPhoneNumber'); // A Twilio phone number you purchased at twilio.com/console

            if ($verbiage == null) {
                $body = '.' . Configure::read('baseUrl') . "reviews-mgmt/reviewStepOne/" . base64_encode($result->id) . '.';
            } else {
                $body = $verbiage;
            }

            $client = new Client($sid, $token);

            // Use the client to do fun stuff like send text messages!
            if ($client->messages->create($recipient_phone, array('from' => $twilio_phone_number, 'body' => $body))) {
                return true;
            } else {
                throw new CustomException('SMS was not sent.');
            }
        } catch (\Exception $e) {
            $this->throwException($e);
        }
    }

    /**
     * Resend method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function resend() 
    {
        $this->loadModel('Users');
        $this->loadModel('CustomEmailTemplates');
        $user = $this->CommonFunction->getUser();

        if ($this->request->is('post')) {
            $data = $this->request->getData();

            if ($data) {
                $result = new \stdClass();
                $result->id = $data['id'];
                $result->recipient_first_name = $data['recipient_first_name'];
                $result->recipient_last_name = $data['recipient_last_name'];
                $result->recipient_email = $data['recipient_email'];
                $result->recipient_phone = $data['recipient_phone'];
                $result->survey_id = $data['survey_id'];
                $result->user_id = $data['user_id'];
                $result->sender_id = $data['sender_id'];

                if ($data['user_id'] == $data['sender_id']) {
                    $userData = $this->Users->getUserDetails($data['sender_id']);
                } else {
                    $userData = $this->Users->getUserDetails($data['user_id']);
                }

                $CustomEmailTemplates = $this->CustomEmailTemplates->getEmailTemplateByUserId($userDetails->company_id);
                $reviewLink = '<a href="' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '">CLICK HERE to rate your experience</a>';

                if (!empty($CustomEmailTemplates)) {
                    if (!empty($CustomEmailTemplates->init_body) && !empty($CustomEmailTemplates->init_subject)) {
                        $initialSubject = $CustomEmailTemplates->init_subject;

                        if (\strpos($CustomEmailTemplates->init_body, '{Recipient_Name}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Recipient_Name}', $data['recipient_first_name'], $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{CLICK_HERE_to_rate_your_experience}')) {
                            /* @var $CustomEmailTemplates type */
                            $CustomEmailTemplates->init_body = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{Sender_Name}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Sender_Name}', $userData->first_name . ' ' . $userData->last_name, $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{Sender_Email}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Sender_Email}', $userData->email, $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{Sender_Phone}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Sender_Phone}', $userData->phone, $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{Sender_Business_Name}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Sender_Business_Name}', $userData->business_name, $CustomEmailTemplates->init_body);
                        }
                        if (\strpos($CustomEmailTemplates->init_body, '{Sender_Name}')) {
                            $CustomEmailTemplates->init_body = \str_replace('{Sender_Name}', $userData->first_name . ' ' . $userData->last_name, $CustomEmailTemplates->init_body);
                        }

                        if (in_array('email', $data['send_type'])) {
                            $this->CommonFunction->sendEmail($result, $emailCondition = 'review', $userData, $CustomEmailTemplates->init_body, $initialSubject);
                        }
                    } else {
                        if (in_array('email', $data['send_type'])) {
                            $this->CommonFunction->sendEmail($result, $emailCondition = 'init_review', $userData);
                        }
                    }

                    if (!empty($CustomEmailTemplates->sms_verbiage)) {
                        $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                        if (\strpos($CustomEmailTemplates->sms_verbiage, '{Recipient_Name}')) {
                            $CustomEmailTemplates->sms_verbiage = \str_replace('{Recipient_Name}', $data['recipient_first_name'], $CustomEmailTemplates->sms_verbiage);
                        }
                        if (\strpos($CustomEmailTemplates->sms_verbiage, '{Sender_Business_Name}')) {
                            $CustomEmailTemplates->sms_verbiage = \str_replace('{Sender_Business_Name}', $userData->business_name, $CustomEmailTemplates->sms_verbiage);
                        }
                        if (\strpos($CustomEmailTemplates->sms_verbiage, '{Sender_Name}')) {
                            $CustomEmailTemplates->sms_verbiage = str_replace('{Sender_Name}', $userData->first_name . ' ' . $userData->last_name, $CustomEmailTemplates->sms_verbiage);
                        }
                        if (\strpos($CustomEmailTemplates->sms_verbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                            $CustomEmailTemplates->sms_verbiage = str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $CustomEmailTemplates->sms_verbiage);
                        }
                        if (in_array('sms', $data['send_type'])) {
                            $sms = $this->sendSms($result, $CustomEmailTemplates->sms_verbiage);
                        }
                    } else {
                        $defaultSmsVerbiage = Configure::read("SMS_VERBIAGE");
                        $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                        if (strpos($defaultSmsVerbiage, '{Recipient_Name}')) {
                            $defaultSmsVerbiage = str_replace('{Recipient_Name}', $data['recipient_first_name'], $defaultSmsVerbiage);
                        }
                        if (strpos($defaultSmsVerbiage, '{Sender_Business_Name}')) {
                            $defaultSmsVerbiage = str_replace('{Sender_Business_Name}', $userData->business_name, $defaultSmsVerbiage);
                        }
                        if (strpos($defaultSmsVerbiage, '{Sender_Name}')) {
                            $defaultSmsVerbiage = str_replace('{Sender_Name}', $userData->first_name . ' ' . $userData->last_name, $defaultSmsVerbiage);
                        }
                        if (strpos($defaultSmsVerbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                            $defaultSmsVerbiage = str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultSmsVerbiage);
                        }
                        if (in_array('sms', $data['send_type'])) {
                            $sms = $this->sendSms($result, $defaultSmsVerbiage);
                        }
                    }
                } else {
                    if (in_array('email', $data['send_type'])) {
                        $this->CommonFunction->sendEmail($result, $emailCondition = 'init_review', $userData);
                    }

                    $defaultSmsVerbiage = Configure::read("SMS_VERBIAGE");
                    $reviewLink = '.' . Configure::read('baseUrl') . 'reviews-mgmt/reviewStepOne/' . base64_encode($result->id) . '.';
                    if (\strpos($defaultSmsVerbiage, '{Recipient_Name}')) {
                        $defaultSmsVerbiage = \str_replace('{Recipient_Name}', $data['recipient_first_name'], $defaultSmsVerbiage);
                    }
                    if (\strpos($defaultSmsVerbiage, '{Sender_Business_Name}')) {
                        $defaultSmsVerbiage = \str_replace('{Sender_Business_Name}', $userData->business_name, $defaultSmsVerbiage);
                    }
                    if (strpos($defaultSmsVerbiage, '{Sender_Name}')) {
                        $defaultSmsVerbiage = \str_replace('{Sender_Name}', $userData->first_name . ' ' . $userData->last_name, $defaultSmsVerbiage);
                    }
                    if (\strpos($defaultSmsVerbiage, '{CLICK_HERE_to_rate_your_experience}')) {
                        $defaultSmsVerbiage = \str_replace('{CLICK_HERE_to_rate_your_experience}', $reviewLink, $defaultSmsVerbiage);
                    }
                    if (in_array('sms', $data['send_type'])) {
                        $sms = $this->sendSms($result, $defaultSmsVerbiage);
                    }
                }

                $this->Flash->success(__('survey_review_resend_success'));
                return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
            }

            $this->Flash->error(__('survey_review_resend_error'));
            return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }

}

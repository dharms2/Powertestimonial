<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * ApiConfigurations Controller
 *
 * @property \App\Model\Table\ApiConfigurationsTable $ApiConfigurations
 *
 * @method \App\Model\Entity\ApiConfiguration[] paginate($object = null, array $settings = [])
 */
class ApiConfigurationsController extends AppController
{
    public $components = ['CommonFunction', 'ReviewApi'];
    
    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null Redirects on successful update, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function index()
    {
        $title = __('{0} power_testimonial', ['API Configurations']);
        
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        if ($userImg->api_config == 1) {
            $this->Flash->alert(__('api_config_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }

        $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
        $baseUrl = Configure::read('baseUrl');

        // Code for Facebook Login and redirect to facebook login screen
        include( ROOT.'/vendor/Facebook/facebook-php-sdk-v5/autoload.php' );
        $fb = new \Facebook\Facebook([
                'app_id' => Configure::read('FacebookAppId'), // Replace {app-id} with your app id
                'app_secret' => Configure::read('FacebookAppSecret'),
                'default_graph_version' => 'v2.10',
        ]);
        // Load Facebook redirect login helper
        $helper = $fb->getRedirectLoginHelper();
        
        // Optional permissions
        $permissions = ['business_management','email','manage_pages','public_profile','user_friends'];
        $loginUrl = $helper->getLoginUrl($baseUrl.'ApiConfigurations/fbCallback', $permissions);

        $this->set(compact('apiConfigurations', 'title', 'userImg', 'baseUrl', 'loginUrl'));
    }
    
    /**
     * zillow method
     *
     * @return \Cake\Http\Response|null Redirects on successful update, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function zillow($id = null)
    {
        $title = __('{0} power_testimonial', ['Zillow API Configurations']);
        $this->loadModel('Zillow');
        
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $zillowInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($result = $this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                if (!empty($result)) {
                    $ApiDetails = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
                    $ApiDetails->zillow_screen_name = '';

                    $apiReviewsTable = TableRegistry::get('ApiReviews');
                    $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($userImg->id)->toArray();

                    if (empty($result->zillow_screen_name)) {
                        foreach ($reviewDetails as $reviewDetail) {
                            $apiReviewsTable->deleteZillowApiReview($reviewDetail->review_id, $userImg->id);
                        }
                    }

                    //fetch Zillow Review data into DB
                    if (!empty($result->zillow_screen_name)) {
                        if (!empty($result->zillow_screen_name)) {
                            $zillowData = $this->Zillow->getZillowDetails($userImg->id);
                            $url = Configure::read('ZillowURL') . '?zws-id=' . $result->zillow_access_Id . '&screenname=' . urlencode($result->zillow_screen_name) . '' . Configure::read('ZillowParam');

                            $zillowXmlData = file_get_contents($url);
                            $xml = simplexml_load_string($zillowXmlData);
                            $msgCode = (array) $xml->message->code;
                            
                            //save Zillow API data into DB
                            if (!empty($xml) && $msgCode[0] == 0) {
                                $zillow = $this->ReviewApi->zillow($xml, $userImg);
                                if (!empty($zillow)) {
                                    $reviewsData = [];
                                    $reviewsData['proReviews'] = (array) $xml->response->result->proReviews;
                                    if (!empty($reviewsData['proReviews'])) {
                                        $proReviews = $this->ReviewApi->zillowDetails($reviewsData['proReviews'], $userImg, $zillowData, $result);
                                    } else {
                                        foreach ($reviewDetails as $reviewDetail) {
                                            $apiReviewsTable->deleteZillowApiReview($reviewDetail->review_id, $userImg->id);
                                        }
                                        $this->Flash->success(__('api_setting_success'));
                                        return $this->redirect(['action' => 'index']);
                                    }
                                } else {
                                    $this->ApiConfigurations->save($ApiDetails);
                                    $this->Flash->error(__('Something went wrong, please try again!'));
                                    return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'zillow', base64_encode($configId)]);
                                }
                                if (empty($proReviews)) {
                                    $this->ApiConfigurations->save($ApiDetails);
                                    $this->Flash->error(__('Something went wrong, please try again!'));
                                    return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'zillow', base64_encode($configId)]);
                                }
                            }
                        }
                    } 
                    $this->Flash->success(__('api_setting_success'));
                    return $this->redirect(['action' => 'index']);
                }
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('zillowInfo', 'title', 'userImg'));
    }
    
    /**
     * google method
     *
     * @return \Cake\Http\Response|null Redirects on successful update, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function google($id = null)
    {
        $title = __('{0} power_testimonial', ['Google API Configurations']);
        $this->loadModel('Google');
        
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $googleInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($result = $this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                if (!empty($result)) {
                    $ApiDetails = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
                    $ApiDetails->google_place_id = '';

                    $apiReviewsTable = TableRegistry::get('ApiReviews');
                    $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($userImg->id)->toArray();

                    if (empty($result->google_place_id)) {
                        foreach ($reviewDetails as $reviewDetail) {
                            $apiReviewsTable->deleteGoogleApiReview($reviewDetail->review_id, $userImg->id);
                        }
                    }

                    //fetch and save Google Review data into DB
                    if (!empty($result->google_place_id)) {
                        if (!empty($result->google_place_id)) {
                            $googlesData = $this->Google->getGoogleDataByUserId($userImg->id);
                            $google = $this->ReviewApi->getGoogleApiDetails($result);
                            if (!empty($google) && $google->status == "OK" && $google->status != NULL) {
                                $insertData = $this->ReviewApi->insertGoogleData($google, $userImg, $result);
                                if ($insertData && !empty($google->result->reviews)) {
                                    $insertGoogleApiReview = $this->ReviewApi->insertGoogleReviewData($google, $userImg, $googlesData, $result);
                                } else {
                                    foreach ($reviewDetails as $reviewDetail) {
                                        $apiReviewsTable->deleteGoogleApiReview($reviewDetail->review_id, $userImg->id);
                                    }
                                    $this->Flash->success(__('api_setting_success'));
                                    return $this->redirect(['action' => 'index']);
                                }
                            } else {
                                $this->ApiConfigurations->save($ApiDetails);
                                $this->Flash->error(__($google->error_message));
                                return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'google', base64_encode($configId)]);
                            }
                            if (empty($insertGoogleApiReview)) {
                                $this->ApiConfigurations->save($ApiDetails);
                                $this->Flash->error(__('Something went wrong, please try again!'));
                                return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'google', base64_encode($configId)]);
                            }
                        }
                    }  
                    $this->Flash->success(__('api_setting_success'));
                    return $this->redirect(['action' => 'index']);
                }
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('googleInfo', 'title', 'userImg'));
    }
    
    /**
     * yelp method
     *
     * @return \Cake\Http\Response|null Redirects on successful update, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function yelp($id = null)
    {
        $title = __('{0} power_testimonial', ['Yelp API Configurations']);
        $this->loadModel('Yelp');
        
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $yelpInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($result = $this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                if (!empty($result)) {
                    $ApiDetails = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
                    $ApiDetails->yelp_business_id = '';

                    $apiReviewsTable = TableRegistry::get('ApiReviews');
                    $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($userImg->id)->toArray();

                    if (empty($result->yelp_business_id)) {
                        foreach ($reviewDetails as $reviewDetail) {
                            $apiReviewsTable->deleteYelpApiReview($reviewDetail->review_id, $userImg->id);
                        }
                    }

                    //fetch and save Yelp Review data into DB
                    if (!empty($result->yelp_business_id)) {
                        $yelpData = $this->Yelp->getYelpDataByUserId($userImg->id);

                            $getYelpDetail = $this->ReviewApi->getYelpDetails($result->yelp_business_id);

                            if (!empty($getYelpDetail)) {
                                $yelp = $this->ReviewApi->insertYelpData($getYelpDetail, $userImg);

                                if (!empty($yelp)) {
                                    $yelpReviews = $this->ReviewApi->getYelpReviews($result->yelp_business_id);

                                    if (!empty($yelpReviews->reviews)) {
                                        $res = $this->ReviewApi->yelpReviewData($yelpReviews, $userImg, $yelpData, $result);
                                    }
                                } else {
                                    $this->ApiConfigurations->save($ApiDetails);
                                    $this->Flash->error(__('Something went wrong, please try again!'));
                                    return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'yelp', base64_encode($configId)]);
                                }
                            } else {
                                $this->ApiConfigurations->save($ApiDetails);
                                $this->Flash->error(__('Something went wrong, please try again!'));
                                return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'yelp', base64_encode($configId)]);
                            }
                            if (empty($res)) {
                                $this->ApiConfigurations->save($ApiDetails);
                                $this->Flash->error(__('Something went wrong, please try again!'));
                                return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'yelp', base64_encode($configId)]);
                            }

                    }
                    $this->Flash->success(__('api_setting_success'));
                    return $this->redirect(['action' => 'index']);
                }
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('yelpInfo', 'title', 'userImg'));
    }
    
    /**
     * facebook method
     *
     * @return \Cake\Http\Response|null Redirects on successful update, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function facebook($id = null)
    {
        $this->loadModel('Facebook');
        $this->loadModel('Users');
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $facebook = $this->ReviewApi->getFacebookDetails($this->request->getData('facebook_user_id'), $this->request->getData('facebook_access_token'));
        
        if ($facebook['message'] == 'OK') {
            if ($this->request->is(['patch', 'post', 'put'])) {
                $data = $this->request->getData();
                $data['facebook_app_id'] = $this->request->getData('facebook_user_id');
                $data['facebook_app_secret'] = $this->request->getData('facebook_access_token');
                if ($result = $this->ApiConfigurations->addApiConfigurations($data)) {
                    if (!empty($result)) {
                        $ApiDetails = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
                        $ApiDetails->facebook_page_name = '';

                        $apiReviewsTable = TableRegistry::get('ApiReviews');
                        $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($userImg->id)->toArray();

                        if (empty($result->facebook_page_name)) {
                            foreach ($reviewDetails as $reviewDetail) {
                                $apiReviewsTable->deleteFacebookApiReview($reviewDetail->review_id, $userImg->id);
                            }
                        }

                        //fetch and save Facebook Review data into DB
                        if (!empty($result->facebook_page_name)) {
                            $facebookData = $this->Facebook->getFacebookDataByUserId($userImg->id);
                            $errFlag = 1;
                            foreach ($facebook['response']->data as $data) {

                                if ($data->name == $result->facebook_page_name) {
                                    $errFlag = 0;
                                    $profileImg = $this->ReviewApi->getFacebookProfileImg($data->id);
                                    $insertFacebook = $this->ReviewApi->insertFacebookData($data, $userImg, $profileImg['response']);

                                    if (!empty($insertFacebook->page_id) && !empty($insertFacebook->access_token)) {
                                        $pullFacebookReview = $this->ReviewApi->getFacebookReviews($insertFacebook->page_id, $insertFacebook->access_token);

                                        if ($pullFacebookReview['message'] == 'OK') {
                                            $insertFacebookReview = $this->ReviewApi->getFacebookReviewsData($pullFacebookReview['response'], $userImg, $facebookData, $result, $data);
                                        } else {
                                            $this->ApiConfigurations->save($ApiDetails);
                                            $this->Flash->error(__('Something went wrong, please try again!'));
                                            return $this->redirect(["controller" => "ApiConfigurations", "action" => "index"]);
                                        }
                                    } else {
                                        $this->ApiConfigurations->save($ApiDetails);
                                        $this->Flash->error(__('Something went wrong, please try again!'));
                                        return $this->redirect(["controller" => "ApiConfigurations", "action" => "index"]);
                                    }
                                    if (empty($insertFacebookReview)) {
                                        $this->ApiConfigurations->save($ApiDetails);
                                        $this->Flash->error(__('Something went wrong, please try again!'));
                                        return $this->redirect(["controller" => "ApiConfigurations", "action" => "index"]);
                                    }
                                } 
                            }
                            if($errFlag == 1){
                                $this->ApiConfigurations->save($ApiDetails);
                                $this->Flash->alert(__('Page not available for this account, please check and try again!'));
                                return $this->redirect(["controller" => "ApiConfigurations", "action" => "index"]);
                            }
                        }
                    }
                    $this->Flash->success(__('api_setting_success'));
                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('api_setting_error'));
            }
        } else {
            $this->Flash->error(__('Something went wrong, please try again!'));
            return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'facebook', base64_encode($configId)]);
        }

        $this->set(compact('facebookInfo', 'title', 'userImg', 'fbAppId'));
    }
    
    /**
     * checkZillowScreenName Method to check Zillow Screen Name is valid
     *
     * @return json
     */
    public function checkZillowScreenName() 
    {
        if ($this->request->is('ajax')) {
            $url = Configure::read('ZillowURL') . '?zws-id=X1-ZWz18zotebfwgb_8gte4&screenname='
                    . urlencode($this->request->data('zillow')) 
                    . '' . Configure::read('ZillowParam');
            $zillowXmlData = file_get_contents($url);
            $xml = simplexml_load_string($zillowXmlData);
            $msgCode = (array) $xml->message->code;
            if (!empty($xml) && $msgCode[0] == 0) {
                $result['msgCode'] = 0;
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * checkGooglePlaceId Method to check Google Place Id is valid
     *
     * @return json
     */
    public function checkGooglePlaceId() 
    {
        if ($this->request->is('ajax')) {
            $google = $this->ReviewApi->getGoogleApiDetails((object)$this->request->data);
            if (!empty($google) && $google->status == "OK") {
                $result['msgCode'] = 0;
            } else {
                $result['msgCode'] = 1;
                $result['errorMsg'] = $google->error_message;
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * checkYelpBussinessName Method to check Yelp Bussiness Name is valid
     *
     * @return json
     */
    public function checkYelpBussinessName() 
    {
        if ($this->request->is('ajax')) {

            if ($this->request->is('post')) {
                $yelpDetail = $this->ReviewApi->getYelpDetails($this->request->data('yelp'));

                if (!empty($yelpDetail->error)) {
                    $result['msgCode'] = 1;
					$result['description'] = $yelpDetail->error->description;
                } else {
                    $result['msgCode'] = 0;
                }
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
        
    /**
     * Facebook Callback method to call Facebook account user and access token
     * for pull Facebook review and rating
     *
     * @param null.
     * @return void.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */    
    public function fbCallback() 
    {
        include( ROOT.'/vendor/Facebook/facebook-php-sdk-v5/autoload.php' );
		
        $fb = new \Facebook\Facebook([
                'app_id' => Configure::read('FacebookAppId'), // Replace {app-id} with your app id
                'app_secret' => Configure::read('FacebookAppSecret'),
                'default_graph_version' => 'v2.10',
        ]);
        
        $helper = $fb->getRedirectLoginHelper();

        if (isset($_GET['state'])) {
            $helper->getPersistentDataHandler()->set('state', $_GET['state']);
        }

        try {
//                $accessToken = $helper->getAccessToken();
                // $accessToken = $helper->getAccessToken('http://powertest.chetu.local/ApiConfigurations/fbCallback');
               $accessToken = $helper->getAccessToken('http://staging.powertestimonial.net/ApiConfigurations/fbCallback');
//                $accessToken = $helper->getAccessToken('https://powertestimonial.net/ApiConfigurations/fbCallback');
        } catch(Facebook\Exceptions\FacebookResponseException $e) {
                // When Graph returns an error
                echo 'Graph returned an error: ' . $e->getMessage();
                var_dump($helper->getError());
                exit;
        } catch(Facebook\Exceptions\FacebookSDKException $e) {
                // When validation fails or other local issues
                echo 'Facebook SDK returned an error: ' . $e->getMessage();
                var_dump($helper->getError());
                exit;
        }

        if (! isset($accessToken)) {
            if ($helper->getError()) {
                header('HTTP/1.0 401 Unauthorized');
                echo "Error: " . $helper->getError() . "\n";
                echo "Error Code: " . $helper->getErrorCode() . "\n";
                echo "Error Reason: " . $helper->getErrorReason() . "\n";
                echo "Error Description: " . $helper->getErrorDescription() . "\n";
            } else {
                header('HTTP/1.0 400 Bad Request');
                echo 'Bad request';
            }
            exit;
        }
        
        $getAccessToken = $accessToken->getValue();

        // Logged in
        // The OAuth 2.0 client handler helps us manage access tokens
        $oAuth2Client = $fb->getOAuth2Client();

        // Get the access token metadata from /debug_token
        $tokenMetadata = $oAuth2Client->debugToken($accessToken);

        $userId = $tokenMetadata->getUserId();
        $scopes = $tokenMetadata->getScopes();

        // Validation (these will throw FacebookSDKException's when they fail)
        $tokenMetadata->validateAppId(Configure::read('FacebookAppId')); // Replace {app-id} with your app id
        $tokenMetadata->validateExpiration();
        if (! $accessToken->isLongLived()) {
        // Exchanges a short-lived access token for a long-lived one
            try {
                $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
            } catch (Facebook\Exceptions\FacebookSDKException $e) {
                echo "<p>Error getting long-lived access token: " . $helper->getMessage() . "</p>\n\n";
                exit;
            }
            $getAccessToken = $accessToken->getValue();

        }
        if (in_array('manage_pages', $scopes)) {

            $title = __('{0} power_testimonial', ['Facebook API Configurations']);
            $this->loadModel('Facebook');

            $this->loadModel('Users');
            $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
            $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);

            $this->set(compact('title', 'userImg', 'apiConfigurations', 'getAccessToken', 'userId'));
            
        } else {
            $this->Flash->error(__('This account has no permission of Manages Pages!'));
            return $this->redirect(['action' => 'ApiConfigurations', 'action' => 'index']);
        }
    }
    
    /**
     * angiesList method
     *
     * @param int $id current login user id
     * @return void.
     */
    public function angiesList($id = null)
    {
        $title = __('{0} power_testimonial', ['Angies List API Configurations']);
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $apiInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                $this->Flash->success(__('api_setting_success'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('apiInfo', 'title', 'userImg'));
    }
    
    /**
     * bbbReview method
     *
     * @param int $id current login user id
     * @return void.
     */
    public function bbbReview($id = null)
    {
        $title = __('{0} power_testimonial', ['BBB API Configurations']);
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $apiInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                $this->Flash->success(__('api_setting_success'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('apiInfo', 'title', 'userImg'));
    }
    
    /**
     * realtorReview method
     *
     * @param int $id current login user id
     * @return void.
     */
    public function realtorReview($id = null)
    {
        $title = __('{0} power_testimonial', ['Realtor API Configurations']);
        $configId = base64_decode($id);
        $this->loadModel('Users');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $apiInfo = $this->ApiConfigurations->get($configId);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->ApiConfigurations->addApiConfigurations($this->request->getData())) {
                $this->Flash->success(__('api_setting_success'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('api_setting_error'));
        }

        $this->set(compact('apiInfo', 'title', 'userImg'));
    }
    
    /**
     * checkYelpBussinessName Method to check Yelp Bussiness Name is valid
     *
     * @return json
     */
    public function fetchOnlineReview() 
    {
//        pr($this->request->data);die;
        if ($this->request->is('ajax')) {
            $result = [];
            if ($this->request->data()) {
                $this->loadModel('Users');
                $userData = $this->Users->findById($this->request->data('userId'))->first();
                $apiDetails = $this->ApiConfigurations->getApiDetails(['user_id' => $userData->id]);
                
                //fetch and save Zillow Review data into DB
                if (!empty($apiDetails->zillow_screen_name)) {
                    $this->loadModel('Zillow');
                    $zillowData = $this->Zillow->getZillowDetails($userData->id);
                    $url = Configure::read('ZillowURL') . '?zws-id=' . $apiDetails->zillow_access_Id . '&screenname=' . urlencode($apiDetails->zillow_screen_name) . '' . Configure::read('ZillowParam');
                    $zillowXmlData = file_get_contents($url);
                    $xml = simplexml_load_string($zillowXmlData);
                    $msgCode = (array) $xml->message->code;

                    //save Zillow API data into DB
                    if (!empty($xml) && $msgCode[0] == 0) {
                        $zillow = $this->ReviewApi->zillow($xml, $userData);
                        if (!empty($zillow)) {
                            $reviewsData = [];
                            $reviewsData['proReviews'] = (array) $xml->response->result->proReviews;
                            if (!empty($reviewsData['proReviews'])) {
                                $this->ReviewApi->zillowDetails($reviewsData['proReviews'], $userData, $zillowData, $apiDetails);
                                $result['zillow'] = 'ok';
                            }
                        }
                    }
                } else {
                    $result['google'] = 'error';
                }
                
                //fetch and save Google Review data into DB
                if (!empty($apiDetails->google_place_id)) {
                    $this->loadModel('Google');
                    $googlesData = $this->Google->getGoogleDataByUserId($userData->id);
                    $google = $this->ReviewApi->getGoogleApiDetails($apiDetails);
                    if (!empty($google) && $google->status == "OK" && $google->status != NULL) {
                        $insertData = $this->ReviewApi->insertGoogleData($google, $userData, $apiDetails);
                        if ($insertData && !empty($google->result->reviews)) {
                            $this->ReviewApi->insertGoogleReviewData($google, $userData, $googlesData, $apiDetails);
                            $result['google'] = 'ok';
                        }
                    }
                } else {
                    $result['google'] = 'error';
                }
                
                //fetch and save Facebook Review data into DB
                if (!empty($apiDetails->yelp_business_id)) {
                    $this->loadModel('Yelp');
                    $yelpData = $this->Yelp->getYelpDataByUserId($userData->id);
                        $getYelpDetail = $this->ReviewApi->getYelpDetails($apiDetails->yelp_business_id);

                        if (!empty($getYelpDetail)) {
                            $yelp = $this->ReviewApi->insertYelpData($getYelpDetail, $userData);

                            if (!empty($yelp)) {
                                $yelpReviews = $this->ReviewApi->getYelpReviews($apiDetails->yelp_business_id);

                                if (!empty($yelpReviews->reviews)) {
                                    $res = $this->ReviewApi->yelpReviewData($yelpReviews, $userData, $yelpData, $apiDetails);
                                    $result['yelp'] = 'ok';
                                }
                            }
                        }
                } else {
                    $result['yelp'] = 'error';
                }
                
                //fetch and save Facebook Review data into DB
                if (!empty($apiDetails->facebook_page_name && !empty($apiDetails->facebook_app_id) && !empty($apiDetails->facebook_app_secret))) {
                    $facebook = $this->ReviewApi->getFacebookDetails($apiDetails->facebook_app_id, $apiDetails->facebook_app_secret);
                    if ($facebook['message'] == 'OK') {
                        $this->loadModel('Facebook');
                        $facebookData = $this->Facebook->getFacebookDataByUserId($userData->id);
                        $errFlag = 1;
                        foreach ($facebook['response']->data as $data) {

                            if ($data->name == $apiDetails->facebook_page_name) {
                                $errFlag = 0;
                                $profileImg = $this->ReviewApi->getFacebookProfileImg($data->id);
                                $insertFacebook = $this->ReviewApi->insertFacebookData($data, $userData, $profileImg['response']);

                                if (!empty($insertFacebook->page_id) && !empty($insertFacebook->access_token)) {
                                    $pullFacebookReview = $this->ReviewApi->getFacebookReviews($insertFacebook->page_id, $insertFacebook->access_token);

                                    if ($pullFacebookReview['message'] == 'OK') {
                                        $this->ReviewApi->getFacebookReviewsData($pullFacebookReview['response'], $userData, $facebookData, $apiDetails, $data);
                                        $result['facebook'] = 'ok';
                                    }
                                }
                            } 
                        }
                        if ($errFlag == 1) {
                            $this->Flash->alert(__('Page not available for this account, please check and try again!'));
                        }
                    }
                } else {
                    $result['facebook'] = 'error';
                }
            }
            if (!empty($result)) {
                $result['success'] = 'ok';
            } else {
                $result['error'] = 'error';
            }
//            pr($result);die;
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
}
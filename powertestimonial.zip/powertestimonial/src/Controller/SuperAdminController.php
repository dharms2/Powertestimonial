<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * SuperAdmin Controller
 *
 *
 * @method \App\Model\Entity\SuperAdmin[] paginate($object = null, array $settings = [])
 */
class SuperAdminController extends AppController
{
    public $components = ['CommonFunction'];
    
    public function initialize() 
    {
        parent::initialize();
        $this->loadComponent('Cookie');        
    }
    
    /**
     * userManagement method
     * fetch all user list for super admin.
     * @param string|null The configuration for the Table.
     * @return array of user list
     */
    public function userManagement()
    {
        $title = __('{0} power_testimonial', ['User Management']);
        $this->loadModel('Users');
        $userDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($userDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        if ($userImg->group_id != 1) {
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
        
        //Get all user.
        $allUserDetails = $this->Users->getSuperUserData();
  
        $this->set(compact('allUserDetails', 'title', 'userImg'));
    }
   
    /**
     * updateStatus method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus() {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('Users');
                try {
                    $category = $this->Users->get($this->request->data['uid'], [
                        'contain' => []
                    ]);

                    if (!empty($category) && $category->is_active == 1) {
                        $category->is_active = 0;
                    } else {
                        $category->is_active = 1;
                    }
                    $data = array('is_active' => $category->is_active);

                    if ($data) {
                        $category = $this->Users->patchEntity($category, $data);

                        $result = $this->Users->save($category);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * upgradeRequest method used for fetch all user list for super admin and show plan upgrade request.
     * 
     * @param string|null The configuration for the Table.
     * @return array of user list
     */
    public function upgradeRequest()
    {
        $title = __('{0} power_testimonial', ['Plan Upgrade']);
        $this->loadModel('Users');
        $userId = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($userId);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        if ($userImg->group_id != 1) {
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
        $baseUrl = Configure::read('baseUrl');
        
        $this->loadModel('UserPlans');
        $getUserPlanDetails = $this->UserPlans->getSuperAdminUserPlans();

        $this->set(compact('getUserPlanDetails', 'title', 'userImg', 'baseUrl'));
    }
    
    /**
     * planUpgradeApproved method used for approved plan upgrade request.
     * 
     * @param string|null The configuration for the Table.
     * @throws \Cake\Network\Exception\CustomException When the record could not updated
     * @return json
     */
    public function planUpgradeApproved()
    {   
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $PlansTable = TableRegistry::get('Plans');
                    $planData = $PlansTable->getPlanDetails($this->request->data('upgradePlanId'));

                    $UserPlansTable = TableRegistry::get('UserPlans');
                    $UserPlan = $UserPlansTable->getUserPlanByUpgradePlanID($this->request->data('userId'), $this->request->data('currentPlanId'), $this->request->data('upgradePlanId'));

                    $UserPlan->end_dt = date("Y-m-d");
                    $UserPlan->approved_dt = date("Y-m-d");
                    $UserPlan->status = 1;
                    $result = $UserPlansTable->save($UserPlan);
                    if ($result) {
                        $newData = $UserPlansTable->newEntity();
                        $newData->user_id = $result->user_id;
                        $newData->plan_id = $this->request->data('upgradePlanId');
                        $newData->start_dt = date("Y-m-d");
                        $newData->amt = ($planData->amt + $planData->setup_fee).'.00';
                        $res = $UserPlansTable->save($newData);
                        if ($res) {
                            $UsersTable = TableRegistry::get('Users');
                            $userData = $UsersTable->getUserDataByPlanId($this->request->data('userId'), $this->request->data('currentPlanId'));
                            $userData->plan_id = $this->request->data('upgradePlanId');
                            $response = $UsersTable->save($userData);

                            if ($response) {
                                $email = $this->CommonFunction->sendEmail($planData, $emailCondition = 'plan_upgrade', $response); 
                            }
                        } else {
                            throw new CustomException('Record could not be updated.');
                        }
                    } else {
                        throw new CustomException('Record could not be updated.');
                    }
                } else {
                    throw new CustomException('Record could not be updated.');
                }
                if ($response && $email) {
                    $results['status'] = 'ok';
                } else {
                    $results['status'] = 'error';
                }
            } catch (\Exception $e) {
                    $this->throwException($e);
            }
            echo json_encode($results);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * userManagement method
     * 
     * fetch all user list for super admin.
     * @param string|null The configuration for the Table.
     * @return array of user list
     */
    public function userTransaction()
    {
        $title = __('{0} power_testimonial', ['User Transaction']);
        $this->loadModel('Users');
        $userDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($userDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        if ($userImg->group_id != 1) {
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
        $baseUrl = Configure::read('baseUrl');
        $this->loadModel('OrderTransactions');
        $userTransactionDetails = $this->OrderTransactions->getUserTransactionData();

        $this->set(compact('userTransactionDetails', 'title', 'userImg', 'baseUrl'));
    }
    
    /**
     * cancelRecuring method used for cacel recuring payment transaction.
     * 
     * @param string|null The configuration for the Table.
     * @throws \Cake\Network\Exception\CustomException When the record could not updated
     * @return json
     */
    public function cancelRecuring() 
    {
        if ($this->request->is('ajax')) {
            try {
                $result = [];
                if ($this->request->is('post')) {
                    $this->loadModel('OrderTransactions');
                    $tranData = $this->OrderTransactions->getRecurTransactionData($this->request->data('userId'), $this->request->data('recurId'));
                    
                    $cancelRecuring = $this->cancelRecuringById($this->request->data('recurId'));
                    $recurResponse = explode(",", $cancelRecuring);
                    $status = (string) str_replace('"', '', $recurResponse[0]);
                    $msg = (string) str_replace('"', '', $recurResponse[1]);

                    if ($status == 'Y') {
                        $tranData->recuring_status = 1;
                        $tranData->subscription_cancel_dt = date('Y-m-d');
                        
                        $this->OrderTransactions->save($tranData);
                        $result['status'] = $status;
                        $result['msg'] = $msg;
                    } else if ($status == 'N') {
                        $result['status'] = $status;
                        $result['msg'] = $msg;
                    }
                }
            } catch (\Exception $e) {
                    $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * Function to cancel Recurring transaction by recur id using curl
     *
     * @param str $recurId
     * @return json
     */
    public function cancelRecuringById($recurId)
    {
        $data = ['ePNAccount' => "080880", "RestrictKey" => "yFqqXJh9Pqnugfr", "TranType" => "Cancel", "RecurID" => $recurId];
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://www.eprocessingnetwork.com/cgi-bin/tdbe/Recur.pl",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $data,
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: multipart/form-data"
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
    
    /**
     * userManagement method
     * 
     * fetch all user list for super admin.
     * @param string|null The configuration for the Table.
     * @return array of user list
     */
    public function coupons()
    {
        $title = __('{0} power_testimonial', ['Coupons']);
        $this->loadModel('Users');
        $userDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($userDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        if ($userImg->group_id != 1) {
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
        
        $this->loadModel("Coupons");
        $couponDetails = $this->Coupons->getCouponData();

        $this->set(compact('title', 'userImg', 'couponDetails'));
    }
    
    /**
     * addCoupon method
     * 
     * @param string|null The configuration for the Table.
     * @return void
     */
    public function addCoupon() 
    {
        $title = __('{0} power_testimonial', ['Coupons']);
        $this->loadModel('Users');
        $userDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($userDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        if ($userImg->group_id != 1) {
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
        
        $this->loadModel("Coupons");
        $coupon = $this->Coupons->newEntity();
        if ($this->request->is('post')) {
            $postData = $this->request->getData();
            if ($result = $this->Coupons->addCoupon($postData)) {
                $this->Flash->success(__('coupon_success'));
                return $this->redirect(['controller' => 'SuperAdmin', 'action' => 'coupons']);
            }
            $this->Flash->error(__('coupon_error'));
        }
        
        $this->set(compact('title', 'userImg', 'coupon'));
    }
    
    /**
     * checkCodeIsUnique Method to check input code is unique
     *
     * @return json
     */
    public function checkCodeIsUnique() 
    {
        if ($this->request->is('ajax')) {
            $this->loadModel("Coupons");
            $result['count'] = $this->Coupons->checkUniqueCode($this->request->data);
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }
    
    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($codeId = null) 
    {
        $id = base64_decode($codeId);
        $this->request->allowMethod(['put', 'delete', 'get']);
        $this->loadModel("Coupons");
        $coupon = $this->Coupons->get($id);
        
        if ($this->Coupons->delete($coupon)) {
            $this->Flash->success(__('delete_coupon_success'));
        } else {
            $this->Flash->error(__('delete_coupon_error'));
        }
        
        return $this->redirect(['controller' => 'SuperAdmin', 'action' => 'coupons']);
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Core\App;
use Cake\Datasource\Exception\CustomException;

/**
 * AutoReminders Controller
 *
 * @property \App\Model\Table\AutoRemindersTable $AutoReminders
 *
 * @method \App\Model\Entity\AutoReminder[] paginate($object = null, array $settings = [])
 */
class AutoRemindersController extends AppController
{
    public $components = ['CommonFunction'];

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $title = __('{0} power_testimonial', ['Create Review Request']);
        $this->loadModel('Users');
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if ($userImg->group_id == 2) {
            $userId = $userImg->id;
        } else {
            $userId = $currentUserID;
        }
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        $baseUrl = Configure::read('baseUrl');
        $this->loadModel('ReviewsMgmt');
        $autoReminders = $this->ReviewsMgmt->getAllIncomleteReview($userId);
        
        $this->set(compact('autoReminders', 'title', 'userImg', 'autoReminder', 'baseUrl'));
        $this->set('_serialize', ['autoReminders']);
    }
    
    /**
     * saveAutoReminderDate method to be used for save auto reminder for sending survey/review
     *
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful update auto reminder, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function saveAutoReminderDate() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $this->loadModel('ReviewsMgmt');
                    $result = $this->ReviewsMgmt->updateAutoReminder($this->request->data());
                } else {
                    throw new CustomException('Record could not be saved.');
                }
                if ($result) {
                    $result['status'] = 'ok';
                } else {
                    $result['status'] = 'error';
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;    
        } else {
            die("You can not access this function directly from URL.");
        }
    }
}

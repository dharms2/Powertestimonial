<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\Core\Configure;
use Cake\Datasource\ConnectionManager;

/**
 * Reports Controller
 *
 * @property \App\Model\Table
 *
 * @method \App\Model\Entity paginate($object = null, array $settings = [])
 */
class ReportsController extends AppController
{
    public $components = ['CommonFunction'];
    
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Cookie');
        $this->loadModel('SurveyMgmt');
        $this->loadModel('SurveyAns');
        $this->loadModel('ReviewsMgmt');
        $this->loadModel('SurveyQuestion');
        $this->loadModel('SurveyTemplatesQuestion');
    }
    
    /**
     * index method
     *
     * @return \Cake\Http\Response|void
     */
    public function survey() 
    {
        $title = __('{0} power_testimonial', ['Survey Reports']);
        $breadcrumb = "Survey";
        $baseUrl = Configure::read('baseUrl');
        $this->loadModel('Users');

        if (!empty($this->request->query('userId'))) {
            $currentUserID = base64_decode($this->request->query('userId'));
        } else {
            $currentUserID = $this->CommonFunction->getCurrentUserId();
        }
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        if (!empty($allUsersData)) {
            $allAssociatesList = $this->Users->getAllAssociatesUserList($allUsersData);
            $allAssociates = $allAssociatesList;
        }
        $allAssociates[$this->CommonFunction->getCurrentUserId()] = Configure::read('myself');
        
        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->find('all')->toArray();

        $survey = [];
        foreach ($surveyTemplatesQuestions as $surveyTemplatesQuestion) {
            if ($surveyTemplatesQuestion->type == 2) {
                $survey['template_id'][] = $surveyTemplatesQuestion->survey_templates_id;
            }
        }

        if (!empty($survey['template_id'])) {
            $surveyList = $this->SurveyMgmt->find('list', [
                                'keyField' => 'id',
                                'valueField' => function ($row) {
                                    return $row['name'];
                                }
                            ])->where(['user_id' => $currentUserID, 'is_deleted' => 0, 'survey_template_id IN' => $survey['template_id']])->toArray();
        }

        if (!empty($this->request->query('surveyId'))) {
            $surveyId = base64_decode($this->request->query('surveyId'));
        } else {
            $surveyId = $this->firstIndex($surveyList);
        }

        $surveyQuestions = $this->SurveyAns->find('all', ['conditions' => ['user_id' => $currentUserID,'survey_mgmt_id' => $surveyId]])->toArray();
            
        if (!empty($surveyQuestions)) {
            $surveyQuestionIds = [];
            foreach ($surveyQuestions as $surveyQuestion) {
                $surveyQuestionId[] = $surveyQuestion->survey_qus_id;
            }
            $surveyQuestionIds = array_keys(array_flip($surveyQuestionId));
        }
            
        $questions = [];
        if (!empty($surveyQuestionIds)) {
            foreach ($surveyQuestionIds as $surveyQuestionId) {
                $questions[] = $this->SurveyQuestion->find('all', [
                    'conditions' => [
                        'user_id' => $currentUserID,
                        'id' => $surveyQuestionId
                    ]
                ])->first();
            }            
        }

        $i = 0;
        foreach ($questions as $question) {
            $qusAns = explode('|', $question->ans_choices);
            if (!empty($qusAns)) {
                $index = 0;
                foreach ($qusAns as $ansKey => $ansVal) {
                    $ansCount = $this->SurveyAns->find('all', [
                        'conditions' => [
                            'survey_qus_id' => $question->id,
                            'user_id' => $currentUserID,
                            'survey_done' => 1,
                            'answers' => $ansKey
                        ]
                    ])->count();
                    $qusAns[$index] = $ansCount;
                    $index++;
                }
            }
            $questions[$i]->ansCount = $qusAns;
            $i++;
        }
          
        $totalSurveyReview = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_all'), $surveyId);
        $totalSurveyReviewComplete = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_completed'), $surveyId);
        $totalSurveyReviewIncomplete = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_pending'), $surveyId);

        $this->set(compact(
                'title', 'userImg', 'baseUrl', 'currentUserID', 'allAssociates', 'surveyId',
                'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete',
                'surveyList', 'breadcrumb', 'questions'
        ));
    }
    
    /**
     * index method
     *
     * @return \Cake\Http\Response|void
     */
    public function review() 
    {
        $title = __('{0} power_testimonial', ['Review Reports']);
        $breadcrumb = "Review";
        $baseUrl = Configure::read('baseUrl');
        $this->loadModel('Users');

        if (!empty($this->request->query('userId'))) {
            $currentUserID = base64_decode($this->request->query('userId'));
        } else {
            $currentUserID = $this->CommonFunction->getCurrentUserId();
        }
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        if (!empty($allUsersData)) {
            $allAssociatesList = $this->Users->getAllAssociatesUserList($allUsersData);
            $allAssociates = $allAssociatesList;
        }
        $allAssociates[$this->CommonFunction->getCurrentUserId()] = Configure::read('myself');
        
        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->find('all')->toArray();
        $review = [];
        foreach ($surveyTemplatesQuestions as $surveyTemplatesQuestion) {
            if ($surveyTemplatesQuestion->type == 1) {
                $review['template_id'][] = $surveyTemplatesQuestion->survey_templates_id;
            }
        }
            
        if (!empty($review['template_id'])) {
            $reviewList = $this->SurveyMgmt->find('list', [
                            'keyField' => 'id',
                            'valueField' => function ($row) {
                                return $row['name'];
                            }
                        ])->where(['user_id' => $currentUserID,'is_deleted' => 0,'survey_template_id IN' => $review['template_id']])->toArray();
        }
            
        if (!empty($this->request->query('surveyId'))) {
            $surveyId = base64_decode($this->request->query('surveyId'));
        } else {
            $surveyId = $this->firstIndex($reviewList);
        }
        
        $surveyQuestions = $this->SurveyAns->find('all', ['conditions' => ['user_id' => $currentUserID,'survey_mgmt_id' => $surveyId]])->toArray();
        
        if (!empty($surveyQuestions)) {
            $surveyQuestionIds = [];
            foreach ($surveyQuestions as $surveyQuestion) {
                $surveyQuestionId[] = $surveyQuestion->survey_qus_id;
            }
            $surveyQuestionIds = array_keys(array_flip($surveyQuestionId));
        }
            
        $questions = [];
        if (!empty($surveyQuestionIds)) {
            foreach ($surveyQuestionIds as $surveyQuestionId) {
                $questions[] = $this->SurveyQuestion->find('all', [
                    'conditions' => [
                        'user_id' => $currentUserID,
                        'id' => $surveyQuestionId
                    ]
                ])->first();
            }            
        }

        $i = 0;
        foreach ($questions as $question) {
            $qusAns = explode('|', $question->ans_choices);
            if (!empty($qusAns)) {
                $index = 0;
                foreach ($qusAns as $ansKey => $ansVal) {
                    $ansCount = $this->SurveyAns->find('all', [
                        'conditions' => [
                            'survey_qus_id' => $question->id,
                            'user_id' => $currentUserID,
                            'survey_done' => 1,
                            'answers' => $ansKey
                        ]
                    ])->count();
                    $qusAns[$index] = $ansCount;
                    $index++;
                }
            }
            $questions[$i]->ansCount = $qusAns;
            $i++;
        }

        $overallReview = $this->ReviewsMgmt->find('all', [
            'conditions' => [
                'survey_id' => $surveyId,
                'user_id' => $currentUserID,
                'is_deleted' => 0,
                'survey_done IN' => Configure::read('partially_completed'),
            ]
        ])->count();

        $rating5star = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'ratings' => 5,'user_id' => $currentUserID]])->count();
        $rating4star = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'ratings' => 4,'user_id' => $currentUserID]])->count();
        $rating3star = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'ratings' => 3,'user_id' => $currentUserID]])->count();
        $rating2star = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'ratings' => 2,'user_id' => $currentUserID]])->count();
        $rating1star = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'ratings' => 1,'user_id' => $currentUserID]])->count();
        $avgRatingAllStar = ($rating5star*5) + ($rating4star*4) + ($rating3star*3) + ($rating2star*2) + ($rating1star*1);
        if ($overallReview) {
            $overallReviewRating = number_format($avgRatingAllStar / $overallReview, 1);
        } else {
            $overallReviewRating = 0;
        }

        $facebook = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'user_action' => 2,'user_id' => $currentUserID]])->count();
        $google = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'user_action' => 1,'user_id' => $currentUserID]])->count();
        $zillow = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'user_action' => 7,'user_id' => $currentUserID]])->count();
        $yelp = $this->ReviewsMgmt->find('all', ['conditions' => ['survey_id' => $surveyId,'is_deleted' => 0,'user_action' => 3,'user_id' => $currentUserID]])->count();
            
        $totalSurveyReview = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_all'), $surveyId);
        $totalSurveyReviewComplete = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_completed'), $surveyId);
        $totalSurveyReviewIncomplete = $this->getAllSurveyReview($currentUserID, Configure::read('survey_review_pending'), $surveyId);
        
        $this->set(compact(
                'title', 'userImg', 'baseUrl', 'currentUserID', 'allAssociates', 'surveyId',
                'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete', 'questions',
                'reviewList', 'breadcrumb', 'overallReviewRating', 'facebook', 'google', 'zillow', 'yelp'
        ));
    }
    
    function firstIndex($a) { 
        foreach ($a as $k => $v) 
            return $k; 
    }
    
    public function ansResponse() 
    {
        if ($this->request->is('ajax')) {
            try {
                $this->loadModel('SurveyAns');
                $ansResponses = $this->SurveyAns->find('all', [
                                'conditions' => [
                                    'survey_qus_id' => $this->request->data('qusId'),
                                    'survey_done' => 1,
                                    'answers' => $this->request->data('ans')
                                ],
                                'contain' => ['Users']
                            ])->toArray();
                if (!empty($ansResponses)) {
                    $result = [];
                    foreach ($ansResponses as $ansResponse) {
                        $result[] = [
                            'first_name' => $ansResponse->user->first_name,
                            'last_name' => $ansResponse->user->last_name,
                            'email' => $ansResponse->user->email,
                            'phone' => $ansResponse->user->phone
                        ];
                    }
                }
            } catch (RecordNotFoundException $ex) {
                $result = 'Somthing went wrong.';
            }
            echo json_encode($result);die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * getAllSurveyReview Function to get all Surveys/Reviews
     *
     * @param array $userIds userids of all associate and its representative
     * @param array $completed combine array for all "completed, pending and sent" request Survey/Review 
     *
     * @return array
     */ 
    public function getAllSurveyReview($userId, $completed, $surveyId) 
    {
        $this->loadModel('ReviewsMgmt');
        $getSurveyReviews = $this->ReviewsMgmt->find('all', [
                                'conditions' => [
                                    'user_id' => $userId,
                                    'survey_id' => $surveyId,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->toArray();
        
        return $getSurveyReviews;
    }
}
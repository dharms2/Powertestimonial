<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\Mailer\Email;
use Twilio\Rest\Client;
use Cake\ORM\TableRegistry;

class CommonFunctionComponent extends Component {

    public $components = ['Auth'];
    
    /**
     * Function to Get User Id
     *
     * @param null
     * @return void
     */
    public function getUser() 
    {
        $userDetail = $this->Auth->user();

        if ($userDetail['group_id'] == 2) {
            $userDetail['id'] = $userDetail['id'];
        } elseif ($userDetail['group_id'] == 4) {
            $userDetail['id'] = $userDetail['parent_id'];
        }
        return $userDetail;
    }

    /**
     * Function to Get Current Login User Id
     *
     * @param null
     * @return void
     */
    public function getCurrentUserId() 
    {
        $userDetail = $this->Auth->user();

        return $userDetail['id'];
    }
    
    /**
     * get All User Ids Function used to get all userids of parent user as well as child user
     *
     * @param int $company_id
     * @return void
     */
    public function getAllUserIds($company_id = null) 
    {
        $userIds = [];
        $usersTable = TableRegistry::get('Users');
        $allUsersData = $usersTable->find('all', [
            'fields' => ['id'],
            'conditions' => [
               'company_id' => $company_id
           ] 
        ])->toArray();
        
        foreach ($allUsersData as $user) {
            $userIds[] = $user->id;
        }

        return $userIds;
    }
        
    /**
     * getChildUers Function used to get all Associated user list with their child users
     *
     * @param array $userImg
     * @return Array
     */
    public function getChildUers($userImg) 
    {
        $userData = [];
        if ($userImg->group_id == 2) {
            $allUsers = $this->getChildUsersId($userImg->company_id, $userImg->parent_id);
        } else if ($userImg->group_id == 3 || $userImg->group_id == 7) {
            $allUsers = $this->getChildUsersId($userImg->company_id, $userImg->id);
        } else {
            $allUsers[] = $userImg->id;
        }
        
        return $allUsers;
    }
        
    /**
     * getChildUsersId Function used to get all userids of parent user as well as child user
     *
     * @param int $companyID
     * @param array $groupIds
     * @return Array
     */
    public function getChildUsersId($companyID = null, $parentId = null) 
    {
        $allUsers = [];
        $usersTable = TableRegistry::get('Users');
        if ($parentId == 0) {
            $childUsers = $usersTable->find('all', [
                'fields' => ['id', 'parent_id'],
                'conditions' => [
                    'company_id' => $companyID, 
                    'parent_id !=' => $parentId
                ]
            ])->toArray();
            foreach ($childUsers as $childUser) {
                $allUsers[] = $childUser->id;
            }
        } else {
            $childUsers = $usersTable->find('all', [
                'fields' => ['id', 'parent_id'],
                'conditions' => [
                    'company_id' => $companyID, 
                    'parent_id' => $parentId
                ]
            ])->toArray();
            if (!empty($childUsers)) {
                foreach ($childUsers as $childUser) {
                    $allUsers[] = $childUser->id;
                }

                $superchildUsers = $usersTable->find('all', [
                    'fields' => ['id', 'parent_id'],
                    'conditions' => ['company_id' => $companyID, 'parent_id IN' => $allUsers]
                ])->toArray();

                if (!empty($superchildUsers)) {
                    foreach ($superchildUsers as $superchildUser) {
                        $allUsers[] = $superchildUser->id;
                    }
                }
            } else {
                $allUsers = [];
            }
        }

        return $allUsers;
    }
    
    /**
     * Function to send email
     *
     * @param Array $postData
     * @param String $emailCondition
     * @param Array|null $userDetail
     * 
     * @return void
     * 
     */
    public function sendEmail($postData = null, $emailCondition = null, $userDetail = null, $surveyMgmt = null, $initialSubject = null) 
    {

        if (!empty($postData)) {
            if (isset($postData->user_action)) {
                switch ($postData->user_action) {
                    case '1':
                        $site = Configure::read('google');
                        break;
                    case '2':
                        $site = Configure::read('facebook');
                        break;
                    case '3':
                        $site = Configure::read('yelp');
                        break;
                    case '6':
                        $site = Configure::read('realtor');
                        break;
                    case '7':
                        $site = Configure::read('zillow');
                        break;
                    case '8':
                        $site = Configure::read('angies');
                        break;
                    case '9':
                        $site = Configure::read('bbb');
                        break;
                    default:
                        $site = '';
                        break;
                }
            }
            
            switch ($emailCondition) {
                case 'associate':
                    $template = 'associate';
                    $emailTo = $postData['email'];
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('emailSubject');
                    $vars = ['userfname' => $postData['first_name'],
                        'userlname' => $postData['last_name'],
                        'useremail' => $postData['email'],
                        'password' => $postData['password'],
                        'senderName' => $userDetail->first_name,
                        'senderBusinessName' => $userDetail->business_name,
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'registered':
                    $template = 'registered';
                    $emailTo = $postData['email'];
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('emailSubject');
                    $vars = ['userfname' => $postData['first_name'],
                        'userlname' => $postData['last_name'],
                        'useremail' => $postData['email'],
                        'password' => $postData['password'],
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'review':
                    $template = 'review';
                    $emailTo = $postData->recipient_email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = $userDetail['business_name'];
                    $subject = $initialSubject;
                    $vars = [
                        'baseUrl' => Configure::read('baseUrl'),
                        'body' => $surveyMgmt
                    ];
                    break;
                case 'init_review':
                    $template = 'init_review';
                    $emailTo = $postData->recipient_email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = $userDetail['business_name'];
                    $subject = Configure::read('reviewSubject') . ' - ' . $userDetail['business_name'];
                    $vars = [
                        'id' => $postData->id,
                        'name' => $postData->recipient_first_name,
                        'senderName' => $userDetail['first_name'] . ' ' . $userDetail['last_name'],
                        'senderPhone' => $userDetail['phone'],
                        'senderEmail' => $userDetail['email'],
                        'senderBusinessName' => $userDetail['business_name'],
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'completeSurvey':
                    $template = 'completeSurvey';
                    $emailTo = $userDetail->email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('completeSurvey');
                    $vars = [
                        'name' => $userDetail->first_name,
                        'recipientName' => $postData->recipient_first_name.' '.$postData->recipient_last_name,
                        'surveyName' => $surveyMgmt->name,
                        'sincerelyName' => Configure::read('siteTitle'),
                        'sincerelyEmail' => Configure::read('siteEmail'),
                        'sincerelyPhone' => Configure::read('sitePhone'),
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'completeStarRating':
                    $template = 'completeStarRating';
                    $emailTo = $userDetail->email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('completeSurveyReview');
                    $vars = [
                        'name' => $userDetail->first_name,
                        'recipientName' => $postData->recipient_first_name.' '.$postData->recipient_last_name,
                        'surveyName' => $surveyMgmt->name,
                        'star' => $postData->ratings,
                        'site' => $site,
                        'sincerelyName' => Configure::read('siteTitle'),
                        'sincerelyEmail' => Configure::read('siteEmail'),
                        'sincerelyPhone' => Configure::read('sitePhone'),
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'newOnlineReview':
                    $template = 'newOnlineReview';
                    $emailTo = $userDetail->email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('onlineReview');
                    $vars = [
                        'name' => $userDetail->first_name,
                        'reviews' => $postData['review'],
                        'reviewChannel' => $postData['from'],
                        'sincerelyName' => Configure::read('siteTitle'),
                        'sincerelyEmail' => Configure::read('siteEmail'),
                        'sincerelyPhone' => Configure::read('sitePhone'),
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'forgot':
                    $template = 'forgot';
                    $emailTo =  $postData['email'];
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('forgotSubject') . ' - ' . Configure::read('siteTitle');
                    $vars = ['id' => $postData['passkey'],
                        'name' =>$userDetail->first_name,
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'planUpgradeReq':
                    $template = 'plan_upgrade_reguest';
                    $emailTo = 'dharmsingh@yopmail.com';
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = $userDetail->business_name;
                    $subject = Configure::read('PlanUpgradeReq') . ' - ' . $userDetail->business_name;
                    $vars = [
                        'name' =>$userDetail->first_name.' '.$userDetail->last_name,
                        'business_name' => $userDetail->business_name,
                        'email' => $userDetail->email,
                        'business_phone' => $userDetail->business_phone,
                        'upgradePlan' => $postData->name,
                        'currentPlan' => $surveyMgmt->name,
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                case 'plan_upgrade':
                    $template = 'plan_upgrade';
                    $emailTo =  $userDetail->email;
                    $fromEmail = Configure::read('fromEMail');
                    $fromName = Configure::read('siteTitle');
                    $subject = Configure::read('PlanUpgradeMail');
                    $vars = [
                        'name' => $userDetail->first_name.' '.$userDetail->last_name,
                        'sincerelyName' => Configure::read('siteTitle'),
                        'sincerelyEmail' => Configure::read('siteEmail'),
                        'sincerelyPhone' => Configure::read('sitePhone'),
                        'upgradePlan' => $postData->name,
                        'baseUrl' => Configure::read('baseUrl'),
                    ];
                    break;
                default:
                    break;
            }

            $email = new Email('default');
            $email->from([$fromEmail => $fromName])
                    ->to($emailTo)
                    ->subject($subject)
                    ->replyTo(Configure::read('fromEMail'))
                    ->emailFormat('html')
                    ->viewVars($vars)
                    ->template($template);
            
            if ($email->send()) {
                return true;
            } else {
                return false;
            }
//            return $email;
        }
    }    
    
    /**
     * Function to get Image name after uploading
     *
     * @param array $imgUrl string,$imgCondtion for company image or profile Image
     *
     * @return void
     */
    public function getImageNameByProfile($imgname = null,$userId = null,$imgCondtion) 
    {
        if (!empty($imgname)) {
            $ext = substr(strtolower(strrchr($imgname['name'], '.')), 1); //get the extension
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png'); //set allowed extensions
                
            switch ($imgCondtion) {
                case 'profile':
                    $saveFileName = 'user_img_' . $userId . '.' . $ext;
                     //only process if the extension is valid
                    if (in_array($ext, $arr_ext)) {
                        $path = "img/users/" . $userId;
                        
                        if (!file_exists("img/users"))
                            mkdir("img/users");

                        if (!file_exists("img/users/" . $userId))
                            mkdir("img/users/" . $userId);
                        if (!file_exists($path))
                            mkdir($path);

                        $existFile = WWW_ROOT . 'img' . DS . 'users' . DS . $userId . DS . $saveFileName;
                        if (file_exists($existFile)) {
                            unlink($existFile);
                        }

                        //do the actual uploading of the file. First arg is the tmp name, second arg is 
                        //where we are putting it
                        if(move_uploaded_file($imgname['tmp_name'], WWW_ROOT . $path . '/' . $saveFileName)){
                            
                            $thumbnail = $path.'/'.$saveFileName;
                            //Call back for resize image
                            $finalImageResizeResult = $this->resizeProfileImage($thumbnail,$arr_ext);
                            if($finalImageResizeResult != null)
                            {
                                //prepare the filename for database entry 
                                 $imageFileName = $saveFileName;
                            }else{
                                //prepare the filename for database entry 
                                return $imageFileName = $finalImageResizeResult;
                            }
                        }
                    }
                    break;
                case 'company':
                    $setNewFileName = 'company_img_' . $userId . '.' . $ext; 
                    //only process if the extension is valid
                    if (in_array($ext, $arr_ext)) 
                    {
                        $path = "img/bussiness_logo/" . $userId;     
                        if (!file_exists("img/bussiness_logo"))
                            mkdir("img/bussiness_logo");

                        if (!file_exists("img/bussiness_logo/" . $userId))
                            mkdir("img/bussiness_logo/" . $userId);

                        if (!file_exists($path))
                            mkdir($path);

                        $existFile = WWW_ROOT . 'img' . DS . 'bussiness_logo' . DS . $userId . DS . $setNewFileName;
                        if (file_exists($existFile)) 
                        {
                            unlink($existFile);
                        }
                        //do the actual uploading of the file. First arg is the tmp name, second arg is 
                        //where we are putting it
                        if (move_uploaded_file($imgname['tmp_name'], WWW_ROOT . $path . '/' . $setNewFileName)){
                         
                            $thumbnail = $path.'/'.$setNewFileName;
                            //Call back for resize image
                            $finalImageResizeResult = $this->resizeCompanyImage($thumbnail,$arr_ext); 
                            if ($finalImageResizeResult != null)
                            {
                                //prepare the filename for database entry 
                                return $imageFileName = $setNewFileName;
                            } else {
                                //prepare the filename for database entry 
                                return $imageFileName = $finalImageResizeResult;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
            return $imageFileName;
        }
    }

    /**
     * Function to get Image name and Profile resizind
     *
     * @param array $imgUrl string,$imgCondtion for company image or profile Image
     *
     * @return void
     */
    public function resizeProfileImage($thumbnail = null, $arr_ext = array())
    {
       
        list($width, $height) = getimagesize($thumbnail);
       
        //Width 1200*800
        if ($width > 2000 && $width < 3500)
        {
            $percent = 0.25;
        } else if ($width > 1300 && $width < 2000)
        {
            $percent = 0.10;
        }else if ($width > 1000 && $width < 1250)
        {
            $percent = 0.14;
        }else if ($width > 700 && $width < 1000)
        {
            $percent = 0.20;
        }else if($width > 500 && $width < 700)
        {
            $percent = 0.25;
        }else if ($width > 200 && $width < 500)
        {
            $percent = 0.40;
        }else if ($width > 100 && $width < 200)
        {
            $percent = 0.70;
        }else if ($width < 100 )
        {
            $percent = 1.0;
        } else {      
            $percent = 0.10;    
        }
     
        if($percent != null)
        {
            $thumb_width = $width * $percent;
            $thumb_height = $height * $percent;
            $thumb_create = imagecreatetruecolor($thumb_width, $thumb_height);
            $info = getimagesize($thumbnail);

            if ($info['mime'] == 'image/jpeg')
                $source = imagecreatefromjpeg($thumbnail);

            elseif ($info['mime'] == 'image/gif')
                $source = imagecreatefromgif($thumbnail);

            elseif ($info['mime'] == 'image/png')
                $source = imagecreatefrompng($thumbnail);

            imagecopyresampled($thumb_create, $source, 0, 0, 0, 0, $thumb_width, $thumb_height, $width, $height);
            switch($arr_ext){
                case 'jpg' || 'jpeg':
                    imagejpeg($thumb_create,$thumbnail,100);
                    break;
                case 'png':
                    imagepng($thumb_create,$thumbnail,100);
                    break;
                case 'gif':
                    imagegif($thumb_create,$thumbnail,100);
                    break;
                default:
                    imagejpeg($thumb_create,$thumbnail,100);
            }
        }
      return $percent;
    }
    
    
     /**
     * Function to get Image name and Company resizind
     *
     * @param array $imgUrl string,$imgCondtion for company image or profile Image
     *
     * @return void
     */
    public function resizeCompanyImage($thumbnail = null, $arr_ext = array())
    {
        list($width,$height) = getimagesize($thumbnail);
       
        //Width 1200*800
        if($width > 1300 && $width < 2000)
        {
            $percent = 0.10;
        }else if ($width > 1000 && $width < 1250)
        {
            $percent = 0.14;
        }else if ($width > 700 && $width < 1000)
        {
            $percent = 0.16;
        }else if ($width > 500 && $width < 700)
        {
            $percent = 0.15;
        }else if ($width > 200 && $width < 500)
        {
            $percent = 0.22;
        }else if ($width > 100 && $width < 200)
        { 
            $percent = 0.45;
        }else if ($width < 100 )
        {
            $percent = 1.0;
        } else {      
            $percent = 0.09;    
        }
    
        if($percent != null)
        {
            $thumb_width = $width * $percent;
            $thumb_height = $height * $percent;
            $thumb_create = imagecreatetruecolor($thumb_width, $thumb_height);
            $info = getimagesize($thumbnail);

            if ($info['mime'] == 'image/jpeg')
                $source = imagecreatefromjpeg($thumbnail);

            elseif ($info['mime'] == 'image/gif')
                $source = imagecreatefromgif($thumbnail);

            elseif ($info['mime'] == 'image/png')
                $source = imagecreatefrompng($thumbnail);
             
            imagecopyresampled($thumb_create, $source, 0, 0, 0, 0, $thumb_width, $thumb_height, $width, $height);
            switch($arr_ext){
                case 'jpg' || 'jpeg':
                    imagejpeg($thumb_create,$thumbnail,100);
                    break;
                case 'png':
                    imagepng($thumb_create,$thumbnail,100);
                    break;
                case 'gif':
                    imagegif($thumb_create,$thumbnail,100);
                    break;
                default:
                    imagejpeg($thumb_create,$thumbnail,100);
            }
        }
      return $percent;
    }
    
    /**
     * check sendSms method
     * 
     * Twilio SMS API
     * @param string|null Array().
     * @return \Cake\Http\Response|null Redirects on successful Submit Survey Answer, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function sendSms($data, $result) {
     
        // Your Account SID and Auth Token from twilio.com/console
        $sid = Configure::read('TwilioAcoountSID');
        $token = Configure::read('TwilioAuthToken');
         
        $recipient_phone = $data['recipient_phone']; // the number you'd like to send the message to
        $twilio_phone_number = Configure::read('TwilioPhoneNumber'); // A Twilio phone number you purchased at twilio.com/console
    
       
        $body = Configure::read('baseUrl') . "reviews-mgmt/reviewStepOne/" . base64_encode($result->id);
        $client = new Client($sid, $token);

        // Use the client to do fun stuff like send text messages!
        $client->messages->create(
            // the number you'd like to send the message to
            $recipient_phone, array(
                // A Twilio phone number you purchased at twilio.com/console
                'from' => $twilio_phone_number,
                // the body of the text message you'd like to send
                'body' => $body
            )
        );
     
        return true;
    }
    
    public function checkPlanFeature($planId = null, $featureId = null)
    {
        $planFeaturesXrefTable = TableRegistry::get('PlanFeaturesXref');
        $planFeatures = $planFeaturesXrefTable->find('all', [
            'conditions' => [
                'plan_id' => $planId,
                'plan_features_id' => $featureId
            ]
        ])->count();
        
        return $planFeatures;
    }
    
    public function allMonths ()
    {
        $month = [];
        $m = date('n');
        for ($i=0; $i < 12; $i++) {
            $mont = date('F', mktime(0, 0, 0, $m-$i, 15, 2017));
            $month[] = substr($mont, 0, 3);
            //you could echo here, but may be handy to place in an array. 
            //Also the day (15) and year (2017) do not matter - 
            //I just picked 15 as it's a mid-number for months.
        }
        $months =  implode(",", $month);
        
        return $months;
    }
    
    public function allDays ()
    {
        $timestamp = strtotime('next Sunday');
        $date = strtotime(date('Y-m-d'));
        $days = array();
        for ($i = 0; $i < 7; $i++) {
            $days[] = substr(strftime('%A', $date), 0, 3);
            $date = strtotime('+1 day', $date);
        }
        $days =  implode(",", $days);
        
        return $days;
    }
    
    /**
     * monthSurvey Function to get month wise Survey
     *
     * @param array $userIds userids of all associate and its representative
     * @param string $startDate month start date
     * @param string $endDate month end date
     * @param array $completed combine array of survey completed, pending and sent request
     *
     * @return array
     */
    public function monthSurvey($userIds = null, $startDate = null, $endDate = null, $completed = null) 
    {
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $getSurveyReviews = $reviewsMgmtTable->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->bind(':start', new \DateTime($startDate.'00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($endDate.'23:59:59'), 'datetime')
                            ->toArray();

        $surveys = [];
        if ($getSurveyReviews) {
            $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
            foreach ($getSurveyReviews as $surveyReview) {

                $survey = $surveyMgmtTable->find('all', [
                            'conditions' => [
                                'id' => $surveyReview->survey_id,
                            ]
                        ])->first();
                $templateIds[] = $survey->survey_template_id;
            }

            foreach ($templateIds as $templateId) {
                $surveyTemplatesQuestionTable = TableRegistry::get('SurveyTemplatesQuestion');
                $surveyTemplates[] = $surveyTemplatesQuestionTable->find('all', [
                                        'conditions' => [
                                            'survey_templates_id' => $templateId,
                                        ]
                                    ])->first();
            }

            foreach ($surveyTemplates as $surveyTemplate) {
                if ($surveyTemplate->type == Configure::read('two')) {
                    $surveys[] = $surveyMgmtTable->find('all', [
                                    'conditions' => [
                                        'user_id IN' => $userIds,
                                        'survey_template_id' => $surveyTemplate->survey_templates_id,
                                    ]
                                ])->first();
                }
            }
        }
        
        return $surveys;
    }
    
    /**
     * oneYearReviews Function to get last one year internal Reviews
     *
     * @param array $userIds userids of all associate and its representative
     *
     * @return array
     */
    public function oneYearReviews($userIds = null) 
    {
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $month1Reviews = $this->monthReview([$userIds], $currentStartDate, $currentDate, Configure::read('partially_completed'));
        $month2Reviews = $this->monthReview([$userIds], $lastDate2, $lastDate1, Configure::read('partially_completed'));
        $month3Reviews = $this->monthReview([$userIds], $lastDate3, date("Y-m-t", strtotime($lastDate3)), Configure::read('partially_completed'));
        $month4Reviews = $this->monthReview([$userIds], $lastDate4, date("Y-m-t", strtotime($lastDate4)), Configure::read('partially_completed'));
        $month5Reviews = $this->monthReview([$userIds], $lastDate5, date("Y-m-t", strtotime($lastDate5)), Configure::read('partially_completed'));
        $month6Reviews = $this->monthReview([$userIds], $lastDate6, date("Y-m-t", strtotime($lastDate6)), Configure::read('partially_completed'));
        $month7Reviews = $this->monthReview([$userIds], $lastDate7, date("Y-m-t", strtotime($lastDate7)), Configure::read('partially_completed'));
        $month8Reviews = $this->monthReview([$userIds], $lastDate8, date("Y-m-t", strtotime($lastDate8)), Configure::read('partially_completed'));
        $month9Reviews = $this->monthReview([$userIds], $lastDate9, date("Y-m-t", strtotime($lastDate9)), Configure::read('partially_completed'));
        $month10Reviews = $this->monthReview([$userIds], $lastDate10, date("Y-m-t", strtotime($lastDate10)), Configure::read('partially_completed'));
        $month11Reviews = $this->monthReview([$userIds], $lastDate11, date("Y-m-t", strtotime($lastDate11)), Configure::read('partially_completed'));
        $month12Reviews = $this->monthReview([$userIds], $lastDate12, date("Y-m-t", strtotime($lastDate12)), Configure::read('partially_completed'));
        
        $allReviews = [count($month1Reviews), count($month2Reviews), count($month3Reviews), count($month4Reviews), count($month5Reviews), 
                       count($month6Reviews), count($month7Reviews), count($month8Reviews), count($month9Reviews), count($month10Reviews),
                       count($month11Reviews), count($month12Reviews)];
        
        return $allReviews;
    }
    
    /**
     * oneYearZillowReviews Function to get last one year Zillow Reviews
     *
     * @param array $userIds userids of all associate and its representative
     *
     * @return array
     */
    public function oneYearZillowReviews($userIds = null) 
    {
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $month1Zillow = $this->onlineReview([$userIds], $currentDate, $currentStartDate, Configure::read('ZillowIcon'));
        $month2Zillow = $this->onlineReview([$userIds], $lastDate1, $lastDate2, Configure::read('ZillowIcon'));
        $month3Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate3)), $lastDate3, Configure::read('ZillowIcon'));
        $month4Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate4)), $lastDate4, Configure::read('ZillowIcon'));
        $month5Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate5)), $lastDate5, Configure::read('ZillowIcon'));
        $month6Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate6)), $lastDate6, Configure::read('ZillowIcon'));
        $month7Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate7)), $lastDate7, Configure::read('ZillowIcon'));
        $month8Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate8)), $lastDate8, Configure::read('ZillowIcon'));
        $month9Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate9)), $lastDate9, Configure::read('ZillowIcon'));
        $month10Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate10)), $lastDate10, Configure::read('ZillowIcon'));
        $month11Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate11)), $lastDate11, Configure::read('ZillowIcon'));
        $month12Zillow = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate12)), $lastDate12, Configure::read('ZillowIcon'));

        
        $allZillowReviews = [$month1Zillow, $month2Zillow, $month3Zillow, $month4Zillow, $month5Zillow, $month6Zillow, 
                            $month7Zillow, $month8Zillow, $month9Zillow, $month10Zillow, $month11Zillow, $month12Zillow];
        
        return $allZillowReviews;
    }
    
    /**
     * oneYearGoogleReviews Function to get last one year Google Reviews
     *
     * @param array $userIds userids of all associate and its representative
     *
     * @return array
     */
    public function oneYearGoogleReviews($userIds = null) 
    {
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $month1Google = $this->onlineReview([$userIds], $currentDate, $currentStartDate, Configure::read('GoogleIcon'));
        $month2Google = $this->onlineReview([$userIds], $lastDate1, $lastDate2, Configure::read('GoogleIcon'));
        $month3Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate3)), $lastDate3, Configure::read('GoogleIcon'));
        $month4Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate4)), $lastDate4, Configure::read('GoogleIcon'));
        $month5Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate5)), $lastDate5, Configure::read('GoogleIcon'));
        $month6Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate6)), $lastDate6, Configure::read('GoogleIcon'));
        $month7Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate7)), $lastDate7, Configure::read('GoogleIcon'));
        $month8Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate8)), $lastDate8, Configure::read('GoogleIcon'));
        $month9Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate9)), $lastDate9, Configure::read('GoogleIcon'));
        $month10Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate10)), $lastDate10, Configure::read('GoogleIcon'));
        $month11Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate11)), $lastDate11, Configure::read('GoogleIcon'));
        $month12Google = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate12)), $lastDate12, Configure::read('GoogleIcon'));

        
        $allGoogleReviews = [$month1Google, $month2Google, $month3Google, $month4Google, $month5Google, $month6Google, 
                            $month7Google, $month8Google, $month9Google, $month10Google, $month11Google, $month12Google];
        
        return $allGoogleReviews;
    }
    
    /**
     * oneYearYelpReviews Function to get last one year Yelp Reviews
     *
     * @param array $userIds userids of all associate and its representative
     *
     * @return array
     */
    public function oneYearYelpReviews($userIds = null) 
    {
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $month1Yelp = $this->onlineReview([$userIds], $currentDate, $currentStartDate, Configure::read('YelpIcon'));
        $month2Yelp = $this->onlineReview([$userIds], $lastDate1, $lastDate2, Configure::read('YelpIcon'));
        $month3Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate3)), $lastDate3, Configure::read('YelpIcon'));
        $month4Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate4)), $lastDate4, Configure::read('YelpIcon'));
        $month5Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate5)), $lastDate5, Configure::read('YelpIcon'));
        $month6Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate6)), $lastDate6, Configure::read('YelpIcon'));
        $month7Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate7)), $lastDate7, Configure::read('YelpIcon'));
        $month8Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate8)), $lastDate8, Configure::read('YelpIcon'));
        $month9Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate9)), $lastDate9, Configure::read('YelpIcon'));
        $month10Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate10)), $lastDate10, Configure::read('YelpIcon'));
        $month11Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate11)), $lastDate11, Configure::read('YelpIcon'));
        $month12Yelp = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate12)), $lastDate12, Configure::read('YelpIcon'));

        
        $allYelpReviews = [$month1Yelp, $month2Yelp, $month3Yelp, $month4Yelp, $month5Yelp, $month6Yelp, 
                          $month7Yelp, $month8Yelp, $month9Yelp, $month10Yelp, $month11Yelp, $month12Yelp];
        
        return $allYelpReviews;
    }
    
    /**
     * oneYearFacebookReviews Function to get last one year Facebook Reviews
     *
     * @param array $userIds userids of all associate and its representative
     *
     * @return array
     */
    public function oneYearFacebookReviews($userIds = null) 
    {
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $month1Facebook = $this->onlineReview([$userIds], $currentDate, $currentStartDate, Configure::read('FacebookIcon'));
        $month2Facebook = $this->onlineReview([$userIds], $lastDate1, $lastDate2, Configure::read('FacebookIcon'));
        $month3Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate3)), $lastDate3, Configure::read('FacebookIcon'));
        $month4Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate4)), $lastDate4, Configure::read('FacebookIcon'));
        $month5Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate5)), $lastDate5, Configure::read('FacebookIcon'));
        $month6Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate6)), $lastDate6, Configure::read('FacebookIcon'));
        $month7Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate7)), $lastDate7, Configure::read('FacebookIcon'));
        $month8Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate8)), $lastDate8, Configure::read('FacebookIcon'));
        $month9Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate9)), $lastDate9, Configure::read('FacebookIcon'));
        $month10Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate10)), $lastDate10, Configure::read('FacebookIcon'));
        $month11Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate11)), $lastDate11, Configure::read('FacebookIcon'));
        $month12Facebook = $this->onlineReview([$userIds], date("Y-m-t", strtotime($lastDate12)), $lastDate12, Configure::read('FacebookIcon'));

        
        $allFacebookReviews = [$month1Facebook, $month2Facebook, $month3Facebook, $month4Facebook, $month5Facebook, $month6Facebook, 
                              $month7Facebook, $month8Facebook, $month9Facebook, $month10Facebook, $month11Facebook, $month12Facebook];
        
        return $allFacebookReviews;
    }
    
    /**
     * onlineReview, Function to get get All online review channel api Reviews
     *
     * @param int $userId, id of current user
     * @param string $start, month start date
     * @param string $end, month end date
     * @param string $img, current review channel image url
     * @return integer
     */
    public function onlineReview($userId = null, $end = null, $start = null, $img = null) 
    {
        $apiReviewsTable = TableRegistry::get('ApiReviews');
        $result = $apiReviewsTable->find('all', [
                    'conditions' => [
                        'user_id IN' => $userId,
                        'deleted' => 0,
                        'source_img' => $img,
                        'review_date BETWEEN :start AND :end'
                    ],
                    'order' => [
                        'review_date' => 'desc',
                    ]
                ])
                ->bind(':start', new \DateTime($start.'00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($end.'23:59:59'), 'datetime')
                ->count();
        
        return $result;
    }
    
    /**
     * monthReview Function to get month wise Review
     *
     * @param array $userIds userids of all associate and its representative
     * @param string $startDate month start date
     * @param string $endDate month end date
     * @param array $completed combine array of Review completed, pending and sent request
     *
     * @return array
     */    
    public function monthReview($userIds = null, $startDate = null, $endDate = null, $completed = null) 
    {
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $getSurveyReviews = $reviewsMgmtTable->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->bind(':start', new \DateTime($startDate.'00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($endDate.'23:59:59'), 'datetime')
                            ->toArray();

        $reviews = [];
        if ($getSurveyReviews) {
            $surveyMgmtTable = TableRegistry::get('SurveyMgmt');
            foreach ($getSurveyReviews as $surveyReview) {

                $survey = $surveyMgmtTable->find('all', [
                            'conditions' => [
                                'id' => $surveyReview->survey_id,
                            ]
                        ])->first();
                $templateIds[] = $survey->survey_template_id;
            }

            foreach ($templateIds as $templateId) {
                $surveyTemplatesQuestionTable = TableRegistry::get('SurveyTemplatesQuestion');
                $surveyTemplates[] = $surveyTemplatesQuestionTable->find('all', [
                                        'conditions' => [
                                            'survey_templates_id' => $templateId,
                                        ]
                                    ])->first();
            }

            foreach ($surveyTemplates as $surveyTemplate) {
                if (!empty($surveyTemplate)) {
                    if ($surveyTemplate->type == Configure::read('one')) {
                        $reviews[] = $surveyMgmtTable->find('all', [
                                        'conditions' => [
                                            'user_id IN' => $userIds,
                                            'survey_template_id' => $surveyTemplate->survey_templates_id,
                                        ]
                                    ])->first();
                    }
                }
            }
        }
        
        return $reviews;
    }
    
    /**
     * getAllSurveyReview Function to get all Surveys/Reviews
     *
     * @param array $userIds userids of all associate and its representative
     * @param array $completed combine array for all "completed, pending and sent" request Survey/Review 
     *
     * @return array
     */ 
    public function getAllSurveyReview($userIds, $completed) 
    {
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $getSurveyReviews = $reviewsMgmtTable->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->toArray();
        
        return $getSurveyReviews;
    }
    
    /**
     * getPast12MonthsSurveyReview Function to get past 12 months Surveys/Reviews
     *
     * @param array $userIds userids of all associate and its representative
     * @param array $completed combine array for all "completed, pending and sent" request Survey/Review 
     *
     * @return array
     */ 
    public function getPast12MonthsSurveyReview($userIds, $completed) 
    {
        $currentDate = date('Y-m-d');
        $lastDate = date('Y-m-d', strtotime($currentDate . " -1 year"));
        
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $getSurveyReviews = $reviewsMgmtTable->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->bind(':start', new \DateTime($lastDate.' 00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($currentDate.' 23:59:59'), 'datetime')
                            ->toArray();
        
        return $getSurveyReviews;
    }
    
    /**
     * past30DaysReviews, Function to get past 30 days internal Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past30DaysReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        $day8 = date('Y-m-d', strtotime($day7 . " -1 days"));
        $day9 = date('Y-m-d', strtotime($day8 . " -1 days"));
        $day10 = date('Y-m-d', strtotime($day9 . " -1 days"));
        $day11 = date('Y-m-d', strtotime($day10 . " -1 days"));
        $day12 = date('Y-m-d', strtotime($day11 . " -1 days"));
        $day13 = date('Y-m-d', strtotime($day12 . " -1 days"));
        $day14 = date('Y-m-d', strtotime($day13 . " -1 days"));
        $day15 = date('Y-m-d', strtotime($day14 . " -1 days"));
        $day16 = date('Y-m-d', strtotime($day15 . " -1 days"));
        $day17 = date('Y-m-d', strtotime($day16 . " -1 days"));
        $day18 = date('Y-m-d', strtotime($day17 . " -1 days"));
        $day19 = date('Y-m-d', strtotime($day18 . " -1 days"));
        $day20 = date('Y-m-d', strtotime($day19 . " -1 days"));
        $day21 = date('Y-m-d', strtotime($day20 . " -1 days"));
        $day22 = date('Y-m-d', strtotime($day21 . " -1 days"));
        $day23 = date('Y-m-d', strtotime($day22 . " -1 days"));
        $day24 = date('Y-m-d', strtotime($day23 . " -1 days"));
        $day25 = date('Y-m-d', strtotime($day24 . " -1 days"));
        $day26 = date('Y-m-d', strtotime($day25 . " -1 days"));
        $day27 = date('Y-m-d', strtotime($day26 . " -1 days"));
        $day28 = date('Y-m-d', strtotime($day27 . " -1 days"));
        $day29 = date('Y-m-d', strtotime($day28 . " -1 days"));
        $day30 = date('Y-m-d', strtotime($day29 . " -1 days"));
        
        $day1Reviews = $this->monthReview([$userIds], $day1, $day1, Configure::read('partially_completed'));
        $day2Reviews = $this->monthReview([$userIds], $day2, $day2, Configure::read('partially_completed'));
        $day3Reviews = $this->monthReview([$userIds], $day3, $day3, Configure::read('partially_completed'));
        $day4Reviews = $this->monthReview([$userIds], $day4, $day4, Configure::read('partially_completed'));
        $day5Reviews = $this->monthReview([$userIds], $day5, $day5, Configure::read('partially_completed'));
        $day6Reviews = $this->monthReview([$userIds], $day6, $day6, Configure::read('partially_completed'));
        $day7Reviews = $this->monthReview([$userIds], $day7, $day7, Configure::read('partially_completed'));
        $day8Reviews = $this->monthReview([$userIds], $day8, $day8, Configure::read('partially_completed'));
        $day9Reviews = $this->monthReview([$userIds], $day9, $day9, Configure::read('partially_completed'));
        $day10Reviews = $this->monthReview([$userIds], $day10, $day10, Configure::read('partially_completed'));
        $day11Reviews = $this->monthReview([$userIds], $day11, $day11, Configure::read('partially_completed'));
        $day12Reviews = $this->monthReview([$userIds], $day12, $day12, Configure::read('partially_completed'));
        $day13Reviews = $this->monthReview([$userIds], $day13, $day13, Configure::read('partially_completed'));
        $day14Reviews = $this->monthReview([$userIds], $day14, $day14, Configure::read('partially_completed'));
        $day15Reviews = $this->monthReview([$userIds], $day15, $day15, Configure::read('partially_completed'));
        $day16Reviews = $this->monthReview([$userIds], $day16, $day16, Configure::read('partially_completed'));
        $day17Reviews = $this->monthReview([$userIds], $day17, $day17, Configure::read('partially_completed'));
        $day18Reviews = $this->monthReview([$userIds], $day18, $day18, Configure::read('partially_completed'));
        $day19Reviews = $this->monthReview([$userIds], $day19, $day19, Configure::read('partially_completed'));
        $day20Reviews = $this->monthReview([$userIds], $day20, $day20, Configure::read('partially_completed'));
        $day21Reviews = $this->monthReview([$userIds], $day21, $day21, Configure::read('partially_completed'));
        $day22Reviews = $this->monthReview([$userIds], $day22, $day22, Configure::read('partially_completed'));
        $day23Reviews = $this->monthReview([$userIds], $day23, $day23, Configure::read('partially_completed'));
        $day24Reviews = $this->monthReview([$userIds], $day24, $day24, Configure::read('partially_completed'));
        $day25Reviews = $this->monthReview([$userIds], $day25, $day25, Configure::read('partially_completed'));
        $day26Reviews = $this->monthReview([$userIds], $day26, $day26, Configure::read('partially_completed'));
        $day27Reviews = $this->monthReview([$userIds], $day27, $day27, Configure::read('partially_completed'));
        $day28Reviews = $this->monthReview([$userIds], $day28, $day28, Configure::read('partially_completed'));
        $day29Reviews = $this->monthReview([$userIds], $day29, $day29, Configure::read('partially_completed'));
        $day30Reviews = $this->monthReview([$userIds], $day30, $day30, Configure::read('partially_completed'));

        $allReviews = [count($day1Reviews), count($day2Reviews), count($day3Reviews), count($day4Reviews), count($day5Reviews), count($day6Reviews), count($day7Reviews), count($day8Reviews),
                        count($day9Reviews), count($day10Reviews), count($day11Reviews), count($day12Reviews), count($day13Reviews), count($day14Reviews), count($day15Reviews), count($day16Reviews),
                        count($day17Reviews), count($day18Reviews), count($day19Reviews), count($day20Reviews), count($day21Reviews), count($day22Reviews), count($day23Reviews), count($day24Reviews),
                        count($day25Reviews), count($day26Reviews), count($day27Reviews), count($day28Reviews), count($day29Reviews), count($day30Reviews)];
        
        return $allReviews;
    }
    
    /**
     * past30DaysZillowReviews, Function to get past 30 days Zillow Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past30DaysZillowReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        $day8 = date('Y-m-d', strtotime($day7 . " -1 days"));
        $day9 = date('Y-m-d', strtotime($day8 . " -1 days"));
        $day10 = date('Y-m-d', strtotime($day9 . " -1 days"));
        $day11 = date('Y-m-d', strtotime($day10 . " -1 days"));
        $day12 = date('Y-m-d', strtotime($day11 . " -1 days"));
        $day13 = date('Y-m-d', strtotime($day12 . " -1 days"));
        $day14 = date('Y-m-d', strtotime($day13 . " -1 days"));
        $day15 = date('Y-m-d', strtotime($day14 . " -1 days"));
        $day16 = date('Y-m-d', strtotime($day15 . " -1 days"));
        $day17 = date('Y-m-d', strtotime($day16 . " -1 days"));
        $day18 = date('Y-m-d', strtotime($day17 . " -1 days"));
        $day19 = date('Y-m-d', strtotime($day18 . " -1 days"));
        $day20 = date('Y-m-d', strtotime($day19 . " -1 days"));
        $day21 = date('Y-m-d', strtotime($day20 . " -1 days"));
        $day22 = date('Y-m-d', strtotime($day21 . " -1 days"));
        $day23 = date('Y-m-d', strtotime($day22 . " -1 days"));
        $day24 = date('Y-m-d', strtotime($day23 . " -1 days"));
        $day25 = date('Y-m-d', strtotime($day24 . " -1 days"));
        $day26 = date('Y-m-d', strtotime($day25 . " -1 days"));
        $day27 = date('Y-m-d', strtotime($day26 . " -1 days"));
        $day28 = date('Y-m-d', strtotime($day27 . " -1 days"));
        $day29 = date('Y-m-d', strtotime($day28 . " -1 days"));
        $day30 = date('Y-m-d', strtotime($day29 . " -1 days"));
        
        $day1ZillowReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('ZillowIcon'));
        $day2ZillowReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('ZillowIcon'));
        $day3ZillowReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('ZillowIcon'));
        $day4ZillowReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('ZillowIcon'));
        $day5ZillowReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('ZillowIcon'));
        $day6ZillowReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('ZillowIcon'));
        $day7ZillowReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('ZillowIcon'));
        $day8ZillowReviews = $this->onlineReview([$userIds], $day8, $day8, Configure::read('ZillowIcon'));
        $day9ZillowReviews = $this->onlineReview([$userIds], $day9, $day9, Configure::read('ZillowIcon'));
        $day10ZillowReviews = $this->onlineReview([$userIds], $day10, $day10, Configure::read('ZillowIcon'));
        $day11ZillowReviews = $this->onlineReview([$userIds], $day11, $day11, Configure::read('ZillowIcon'));
        $day12ZillowReviews = $this->onlineReview([$userIds], $day12, $day12, Configure::read('ZillowIcon'));
        $day13ZillowReviews = $this->onlineReview([$userIds], $day13, $day13, Configure::read('ZillowIcon'));
        $day14ZillowReviews = $this->onlineReview([$userIds], $day14, $day14, Configure::read('ZillowIcon'));
        $day15ZillowReviews = $this->onlineReview([$userIds], $day15, $day15, Configure::read('ZillowIcon'));
        $day16ZillowReviews = $this->onlineReview([$userIds], $day16, $day16, Configure::read('ZillowIcon'));
        $day17ZillowReviews = $this->onlineReview([$userIds], $day17, $day17, Configure::read('ZillowIcon'));
        $day18ZillowReviews = $this->onlineReview([$userIds], $day18, $day18, Configure::read('ZillowIcon'));
        $day19ZillowReviews = $this->onlineReview([$userIds], $day19, $day19, Configure::read('ZillowIcon'));
        $day20ZillowReviews = $this->onlineReview([$userIds], $day20, $day20, Configure::read('ZillowIcon'));
        $day21ZillowReviews = $this->onlineReview([$userIds], $day21, $day21, Configure::read('ZillowIcon'));
        $day22ZillowReviews = $this->onlineReview([$userIds], $day22, $day22, Configure::read('ZillowIcon'));
        $day23ZillowReviews = $this->onlineReview([$userIds], $day23, $day23, Configure::read('ZillowIcon'));
        $day24ZillowReviews = $this->onlineReview([$userIds], $day24, $day24, Configure::read('ZillowIcon'));
        $day25ZillowReviews = $this->onlineReview([$userIds], $day25, $day25, Configure::read('ZillowIcon'));
        $day26ZillowReviews = $this->onlineReview([$userIds], $day26, $day26, Configure::read('ZillowIcon'));
        $day27ZillowReviews = $this->onlineReview([$userIds], $day27, $day27, Configure::read('ZillowIcon'));
        $day28ZillowReviews = $this->onlineReview([$userIds], $day28, $day28, Configure::read('ZillowIcon'));
        $day29ZillowReviews = $this->onlineReview([$userIds], $day29, $day29, Configure::read('ZillowIcon'));
        $day30ZillowReviews = $this->onlineReview([$userIds], $day30, $day30, Configure::read('ZillowIcon'));

        $allZillowReviews = [$day1ZillowReviews, $day2ZillowReviews, $day3ZillowReviews, $day4ZillowReviews, $day5ZillowReviews, $day6ZillowReviews, $day7ZillowReviews, $day8ZillowReviews,
                        $day9ZillowReviews, $day10ZillowReviews, $day11ZillowReviews, $day12ZillowReviews, $day13ZillowReviews, $day14ZillowReviews, $day15ZillowReviews, $day16ZillowReviews,
                        $day17ZillowReviews, $day18ZillowReviews, $day19ZillowReviews, $day20ZillowReviews, $day21ZillowReviews, $day22ZillowReviews, $day23ZillowReviews, $day24ZillowReviews,
                        $day25ZillowReviews, $day26ZillowReviews, $day27ZillowReviews, $day28ZillowReviews, $day29ZillowReviews, $day30ZillowReviews];
        
        return $allZillowReviews;
    }
    
    /**
     * past30DaysYelpReviews, Function to get past 30 days Yelp Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past30DaysYelpReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        $day8 = date('Y-m-d', strtotime($day7 . " -1 days"));
        $day9 = date('Y-m-d', strtotime($day8 . " -1 days"));
        $day10 = date('Y-m-d', strtotime($day9 . " -1 days"));
        $day11 = date('Y-m-d', strtotime($day10 . " -1 days"));
        $day12 = date('Y-m-d', strtotime($day11 . " -1 days"));
        $day13 = date('Y-m-d', strtotime($day12 . " -1 days"));
        $day14 = date('Y-m-d', strtotime($day13 . " -1 days"));
        $day15 = date('Y-m-d', strtotime($day14 . " -1 days"));
        $day16 = date('Y-m-d', strtotime($day15 . " -1 days"));
        $day17 = date('Y-m-d', strtotime($day16 . " -1 days"));
        $day18 = date('Y-m-d', strtotime($day17 . " -1 days"));
        $day19 = date('Y-m-d', strtotime($day18 . " -1 days"));
        $day20 = date('Y-m-d', strtotime($day19 . " -1 days"));
        $day21 = date('Y-m-d', strtotime($day20 . " -1 days"));
        $day22 = date('Y-m-d', strtotime($day21 . " -1 days"));
        $day23 = date('Y-m-d', strtotime($day22 . " -1 days"));
        $day24 = date('Y-m-d', strtotime($day23 . " -1 days"));
        $day25 = date('Y-m-d', strtotime($day24 . " -1 days"));
        $day26 = date('Y-m-d', strtotime($day25 . " -1 days"));
        $day27 = date('Y-m-d', strtotime($day26 . " -1 days"));
        $day28 = date('Y-m-d', strtotime($day27 . " -1 days"));
        $day29 = date('Y-m-d', strtotime($day28 . " -1 days"));
        $day30 = date('Y-m-d', strtotime($day29 . " -1 days"));
        
        $day1YelpReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('YelpIcon'));
        $day2YelpReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('YelpIcon'));
        $day3YelpReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('YelpIcon'));
        $day4YelpReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('YelpIcon'));
        $day5YelpReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('YelpIcon'));
        $day6YelpReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('YelpIcon'));
        $day7YelpReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('YelpIcon'));
        $day8YelpReviews = $this->onlineReview([$userIds], $day8, $day8, Configure::read('YelpIcon'));
        $day9YelpReviews = $this->onlineReview([$userIds], $day9, $day9, Configure::read('YelpIcon'));
        $day10YelpReviews = $this->onlineReview([$userIds], $day10, $day10, Configure::read('YelpIcon'));
        $day11YelpReviews = $this->onlineReview([$userIds], $day11, $day11, Configure::read('YelpIcon'));
        $day12YelpReviews = $this->onlineReview([$userIds], $day12, $day12, Configure::read('YelpIcon'));
        $day13YelpReviews = $this->onlineReview([$userIds], $day13, $day13, Configure::read('YelpIcon'));
        $day14YelpReviews = $this->onlineReview([$userIds], $day14, $day14, Configure::read('YelpIcon'));
        $day15YelpReviews = $this->onlineReview([$userIds], $day15, $day15, Configure::read('YelpIcon'));
        $day16YelpReviews = $this->onlineReview([$userIds], $day16, $day16, Configure::read('YelpIcon'));
        $day17YelpReviews = $this->onlineReview([$userIds], $day17, $day17, Configure::read('YelpIcon'));
        $day18YelpReviews = $this->onlineReview([$userIds], $day18, $day18, Configure::read('YelpIcon'));
        $day19YelpReviews = $this->onlineReview([$userIds], $day19, $day19, Configure::read('YelpIcon'));
        $day20YelpReviews = $this->onlineReview([$userIds], $day20, $day20, Configure::read('YelpIcon'));
        $day21YelpReviews = $this->onlineReview([$userIds], $day21, $day21, Configure::read('YelpIcon'));
        $day22YelpReviews = $this->onlineReview([$userIds], $day22, $day22, Configure::read('YelpIcon'));
        $day23YelpReviews = $this->onlineReview([$userIds], $day23, $day23, Configure::read('YelpIcon'));
        $day24YelpReviews = $this->onlineReview([$userIds], $day24, $day24, Configure::read('YelpIcon'));
        $day25YelpReviews = $this->onlineReview([$userIds], $day25, $day25, Configure::read('YelpIcon'));
        $day26YelpReviews = $this->onlineReview([$userIds], $day26, $day26, Configure::read('YelpIcon'));
        $day27YelpReviews = $this->onlineReview([$userIds], $day27, $day27, Configure::read('YelpIcon'));
        $day28YelpReviews = $this->onlineReview([$userIds], $day28, $day28, Configure::read('YelpIcon'));
        $day29YelpReviews = $this->onlineReview([$userIds], $day29, $day29, Configure::read('YelpIcon'));
        $day30YelpReviews = $this->onlineReview([$userIds], $day30, $day30, Configure::read('YelpIcon'));

        $allYelpReviews = [$day1YelpReviews, $day2YelpReviews, $day3YelpReviews, $day4YelpReviews, $day5YelpReviews, $day6YelpReviews, $day7YelpReviews, $day8YelpReviews,
                        $day9YelpReviews, $day10YelpReviews, $day11YelpReviews, $day12YelpReviews, $day13YelpReviews, $day14YelpReviews, $day15YelpReviews, $day16YelpReviews,
                        $day17YelpReviews, $day18YelpReviews, $day19YelpReviews, $day20YelpReviews, $day21YelpReviews, $day22YelpReviews, $day23YelpReviews, $day24YelpReviews,
                        $day25YelpReviews, $day26YelpReviews, $day27YelpReviews, $day28YelpReviews, $day29YelpReviews, $day30YelpReviews];
        
        return $allYelpReviews;
    }
    
    /**
     * past30DaysGoogleReviews, Function to get past 30 days Google Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past30DaysGoogleReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        $day8 = date('Y-m-d', strtotime($day7 . " -1 days"));
        $day9 = date('Y-m-d', strtotime($day8 . " -1 days"));
        $day10 = date('Y-m-d', strtotime($day9 . " -1 days"));
        $day11 = date('Y-m-d', strtotime($day10 . " -1 days"));
        $day12 = date('Y-m-d', strtotime($day11 . " -1 days"));
        $day13 = date('Y-m-d', strtotime($day12 . " -1 days"));
        $day14 = date('Y-m-d', strtotime($day13 . " -1 days"));
        $day15 = date('Y-m-d', strtotime($day14 . " -1 days"));
        $day16 = date('Y-m-d', strtotime($day15 . " -1 days"));
        $day17 = date('Y-m-d', strtotime($day16 . " -1 days"));
        $day18 = date('Y-m-d', strtotime($day17 . " -1 days"));
        $day19 = date('Y-m-d', strtotime($day18 . " -1 days"));
        $day20 = date('Y-m-d', strtotime($day19 . " -1 days"));
        $day21 = date('Y-m-d', strtotime($day20 . " -1 days"));
        $day22 = date('Y-m-d', strtotime($day21 . " -1 days"));
        $day23 = date('Y-m-d', strtotime($day22 . " -1 days"));
        $day24 = date('Y-m-d', strtotime($day23 . " -1 days"));
        $day25 = date('Y-m-d', strtotime($day24 . " -1 days"));
        $day26 = date('Y-m-d', strtotime($day25 . " -1 days"));
        $day27 = date('Y-m-d', strtotime($day26 . " -1 days"));
        $day28 = date('Y-m-d', strtotime($day27 . " -1 days"));
        $day29 = date('Y-m-d', strtotime($day28 . " -1 days"));
        $day30 = date('Y-m-d', strtotime($day29 . " -1 days"));
        
        $day1GoogleReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('GoogleIcon'));
        $day2GoogleReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('GoogleIcon'));
        $day3GoogleReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('GoogleIcon'));
        $day4GoogleReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('GoogleIcon'));
        $day5GoogleReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('GoogleIcon'));
        $day6GoogleReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('GoogleIcon'));
        $day7GoogleReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('GoogleIcon'));
        $day8GoogleReviews = $this->onlineReview([$userIds], $day8, $day8, Configure::read('GoogleIcon'));
        $day9GoogleReviews = $this->onlineReview([$userIds], $day9, $day9, Configure::read('GoogleIcon'));
        $day10GoogleReviews = $this->onlineReview([$userIds], $day10, $day10, Configure::read('GoogleIcon'));
        $day11GoogleReviews = $this->onlineReview([$userIds], $day11, $day11, Configure::read('GoogleIcon'));
        $day12GoogleReviews = $this->onlineReview([$userIds], $day12, $day12, Configure::read('GoogleIcon'));
        $day13GoogleReviews = $this->onlineReview([$userIds], $day13, $day13, Configure::read('GoogleIcon'));
        $day14GoogleReviews = $this->onlineReview([$userIds], $day14, $day14, Configure::read('GoogleIcon'));
        $day15GoogleReviews = $this->onlineReview([$userIds], $day15, $day15, Configure::read('GoogleIcon'));
        $day16GoogleReviews = $this->onlineReview([$userIds], $day16, $day16, Configure::read('GoogleIcon'));
        $day17GoogleReviews = $this->onlineReview([$userIds], $day17, $day17, Configure::read('GoogleIcon'));
        $day18GoogleReviews = $this->onlineReview([$userIds], $day18, $day18, Configure::read('GoogleIcon'));
        $day19GoogleReviews = $this->onlineReview([$userIds], $day19, $day19, Configure::read('GoogleIcon'));
        $day20GoogleReviews = $this->onlineReview([$userIds], $day20, $day20, Configure::read('GoogleIcon'));
        $day21GoogleReviews = $this->onlineReview([$userIds], $day21, $day21, Configure::read('GoogleIcon'));
        $day22GoogleReviews = $this->onlineReview([$userIds], $day22, $day22, Configure::read('GoogleIcon'));
        $day23GoogleReviews = $this->onlineReview([$userIds], $day23, $day23, Configure::read('GoogleIcon'));
        $day24GoogleReviews = $this->onlineReview([$userIds], $day24, $day24, Configure::read('GoogleIcon'));
        $day25GoogleReviews = $this->onlineReview([$userIds], $day25, $day25, Configure::read('GoogleIcon'));
        $day26GoogleReviews = $this->onlineReview([$userIds], $day26, $day26, Configure::read('GoogleIcon'));
        $day27GoogleReviews = $this->onlineReview([$userIds], $day27, $day27, Configure::read('GoogleIcon'));
        $day28GoogleReviews = $this->onlineReview([$userIds], $day28, $day28, Configure::read('GoogleIcon'));
        $day29GoogleReviews = $this->onlineReview([$userIds], $day29, $day29, Configure::read('GoogleIcon'));
        $day30GoogleReviews = $this->onlineReview([$userIds], $day30, $day30, Configure::read('GoogleIcon'));

        $allGoogleReviews = [$day1GoogleReviews, $day2GoogleReviews, $day3GoogleReviews, $day4GoogleReviews, $day5GoogleReviews, $day6GoogleReviews, $day7GoogleReviews, $day8GoogleReviews,
                        $day9GoogleReviews, $day10GoogleReviews, $day11GoogleReviews, $day12GoogleReviews, $day13GoogleReviews, $day14GoogleReviews, $day15GoogleReviews, $day16GoogleReviews,
                        $day17GoogleReviews, $day18GoogleReviews, $day19GoogleReviews, $day20GoogleReviews, $day21GoogleReviews, $day22GoogleReviews, $day23GoogleReviews, $day24GoogleReviews,
                        $day25GoogleReviews, $day26GoogleReviews, $day27GoogleReviews, $day28GoogleReviews, $day29GoogleReviews, $day30GoogleReviews];
        
        return $allGoogleReviews;
    }
    
    /**
     * past30DaysFacebookReviews, Function to get past 30 days Facebook Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past30DaysFacebookReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        $day8 = date('Y-m-d', strtotime($day7 . " -1 days"));
        $day9 = date('Y-m-d', strtotime($day8 . " -1 days"));
        $day10 = date('Y-m-d', strtotime($day9 . " -1 days"));
        $day11 = date('Y-m-d', strtotime($day10 . " -1 days"));
        $day12 = date('Y-m-d', strtotime($day11 . " -1 days"));
        $day13 = date('Y-m-d', strtotime($day12 . " -1 days"));
        $day14 = date('Y-m-d', strtotime($day13 . " -1 days"));
        $day15 = date('Y-m-d', strtotime($day14 . " -1 days"));
        $day16 = date('Y-m-d', strtotime($day15 . " -1 days"));
        $day17 = date('Y-m-d', strtotime($day16 . " -1 days"));
        $day18 = date('Y-m-d', strtotime($day17 . " -1 days"));
        $day19 = date('Y-m-d', strtotime($day18 . " -1 days"));
        $day20 = date('Y-m-d', strtotime($day19 . " -1 days"));
        $day21 = date('Y-m-d', strtotime($day20 . " -1 days"));
        $day22 = date('Y-m-d', strtotime($day21 . " -1 days"));
        $day23 = date('Y-m-d', strtotime($day22 . " -1 days"));
        $day24 = date('Y-m-d', strtotime($day23 . " -1 days"));
        $day25 = date('Y-m-d', strtotime($day24 . " -1 days"));
        $day26 = date('Y-m-d', strtotime($day25 . " -1 days"));
        $day27 = date('Y-m-d', strtotime($day26 . " -1 days"));
        $day28 = date('Y-m-d', strtotime($day27 . " -1 days"));
        $day29 = date('Y-m-d', strtotime($day28 . " -1 days"));
        $day30 = date('Y-m-d', strtotime($day29 . " -1 days"));
        
        $day1FacebookReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('FacebookIcon'));
        $day2FacebookReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('FacebookIcon'));
        $day3FacebookReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('FacebookIcon'));
        $day4FacebookReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('FacebookIcon'));
        $day5FacebookReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('FacebookIcon'));
        $day6FacebookReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('FacebookIcon'));
        $day7FacebookReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('FacebookIcon'));
        $day8FacebookReviews = $this->onlineReview([$userIds], $day8, $day8, Configure::read('FacebookIcon'));
        $day9FacebookReviews = $this->onlineReview([$userIds], $day9, $day9, Configure::read('FacebookIcon'));
        $day10FacebookReviews = $this->onlineReview([$userIds], $day10, $day10, Configure::read('FacebookIcon'));
        $day11FacebookReviews = $this->onlineReview([$userIds], $day11, $day11, Configure::read('FacebookIcon'));
        $day12FacebookReviews = $this->onlineReview([$userIds], $day12, $day12, Configure::read('FacebookIcon'));
        $day13FacebookReviews = $this->onlineReview([$userIds], $day13, $day13, Configure::read('FacebookIcon'));
        $day14FacebookReviews = $this->onlineReview([$userIds], $day14, $day14, Configure::read('FacebookIcon'));
        $day15FacebookReviews = $this->onlineReview([$userIds], $day15, $day15, Configure::read('FacebookIcon'));
        $day16FacebookReviews = $this->onlineReview([$userIds], $day16, $day16, Configure::read('FacebookIcon'));
        $day17FacebookReviews = $this->onlineReview([$userIds], $day17, $day17, Configure::read('FacebookIcon'));
        $day18FacebookReviews = $this->onlineReview([$userIds], $day18, $day18, Configure::read('FacebookIcon'));
        $day19FacebookReviews = $this->onlineReview([$userIds], $day19, $day19, Configure::read('FacebookIcon'));
        $day20FacebookReviews = $this->onlineReview([$userIds], $day20, $day20, Configure::read('FacebookIcon'));
        $day21FacebookReviews = $this->onlineReview([$userIds], $day21, $day21, Configure::read('FacebookIcon'));
        $day22FacebookReviews = $this->onlineReview([$userIds], $day22, $day22, Configure::read('FacebookIcon'));
        $day23FacebookReviews = $this->onlineReview([$userIds], $day23, $day23, Configure::read('FacebookIcon'));
        $day24FacebookReviews = $this->onlineReview([$userIds], $day24, $day24, Configure::read('FacebookIcon'));
        $day25FacebookReviews = $this->onlineReview([$userIds], $day25, $day25, Configure::read('FacebookIcon'));
        $day26FacebookReviews = $this->onlineReview([$userIds], $day26, $day26, Configure::read('FacebookIcon'));
        $day27FacebookReviews = $this->onlineReview([$userIds], $day27, $day27, Configure::read('FacebookIcon'));
        $day28FacebookReviews = $this->onlineReview([$userIds], $day28, $day28, Configure::read('FacebookIcon'));
        $day29FacebookReviews = $this->onlineReview([$userIds], $day29, $day29, Configure::read('FacebookIcon'));
        $day30FacebookReviews = $this->onlineReview([$userIds], $day30, $day30, Configure::read('FacebookIcon'));

        $allFacebookReviews = [$day1FacebookReviews, $day2FacebookReviews, $day3FacebookReviews, $day4FacebookReviews, $day5FacebookReviews, $day6FacebookReviews, $day7FacebookReviews, $day8FacebookReviews,
                        $day9FacebookReviews, $day10FacebookReviews, $day11FacebookReviews, $day12FacebookReviews, $day13FacebookReviews, $day14FacebookReviews, $day15FacebookReviews, $day16FacebookReviews,
                        $day17FacebookReviews, $day18FacebookReviews, $day19FacebookReviews, $day20FacebookReviews, $day21FacebookReviews, $day22FacebookReviews, $day23FacebookReviews, $day24FacebookReviews,
                        $day25FacebookReviews, $day26FacebookReviews, $day27FacebookReviews, $day28FacebookReviews, $day29FacebookReviews, $day30FacebookReviews];
        
        return $allFacebookReviews;
    }
    
    /**
     * past30DaysSurveyReview, Function to get past 30 days internal Survey/Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     * @param string $surveyReview 
     *
     * @return array
     */
    public function past30DaysSurveyReview($userIds, $surveyReview)
    {
        $day1 = date('Y-m-d');
        $day30 = date('Y-m-d', strtotime($day1 . " -30 days"));
        
        return $this->getPastDaysSurveyReview([$userIds], $day30, $day1, $surveyReview);
    }
    
    /**
     * past7DaysReviews, Function to get past 7 days internal Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past7DaysReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
        
        $day1Reviews = $this->monthReview([$userIds], $day1, $day1, Configure::read('partially_completed'));
        $day2Reviews = $this->monthReview([$userIds], $day2, $day2, Configure::read('partially_completed'));
        $day3Reviews = $this->monthReview([$userIds], $day3, $day3, Configure::read('partially_completed'));
        $day4Reviews = $this->monthReview([$userIds], $day4, $day4, Configure::read('partially_completed'));
        $day5Reviews = $this->monthReview([$userIds], $day5, $day5, Configure::read('partially_completed'));
        $day6Reviews = $this->monthReview([$userIds], $day6, $day6, Configure::read('partially_completed'));
        $day7Reviews = $this->monthReview([$userIds], $day7, $day7, Configure::read('partially_completed'));
        
        $allReviews = [count($day1Reviews), count($day2Reviews), count($day3Reviews), count($day4Reviews), count($day5Reviews), count($day6Reviews), count($day7Reviews)];
        
        return $allReviews;
    }
    
    /**
     * past7DaysZillowReviews, Function to get past 7 days Zillow Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past7DaysZillowReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
                
        $day1ZillowReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('ZillowIcon'));
        $day2ZillowReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('ZillowIcon'));
        $day3ZillowReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('ZillowIcon'));
        $day4ZillowReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('ZillowIcon'));
        $day5ZillowReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('ZillowIcon'));
        $day6ZillowReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('ZillowIcon'));
        $day7ZillowReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('ZillowIcon'));
        
        $allZillowReviews = [$day1ZillowReviews, $day2ZillowReviews, $day3ZillowReviews, $day4ZillowReviews, $day5ZillowReviews, $day6ZillowReviews, $day7ZillowReviews];
        
        return $allZillowReviews;
    }
    
    /**
     * past7DaysYelpReviews, Function to get past 7 days Yelp Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past7DaysYelpReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
                
        $day1YelpReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('YelpIcon'));
        $day2YelpReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('YelpIcon'));
        $day3YelpReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('YelpIcon'));
        $day4YelpReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('YelpIcon'));
        $day5YelpReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('YelpIcon'));
        $day6YelpReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('YelpIcon'));
        $day7YelpReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('YelpIcon'));
        
        $allYelpReviews = [$day1YelpReviews, $day2YelpReviews, $day3YelpReviews, $day4YelpReviews, $day5YelpReviews, $day6YelpReviews, $day7YelpReviews];
        
        return $allYelpReviews;
    }
    
    /**
     * past7DaysGoogleReviews, Function to get past 7 days Google Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past7DaysGoogleReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
                
        $day1GoogleReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('GoogleIcon'));
        $day2GoogleReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('GoogleIcon'));
        $day3GoogleReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('GoogleIcon'));
        $day4GoogleReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('GoogleIcon'));
        $day5GoogleReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('GoogleIcon'));
        $day6GoogleReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('GoogleIcon'));
        $day7GoogleReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('GoogleIcon'));
        
        $allGoogleReviews = [$day1GoogleReviews, $day2GoogleReviews, $day3GoogleReviews, $day4GoogleReviews, $day5GoogleReviews, $day6GoogleReviews, $day7GoogleReviews];
        
        return $allGoogleReviews;
    }
    
    /**
     * past7DaysFacebookReviews, Function to get past 7 days Facebook Reviews
     *
     * @param array $userIds user ids of all associate and its representative
     *
     * @return array
     */
    public function past7DaysFacebookReviews($userIds = null)
    {
        $day1 = date('Y-m-d');
        $day2 = date('Y-m-d', strtotime($day1 . " -1 days"));
        $day3 = date('Y-m-d', strtotime($day2 . " -1 days"));
        $day4 = date('Y-m-d', strtotime($day3 . " -1 days"));
        $day5 = date('Y-m-d', strtotime($day4 . " -1 days"));
        $day6 = date('Y-m-d', strtotime($day5 . " -1 days"));
        $day7 = date('Y-m-d', strtotime($day6 . " -1 days"));
                
        $day1FacebookReviews = $this->onlineReview([$userIds], $day1, $day1, Configure::read('FacebookIcon'));
        $day2FacebookReviews = $this->onlineReview([$userIds], $day2, $day2, Configure::read('FacebookIcon'));
        $day3FacebookReviews = $this->onlineReview([$userIds], $day3, $day3, Configure::read('FacebookIcon'));
        $day4FacebookReviews = $this->onlineReview([$userIds], $day4, $day4, Configure::read('FacebookIcon'));
        $day5FacebookReviews = $this->onlineReview([$userIds], $day5, $day5, Configure::read('FacebookIcon'));
        $day6FacebookReviews = $this->onlineReview([$userIds], $day6, $day6, Configure::read('FacebookIcon'));
        $day7FacebookReviews = $this->onlineReview([$userIds], $day7, $day7, Configure::read('FacebookIcon'));
        
        $allFacebookReviews = [$day1FacebookReviews, $day2FacebookReviews, $day3FacebookReviews, $day4FacebookReviews, $day5FacebookReviews, $day6FacebookReviews, $day7FacebookReviews];
        
        return $allFacebookReviews;
    }
    
    /**
     * past7DaysSurveyReview, Function to get past 7 days internal survey/reviews
     *
     * @param array $userIds user ids of all associate and its representative
     * @param string $surveyReview
     *
     * @return array
     */
    public function past7DaysSurveyReview($userIds, $surveyReview)
    {
        $day1 = date('Y-m-d');
        $day7 = date('Y-m-d', strtotime($day1 . " -7 days"));
        
        return $this->getPastDaysSurveyReview([$userIds], $day7, $day1, $surveyReview);
    }
    
    /**
     * getPastDaysSurveyReview Function to get past 30 days Surveys/Reviews
     *
     * @param array $userIds userids of all associate and its representative
     * @param array $completed combine array for all "completed, pending and sent" request Survey/Review 
     *
     * @return array
     */ 
    public function getPastDaysSurveyReview($userIds, $start, $end, $completed) 
    {
        $reviewsMgmtTable = TableRegistry::get('ReviewsMgmt');
        $getSurveyReviews = $reviewsMgmtTable->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ]
                            ])
                            ->bind(':start', new \DateTime($start.'00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($end.'23:59:59'), 'datetime')
                            ->count();
        
        return $getSurveyReviews;
    }
}

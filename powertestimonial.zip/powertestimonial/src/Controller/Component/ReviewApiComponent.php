<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

/**
 * ReviewApi Component
 *
 * @property \App\Controller\Component\ 
 *
 */
class ReviewApiComponent extends Component 
{
    public $components = ['Auth', 'Flash', 'CommonFunction'];
    
    /*
     * Function to save Zillow Basic
     *
     * @param array $xml array of Zillow basic details content
     * @param array $user array of current login user content
     *
     * @return void
     */
    public function zillow($xml = null, $user = null) 
    {
        $zillowData = '';
        $zillowTable = TableRegistry::get('Zillow');
        $result = [];
        $tmp = [];
        $tmp['screen_name'] = (array) $xml->response->result->screenname;
        $tmp['photo'] = (array) $xml->response->result->proInfo->photo;
        $tmp['profileURL'] = (array) $xml->response->result->proInfo->profileURL;
        $tmp['businessName'] = (array) $xml->response->result->proInfo->businessName;
        $tmp['address'] = (array) $xml->response->result->proInfo->address;
        $tmp['phone'] = (array) $xml->response->result->proInfo->phone;
        $tmp['reviewRequestURL'] = (array) $xml->response->result->proInfo->reviewRequestURL;
        $tmp['reviewCount'] = (array) $xml->response->result->proInfo->reviewCount;
        $tmp['avgRating'] = (array) $xml->response->result->proInfo->avgRating;
        $tmp['localknowledgeRating'] = (array) $xml->response->result->proInfo->localknowledgeRating;
        $tmp['processexpertiseRating'] = (array) $xml->response->result->proInfo->processexpertiseRating;
        $tmp['responsivenessRating'] = (array) $xml->response->result->proInfo->responsivenessRating;
        $tmp['negotiationskillsRating'] = (array) $xml->response->result->proInfo->negotiationskillsRating;
        $tmp['reviewRequestURL'] = (array) $xml->response->result->proInfo->reviewRequestURL;

        $conditions = ['user_id' => $user['id']];
        $zillowData = $zillowTable->getZillowDetails($user['id']);

        $zillowData['user_id'] = $user['id'];
        $zillowData['screen_name'] = $tmp['screen_name'] ? $tmp['screen_name'][0] : '';
        $zillowData['img_url'] = $tmp['photo'] ? $tmp['photo'][0] : '';
        $zillowData['profile_url'] = $tmp['profileURL'] ? $tmp['profileURL'][0] : '';
        $zillowData['business_name'] = $tmp['businessName'] ? $tmp['businessName'][0] : '';
        $zillowData['address'] = $tmp['address'] ? $tmp['address'][0] : '';
        $zillowData['phone'] = $tmp['phone'] ? $tmp['phone'][0] : '';
        $zillowData['review_request_url'] = $tmp['reviewRequestURL'] ? $tmp['reviewRequestURL'][0] : '';
        $zillowData['review_count'] = $tmp['reviewCount'] ? $tmp['reviewCount'][0] : '';
        $zillowData['avg_rating'] = $tmp['avgRating'] ? $tmp['avgRating'][0] : '';
        $zillowData['local_knowledge_rating'] = $tmp['localknowledgeRating'] ? $tmp['localknowledgeRating'][0] : '';
        $zillowData['process_expertise_rating'] = $tmp['processexpertiseRating'] ? $tmp['processexpertiseRating'][0] : '';
        $zillowData['responsiveness_rating'] = $tmp['responsivenessRating'] ? $tmp['responsivenessRating'][0] : '';
        $zillowData['negotiation_skills_rating'] = $tmp['negotiationskillsRating'] ? $tmp['negotiationskillsRating'][0] : '';
        $zillowData['review_write_id'] = $tmp['reviewRequestURL'] ? $tmp['reviewRequestURL'][0] : '';
        if (!empty($zillowData['review_write_id'])) {
            parse_str(parse_url($zillowData['review_write_id'], PHP_URL_QUERY ), $query);
            $zillowData['review_write_id'] = $query['s'];
        }
        
        if (!empty($zillowData)) {
            $result = $zillowTable->save($zillowData);
        }
        return $result;
    }

    /**
     * Function to save Zillow Details
     *
     * @param array $proReviews array of Zillow Review content
     * @param array $user array of current login user content
     *
     * @return void
     */
    public function zillowDetails($proReviews = null, $user = null, $zillowData = null, $apiDetails = null) 
    {
        $reviewDetails = '';
        $apiReviewsTable = TableRegistry::get('ApiReviews');
        $result = [];
        $revs = [];
        $revData = [];
        if (is_array($proReviews['review'])) {
            foreach ($proReviews['review'] as $reviews) {
                $rev = [];
                $rev['reviewer'] = (array) $reviews->reviewer;
                $rev['reviewerLink'] = (array) $reviews->reviewerLink;
                $rev['reviewURL'] = (array) $reviews->reviewURL;
                $rev['reviewDate'] = (array) $reviews->reviewDate;
                $rev['reviewSummary'] = (array) $reviews->reviewSummary;
                $rev['rating'] = (array) $reviews->rating;
                $rev['description'] = (array) $reviews->description;

                $review['user_id'] = $user['id'];
                $review['source_img'] = Configure::read('ZillowIcon');
                $review['reviewer_name'] = $rev['reviewer'] ? $rev['reviewer'][0] : '';
                $review['reviewer_profile_url'] = $rev['reviewerLink'] ? $rev['reviewerLink'][0] : '';
                $review['review_url'] = $rev['reviewURL'] ? $rev['reviewURL'][0] : '';
                $review['review_date'] = date("Y-m-d", strtotime($rev['reviewDate'] ? $rev['reviewDate'][0] : ''));
                $review['zillow_review_summary'] = $rev['reviewSummary'] ? $rev['reviewSummary'][0] : '';
                $review['rating'] = $rev['rating'] ? $rev['rating'][0] : '';
                $review['review_desc'] = $rev['description'] ? $rev['description'][0] : '';

                $parts = parse_url($review['review_url']);
                parse_str($parts['query'], $query);
                $review['review_id'] = $query['review'];
                $review['zillow_review_id'] = $query['review'];

                $revs[] = $review['review_id'];
                $revData[] = $review;
            }
        } else {
            $rev = [];
            $rev['reviewer'] = (array) $reviewsData['proReviews']['review']->reviewer;
            $rev['reviewerLink'] = (array) $reviewsData['proReviews']['review']->reviewerLink;
            $rev['reviewURL'] = (array) $reviewsData['proReviews']['review']->reviewURL;
            $rev['reviewDate'] = (array) $reviewsData['proReviews']['review']->reviewDate;
            $rev['reviewSummary'] = (array) $reviewsData['proReviews']['review']->reviewSummary;
            $rev['rating'] = (array) $reviewsData['proReviews']['review']->rating;
            $rev['description'] = (array) $reviewsData['proReviews']['review']->description;

            $review['user_id'] = $user['id'];
            $review['source_img'] = Configure::read('ZillowIcon');
            $review['reviewer_name'] = $rev['reviewer'] ? $rev['reviewer'][0] : '';
            $review['reviewer_profile_url'] = $rev['reviewerLink'] ? $rev['reviewerLink'][0] : '';
            $review['review_url'] = $rev['reviewURL'] ? $rev['reviewURL'][0] : '';
            $review['review_date'] = date("Y-m-d", strtotime($rev['reviewDate'] ? $rev['reviewDate'][0] : ''));
            $review['zillow_review_summary'] = $rev['reviewSummary'] ? $rev['reviewSummary'][0] : '';
            $review['rating'] = $rev['rating'] ? $rev['rating'][0] : '';
            $review['review_desc'] = $rev['description'] ? $rev['description'][0] : '';

            $parts = parse_url($review['review_url']);
            parse_str($parts['query'], $query);
            $review['review_id'] = $query['review'];
            $review['zillow_review_id'] = $query['review'];

            $revs[] = $review['review_id'];
            $revData[] = $review;
        }
        $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($user['id'])->toArray();
        $reviewIds = [];
        $zillowReviewIds = [];
        if (!empty($reviewDetails)) {
            foreach ($reviewDetails as $reviewDetail) {
                $reviewIds[] = $reviewDetail->review_id;
                $zillowReviewIds[] = $reviewDetail->zillow_review_id;
            }
        }
        $diffReviews = array_values(array_diff($revs, $reviewIds));
        $sameReviews = array_intersect($revs, $reviewIds);
        
        if ($zillowData->screen_name !== $apiDetails->zillow_screen_name) {
            foreach ($zillowReviewIds as $zillowReviewId) {
                if (!empty($zillowReviewId)) {
                    $result = $apiReviewsTable->deleteZillowApiReview($zillowReviewId, $user['id']);
                }
             }
        }
        
        if (!empty($revData) && !empty($diffReviews)) {
            foreach ($revData as $data) {
                foreach ($diffReviews as $diffReview) {
                    if($data['review_id'] == $diffReview) 
                    {
                        $data['deleted'] = 0;
                        $datas = $apiReviewsTable->newEntity($data);
                        $result = $apiReviewsTable->save($datas);
                    }
                }
            }
            if (!empty($result)) {
                $usersTable = TableRegistry::get('Users');
                $usersDetails = $usersTable->get($result->user_id);
                $res = [];
                $res['review'] = count($diffReviews);
                $res['from'] = Configure::read('zillow');
                $this->CommonFunction->sendEmail($res, $emailCondition = 'newOnlineReview', $usersDetails);
            }
        }

        if (!empty($revData) && !empty($sameReviews)) {
            foreach ($revData as $data) {
                foreach ($sameReviews as $sameReview) {
                    if($data['review_id'] == $sameReview) 
                    {
                        $result = $apiReviewsTable->updateApiReview($data['review_id'], $user['id']);
                    }
                }
            }
        }
        return $result;
    }
    
    /**
     * Function to get Google API Details
     *
     * @param array $apiDetails array of  api Details content
     *
     * @return void
     */
    public function getGoogleApiDetails($apiDetails = null) 
    {
        $googleUrl = Configure::read('GOOGLEURL');
        $postUrl = $googleUrl ."?placeid=". $apiDetails->google_place_id ."&key=". Configure::read('googleKey');

        $curl = curl_init();

        curl_setopt_array($curl, array(
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_URL => $postUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array("cache-control: no-cache"),
        ));

        $res = curl_exec($curl);
        $response = json_decode($res);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
                return "cURL Error #:" . json_decode($err);
        } else {
                return $response;
        }
    }
    
    /**
     * Function to insert Google Data
     *
     * @param array $google array of google Review content
     * @param array $user array of current login user content
     * @param array $apiDetails array of  api Details content
     *
     * @return void
     */
    public function insertGoogleData($google = null, $user = null, $apiDetails = null) 
    {
        $result = [];
        if (!empty($google)) {
            $googleTable = TableRegistry::get('Google');
            $googleData = $googleTable->getGoogleDataByUserId($user['id']);

            $googleData->user_id = $user['id'];
            $googleData->place_id = $apiDetails->google_place_id;
            $googleData->name = $google->result->name ? $google->result->name : '';
            $googleData->rating = isset($google->result->rating) ? $google->result->rating : '';
            $googleData->adr_address = $google->result->adr_address ? $google->result->adr_address : '';
            $googleData->formatted_address = isset($google->result->formatted_address) ? $google->result->formatted_address : '';
            $googleData->location_lat = isset($google->result->geometry->location->lat) ? $google->result->geometry->location->lat : '';
            $googleData->location_lng = isset($google->result->geometry->location->lng) ? $google->result->geometry->location->lng : '';
            $googleData->formatted_phone_number = isset($google->result->formatted_phone_number) ? $google->result->formatted_phone_number : '';
            $googleData->international_phone_number = isset($google->result->international_phone_number) ? $google->result->international_phone_number : '';
            $googleData->reference = $google->result->reference ? $google->result->reference : '';
            $googleData->map_url = isset($google->result->url) ? $google->result->url : '';
            $googleData->website = isset($google->result->website) ? $google->result->website : '';

            if (!empty($googleData)) {
                $result = $googleTable->save($googleData);
            }
        }
        return $result;
    }

    /**
     * Function to insert Google Review Data
     *
     * @param array $google array of google Review content
     * @param array $user array of current login user content
     * @param array $googlesData array of stored Google review content
     * @param array $apiDetails array of  api Details content
     *
     * @return void
     */
    public function insertGoogleReviewData($google = null, $user = null, $googlesData = null, $apiDetails = null) {
        $googleData = [];
        $apiReviewsTable = TableRegistry::get('ApiReviews');
        $result = [];
        if (!empty($google)) {
            if ($google->result->reviews) {
                foreach ($google->result->reviews as $reviews) {
                    $googleData['user_id'] = $user['id'];
                    $googleData['source_img'] = Configure::read('GoogleIcon');
                    $googleData['reviewer_name'] = $reviews->author_name ? $reviews->author_name : '';
                    $googleData['rating'] = $reviews->rating ? $reviews->rating : '';
                    $googleData['review_url'] = isset($reviews->author_url) ? $reviews->author_url : '';
                    $googleData['reviewer_profile_url'] = isset($reviews->profile_photo_url) ? $reviews->profile_photo_url : '';
                    $googleData['google_relative_time'] = $reviews->relative_time_description ? $reviews->relative_time_description : '';
                    $googleData['review_date'] = $reviews->time ? date("Y-m-d H:i:s", $reviews->time) : '';
                    $googleData['review_desc'] = $reviews->text ? $reviews->text : '';

                    $parts = parse_url(isset($reviews->author_url) ? $reviews->author_url : '', PHP_URL_PATH);
                    $path = explode('/', $parts);
                    if (!empty($path[3])) {
                        $googleData['review_id'] = $path[3];
                        $googleData['google_review_id'] = $path[3];
                    } else {
                        $googleData['review_id'] = $reviews->time;
                        $googleData['google_review_id'] = $reviews->time;
                    }
                    $allReviewIds[] = $googleData['review_id'];
                    $allData[] = $googleData;
                }
            }
            $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($user['id'])->toArray();
            $reviewIds = [];
            $googleReviewIds = [];
            if (!empty($reviewDetails)) {
                foreach ($reviewDetails as $reviewDetail) {
                    $reviewIds[] = $reviewDetail->review_id;
                    $googleReviewIds[] = $reviewDetail->google_review_id;
                }
            }
            
            $diffReviews = array_values(array_diff($allReviewIds, $reviewIds));
            $sameReviews = array_intersect($allReviewIds, $reviewIds);
            
            if ($googlesData->place_id !== $apiDetails->google_place_id) {
                foreach ($googleReviewIds as $googleReviewId) {
                    if (!empty($googleReviewId)) {
                        $result = $apiReviewsTable->deleteGoogleApiReview($googleReviewId, $user['id']);
                    }
                 }
            }

            if (!empty($allData) && !empty($diffReviews)) {
                foreach ($allData as $data) {
                    foreach ($diffReviews as $diffReview) {
                        if($data['review_id'] == $diffReview) 
                        {
                            $data['deleted'] = 0;
                            $insertData = $apiReviewsTable->newEntity($data);
                            $result = $apiReviewsTable->save($insertData);
                        }
                    }
                }
                if (!empty($result)) {
                    $usersTable = TableRegistry::get('Users');
                    $usersDetails = $usersTable->get($result->user_id);
                    $res = [];
                    $res['review'] = count($diffReviews);
                    $res['from'] = Configure::read('google');
                    $this->CommonFunction->sendEmail($res, $emailCondition = 'newOnlineReview', $usersDetails);
                }
            }

            if (!empty($allData) && !empty($sameReviews)) {
                foreach ($allData as $data) {
                    foreach ($sameReviews as $sameReview) {
                        if($data['review_id'] == $sameReview) 
                        {
                            $result = $apiReviewsTable->updateApiReview($data['review_id'], $user['id']);
                        }
                    }
                }
            }
        }
        return $result;
    }
           
    /**
     * Function to get Yelp Details
     *
     * @param array $token array of Yelp details token
     * @param string $business_id string of current business ID
     *
     * @return void
     */
    public function getYelpDetails($business_id = null) 
    {
        $url = Configure::read('yelpBusinessesUrl').''.$business_id;
        $access_token = Configure::read('yelpClientSecret');
        $token_type = 'Bearer';
        $fields = array(
                    "authorization: ".$token_type.' '.$access_token,
                    "cache-control: no-cache",
                );
        
       $curl = curl_init();
       curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $fields,
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
        if ($err) {
            return "cURL Error #:" . json_decode($err);
        } else {
            return json_decode($response);
        }
    }
    
    /**
     * Function to get Yelp Reviews
     *
     * @param array $token array of Yelp details token
     * @param string $business_id string of current business ID
     *
     * @return void
     */
    public function getYelpReviews($business_id = null) 
    {
        $url = Configure::read('yelpBusinessesUrl').''.$business_id.'/reviews';
        $access_token = Configure::read('yelpClientSecret');
        $token_type = 'Bearer';
        $fields = array(
                    "authorization: ".$token_type.' '.$access_token,
                    "cache-control: no-cache",
                );
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $fields,
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
          return "cURL Error #:" . json_decode($err);
        } else {
          return json_decode($response);
        }
    }
    
    /**
     * Function to insert Google Data
     *
     * @param array $yelpDetails array of Yelp Data content
     * @param array $user array of current login user content
     *
     * @return void
     */
    public function insertYelpData($yelpDetails = null, $user = null) 
    {
        $result = [];
        if (!empty($yelpDetails)) {
            $yelpTable = TableRegistry::get('Yelp');
            $yelpData = $yelpTable->getYelpDataByUserId($user['id']);
            
            $yelpData->name = $yelpDetails->name ? $yelpDetails->name : '';
            $yelpData->rating = $yelpDetails->rating ? $yelpDetails->rating : '';
            $yelpData->business_id = $yelpDetails->id ? $yelpDetails->id : '';
            $yelpData->review_count = $yelpDetails->review_count ? $yelpDetails->review_count : '';
            $yelpData->display_phone = $yelpDetails->display_phone ? $yelpDetails->display_phone : '';
            $yelpData->latitude = $yelpDetails->coordinates->latitude ? $yelpDetails->coordinates->latitude : '';
            $yelpData->longitude = $yelpDetails->coordinates->longitude ? $yelpDetails->coordinates->longitude : '';
            $yelpData->display_address = $yelpDetails->location->display_address[0].' '.$yelpDetails->location->display_address[1];
            $yelpData->url = $yelpDetails->url ? $yelpDetails->url : '';
            $yelpData->image_url = $yelpDetails->image_url ? $yelpDetails->image_url : '';
            
            include_once(WWW_ROOT.'yelp/simple_html_dom.php');
            $url = Configure::read('YELPDOMURL').$yelpDetails->id.'?start=0';
            $review_data = file_get_html($url); 
            if ($review_data) {
                $yelpData->request_url = $review_data->find('.js-war-text-link')[0]->attr['href'];
            }
             if (!empty($yelpData)) {
                $result = $yelpTable->save($yelpData);
            }
        }
        return $result;
    }
    
    /**
     * Function to insert Yelp Review Data
     *
     * @param array $yelp array of Yelp Review content
     * @param array $user array of current login user content
     * @param array $yelpData array of stored Yelp basic content
     * @param array $apiDetails array of  api Details content
     *
     * @return void
     */
    public function yelpReviewData($yelp = null, $user = null, $yelpDetail = null, $apiDetails = null) 
    {
        $apiReviewsTable = TableRegistry::get('ApiReviews');
        $result = [];
        
        if (!empty($yelp->reviews)) {
            foreach ($yelp->reviews as $reviews) {
                $yelpData = [];
                $yelpData['user_id'] = $user['id'];
                $yelpData['source_img'] = Configure::read('YelpIcon');
                $yelpData['reviewer_name'] = $reviews->user->name ? $reviews->user->name : '';
                $yelpData['rating'] = $reviews->rating ? $reviews->rating : '';
                $yelpData['review_url'] = isset($reviews->url) ? $reviews->url : '';
                $yelpData['reviewer_profile_url'] = isset($reviews->user->image_url) ? $reviews->user->image_url : '';
                $yelpData['review_date'] = $reviews->time_created ? $reviews->time_created : '';
                $yelpData['review_desc'] = $reviews->text ? $reviews->text : '';
                
                parse_str(parse_url($reviews->url, PHP_URL_QUERY ), $query);
                if (!empty($query['hrid'])) {
                    $yelpData['review_id'] = $query['hrid'];
                    $yelpData['yelp_review_id'] = $query['hrid'];
                }
                $allReviewIds[] = $yelpData['review_id'];
                $allData[] = $yelpData;
            }
            
            $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($user['id'])->toArray();
            $reviewIds = [];
            $yelpReviewIds = [];
            if (!empty($reviewDetails)) {
                foreach ($reviewDetails as $reviewDetail) {
                    $reviewIds[] = $reviewDetail->review_id;
                    $yelpReviewIds[] = $reviewDetail->yelp_review_id;
                }
            }
            
            $diffReviews = array_values(array_diff($allReviewIds, $reviewIds));
            $sameReviews = array_intersect($allReviewIds, $reviewIds);
         
            if ($yelpDetail->business_id !== $apiDetails->yelp_business_id) {
                foreach ($yelpReviewIds as $yelpReviewId) {
                    if (isset($yelpReviewId)) {
                        $result = $apiReviewsTable->deleteYelpApiReview($yelpReviewId, $user['id']);
                    }
                 }
            }
            
            if (!empty($allData) && !empty($diffReviews)) {
                foreach ($diffReviews as $diffReview) {
                    foreach ($allData as $data) {
                        if($data['review_id'] == $diffReview)
                        {
                            $data['deleted'] = 0;
                            $insertData = $apiReviewsTable->newEntity($data);
                            $result = $apiReviewsTable->save($insertData);
                        }
                    }
                }
                if (!empty($result)) {
                    $usersTable = TableRegistry::get('Users');
                    $usersDetails = $usersTable->get($result->user_id);
                    $res = [];
                    $res['review'] = count($diffReviews);
                    $res['from'] = Configure::read('yelp');
                    $this->CommonFunction->sendEmail($res, $emailCondition = 'newOnlineReview', $usersDetails);
                }
            }

            if (!empty($allData) && !empty($sameReviews)) {
                foreach ($allData as $data) {
                    foreach ($sameReviews as $sameReview) {
                        if($data['review_id'] == $sameReview) 
                        {
                            $result = $apiReviewsTable->updateApiReview($data['review_id'], $user['id']);
                        }
                    }
                }
            }
        }
        return $result;
    }
    
    /**
     * Function to get Facebook Details using CURL
     *
     * @param NULL
     *
     * @return void
     */    
    public function getFacebookDetails($userId = null, $accessToken = null) 
    {
        $res = array();
        $user_id = $userId;
        $access_token = $accessToken;
        $graph_url = Configure::read('FacebookDetailsURL');
        $post_url = $graph_url.''.$user_id.'/accounts?access_token='.$access_token.'&pretty=1&limit=1000';
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $post_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("cache-control: no-cache"),    
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . json_decode($err);
        } else {
            $res['message'] = 'OK';
            $res['response'] = json_decode($response);
            return $res;
        }
        
    }
    
    /**
     * Function to get Facebook Avg Rating using CURL
     *
     * @param string $pageId
     *
     * @return void
     */
    public function getFacebookAvgRating($pageId = null, $appId = null, $secretKey = null) 
    {
        $url = Configure::read('FacebookGraphURL')
                . $pageId
                . Configure::read('FacebookRatingField')
                . $appId
                . '|'
                . $secretKey;
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("cache-control: no-cache"),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . json_decode($err);
        } else {
            $res['message'] = 'OK';
            $res['response'] = json_decode($response);
            return $res;
        }
    }
    
    /**
     * Function to get Facebook Profile Image using CURL
     *
     * @param string $pageId
     *
     * @return void
     */
    public function getFacebookProfileImg($pageId = null) 
    {
        $postUrl = Configure::read('FacebookGraphURL')
                    . $pageId
                    . '/picture?redirect=0';
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $postUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("cache-control: no-cache"),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . json_decode($err);
        } else {
            $res['message'] = 'OK';
            $res['response'] = json_decode($response);
            return $res;
        }
    }
    
    /**
     * Function to insert Facebook Data
     *
     * @param array $facebookDetails array of Facebook Data content
     * @param array $ratingData array of Facebook Rating and Review Data content
     * @param array $user array of current login user content
     * @param array $profileImg array of Facebook Profile image Data content
     *
     * @return void
     */
    public function insertFacebookData($facebookDetails = null, $user = null, $profileImg = null) 
    {
        $result = [];
        if (!empty($facebookDetails)) {
            $facebookTable = TableRegistry::get('Facebook');
            $facebookData = $facebookTable->getFacebookDataByUserId($user['id']);

            $facebookData->page_id = $facebookDetails->id ? $facebookDetails->id : '';
            $facebookData->access_token = $facebookDetails->access_token ? $facebookDetails->access_token : '';
            $facebookData->page_name = $facebookDetails->name ? $facebookDetails->name : '';
            $facebookData->page_url = 'https://www.facebook.com/pg/'.urlencode($facebookDetails->name.'-'.$facebookDetails->id).'/reviews/';
            $facebookData->image_url = $profileImg->data ? $profileImg->data->url : '';

            if (!empty($facebookData)) {
                $result = $facebookTable->save($facebookData);
            }
        }
        return $result;
    }
    
    /**
     * Function to get Facebook Reviews using CURL
     *
     * @param string $pageId, User Page Id
     * @param string $access_token, User Access Token
     *
     * @return void
     */
    public function getFacebookReviews($page_id = null, $access_token = null) 
    {
        $res = array();
        $graph_url = 'https://graph.facebook.com/';
        $post_url = $graph_url.''.$page_id.'/ratings?access_token='.$access_token.'&pretty=1&limit=1000';
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_URL => $post_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("cache-control: no-cache"),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . json_decode($err);
        } else {
            $res['message'] = 'OK';
            $res['response'] = json_decode($response);
            return $res;
        }
    }
    
    /**
     * Function to get Facebook Reviews Data
     *
     * @param array $facebook array of Facebook Review content
     * @param array $user array of current login user content
     * @param array $facebookDetail array of stored Facebook basic content
     * @param array $apiDetails array of  api Details content
     *
     * @return void
     */
    public function getFacebookReviewsData($facebook = null, $user = null, $facebookDetail = null, $apiDetails = null, $fuser = null) 
    {
        $apiReviewsTable = TableRegistry::get('ApiReviews');
        $result = [];
        if (!empty($facebook->data)) {
            foreach ($facebook->data as $reviews) {
                $facebookData = [];
                $facebookData['user_id'] = $user['id'];
                $facebookData['source_img'] = Configure::read('FacebookIcon');
                $facebookData['reviewer_name'] = $reviews->reviewer->name ? $reviews->reviewer->name : '';
                $facebookData['rating'] = $reviews->rating ? $reviews->rating : '';
                $facebookData['review_date'] = $reviews->created_time ? $reviews->created_time : '';
                $facebookData['review_desc'] = isset($reviews->review_text) ? $reviews->review_text : '';
                $facebookData['review_url'] = 'https://www.facebook.com/pg/'.urlencode($fuser->name.'-'.$fuser->id).'/reviews/';

                if (!empty($reviews->created_time)) {
                    $facebookData['review_id'] = $reviews->reviewer->id.''.strtotime($reviews->created_time);
                    $facebookData['facebook_review_id'] = $reviews->reviewer->id.''.strtotime($reviews->created_time);
                }
                $allReviewIds[] = $facebookData['review_id'];
                $allData[] = $facebookData;
            }
            
            $reviewDetails = $apiReviewsTable->getAllApiReviewByUserId($user['id'])->toArray();
            $reviewIds = [];
            $facebookReviewIds = [];
            if (!empty($reviewDetails)) {
                foreach ($reviewDetails as $reviewDetail) {
                    $reviewIds[] = $reviewDetail->review_id;
                    $facebookReviewIds[] = $reviewDetail->facebook_review_id;
                }
            }
            
            if (!empty($allReviewIds)) {
                $diffReviews = array_values(array_diff($allReviewIds, $reviewIds));
                $sameReviews = array_intersect($allReviewIds, $reviewIds);
            }
            
            if ($facebookDetail->page_name !== $apiDetails->facebook_page_name) {
                foreach ($facebookReviewIds as $facebookReviewId) {
                    if (isset($facebookReviewId)) {
                        $result = $apiReviewsTable->deleteFacebookApiReview($facebookReviewId, $user['id']);
                    }
                }
            }
            
            if (!empty($allData) && !empty($diffReviews)) {
                foreach ($diffReviews as $diffReview) {
                    foreach ($allData as $data) {
                        if($data['review_id'] == $diffReview)
                        {
                            $data['deleted'] = 0;
                            $insertData = $apiReviewsTable->newEntity($data);
                            $result = $apiReviewsTable->save($insertData);
                        }
                    }
                }
                if (!empty($result)) {
                    $usersTable = TableRegistry::get('Users');
                    $usersDetails = $usersTable->get($result->user_id);
                    $res = [];
                    $res['review'] = count($diffReviews);
                    $res['from'] = Configure::read('facebook');
                    $this->CommonFunction->sendEmail($res, $emailCondition = 'newOnlineReview', $usersDetails);
                }
            }

            if (!empty($allData) && !empty($sameReviews)) {
                foreach ($allData as $data) {
                    foreach ($sameReviews as $sameReview) {
                        if($data['review_id'] == $sameReview) 
                        {
                            $result = $apiReviewsTable->updateApiReview($data['review_id'], $user['id']);
                        }
                    }
                }
            }
        }
        return $result;
    }
}

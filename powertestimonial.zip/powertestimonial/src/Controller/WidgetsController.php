<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\Core\Configure;

/**
 * Widgets Controller
 *
 *
 * @method \App\Model\Entity\CrossDomainApi[] paginate($object = null, array $settings = [])
 */
class WidgetsController extends AppController {

    public $components = ['CommonFunction'];

    public function initialize() 
    {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * View part of index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Create Widgets']);
        $this->loadModel('Users');
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        //if user is representative then fetch all associates user        
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        if (!empty($allUsersData)) {
            $associatesUser = $this->Users->getAllAssociatesUserList($allUsersData);
        } else {
            $associatesUser = $this->Users->getAllAssociatesUserList($currentUserID);
        }
        

        $baseUrl = Configure::read('baseUrl');
        $this->set(compact('title', 'associatesUser', 'userDetailId', 'baseUrl', 'userImg'));
    }

    /**
     * View part of Widget smal box method
     *
     * @return \Cake\Http\Response|void
     */
    public function reviewSmall($userID = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Collect  widgets for small Box']);
        $user_id = base64_decode($userID);

        $this->loadModel('Users');
        $associatesUser = $this->Users->getAllChildAssociates($user_id);

        $userName = $this->Users->getUserDetails($user_id);

        if (!empty($associatesUser)) {
            foreach ($associatesUser as $value) {
                $associatesUserReviews[] = $value->id;
            }
        } else {
            $associatesUserReviews[] = $user_id;
        }
        
        $this->paginate = ['limit' => 1000];
        $this->loadModel('ApiReviews');
        $apiReviewsDetails = $this->paginate($this->ApiReviews->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
        ]));

        //Find overall rating   
        $this->loadModel('ApiReviews');
        $overallRatings = $this->ApiReviews->find('all', [
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
                ])->toArray();

        $overallRating = [];
        $overallData = [];

        foreach ($overallRatings as $allRating) {
            $overallRating[] = $allRating->rating;
            $associatesUserDataReviewsDetails[] = array(
                'reviewFor' => $allRating->source_img,
                'reviewDesc' => $allRating->review_desc,
                'reviewRating' => $allRating->rating,
                'reviewUser' => $allRating->reviewer_name,
            );
        }
        $baseUrl = Configure::read('baseUrl');

        $this->set(compact('title', 'overallRating', 'associatesUserDataReviewsDetails', 'userName', 'apiReviewsDetails', 'baseUrl', 'user_id'));

        //Ajax request For Widget API
        if ($this->request->is('ajax')) {
            if ($this->request->data['userId']) {
                try {
                    //According to user id ,if user representative then fetch all user is then
                    //Behalf of user id fetch all reviews and if user is asscoiates then same.
                    $result = $baseUrl . 'widgets/review-small/' . base64_encode($this->request->data['userId']);

                    //Generate Download html file for 
                    $url = $baseUrl . 'widgets/email/' . base64_encode($this->request->data['userId']) . '&s';
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "GET",
                    ));
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if ($err) {
                        $result = ['error' => "cURL Error #:" . json_decode($err)];
                    } else {
                        $var = $response;
                    }
                    
                    $filePath = WWW_ROOT . 'img/email' . DS . 'review.html';
                    file_put_contents($filePath, $var);
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
            }
            echo json_encode($result);
            die;
        }
    }

    /**
     * View part of Widget large box method
     *
     * @return \Cake\Http\Response|void
     */
    public function reviewLarge($userID = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Create Large Widgets']);
        $user_id = base64_decode($userID);

        $this->loadModel('Users');
        $associatesUser = $this->Users->getAllChildAssociates($user_id);

        $userName = $this->Users->getUserDetails($user_id);

        if (!empty($associatesUser)) {
            foreach ($associatesUser as $value) {
                $associatesUserReviews[] = $value->id;
            }
        } else {
            $associatesUserReviews[] = $user_id;
        }

        $this->paginate = ['limit' => 1000];
        $this->loadModel('ApiReviews');
        $apiReviewsDetails = $this->paginate($this->ApiReviews->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
        ]));

        //Find overall rating   
        $this->loadModel('ApiReviews');
        $overallRatings = $this->ApiReviews->find('all', [
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
                ])->toArray();

        $overallRating = [];
        $overallData = [];

        foreach ($overallRatings as $allRating) {
            $overallRating[] = $allRating->rating;
            $associatesUserDataReviewsDetails[] = array(
                'reviewFor' => $allRating->source_img,
                'reviewDesc' => $allRating->review_desc,
                'reviewRating' => $allRating->rating,
                'reviewUser' => $allRating->reviewer_name,
            );
        }

        $baseUrl = Configure::read('baseUrl');
        $this->set(compact('title', 'overallRating', 'associatesUserDataReviewsDetails', 'apiReviewsDetails', 'baseUrl', 'userName', 'user_id'));
    }

    /**
     * Iframe code for widgt
     *
     * @return \Cake\Http\Response|void
     */
    public function largeReviewIframe() 
    {
        $baseUrl = Configure::read('baseUrl');
        //Ajax request For Widgets API
        if ($this->request->is('ajax')) {
            if ($this->request->data['userId']) {
                try {
                    $result = $baseUrl . 'widgets/review-large/' . base64_encode($this->request->data['userId']);
                    //According to user id ,if user representative then fetch all user is then
                    //Behalf of user id fetch all reviews and if user is asscoiates then same.
                    //Generate Download html file for 
                    $url = $baseUrl . 'widgets/email/' . base64_encode($this->request->data['userId']) . '&l';
//                    $var = file_get_contents($url);
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_URL => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "GET",
                    ));
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if ($err) {
                        $result = ['error' => "cURL Error #:" . json_decode($err)];
                    } else {
                        $var = $response;
                    }

                    $filePath = WWW_ROOT . 'img/email' . DS . 'review.html';
                    file_put_contents($filePath, $var);
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
            }
            echo json_encode($result);
            die;
        } 
    }
    
    /**
     * seeReview method for fuul review
     *
     * @return \Cake\Http\Response|void
     */
    public function seeReview($requestData = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['See full reviews']);

        $requestDataNew = explode('&', $requestData);
        $user_id = base64_decode($requestDataNew[0]);
        $requestFrom = $requestDataNew[1];


        $this->loadModel('Users');
        $associatesUser = $this->Users->getAllChildAssociates($user_id);

        $userName = $this->Users->getUserDetails($user_id);

        if (!empty($associatesUser)) {
            foreach ($associatesUser as $value) {
                $associatesUserReviews[] = $value->id;
            }
        } else {
            $associatesUserReviews[] = $user_id;
        }

        $this->paginate = ['limit' => 1000];
        $this->loadModel('ApiReviews');
        $apiReviewsDetails = $this->paginate($this->ApiReviews->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
        ]));

          //Find overall rating   
        $this->loadModel('ApiReviews');
        $overallRatings = $this->ApiReviews->find('all', [
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
                ])->toArray();

        $overallRating = [];
        $overallData = [];

        foreach ($overallRatings as $allRating) {
            $overallRating[] = $allRating->rating;
            $associatesUserDataReviewsDetails[] = array(
                'reviewFor' => $allRating->source_img,
                'reviewDesc' => $allRating->review_desc,
                'reviewRating' => $allRating->rating,
                'reviewUser' => $allRating->reviewer_name,
            );
        }
        $baseUrl = Configure::read('baseUrl');
        $this->set(compact('title', 'associatesUserDataReviewsDetails','apiReviewsDetails', 'baseUrl', 'userName', 'user_id','requestFrom'));
    }
    
    
    /**
     * View part of Widgets smal box method
     *
     * @return \Cake\Http\Response|void
     */
    public function reviewMe($requestData = null) 
    {
        $requestDataNew = explode('&', $requestData);
        $userID = $requestDataNew[0];
        $requestFrom = $requestDataNew[1];

        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Review Me For Widgets']);
        $user_id = base64_decode($userID);

        $this->loadModel('Users');
        //Fetch survey for company/associates
        //If user is asscoiates fetch their company's
        $user = $this->Users->getUserData($user_id);

        $this->loadModel('SurveyMgmt');
        $fetchDefaultSurvey = $this->SurveyMgmt->getSurveyId($user->company_id);

        if (!empty($fetchDefaultSurvey)) {
           // $survey_id =  $fetchDefaultSurvey;
            $survey_id =  $fetchDefaultSurvey->id;
        }
        $this->set(compact('title', 'user_id', 'survey_id', 'requestFrom'));
    }

    /**
     * Method for Review Send.
     * 
     * @param null
     * @return \Cake\Http\Response|void
     */
    public function reviewsSend() 
    {
        if ($this->request->is('post')) {
            $this->loadModel('ReviewsMgmt');
            $this->loadModel('Users');
            $data = $this->request->getData();
            $user = $this->Users->getUserDetails($this->request->getData('user_id'));

            if ($result = $this->ReviewsMgmt->addSurveyReview($data)) {

                if ($result) {
                    if (in_array('email', $data['send_type'])) {
                        $email = $this->CommonFunction->sendEmail($result, $emailCondition = 'review', $user);
                    }
                    if (in_array('sms', $data['send_type'])) {
                        $sms = $this->CommonFunction->sendSms($data, $result);
                    }

                    if ($this->request->getData('requestFrom') == 's') {
                        return $this->redirect(['controller' => 'Widgets', 'action' => 'successSmall', base64_encode($this->request->getData('user_id'))]);
                    } else if ($this->request->getData('requestFrom') == 'l') {
                        return $this->redirect(['controller' => 'Widgets', 'action' => 'successLarge', base64_encode($this->request->getData('user_id'))]);
                    }
                }
            }
        }
    }

    /**
     * View part of Email method
     *
     * @return \Cake\Http\Response|void
     */
    public function email($requestData = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Collect Email Code']);

        $requestDataNew = explode('&', $requestData);
        $userID = $requestDataNew[0];
        $requestFrom = $requestDataNew[1];
        $user_id = base64_decode($userID);

        $this->loadModel('Users');
        $associatesUser = $this->Users->getAllChildAssociates($user_id);

        $userName = $this->Users->getUserDetails($user_id);

        if (!empty($associatesUser)) {
            foreach ($associatesUser as $value) {
                $associatesUserReviews[] = $value->id;
            }
        } else {
            $associatesUserReviews[] = $user_id;
        }

        $this->paginate = ['limit' => 10];
        $this->loadModel('ApiReviews');
        $apiReviewsDetails = $this->paginate($this->ApiReviews->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
        ]));

        //Find overall rating   
        $this->loadModel('ApiReviews');
        $overallRatings = $this->ApiReviews->find('all', [
                    'conditions' => [
                        'user_id IN' => $associatesUserReviews,
                        'deleted' => 0
                    ]
                ])->toArray();

        $overallRating = [];
        $overallData = [];

        foreach ($overallRatings as $allRating) {
            $overallRating[] = $allRating->rating;
            $associatesUserDataReviewsDetails[] = array(
                'reviewFor' => $allRating->source_img,
                'reviewDesc' => $allRating->review_desc,
                'reviewRating' => $allRating->rating,
                'reviewUser' => $allRating->reviewer_name,
            );
        }

        $baseUrl = Configure::read('baseUrl');
        $this->set(compact('title', 'overallRating', 'associatesUserDataReviewsDetails', 'apiReviewsDetails', 'baseUrl', 'userName', 'user_id', 'requestFrom'));
    }

    /**
     * View part for widgets success show for small box
     *
     * @return \Cake\Http\Response|void
     */
    public function successSmall($userID = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Widgets Request Review Success']);
        $this->set(compact('title', 'userID'));
    }

    /**
     * View part for widgets success show for Lareg box
     *
     * @return \Cake\Http\Response|void
     */
    public function successLarge($userID = null) 
    {
        $this->viewBuilder()->layout(false);
        $title = __('{0} power_testimonial', ['Widgets Request Review Success']);
        $this->set(compact('title', 'userID'));
    }

    public function download() {
        $filePath = WWW_ROOT . 'img/email' . DS . 'review.html';
        $this->response->file($filePath, array(
            'download' => true,
            'name' => 'review.html',
        ));
        return $this->response;
    }

}

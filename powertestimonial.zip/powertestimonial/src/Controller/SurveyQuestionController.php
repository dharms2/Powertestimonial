<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;

/**
 * SurveyQuestion Controller
 *
 * @property \App\Model\Table\SurveyQuestionTable $SurveyQuestion
 *
 * @method \App\Model\Entity\SurveyQuestion[] paginate($object = null, array $settings = [])
 */
class SurveyQuestionController extends AppController
{

    public $components = ['CommonFunction'];
    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Question List']);
        $this->loadModel('Users');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $surveyQuestion = $this->SurveyQuestion->getAllQuestionsByUserIds($userIds);
        
        $this->set(compact('surveyQuestion', 'title', 'surveyCategory', 'userImg'));
        $this->set('_serialize', ['surveyQuestion']);
    }


    /**
     * Add Question method
     *
     * @return \Cake\View\View
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $title = __('{0} power_testimonial', ['Add New Question']);
        $this->loadModel('Users');
        $this->loadModel('SurveyCategory');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $surveyQuestion = $this->SurveyQuestion->newEntity();
        if ($this->request->is('post')) {
            $this->request->data['user_id'] = $currentUserID;
            if($this->request->data['ans_types'] == 3 ||$this->request->data['ans_types'] == 4 || $this->request->data['ans_types'] == 5) {
                $this->request->data['ans_choices'] = '';
            } else {
                if (!empty($this->request->data['ans_choices'])) {
                    $this->request->data['ans_choices'] = implode('|', $this->request->data['ans_choices']);
                }
            }

            if ($this->SurveyQuestion->addQuestion($this->request->getData())) {
                $this->Flash->success(__('question_add_success'));
                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(__('question_add_error'));
        }

        $surveyCategory = $this->SurveyCategory->getCategoryList($userIds);

        $this->set(compact('surveyQuestion', 'surveyCategory', 'title', 'userImg'));
        $this->set('_serialize', ['surveyQuestion']);
    }

    /**
     * Edit Question method
     *
     * @param string|null $id Survey Question id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $title = __('{0} power_testimonial', ['Edit New Question']);
        $this->loadModel('Users');
        $this->loadModel('SurveyCategory');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $surveyQuestion = $this->SurveyQuestion->get($id);

        if ($this->request->is(['patch', 'post', 'put'])) {
            
            if ($this->request->data['ans_types'] == 3 ||$this->request->data['ans_types'] == 4 || $this->request->data['ans_types'] == 5) {
                $this->request->data['ans_choices'] = '';
            } else {
                if (!empty($this->request->data['ans_choices'])) {
                    $this->request->data['ans_choices'] = implode('|', $this->request->data['ans_choices']);
                }
            }
            $this->request->data['question_id'] = $id;
            if ($this->SurveyQuestion->editQuestion($this->request->getData())) {
                $this->Flash->success(__('question_add_success'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('question_add_error'));
        }

        $surveyCategory = $this->SurveyCategory->getCategoryList($userIds);

        $this->set(compact('surveyQuestion', 'surveyCategory', 'title', 'userImg'));
        $this->set('_serialize', ['surveyQuestion']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Survey Question id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete', 'get']);
        //Load Model for check question ids exist or not in template question table
        $this->loadModel('SurveyTemplatesQuestion');
        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->find('all', [
                    'conditions' => [
                        'question' => $id,
                    ]
                ])->count();

        if ($surveyTemplatesQuestions > 0) {
            $this->Flash->error(__('question_per_error'));
        } else {
            $surveyQuestion = $this->SurveyQuestion->get($id);
            $surveyQuestion->is_deleted = 1;
            if ($this->SurveyQuestion->save($surveyQuestion)) {
                $this->Flash->success(__('question_success_del'));
            } else {
                $this->Flash->error(__('question_error_del'));
            }
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * getOwnerContractByCode method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('SurveyQuestion');
                try {
                    $category = $this->SurveyQuestion->get($this->request->data['uid'], [
                        'contain' => []
                    ]);

                    if (!empty($category) && $category->status == 0) {
                        $category->status = 1;
                    } else {
                        $category->status = 0;
                    }
                    $data = array('status' => $category->status);

                    if ($data) {
                        $category = $this->SurveyQuestion->patchEntity($category, $data);
                        $result = $this->SurveyQuestion->save($category);
                    }
                    
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

}

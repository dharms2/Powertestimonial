<?php

namespace App\Controller;

use App\Controller\AppController;

/**
 * SurveyCategory Controller
 *
 * @property \App\Model\Table\SurveyCategoryTable $SurveyCategory
 *
 * @method \App\Model\Entity\SurveyCategory[] paginate($object = null, array $settings = [])
 */
class SurveyCategoryController extends AppController {

    public $components = ['CommonFunction'];
    
    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Category List']);
        $this->loadModel('Users');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $this->paginate = [
            'limit' => 25,
            'order' => [
                'created' => 'desc'
            ],
            'conditions' => [
                'user_id IN' => $userIds,
                'is_deleted' => 0,
            ],
        ];

        $surveyCategory = $this->paginate($this->SurveyCategory);

        $this->set(compact('surveyCategory', 'title', 'userImg'));
        $this->set('_serialize', ['surveyCategory']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() 
    {
        $title = __('{0} power_testimonial', ['Add new Category']);
        $this->loadModel('Users');
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $surveyCategory = $this->SurveyCategory->newEntity();
        if ($this->request->is('post')) {
            $this->request->data['user_id'] = $userImg->id;
            $surveyCategory = $this->SurveyCategory->patchEntity($surveyCategory, $this->request->getData());
            if ($this->SurveyCategory->save($surveyCategory)) {
                $this->Flash->success(__('The survey category has been created.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The survey category could not be creates. Please, try again.'));
        }
        $this->set(compact('surveyCategory', 'title', 'userImg'));
        $this->set('_serialize', ['surveyCategory']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Survey Category id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) 
    {
        $title = __('{0} power_testimonial', ['Edit Category']);
        $this->loadModel('Users');
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $surveyCategory = $this->SurveyCategory->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $surveyCategory = $this->SurveyCategory->patchEntity($surveyCategory, $this->request->getData());
            if ($this->SurveyCategory->save($surveyCategory)) {
                $this->Flash->success(__('The survey category has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The survey category could not be saved. Please, try again.'));
        }
        $this->set(compact('surveyCategory', 'title', 'userImg'));
        $this->set('_serialize', ['surveyCategory']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Survey Category id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) 
    {
        $this->request->allowMethod(['post', 'delete', 'get']);

        //Load Model for check category ids exist or not in template question table
        $this->loadModel('SurveyQuestion');
        $questionCategory = $this->SurveyQuestion->find('all', [
                                'conditions' => [
                                    'category_id' => $id,
                                ]
                            ])->count();

        if ($questionCategory > 0) {
            $this->Flash->error(__('You do not have permission to delete this category'));
        } else {
            $surveyCategory = $this->SurveyCategory->get($id);
            $surveyCategory->is_deleted = 1;
            if ($this->SurveyCategory->save($surveyCategory)) {
                $this->Flash->success(__('The survey category has been deleted.'));
            } else {
                $this->Flash->error(__('The survey category could not be deleted. Please, try again.'));
            }
        }
        return $this->redirect(['action' => 'index']);
    }

    /**
     * updateStatus method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus() 
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('SurveyCategory');
                try {
                    $category = $this->SurveyCategory->get($this->request->data['uid'], [
                        'contain' => []
                    ]);

                    if (!empty($category) && $category->status == 0) {
                        $category->status = 1;
                    } else {
                        $category->status = 0;
                    }
                    $data = array('status' => $category->status);

                    if ($data) {
                        $category = $this->SurveyCategory->patchEntity($category, $data);
                        $result = $this->SurveyCategory->save($category);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * checkNameIsUnique Method to check input name is unique
     *
     * @return json
     */
    public function checkNameIsUnique()
    {
        if ($this->request->is('ajax')) {
            $result['count'] = $this->SurveyCategory->checkUniqueCategoryName($this->request->data);
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }

}

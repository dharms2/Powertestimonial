<?php
namespace App\View\Helper;

use Cake\View\Helper;
use Cake\View\View;

/**
 * ReviewsMgmt helper
 */
class ReviewsMgmtHelper extends Helper
{

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];

    public function selectedAPI($reviewApps, $userID, $reviewID)
    {
        $html = ''; 
        if (count($reviewApps) < 7) {
            $col = 'col-md-2';
        } else {
            $col = 'col';
        }
        foreach ($reviewApps as $reviewApp)
        {
            $note = '';
            switch ($reviewApp->question) 
            {
                case 1:
                    $class = 'facebook';
                    $loader = 'facebook-loader';
                    $event = 'facebookRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa fa-facebook"></i>';
                    break;
                case 2:
                    $class = 'yelp';
                    $loader = 'yelp-loader';
                    $event = 'yelpRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa"><img src="/img/yelp.png"></i>';
                    $note = '<median class="text-primary"><strong class="text-danger">Note:</strong> If you are not an active Yelper please don\'t choose this '
                            . 'option as your review will most likely get filtered.</median>';
                    break;
                case 3:
                    $class = 'zillow';
                    $loader = 'zillow-loader';
                    $event = 'zillowRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa"><img src="/img/zillow_icon.png" height="60"></i>';
                    break;
                case 4:
                    $class = 'google-plus';
                    $loader = 'google-loader';
                    $event = 'googleRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa fa-google"></i>';
                    break;
                case 5:
                    $class = 'angies';
                    $loader = 'angies-loader';
                    $event = 'angiesListRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa"><img src="/img/angies-list.png" height="80"></i>';
                    break;
                case 6:
                    $class = 'bbb-business';
                    $loader = 'bbb-loader';
                    $event = 'bbbRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa"><img src="/img/logo.svg" height="80"></i>';
                    break;
                case 7:
                    $class = 'realtor';
                    $loader = 'realtor-loader';
                    $event = 'realtorRequest('.$userID.', '.$reviewID.')';
                    $icon = '<i class="fa"><img src="/img/realtor.png" height="80"></i>';
                    break;
                default:
                    break;
            }

            $html .= '<div class="'.$col.'">';
            $html .= '<div class="social-box '.$class.' review-icon" style="border: none">';
            $html .= '<a href="#" class="social-icon" onclick="'.$event.'">';
            $html .= $icon;
            $html .= '</a>';
            $html .= $note;
            $html .= '</div>';
            $html .= '<div class="loader" id="'.$loader.'" style="display: none;margin: 0px 45px"></div>';
            $html .= '</div>';
        }
        return $html;
    }
    
    
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OrderTransaction Entity
 *
 * @property int $id
 * @property int $order_ref
 * @property int $user_id
 * @property int $amount
 * @property string $first_name
 * @property string $last_name
 * @property int $plan_id
 * @property string $auth_response
 * @property string $transaction_status
 * @property string $transaction_id
 * @property string $payment_type
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Plan $plan
 * @property \App\Model\Entity\Transaction $transaction
 */
class OrderTransaction extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'order_ref' => true,
        'user_id' => true,
        'amount' => true,
        'first_name' => true,
        'last_name' => true,
        'plan_id' => true,
        'transaction_status' => true,
        'transaction_id' => true,
        'payment_type' => true,
        'created' => true,
        'modified' => true,
        'modified' => true,
        'invoice_id' => true,
        'recur_id' => true,
        'auth_request' => true,
        'approval_code' => true,
        'auth_response' => true,
        'recuring_status' => true,
        'recur_amt' => true,
    ];
}

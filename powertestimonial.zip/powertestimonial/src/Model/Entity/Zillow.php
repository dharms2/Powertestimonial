<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Zillow Entity
 *
 * @property int $id
 * @property string $screen_name
 * @property string $img_url
 * @property string $profile_url
 * @property string $business_name
 * @property string $address
 * @property string $phone
 * @property string $review_request_url
 * @property int $review_count
 * @property float $avg_rating
 * @property float $local_knowledge_rating
 * @property float $process_expertise_rating
 * @property float $responsiveness_rating
 * @property float $negotiation_skills_rating
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Zillow extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'screen_name' => true,
        'img_url' => true,
        'profile_url' => true,
        'business_name' => true,
        'address' => true,
        'phone' => true,
        'review_request_url' => true,
        'review_count' => true,
        'avg_rating' => true,
        'local_knowledge_rating' => true,
        'process_expertise_rating' => true,
        'responsiveness_rating' => true,
        'negotiation_skills_rating' => true,
        'created' => true,
        'modified' => true
    ];
}

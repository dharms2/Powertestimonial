<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ZillowReview Entity
 *
 * @property int $id
 * @property int $review_id
 * @property string $zillow_img
 * @property string $zillow_reviewer
 * @property string $zillow_reviewerLink
 * @property string $zillow_reviewURL
 * @property \Cake\I18n\FrozenDate $zillow_reviewDate
 * @property string $zillow_reviewSummary
 * @property float $zillow_rating
 * @property string $zillow_description
 *
 * @property \App\Model\Entity\Review $review
 */
class ZillowReview extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'review_id' => true,
        'user_id' => true,
        'zillow_img' => true,
        'zillow_reviewer' => true,
        'zillow_reviewerLink' => true,
        'zillow_reviewURL' => true,
        'zillow_reviewDate' => true,
        'zillow_reviewSummary' => true,
        'zillow_rating' => true,
        'zillow_description' => true,
        'review' => true,
        'deleted' => true
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ApiConfiguration Entity
 *
 * @property int $id
 * @property string $google_details
 * @property string $google_end_url
 * @property bool $google_include_in_survey
 * @property string $facebook_details
 * @property string $facebook_end_url
 * @property bool $facebook_include_in_survey
 * @property string $yelp_details
 * @property bool $yelp_include_in_survey
 * @property string $zillow_details
 * @property bool $zillow_include_in_survey
 * @property string $realtor_details
 * @property bool $realtor_include_in_survey
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class ApiConfiguration extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'google_place_id' => true,
        'google_include_in_survey' => true,
        'facebook_page_name' => true,
        'facebook_app_id' => true,
        'facebook_app_secret' => true,
        'facebook_include_in_survey' => true,
        'yelp_business_id' => true,
        'yelp_include_in_survey' => true,
        'zillow_access_Id' => true,
        'zillow_screen_name' => true,
        'zillow_include_in_survey' => true,
        'realtor_business_name' => true,
        'realtor_include_in_survey' => true,
        'created' => true,
        'modified' => true,
        'angies_business_id' => true,
        'bbb_business_name' => true
    ];
}

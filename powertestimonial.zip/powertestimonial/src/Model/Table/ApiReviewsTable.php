<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;

/**
 * ApiReviews Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\ReviewsTable|\Cake\ORM\Association\BelongsTo $Reviews
 *
 * @method \App\Model\Entity\ApiReview get($primaryKey, $options = [])
 * @method \App\Model\Entity\ApiReview newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ApiReview[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ApiReview|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ApiReview patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ApiReview[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ApiReview findOrCreate($search, callable $callback = null, $options = [])
 */
class ApiReviewsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('api_reviews');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
    
    /**
     * Function to get get All Api Review By User Id
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllApiReviewByUserId($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]]);
        return $result;
    }
    
    /**
     * Function to get get All Yelp Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllZilloReview($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('ZillowIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->count();
        
        return $result;
    }
    
    /**
     * Function to get All Google Review Count
     *
     * @param int $userId, current user id
     * @return void
     */
    public function getAllGoogleReview($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('GoogleIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->count();
        
        return $result;
    }
    
    /**
     * Function to get Avg Google Rating
     *
     * @param int $userId, current user id
     * @return void
     */
    public function getAvgGoogleRating($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('GoogleIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        return $result;
    }
    
    /**
     * Function to get get All Yelp Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllYelpReview($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('YelpIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->count();
        
        return $result;
    }
    
    /**
     * Function to get get All Facebook Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllFacebookReview($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('FacebookIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->count();
        
        return $result;
    }
    
    /**
     * Function to get get All Facebook Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAvgFacebookRating($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id' => $userId,
                        'source_img' => Configure::read('FacebookIcon'),
                        'deleted' => Configure::read('zero'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
    
    /**
     * Function to update API Review
     *
     * @param int $reviewId, review_id of current review
     * @param int $userId, id of current user
     * @return void
     */
    public function updateApiReview($reviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 0])
                            ->where(['review_id' => $reviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
    
    /**
     * Function to (#soft) delete Zillow Api Review
     *
     * @param int $reviewId, review_id of current review
     * @param int $userId, id of current user
     * @return void
     */
    public function deleteZillowApiReview($reviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 1])
                            ->where(['zillow_review_id' => $reviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
    
    /**
     * Function to (#soft) delete Google Api Review
     *
     * @param int $googleReviewId, Google Review Id
     * @param int $userId, id of current user
     * @return void
     */
    public function deleteGoogleApiReview($googleReviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 1])
                            ->where(['google_review_id' => $googleReviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
    
    /**
     * Function to (#soft) delete Yelp Api Review
     *
     * @param int $yelpReviewId, Yelp Review Id
     * @param int $userId, id of current user
     * @return void
     */
    public function deleteYelpApiReview($yelpReviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 1])
                            ->where(['yelp_review_id' => $yelpReviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
    
    /**
     * Function to (#soft) delete Facebook Api Review
     *
     * @param int $facebookReviewId, Yelp Review Id
     * @param int $userId, id of current user
     * @return void
     */
    public function deleteFacebookApiReview($facebookReviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 1])
                            ->where(['facebook_review_id' => $facebookReviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
    
    /**
     * Function to get get All Valid Api Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllValidApiReview($userId = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id' => $userId,
                        'deleted' => 0,
                        'review_date BETWEEN :start AND :end'
                    ]   
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime');
        
        return $result;
    }
    
    /**
     * Function to get get All Valid Api Review
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getLifeTimeApiReview($endDate, $userIds = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userIds,
                        'deleted' => 0,
                        'review_date BETWEEN :start AND :end'
                    ],
                    'order' => [
                        'review_date' => 'desc',
                    ]
                ])
                ->bind(':start', new \DateTime('1970-01-01 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($endDate.'23:59:59'), 'datetime');
        
        return $result;
    }
    
    /**
     * getOnlineReviews, Function to get All 5 star online API reviews
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getOnlineReviews($userId = null, $star = null) 
    {
        $currentDate = date('Y-m-d');
        $lastDate = '1970-01-01';
        
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userId,
                        'deleted' => 0,
                        'rating' => $star,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($lastDate.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($currentDate.' 23:59:59'), 'datetime')
                ->count();

        return $result;
    }
    
    /**
     * getOnlineReviews, Function to get All 5 star online API reviews
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function get12MonthsOnlineReviews($userId = null, $star = null) 
    {
        $currentDate = date('Y-m-d');
        $lastDate = date('Y-m-d', strtotime($currentDate . " -1 year"));
        
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userId,
                        'deleted' => 0,
                        'rating' => $star,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($lastDate.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($currentDate.' 23:59:59'), 'datetime')
                ->count();

        return $result;
    }
    
    /**
     * getOnlineReviews, Function to get All 5 star online API reviews
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function get30DaysOnlineReviews($userId = null, $star = null) 
    {
        $currentDate = date('Y-m-d');
        $lastDate = date('Y-m-d', strtotime($currentDate . " -30 days"));
        
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userId,
                        'deleted' => 0,
                        'rating' => $star,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($lastDate.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($currentDate.' 23:59:59'), 'datetime')
                ->count();

        return $result;
    }
    
    /**
     * getOnlineReviews, Function to get All 5 star online API reviews
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function get7DaysOnlineReviews($userId = null, $star = null) 
    {
        $currentDate = date('Y-m-d');
        $lastDate = date('Y-m-d', strtotime($currentDate . " -7 days"));
        
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userId,
                        'deleted' => 0,
                        'rating' => $star,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($lastDate.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($currentDate.' 23:59:59'), 'datetime')
                ->count();

        return $result;
    }
    
    /**
     * getOverAllApiReview, Function to get over all valid API Reviews
     *
     * @param array $userIds
     * @return void
     */
    public function getOverAllApiReview($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'order' => [
                        'review_date' => 'desc',
                    ],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime');
        
        return $result;
    }
    
    /**
     * getOverAllApiRating, Function to get over all valid API Ratings
     *
     * @param array $userIds
     * @return void
     */
    public function getOverAllApiRating($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
    
    /**
     * getOverAllFbRatings, Function to get over all valid Facebook API Ratings
     *
     * @param array $ids
     * @return void
     */
    public function getOverAllFbRatings($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'source_img' => Configure::read('FacebookIcon'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
    
    /**
     * getOverAllZillowRatings, Function to get over all valid Zillow API Ratings
     *
     * @param array $ids
     * @return void
     */
    public function getOverAllZillowRatings($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'source_img' => Configure::read('ZillowIcon'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
    
    /**
     * getOverAllGoogleRatings, Function to get over all valid Google API Ratings
     *
     * @param array $ids
     * @return void
     */
    public function getOverAllGoogleRatings($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'source_img' => Configure::read('GoogleIcon'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
    
    /**
     * getOverAllYelpRatings, Function to get over all valid Yelp API Ratings
     *
     * @param array $ids
     * @return void
     */
    public function getOverAllYelpRatings($ids = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        $result = $this->find('all', [
                    'fields' => ['rating'],
                    'conditions' => [
                        'user_id IN' => $ids,
                        'deleted' => 0,
                        'source_img' => Configure::read('YelpIcon'),
                        'review_date BETWEEN :start AND :end'
                    ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')
                ->toArray();
        
        return $result;
    }
}

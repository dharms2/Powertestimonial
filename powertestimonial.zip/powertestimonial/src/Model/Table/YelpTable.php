<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Yelp Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\BusinessesTable|\Cake\ORM\Association\BelongsTo $Businesses
 *
 * @method \App\Model\Entity\Yelp get($primaryKey, $options = [])
 * @method \App\Model\Entity\Yelp newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Yelp[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Yelp|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Yelp patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Yelp[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Yelp findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class YelpTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('yelp');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        return $rules;
    }
    
    /**
     * Function to get Yelp Data By User Id
     *
     * @param int $userId, get User id content
     * @return void
     */
    public function getYelpDataByUserId($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]])->first();
        return $result;
    }
    
    /**
    * Add Yelp Method used to add default Empty data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addYelp($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $yelp = $this->newEntity();
        } else {
            $yelp = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $yelp = $this->patchEntity($yelp, $data);

        $yelp->user_id = $data['user_id'];
        // save data in the table
        $result = $this->save($yelp);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * Function to get Yelp Data By Business Name
     *
     * @param int $userId array of User id
     * @param string $businessId, content of Yelp business name
     * 
     * @return void
     */
    public function getYelpDataByBusinessName($userId = null, $businessId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'business_id' => $businessId
                    ]
                ])->first();
        return $result;
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;

/**
 * SurveyQuestion Model
 *
 * @property |\Cake\ORM\Association\BelongsTo $Categories
 *
 * @method \App\Model\Entity\SurveyQuestion get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyQuestion newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyQuestion[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyQuestion|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyQuestion patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyQuestion[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyQuestion findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyQuestionTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_question');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');

        $this->belongsTo('SurveyCategory', [
            'foreignKey' => 'category_id',
            'joinType' => 'INNER'
        ]);
        
        $this->hasMany('SurveyTemplatesQuestion', [
            'foreignKey' => 'question'
        ]);
        
//        $this->hasMany('SurveyAns', [
//            'foreignKey' => 'survey_qus_id'
//        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('questions')
            ->requirePresence('questions', 'create')
            ->notEmpty('questions');

        $validator
            ->integer('ans_types')
            ->requirePresence('ans_types', 'create')
            ->notEmpty('qus_types');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['category_id'], 'SurveyCategory'));

        return $rules;
    }
    
    /**
    * Add Survey Question Method used to add default Survey Question data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addSurveyQuestion($data = array(), $categoryId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyQuestion = $this->newEntity();
        } else {
            $surveyQuestion = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyQuestion = $this->patchEntity($surveyQuestion, $data);

        $surveyQuestion->user_id = $data['user_id'];
        $surveyQuestion->category_id = $categoryId;
        $surveyQuestion->questions = Configure::read('surveyQuestion');
        $surveyQuestion->ans_choices = Configure::read('questionAnsChoices');
        $surveyQuestion->correct_ans = Configure::read('questionCorrectAns');
        $surveyQuestion->ans_types = Configure::read('questionAnsTypes');
        
        // save data in the table
        $result = $this->save($surveyQuestion);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * Function to get Question Details
     *
     * @param int $questionId, Question id content
     * @return void
     */
    public function getQuestionDetails($questionId = null) 
    {
        $result = $this->find('all', [
            'conditions' => [
                'id' => $questionId
                ]
            ])->first();
        return $result;
    }
      
    /**
    * Add  Question Method for template 
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addQuestion($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }
        if (isset($data['user_id'])) {
            $surveyQuestion = $this->newEntity();
        } else {
            $surveyQuestion = $this->get(
                $data['user_id'], 
                [ 'contain' => [] ]
            );
        }
        $surveyQuestion = $this->patchEntity($surveyQuestion, $data);
        //Save data in the table
        $result = $this->save($surveyQuestion);
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    } 
     
    /**
    * Edit Question Method for template 
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function editQuestion($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }
        $surveyQuestion = $this->get($data['question_id'], [
            'contain' => []
        ]);
      
        $surveyQuestion = $this->patchEntity($surveyQuestion, $data);
        //Save data in the table
        $result = $this->save($surveyQuestion);
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }   
    
    /**
    * Method for get question details for template module
    *
    * @access public
    * @param Array $data
    * @return array data
    */
    public function findQuestionDetailsById($data = array())
    {
     
        if (!$data) {  // no data submitted
            return false;
        }
        foreach($data as $dataVal){
            if($dataVal->star== 5){
                $surveyQuestion[5][] = $dataVal->question;
            }
             if($dataVal->star== 4){
                if($dataVal->fouroption== 2)
                {
                    $surveyQuestion[4][] = $dataVal->question;
                }else
                {
                    $surveyQuestion[4][] = $this->get($dataVal->question, [
                    'contain' => []
                    ]);
                }
            } 
            if($dataVal->star== 3){
                $surveyQuestion[3][] = $this->get($dataVal->question, [
                    'contain' => []
                ]);
            } 
            if($dataVal->star== 2){
                $surveyQuestion[2][] = $this->get($dataVal->question, [
                    'contain' => []
                ]);
            } 
            if($dataVal->star== 1){
                $surveyQuestion[1][] = $this->get($dataVal->question, [
                    'contain' => []
                ]);
            }
            //0 for survey
            if($dataVal->star== 0){
                $surveyQuestion[0][] = $this->get($dataVal->question, [
                    'contain' => []
                ]);
            }
            
            //0 for survey
            if($dataVal->star== -1){
                $surveyQuestion[-1][] = $this->get($dataVal->question, [
                    'contain' => []
                ]);
            }
        }
        return $surveyQuestion;
    }
    
    /**
    * Method for get question list according to category 
    * showing on add more question model popup.
    *
    * @access public
    * @param Array $userId
    * @return array data
    */
    public function findQuestionListByUserId($userIds = null)
    {
        $surveyQuestion = $this->find('all', [
            'contain' => [
                'SurveyCategory' => [
                    'conditions' => [
                        'SurveyCategory.is_deleted' => 0,
                        'SurveyCategory.user_id IN' => $userIds
                    ],
                ],
            ],
            'conditions' => [
                'SurveyQuestion.user_id IN' => $userIds, 
                'SurveyQuestion.is_deleted' => 0
                ],
            'group' => array('SurveyQuestion.category_id'),
        ]);
        //THis is for popup
        if (!$surveyQuestion->isEmpty()) {
            foreach ($surveyQuestion as $dt) {
                $categoryNameByquestion[$dt->survey_category->name] = $this->find(
                        'all', array(
                            'conditions' => array(
                                'category_id' => $dt->survey_category->id,
                                'is_deleted' => 0,
                                'status' => 1
                                )
                            )
                        )->toArray();
            }
        } else {
            $categoryNameByquestion = 0;
        }
        
       return $categoryNameByquestion;
    }
    
    /**
    * getAllQuestionsByUserIds, Method for get question list according to category.
    *
    * @access public
    * @param Array $userIds
    * @return array data
    */
    public function getAllQuestionsByUserIds($userIds) 
    {
        return $this->find('all', [
                    'conditions' => [
                        'SurveyQuestion.user_id IN' => $userIds,
                        'SurveyQuestion.is_deleted' => 0,
                    ],
                    'order' => [
                        'SurveyQuestion.created' => 'desc'
                    ],
                    'contain' => [
                        'SurveyCategory' => [
                            'conditions' => [
                                'SurveyCategory.is_deleted' => 0,
                                'SurveyCategory.user_id IN' => $userIds
                            ],
                        ],
                    ]
                ])->toArray();
    }
}

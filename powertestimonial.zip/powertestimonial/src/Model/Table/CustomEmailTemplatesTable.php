<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;

/**
 * CustomEmailTemplates Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 *
 * @method \App\Model\Entity\CustomEmailTemplate get($primaryKey, $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\CustomEmailTemplate findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CustomEmailTemplatesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('custom_email_templates');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
    
    /**
     * getEmailTemplateByUserId, Function to get Email Template data
     *
     * @param int $userId
     * 
     * @return array|object
     */
    public function getEmailTemplateByUserId($userId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId
                    ]
                ])->first();
       
        return $result;
    }
    
    /**
    * Method used to addEmailTemplate at run-time
    *
    * @access public
    * @param array $data List of data to set at run-time
    * @return boolean 
    */
    public function addEmailTemplate($data = array())
    {
        if (!$data) {
            // no data submitted
            return false;
        }

        if ($data['id'] != '') {
            $customEmailTemplate = $this->get($data['id']);
        } else {
            $customEmailTemplate = $this->newEntity();
        }
        
        $customEmailTemplate = $this->patchEntity($customEmailTemplate, $data);
//        pr($customEmailTemplate);die;
        $result = $this->save($customEmailTemplate);
        
        //debug($unitType);
        if (!$result) {
            // problem saving the data
            return false;
        }
        // if all is successful
        return $result;
    }
    
    /**
    * This Method used to add Default Email Template at new user registration
    *
    * @access public
    * @param array $data List of data to set at run-time
    * @return boolean 
    */
    public function addDefaultEmailTemplate($data = array())
    {
        if (!$data) {
            // no data submitted
            return false;
        }
        $customEmailTemplate = $this->newEntity();
        $customEmailTemplate = $this->patchEntity($customEmailTemplate, $data);
        $customEmailTemplate->init_subject = "Please Rate Your Experience";
        $customEmailTemplate->init_body = Configure::read('emailBody');
        $customEmailTemplate->first_reminder_days = 3;
        $customEmailTemplate->first_subject = "Reminder Mail: Please Rate Your Experience";
        $customEmailTemplate->first_body = Configure::read('emailBody');
        $customEmailTemplate->second_reminder_days = 7;
        $customEmailTemplate->second_subject = "Reminder Mail: Please Rate Your Experience";
        $customEmailTemplate->second_body = Configure::read('emailBody');
        $customEmailTemplate->sms_verbiage = Configure::read("SMS_VERBIAGE");
        
        $result = $this->save($customEmailTemplate);
        if (!$result) {
            // problem saving the data
            return false;
        }
        // if all is successful
        return true;
    }
}

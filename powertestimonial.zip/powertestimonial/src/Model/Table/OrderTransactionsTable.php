<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * OrderTransactions Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\PlansTable|\Cake\ORM\Association\BelongsTo $Plans
 * @property \App\Model\Table\TransactionsTable|\Cake\ORM\Association\BelongsTo $Transactions
 *
 * @method \App\Model\Entity\OrderTransaction get($primaryKey, $options = [])
 * @method \App\Model\Entity\OrderTransaction newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\OrderTransaction[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\OrderTransaction|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\OrderTransaction patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\OrderTransaction[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\OrderTransaction findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class OrderTransactionsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('order_transactions');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Plans', [
            'foreignKey' => 'plan_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->integer('order_ref')
            ->requirePresence('order_ref', 'create')
            ->notEmpty('order_ref');

        $validator
            ->integer('amount')
            ->requirePresence('amount', 'create')
            ->notEmpty('amount');

        $validator
            ->scalar('first_name')
            ->requirePresence('first_name', 'create')
            ->notEmpty('first_name');

        $validator
            ->scalar('last_name')
            ->requirePresence('last_name', 'create')
            ->notEmpty('last_name');

        $validator
            ->scalar('auth_response')
            ->requirePresence('auth_response', 'create')
            ->notEmpty('auth_response');

        $validator
            ->scalar('transaction_status')
            ->requirePresence('transaction_status', 'create')
            ->notEmpty('transaction_status');

        $validator
            ->scalar('payment_type')
            ->requirePresence('payment_type', 'create')
            ->notEmpty('payment_type');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['plan_id'], 'Plans'));

        return $rules;
    }
    
    /**
     * getUserTransactionData method
     *
     * @param NULL.
     * @return void
     */
    public function getUserTransactionData()
    {
        $result = $this->find('all', [
                    'order' => [
                        'OrderTransactions.created' => 'desc'
                    ],
                    'conditions' => [
//                        'OrderTransactions.transaction_status' => 'Approved'
                    ],
                    'contain' => ['plans']
                ])->toArray();
        
        return $result;
    }
    
    /**
     * getUserTransactionData method
     *
     * @param str $uId.
     * @param str $rId.
     * @return void
     */
    public function getRecurTransactionData($uId, $rId)
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $uId,
                        'recur_id' => $rId
                    ]
                ])->first();
        
        return $result;
    }
    
    /**
     * getTransactionDataByUserId method
     *
     * @param string $uId.
     * @return void
     */
    public function getTransactionDataByUserId($uId, $status)
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $uId,
                        'transaction_status' => $status
                    ]
                ])->first();
        
        return $result;
    }
}

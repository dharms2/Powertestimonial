<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Facebook Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property |\Cake\ORM\Association\BelongsTo $Pages
 *
 * @method \App\Model\Entity\Facebook get($primaryKey, $options = [])
 * @method \App\Model\Entity\Facebook newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Facebook[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Facebook|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Facebook patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Facebook[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Facebook findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class FacebookTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('facebook');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
    
    /**
     * Function to get Facebook Data By User Id
     *
     * @param int $userId, get User id content
     * @return void
     */
    public function getFacebookDataByUserId($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]])->first();
        return $result;
    }
    
    /**
     * Function to get Facebook Data By Screen Name
     *
     * @param int $userId array of User id
     * @param string $pageName, content of Facebook page name
     * 
     * @return void
     */
    public function getFacebookDataByPageName($userId = null, $pageName = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'page_name' => $pageName
                    ]
                ])->first();
        return $result;
    }
    
    /**
    * Add Facebook Method used to add default Empty data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addFacebook($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $facebook = $this->newEntity();
        } else {
            $facebook = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $facebook = $this->patchEntity($facebook, $data);

        $facebook->user_id = $data['user_id'];
        // save data in the table
        $result = $this->save($facebook);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
}

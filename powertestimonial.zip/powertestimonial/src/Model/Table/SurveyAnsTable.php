<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SurveyAns Model
 *
 * @property \App\Model\Table\SurveyMgmtTable|\Cake\ORM\Association\BelongsTo $SurveyMgmt
 * @property \App\Model\Table\SurveyQusOldTable|\Cake\ORM\Association\BelongsTo $SurveyQusOld
 *
 * @method \App\Model\Entity\SurveyAn get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyAn newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyAn[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyAn|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyAn patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyAn[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyAn findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyAnsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_ans');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('SurveyQuestion', [
            'foreignKey' => 'survey_qus_id',
            'joinType' => 'INNER'
        ]);
        
        $this->belongsTo('ReviewsMgmt', [
            'foreignKey' => 'review_mgmt_id',
            'joinType' => 'INNER'
        ]);
        
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        
        $this->belongsTo('SurveyMgmt', [
            'foreignKey' => 'survey_mgmt_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['survey_qus_id'], 'SurveyQuestion'));
        $rules->add($rules->existsIn(['review_mgmt_id'], 'ReviewsMgmt'));
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['survey_mgmt_id'], 'SurveyMgmt'));

        return $rules;
    }
    
    /**
     * Function to get Answers Details
     *
     * @param int $surveyId, survey id content
     * @param int $reviewId, review id content
     * @return void
     */
    public function getAnswersDetails($surveyId = null, $reviewId = null) 
    {
        $result = $this->find('all', [
                        'conditions' => [
                            'survey_mgmt_id' => $surveyId,
                            'review_mgmt_id' => $reviewId,
                        ]
                    ]);
        return $result;
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;

/**
 * SurveyCategory Model
 *
 * @method \App\Model\Entity\SurveyCategory get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyCategory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyCategory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyCategory|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyCategory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyCategory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyCategory findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyCategoryTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_category');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        
        $this->hasMany('SurveyQuestion', [
            'foreignKey' => 'category_id',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('name')
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->scalar('description')
            ->requirePresence('description', 'create')
            ->notEmpty('description');

        return $validator;
    }
    
    /**
     * Function to get Categiory Details
     *
     * @param int $surveyId content of Survey id
     * @return void
     */
    public function getCategoryList($userIds = null) 
    {
        $result = $this->find('list', [
            'conditions' => [
                'user_id IN' => $userIds,
                'status' =>1,
                'is_deleted' => 0
            ]
        ])->toArray();
        return $result;
    }
    
    /**
    * Add Survey Category Method used to add default Survey Category data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addSurveyCategory($data = array(), $categoryId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyCategory = $this->newEntity();
        } else {
            $surveyCategory = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyCategory = $this->patchEntity($surveyCategory, $data);

        $surveyCategory->user_id = $data['user_id'];
        $surveyCategory->name = Configure::read('categoryName');
        $surveyCategory->description = Configure::read('categoryDescription');
        
        // save data in the table
        $result = $this->save($surveyCategory);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * checkUniqueCategoryName method
     *
     * @param string|null The configuration for the Table.
     * @return array(count)
     */
    public function checkUniqueCategoryName($data) {
        return $this->find('all', [
            'conditions' => [
                'user_id' => $data['user_id'],
                'name' => $data['name'],
                'is_deleted' => '0'
            ]
        ])->count();
    }
}

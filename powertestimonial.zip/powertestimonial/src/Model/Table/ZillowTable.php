<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Zillow Model
 *
 * @method \App\Model\Entity\Zillow get($primaryKey, $options = [])
 * @method \App\Model\Entity\Zillow newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Zillow[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Zillow|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Zillow patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Zillow[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Zillow findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ZillowTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('zillow');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');
        
        return $validator;
    }
    
    /**
     * Function to get Zillow Details
     *
     * @param int $userId, int of User id content
     * @return void
     */
    public function getZillowDetails($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]])->first();
        return $result;
    }
    
    /**
    * Add Zillow Method used to add default Zillow data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addZillow($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $zillow = $this->newEntity();
        } else {
            $zillow = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $zillow = $this->patchEntity($zillow, $data);

        $zillow->user_id = $data['user_id'];
        // save data in the table
        $result = $this->save($zillow);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * Function to get Zillow Data By Screen Name
     *
     * @param int $userId array of User id
     * @param string $screenName, content of Zillow screen name
     * 
     * @return void
     */
    public function getZillowDataByScreenName($userId = null, $screenName = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'screen_name' => $screenName
                    ]
                ])->first();
        return $result;
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ApiConfigurations Model
 *
 * @method \App\Model\Entity\ApiConfiguration get($primaryKey, $options = [])
 * @method \App\Model\Entity\ApiConfiguration newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ApiConfiguration[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ApiConfiguration|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ApiConfiguration patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ApiConfiguration[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ApiConfiguration findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ApiConfigurationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('api_configurations');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }
    
    /**
     * Function to get Api Details
     *
     * @param array $user array of User id content
     * @return void
     */
    public function getApiDetails($user = null) 
    {
        $result = $this->find('all', ['conditions' => $user])->first();
        return $result;
    }
    
    /**
    * Add Api Configurations Method used to add default API Configurations for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addApiConfigurations($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $apiConfiguration = $this->newEntity();
        } elseif (isset($data['id'])) {
            $apiConfiguration = $this->get($data['id'], [ 'contain' => [] ]);
        }
        $apiConfiguration = $this->patchEntity($apiConfiguration, $data);
        if (isset($data['user_id'])) {
            $apiConfiguration->user_id = $data['user_id'];
        }
        // save data in the table
        $result = $this->save($apiConfiguration);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;

/**
 * SurveyMgmt Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\SurveyTemplatesTable|\Cake\ORM\Association\BelongsTo $SurveyTemplates
 * @property \App\Model\Table\SurveyAnsTable|\Cake\ORM\Association\HasMany $SurveyAns
 * @property \App\Model\Table\SurveyQusTable|\Cake\ORM\Association\HasMany $SurveyQus
 *
 * @method \App\Model\Entity\SurveyMgmt get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyMgmt newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyMgmt[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyMgmt|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyMgmt patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyMgmt[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyMgmt findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyMgmtTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_mgmt');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('SurveyTemplates', [
            'foreignKey' => 'survey_template_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('SurveyAns', [
            'foreignKey' => 'survey_mgmt_id'
        ]);
        $this->hasMany('SurveyQus', [
            'foreignKey' => 'survey_mgmt_id'
        ]);
        $this->hasMany('ReviewsMgmt', [
            'foreignKey' => 'survey_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('name')
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->scalar('description')
            ->requirePresence('description', 'create')
            ->notEmpty('description');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['survey_template_id'], 'SurveyTemplates'));

        return $rules;
    }
    
    /**
     * Function to get Survey Details
     *
     * @param int $surveyId content of Survey id
     * @return void
     */
    public function getSurveyDetails($surveyId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'id' => $surveyId
                    ]
                ])->first();
        
        return $result;
    }
    
    /**
     * Function to get Survey List
     *
     * @param array $userId, user id in array
     * @return void
     */
    public function getSurveyList($userIds = null) 
    {
        $result = $this->find('list', [
                        'limit' => 200,
                        'conditions' => [
                            'SurveyMgmt.user_id IN' => $userIds, 
                            'SurveyMgmt.is_deleted' => 0,
                            'SurveyMgmt.status' => 1
                        ],
                        'contains' => [
                            'ReviewsMgmt'
                        ]
                    ]);
        return $result;
    }
    
    /**
     * Function to get All Survey Review By User Id
     *
     * @param int $userId, user id content
     * @param int $parentId, Parent id content
     * @return void
     */
    public function getAllSurveyReviewByUserId($userIds = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id IN' => $userIds, 
                        'is_deleted' => 0,
                    ]
                ])->count();
        
        return $result;
    }
    
    /**
    * Add Survey Survey Method used to add default Survey Survey data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addSurveyDafault($data = array(), $templateId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyMgmt = $this->newEntity();
        } else {
            $surveyMgmt = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyMgmt = $this->patchEntity($surveyMgmt, $data);

        $surveyMgmt->user_id = $data['user_id'];
        $surveyMgmt->name = Configure::read('surveyCreateSurveyName');
        $surveyMgmt->description = Configure::read('surveyCreateSurveyDescription');
        $surveyMgmt->survey_template_id = $templateId;
        $surveyMgmt->is_edited = Configure::read('one');
        
        // save data in the table
        $result = $this->save($surveyMgmt);
       
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
   
    
    
      /**
    * Add Survey Review Method used to add default Survey for Review data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addReviewSurveyDafault($data = array(), $templateId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyMgmt = $this->newEntity();
        } else {
            $surveyMgmt = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyMgmt = $this->patchEntity($surveyMgmt, $data);

        $surveyMgmt->user_id = $data['user_id'];
        $surveyMgmt->name = Configure::read('surveyCreateReviewName');
        $surveyMgmt->description = Configure::read('surveyCreateReviewDescription');
        $surveyMgmt->survey_template_id = $templateId;
        $surveyMgmt->is_edited = Configure::read('one');
        
        // save data in the table
        $result = $this->save($surveyMgmt);
       
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * getSurveyId, Function to get default Survey Id 
     *
     * @param int $userId
     * @return void
     */
    public function getSurveyId($userId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'is_edited' => Configure::read('one'),        
                    ],
                    'order' => [              
                        'id' => 'desc',
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getSurveyData, Function to get Survey Details 
     *
     * @param int $surveyId
     * 
     * @return array|object
     */
    public function getSurveyData($surveyId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'id' => $surveyId,
                        'is_deleted' => Configure::read('zero'),
                    ]
                ])->first();
        
        return $result;
    }
    
    /**
     * getAllSurveyReviewByUserIds, Function to get all Survey/Review Details 
     *
     * @param array $userIds
     * @return array|object
     */
    public function getAllSurveyReviewByUserIds($userIds) 
    {
        return $this->find('all', [
            'conditions' => [
                'SurveyMgmt.user_id IN' => $userIds,
                'SurveyMgmt.is_deleted' => Configure::read('zero'),
            ],
            'contain' => ['Users', 'SurveyTemplates'],
            'order' => [
                'SurveyMgmt.created' => 'desc'
            ],
        ])->toArray();
    }
}

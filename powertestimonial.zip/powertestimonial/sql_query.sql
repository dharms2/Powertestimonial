ALTER TABLE `survey_templates_question`
	ADD COLUMN `has_question_logic` INT(1) NOT NULL DEFAULT '0' AFTER `question_ordering`,
	ADD COLUMN `question_logic_id` INT(1) NULL DEFAULT '0' AFTER `has_question_logic`,
	ADD COLUMN `q_level` VARCHAR(255) NULL AFTER `question_logic_id`;
	
	
CREATE TABLE `survey_templates_question_logic` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`survey_template_question_id` INT(11) NOT NULL,
	`ans_option` INT(11) NOT NULL,
	`survey_template_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
AUTO_INCREMENT=149
;

DROP TABLE IF EXISTS `coupons`;
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `discount_type` enum('per','amt') NOT NULL COMMENT '"per" => "On Percentage","amt" => "On Amount"',
  `discount` varchar(50) NOT NULL,
  `used` int(11) NOT NULL DEFAULT '0',
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `status` enum('A','I') NOT NULL COMMENT '"A"=>"Active", "I"=>"Inactive"',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `order_transactions`;
CREATE TABLE IF NOT EXISTS `order_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_ref` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `transaction_status` enum('Pending','Complete') NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `approval_code` varchar(50) DEFAULT NULL,
  `invoice_id` bigint(50) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `recur_id` bigint(50) DEFAULT NULL,
  `recur_amt` varchar(50) DEFAULT NULL,
  `recuring_status` int(1) NOT NULL DEFAULT '0',
  `subscription_cancel_dt` date DEFAULT NULL,
  `auth_request` text NOT NULL,
  `auth_response` text,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;


ALTER TABLE `groups`
	ADD COLUMN `priority` int(11) NOT NULL DEFAULT '0' AFTER `name`;
	
	
INSERT INTO `groups` (`id`, `name`, `priority`, `created`, `modified`) VALUES
	(7, 'Team Lead', 4, '2018-03-08 17:03:00', '2018-03-08 17:04:26');
	


INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(NULL, NULL, 'Groups', 7, NULL, 113, 114);
	
	
INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
	(NULL, 4, 1, '1', '1', '1', '1'),
	(NULL, 303, 1, '1', '1', '1', '1'),
	(NULL, 303, 17, '1', '1', '1', '1'),
	(NULL, 4, 24, '1', '1', '1', '1'),
	(NULL, 303, 24, '1', '1', '1', '1'),
	(NULL, 303, 44, '1', '1', '1', '1');
	
DROP TABLE IF EXISTS `acos`;
CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`,`rght`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8;

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(1, NULL, NULL, NULL, 'controllers', 1, 354),
	(2, 1, NULL, NULL, 'Error', 2, 5),
	(3, 1, NULL, NULL, 'Groups', 6, 19),
	(4, 3, NULL, NULL, 'index', 7, 8),
	(5, 3, NULL, NULL, 'view', 9, 10),
	(6, 3, NULL, NULL, 'add', 11, 12),
	(7, 3, NULL, NULL, 'edit', 13, 14),
	(8, 3, NULL, NULL, 'delete', 15, 16),
	(9, 1, NULL, NULL, 'Pages', 20, 25),
	(10, 9, NULL, NULL, 'display', 21, 22),
	(17, 1, NULL, NULL, 'Users', 26, 91),
	(18, 17, NULL, NULL, 'index', 27, 28),
	(22, 17, NULL, NULL, 'delete', 29, 30),
	(23, 17, NULL, NULL, 'login', 31, 32),
	(24, 17, NULL, NULL, 'logout', 33, 34),
	(25, 1, NULL, NULL, 'Acl', 92, 93),
	(26, 1, NULL, NULL, 'Bake', 94, 95),
	(41, 1, NULL, NULL, 'Migrations', 96, 97),
	(44, 17, NULL, NULL, 'associateDashboard', 37, 38),
	(46, 17, NULL, NULL, 'addAssociate', 39, 40),
	(48, 17, NULL, NULL, 'editAssociate', 41, 42),
	(50, 17, NULL, NULL, 'updateStatus', 43, 44),
	(52, 1, NULL, NULL, 'Indexes', 98, 121),
	(53, 52, NULL, NULL, 'index', 99, 100),
	(54, 52, NULL, NULL, 'price', 101, 102),
	(55, 52, NULL, NULL, 'howItWork', 103, 104),
	(56, 52, NULL, NULL, 'contact', 105, 106),
	(57, 52, NULL, NULL, 'confirmSignup', 107, 108),
	(59, 17, NULL, NULL, 'checkEmailIsUnique', 45, 46),
	(88, 1, NULL, NULL, 'SurveyCategory', 122, 137),
	(89, 88, NULL, NULL, 'index', 123, 124),
	(91, 88, NULL, NULL, 'add', 125, 126),
	(92, 88, NULL, NULL, 'edit', 127, 128),
	(93, 88, NULL, NULL, 'delete', 129, 130),
	(94, 1, NULL, NULL, 'ReviewsMgmt', 138, 177),
	(95, 94, NULL, NULL, 'index', 139, 140),
	(97, 94, NULL, NULL, 'add', 141, 142),
	(100, 94, NULL, NULL, 'reviewStepOne', 143, 144),
	(101, 94, NULL, NULL, 'reviewStepTwo', 145, 146),
	(102, 52, NULL, NULL, 'invoice', 109, 110),
	(104, 88, NULL, NULL, 'updateStatus', 131, 132),
	(105, 17, NULL, NULL, 'register', 47, 48),
	(106, 52, NULL, NULL, 'emailContact', 111, 112),
	(108, 94, NULL, NULL, 'rating', 147, 148),
	(109, 1, NULL, NULL, 'SurveyMgmt', 178, 197),
	(110, 109, NULL, NULL, 'index', 179, 180),
	(112, 109, NULL, NULL, 'add', 181, 182),
	(113, 109, NULL, NULL, 'edit', 183, 184),
	(114, 109, NULL, NULL, 'delete', 185, 186),
	(115, 109, NULL, NULL, 'updateStatus', 187, 188),
	(116, 1, NULL, NULL, 'SurveyQuestion', 198, 211),
	(117, 116, NULL, NULL, 'index', 199, 200),
	(119, 116, NULL, NULL, 'add', 201, 202),
	(120, 116, NULL, NULL, 'edit', 203, 204),
	(121, 116, NULL, NULL, 'delete', 205, 206),
	(122, 116, NULL, NULL, 'updateStatus', 207, 208),
	(123, 1, NULL, NULL, 'SurveyTemplates', 212, 237),
	(124, 123, NULL, NULL, 'index', 213, 214),
	(126, 123, NULL, NULL, 'add', 215, 216),
	(127, 123, NULL, NULL, 'edit', 217, 218),
	(128, 123, NULL, NULL, 'delete', 219, 220),
	(129, 123, NULL, NULL, 'updateStatus', 221, 222),
	(131, 123, NULL, NULL, 'chooseQuestion', 223, 224),
	(132, 94, NULL, NULL, 'submitSurveyAnswer', 149, 150),
	(140, 1, NULL, NULL, 'ApiConfigurations', 238, 267),
	(141, 140, NULL, NULL, 'index', 239, 240),
	(146, 109, NULL, NULL, 'getAnalyzeData', 189, 190),
	(147, 109, NULL, NULL, 'surveysUserAns', 191, 192),
	(150, 109, NULL, NULL, 'checkTemplateExist', 193, 194),
	(153, 94, NULL, NULL, 'checkZillowApiDetails', 151, 152),
	(154, 17, NULL, NULL, 'profile', 49, 50),
	(155, 17, NULL, NULL, 'forgotPassword', 51, 52),
	(156, 17, NULL, NULL, 'resetPassword', 53, 54),
	(157, 17, NULL, NULL, 'editProfile', 55, 56),
	(158, 17, NULL, NULL, 'editCompanyProfile', 57, 58),
	(159, 17, NULL, NULL, 'changePassword', 59, 60),
	(160, 17, NULL, NULL, 'checkPassword', 61, 62),
	(163, 17, NULL, NULL, 'checkAddionalEmailIsUnique', 63, 64),
	(164, 140, NULL, NULL, 'checkZillowScreenName', 241, 242),
	(165, 140, NULL, NULL, 'checkGooglePlaceId', 243, 244),
	(166, 140, NULL, NULL, 'checkYelpBussinessName', 245, 246),
	(168, 52, NULL, NULL, 'accountSuspended', 113, 114),
	(169, 94, NULL, NULL, 'checkFacebookApiDetails', 153, 154),
	(170, 94, NULL, NULL, 'checkGoogleApiDetails', 155, 156),
	(171, 94, NULL, NULL, 'checkYelpApiDetails', 157, 158),
	(172, 123, NULL, NULL, 'importSurveyTempalteQuestion', 225, 226),
	(173, 140, NULL, NULL, 'zillow', 247, 248),
	(174, 140, NULL, NULL, 'google', 249, 250),
	(175, 140, NULL, NULL, 'yelp', 251, 252),
	(176, 140, NULL, NULL, 'facebook', 253, 254),
	(177, 1, NULL, NULL, 'Twilio', 268, 269),
	(178, 140, NULL, NULL, 'fbCallback', 255, 256),
	(179, 1, NULL, NULL, 'CrossDomainApi', 270, 275),
	(180, 179, NULL, NULL, 'index', 271, 272),
	(181, 52, NULL, NULL, 'privacyPolicy', 115, 116),
	(182, 88, NULL, NULL, 'checkNameIsUnique', 133, 134),
	(183, 52, NULL, NULL, 'contactSuccess', 117, 118),
	(184, 1, NULL, NULL, 'Reports', 276, 287),
	(185, 184, NULL, NULL, 'index', 277, 278),
	(186, 17, NULL, NULL, 'associateReviewData', 65, 66),
	(187, 17, NULL, NULL, 'overallReview', 67, 68),
	(199, 140, NULL, NULL, 'angiesList', 257, 258),
	(200, 140, NULL, NULL, 'throwException', 259, 260),
	(201, 179, NULL, NULL, 'throwException', 273, 274),
	(202, 2, NULL, NULL, 'throwException', 3, 4),
	(203, 3, NULL, NULL, 'throwException', 17, 18),
	(204, 52, NULL, NULL, 'throwException', 119, 120),
	(205, 9, NULL, NULL, 'throwException', 23, 24),
	(206, 184, NULL, NULL, 'monthSurvey', 279, 280),
	(207, 184, NULL, NULL, 'monthReview', 281, 282),
	(208, 184, NULL, NULL, 'getAllSurveyReview', 283, 284),
	(209, 184, NULL, NULL, 'throwException', 285, 286),
	(210, 94, NULL, NULL, 'checkAngiesListApiDetails', 159, 160),
	(211, 94, NULL, NULL, 'delete', 161, 162),
	(212, 94, NULL, NULL, 'sendSms', 163, 164),
	(213, 94, NULL, NULL, 'resend', 165, 166),
	(214, 94, NULL, NULL, 'throwException', 167, 168),
	(215, 1, NULL, NULL, 'SuperAdmin', 288, 313),
	(216, 215, NULL, NULL, 'userManagement', 289, 290),
	(217, 215, NULL, NULL, 'updateStatus', 291, 292),
	(218, 215, NULL, NULL, 'upgradeRequest', 293, 294),
	(219, 215, NULL, NULL, 'planUpgradeApproved', 295, 296),
	(220, 215, NULL, NULL, 'throwException', 297, 298),
	(221, 88, NULL, NULL, 'throwException', 135, 136),
	(222, 109, NULL, NULL, 'throwException', 195, 196),
	(223, 116, NULL, NULL, 'throwException', 209, 210),
	(224, 123, NULL, NULL, 'throwException', 227, 228),
	(225, 17, NULL, NULL, 'apiConfigForAssociate', 69, 70),
	(226, 17, NULL, NULL, 'planUpgrade', 71, 72),
	(227, 17, NULL, NULL, 'planUpgradeReq', 73, 74),
	(228, 17, NULL, NULL, 'throwException', 75, 76),
	(229, 1, NULL, NULL, 'Widgets', 314, 339),
	(230, 229, NULL, NULL, 'index', 315, 316),
	(231, 229, NULL, NULL, 'reviewSmall', 317, 318),
	(232, 229, NULL, NULL, 'reviewLarge', 319, 320),
	(233, 229, NULL, NULL, 'largeReviewIframe', 321, 322),
	(234, 229, NULL, NULL, 'seeReview', 323, 324),
	(235, 229, NULL, NULL, 'reviewMe', 325, 326),
	(236, 229, NULL, NULL, 'reviewsSend', 327, 328),
	(237, 229, NULL, NULL, 'email', 329, 330),
	(238, 229, NULL, NULL, 'successSmall', 331, 332),
	(239, 229, NULL, NULL, 'successLarge', 333, 334),
	(240, 229, NULL, NULL, 'download', 335, 336),
	(241, 229, NULL, NULL, 'throwException', 337, 338),
	(242, 140, NULL, NULL, 'bbbReview', 261, 262),
	(243, 1, NULL, NULL, 'AutoReminders', 340, 347),
	(244, 243, NULL, NULL, 'index', 341, 342),
	(245, 243, NULL, NULL, 'saveAutoReminderDate', 343, 344),
	(246, 243, NULL, NULL, 'throwException', 345, 346),
	(247, 1, NULL, NULL, 'CustomEmailTemplates', 348, 353),
	(248, 247, NULL, NULL, 'index', 349, 350),
	(249, 247, NULL, NULL, 'throwException', 351, 352),
	(250, 140, NULL, NULL, 'realtorReview', 263, 264),
	(251, 94, NULL, NULL, 'checkBBBApiDetails', 169, 170),
	(252, 94, NULL, NULL, 'checkRealtorApiDetails', 171, 172),
	(254, 123, NULL, NULL, 'questionOrderingUp', 229, 230),
	(255, 140, NULL, NULL, 'fetchOnlineReview', 265, 266),
	(256, 123, NULL, NULL, 'questionOrderingDown', 231, 232),
	(257, 17, NULL, NULL, 'onlineReviewBreakdown', 77, 78),
	(258, 17, NULL, NULL, 'internalReviewBreakdown', 79, 80),
	(259, 123, NULL, NULL, 'removeQuestion', 233, 234),
	(260, 94, NULL, NULL, 'getChildArray', 173, 174),
	(261, 94, NULL, NULL, 'getArrayByKey', 175, 176),
	(262, 123, NULL, NULL, 'recursiveDataInsert', 235, 236),
	(263, 215, NULL, NULL, 'userTransaction', 299, 300),
	(264, 215, NULL, NULL, 'cancelRecuring', 301, 302),
	(265, 215, NULL, NULL, 'cancelRecuringById', 303, 304),
	(266, 17, NULL, NULL, 'makePayment', 81, 82),
	(267, 215, NULL, NULL, 'coupons', 305, 306),
	(268, 17, NULL, NULL, 'getAllParentUsers', 83, 84),
	(269, 215, NULL, NULL, 'addCoupon', 307, 308),
	(270, 215, NULL, NULL, 'checkCodeIsUnique', 309, 310),
	(271, 215, NULL, NULL, 'delete', 311, 312),
	(272, 17, NULL, NULL, 'applyCoupon', 85, 86),
	(273, 17, NULL, NULL, 'updatePaymentInfo', 87, 88),
	(274, 17, NULL, NULL, 'paymentUpdate', 89, 90);
	
	
ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `first_reminder_dt` `first_reminder_dt` DATE NULL DEFAULT '0000-00-00' AFTER `is_deleted`,
	CHANGE COLUMN `second_reminder_dt` `second_reminder_dt` DATE NULL DEFAULT '0000-00-00' AFTER `first_reminder_send`;
	
ALTER TABLE `users`
	ADD COLUMN `company_id` INT(11) NOT NULL AFTER `parent_id`;
	

ALTER TABLE `survey_ans`
	ADD COLUMN `q_level` VARCHAR(250) NULL AFTER `survey_done`;	

UPDATE users SET parent_id=0 WHERE parent_id=10

ALTER TABLE `users`
	CHANGE COLUMN `company_id` `company_id` INT(11) NOT NULL DEFAULT '0' AFTER `parent_id`;

ALTER TABLE `users`
	ADD COLUMN `location` VARCHAR(50) NULL AFTER `company_id`;
	
CREATE TABLE IF NOT EXISTS `update_payment_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `recur_id` int(11) NOT NULL,
  `status` enum('Success','Error') NOT NULL,
  `update_request` text NOT NULL,
  `update_response` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;


ALTER TABLE `order_transactions`
	ADD COLUMN `expiry_date` DATE NULL DEFAULT NULL AFTER `subscription_cancel_dt`;
	
	
	
/* 04-Apr-2018 */
ALTER TABLE `users`
	ADD COLUMN `website_address` VARCHAR(255) NULL DEFAULT NULL AFTER `zip_code`;
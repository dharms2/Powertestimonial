/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global alertify, ERROR_MESSAGES */

$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
    
    /*Capitalize fields */
    $('input[capitalize="YES"]').keyup(function (event) {
        var textBox = event.target, start = textBox.selectionStart, end = textBox.selectionEnd;
        textBox.value = textBox.value.charAt(0).toUpperCase() + textBox.value.slice(1);
        textBox.setSelectionRange(start, end);
    });

    /*Uppercase fields */
    $('input[upper="YES"]').keyup(function (event) {
        var textBox = event.target;
        var start = textBox.selectionStart;
        var end = textBox.selectionEnd;
        textBox.value = textBox.value.toUpperCase();
        textBox.setSelectionRange(start, end);
    });

    /* jquery.maskedinput for US phone formater */
    var phones = [{"mask": "+#-###-###-####"}];
    $('#recipient-phone').inputmask({
        mask: phones,
        greedy: false,
        definitions: {'#': {validator: "[0-9]", cardinality: 1}}
    });
    
    var phones = [{"mask": "+#-###-###-####"}];
    $('#phone, #business-phone').inputmask({
        mask: phones,
        greedy: false,
        definitions: {'#': {validator: "[0-9]", cardinality: 1}}
    });
//    var phones = [{"mask": "###-###-####"}, {"mask": "(###) ###-##############"}];

});

function confirmDelete(event) {
    event.preventDefault();
    alertify.confirm(ERROR_MESSAGES.CONFIRM_DELETE_TITLE, ERROR_MESSAGES.CONFIRM_DELETE_MESSAGE, function () {
        window.location = event.target.href;
    }, function () {
        console.log('dismiss');
    });
}

function getConfirmation(id) {
    $.ajax({
        url: "/users/updateStatus",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_UPDATE, 'success', 5);
            var jsonData = JSON.parse(response);

            if (jsonData.is_active == true) {
                $('#inact-status-' + id).fadeOut();
                $('#act-status-' + id).fadeIn();
            } else {
                $('#inact-status-' + id).fadeIn();
                $('#act-status-' + id).fadeOut();
            }
            //location.reload(); 
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/*setting for the business or main account holder to have a setting in their account to 
 * either ALLOW agents to put in their own API credentials or NOT ALLOW so that it will 
 * automatically default to the company pages.*/
function changeApiConfig(id)
{
    $.ajax({
        url: "/Users/apiConfigForAssociate",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_API_SETTING, 'success', 5);
            var jsonData = JSON.parse(response);
            
            if (jsonData.api_config == true) {
                $('#allow-' + id).fadeOut();
                $('#not-allow-' + id).fadeIn();
            } else {
                $('#allow-' + id).fadeIn();
                $('#not-allow-' + id).fadeOut();
            }
        },
        error: function (response) {
            var jsonData = JSON.parse(response);
            if (jsonData.error) {
                alertify.set('notifier', 'position', 'top-right');
                alertify.notify(ERROR_MESSAGES.ERROR_API_SETTING, 'error', 10, function () {
                    console.log('dismissed');
                });
            }
        }
    });
}

/*change Category Status Active/Inactive*/
function changeCategoryStatus(id)
{
    $.ajax({
        url: "/SurveyCategory/updateStatus",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_CATEGORY_UPDATE, 'success', 5);
            var jsonData = JSON.parse(response);

            if (jsonData.status == true) {
                $('#inact-status-' + id).fadeOut();
                $('#act-status-' + id).fadeIn();
            } else {
                $('#inact-status-' + id).fadeIn();
                $('#act-status-' + id).fadeOut();
            }
            //location.reload(); 
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_CATEGORY_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/*change Question Status Active/Inactive*/
function changeQuestionStatus(id)
{
    $.ajax({
        url: "/SurveyQuestion/updateStatus",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_QUESTION_UPDATE, 'success', 5);
            var jsonData = JSON.parse(response);

            if (jsonData.status == true) {
                $('#inact-status-' + id).fadeOut();
                $('#act-status-' + id).fadeIn();
            } else {
                $('#inact-status-' + id).fadeIn();
                $('#act-status-' + id).fadeOut();
            }
            //location.reload(); 
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_QUESTION_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/*change Template Status Active/Inactive*/
function changeTemplateStatus(id)
{
    $.ajax({
        url: "/SurveyTemplates/updateStatus",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_TEMPLATE_UPDATE, 'success', 5);
            var jsonData = JSON.parse(response);

            if (jsonData.status == true) {
                $('#inact-status-' + id).fadeOut();
                $('#act-status-' + id).fadeIn();
            } else {
                $('#inact-status-' + id).fadeIn();
                $('#act-status-' + id).fadeOut();
            }
            //location.reload(); 
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_TEMPLATE_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/*change Survey Status Active/Inactive*/
function changeSurveyStatus(id)
{
    $.ajax({
        url: "/SurveyMgmt/updateStatus",
        type: "post",
        data: {'uid': id},
        success: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.CONFIRM_SURVEY_UPDATE, 'success', 5);
            var jsonData = JSON.parse(response);

            if (jsonData.status == true) {
                $('#inact-status-' + id).fadeOut();
                $('#act-status-' + id).fadeIn();
            } else {
                $('#inact-status-' + id).fadeIn();
                $('#act-status-' + id).fadeOut();
            }
            //location.reload(); 
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_SURVEY_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/***********Onchange fucntion for Question**************************/
function myQuestionFunction() {
    var x = document.getElementById("mySelect").value;

    var textareaHtml = '<input type="text" name="ans_choices[]" class="form-control" value="" style="display:none">';
    if (x == 2) {
        $("input:checkbox").css("display", "block");
        $("input:radio").css("display", "none");
        $("#removeOnTextarea").css("display", "none");
        $("#addOnTextarea").css("display", "block");
    } else if (x == 1) {
        $("input:checkbox").css("display", "none");
        $("input:radio").css("display", "block");
        $("#removeOnTextarea").css("display", "none");
        $("#addOnTextarea").css("display", "block");
    } else if (x == 3) {
        $("#removeOnTextarea").html(textareaHtml);
        $("#addOnTextarea").css("display", "none");
    } else if (x == 4 || x == 5) {
        $("#removeOnTextarea").html(textareaHtml);
        $("#addOnTextarea").css("display", "none");
    }
}

//---------Analyze Survey Module------------//
function analyzeSurveys(surveyid,userId) {
    $.ajax({
        url: "/SurveyMgmt/getAnalyzeData",
        type: "post",
        data: {'surveyid': surveyid, userId: userId},
        success: function (response) {
            var jsonDataAnalyze = JSON.parse(response);
            console.log(jsonDataAnalyze);
            var res = '';
            var rating = '';
            var reviewType = '';
            var actionStatus = '';
            var actionStatusRow = '';
            var surveyUserCnt = 0;
            if (jsonDataAnalyze['type'] == 1) {
                $('#surveyAnalyseHeading').html('Review');
            }
            if (jsonDataAnalyze['type'] == 2) {
                $('#surveyAnalyseHeading').html('Survey');
            }
            /*****************************************/
            if (jsonDataAnalyze['data'].length != 0) {
                var analyzeTableReview = $('#DataTables_Table_Review').DataTable();
                var analyzeTableSurvey = $('#DataTables_Table_Survey').DataTable();
                analyzeTableReview.clear();
                analyzeTableSurvey.clear();

                $.each(jsonDataAnalyze['data'], function (index, value) {
                    //Checing status

                    if (value.survey_done === 1) {
                        var status = 'Sent';
                    } else if (value.survey_done === 2) {
                        var status = 'Completed';
                    } else if (value.survey_done === 3) {
                        var status = 'Pending';
                    }
                    //Rating Section
                    if (value.ratings === 5) {
                        rating = '<i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>';
                        if (value.user_action === 7) {
                            reviewType = 'Zillow';
                        } else if (value.user_action === 1) {
                            reviewType = 'Google';
                        } else if (value.user_action === 2) {
                            reviewType = 'Facebook';
                        } else if (value.user_action === 3) {
                            reviewType = 'Yelp';
                        } else if (value.user_action === 6) {
                            reviewType = 'Realtor';
                        } else if (value.user_action === 4) {
                            reviewType = 'N/A';
                        } else if (value.user_action === 8) {
                            reviewType = 'Angies List';
                        } else if (value.user_action === 9) {
                            reviewType = 'BBB';
                        }
                    } else if (value.ratings === 4) {
                        rating = '<i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i>';
                                if (value.user_action === 7) {
                            reviewType = 'Zillow';
                        } else if (value.user_action === 1) {
                            reviewType = 'Google';
                        } else if (value.user_action === 2) {
                            reviewType = 'Facebook';
                        } else if (value.user_action === 3) {
                            reviewType = 'Yelp';
                        } else if (value.user_action === 6) {
                            reviewType = 'Realtor';
                        } else if (value.user_action === 4) {
                            reviewType = 'N/A';
                        } else if (value.user_action === 8) {
                            reviewType = 'Angies List';
                        } else if (value.user_action === 9) {
                            reviewType = 'BBB';
                        }
                    } else if (value.ratings === 3) {
                        rating = '<i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i>';
                        reviewType = 'N/A';
                    
                    } else if (value.ratings === 2) {
                        rating = '<i class="fa fa-star fa-2x star-color"></i> \n\
                                <i class="fa fa-star fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i> \n\
                                <i class="fa fa-star-o fa-2x star-color"></i>';
                        reviewType = 'N/A';
                    
                    } else if (value.ratings === 1) {
                        rating = '<i class="fa fa-star fa-2x star-color"></i> \n\
                                <i class="fa fa-star-o fa-2x star-color"></i> \n\
                                <i class="fa fa-star-o fa-2x star-color"></i> \n\
                                <i class="fa fa-star-o fa-2x star-color"></i>\n\
                                <i class="fa fa-star-o fa-2x star-color"></i>';
                        reviewType = 'N/A';
                    
                    } else if (value.ratings === null) {
                        rating = 'N/A';
                        reviewType = 'N/A';
                    }

                    /***************************************************************************************/
                    if (jsonDataAnalyze['type'] === 1) {
                        $('#DataTables_Table_Review_wrapper').css('display', 'block');
                        $('#DataTables_Table_Survey_wrapper').css('display', 'none');
                        if (value.ratings === 5) {
                            if (value.survey_done === 1 || value.survey_done === 3) {
                                actionStatus = '<form action="/ReviewsMgmt/resend" method="post">\n\
                                                    <input type="submit" class="btn btn-info btn-sm btnanalyze" value="Resend">\n\
                                                    <input type="hidden" name="recipient_first_name" value='+ value.recipient_first_name+'>\n\
                                                    <input type="hidden" name="recipient_last_name" value='+ value.recipient_last_name+'>\n\
                                                    <input type="hidden" name="recipient_email" value='+ value.recipient_email+'>\n\
                                                    <input type="hidden" name="recipient_phone" value='+ value.recipient_phone+'>\n\
                                                    <input type="hidden" name="survey_id" value='+ value.survey_id+'>\n\
                                                    <input type="hidden" name="user_id" value='+ value.user_id+'>\n\
                                                    <input type="hidden" name="sender_id" value='+ value.sender_id+'>\n\
                                                    <input type="hidden" name="id" value='+value.id+'>\n\
                                                    <input type="hidden" name="send_type[]" value="email">\n\
                                                    <input type="hidden" name="send_type[]" value="sms"></form>\n\
                                                    <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                            } else {
                                 actionStatus = '<input type="submit" class="btn btn-info btn-sm btnanalyze custom-disable" value="Resend">\n\
                                                <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                            }
                          
                        } else if (value.ratings === 4) {
                            if (value.survey_done === 1 || value.survey_done === 3) {
                                actionStatus = '<form action="/ReviewsMgmt/resend" method="post">\n\
                                                    <input type="submit" class="btn btn-info btn-sm btnanalyze" value="Resend">\n\
                                                    <input type="hidden" name="recipient_first_name" value='+ value.recipient_first_name+'>\n\
                                                    <input type="hidden" name="recipient_last_name" value='+ value.recipient_last_name+'>\n\
                                                    <input type="hidden" name="recipient_email" value='+ value.recipient_email+'>\n\
                                                    <input type="hidden" name="recipient_phone" value='+ value.recipient_phone+'>\n\
                                                    <input type="hidden" name="survey_id" value='+ value.survey_id+'>\n\
                                                    <input type="hidden" name="user_id" value='+ value.user_id+'>\n\
                                                    <input type="hidden" name="sender_id" value='+ value.sender_id+'>\n\
                                                    <input type="hidden" name="id" value='+value.id+'>\n\
                                                    <input type="hidden" name="send_type[]" value="email">\n\
                                                    <input type="hidden" name="send_type[]" value="sms"></form>\n\
                                                    <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                            } else if (value.survey_done === 2 && value.user_action !== 4) {
                                
                                 actionStatus = '<input type="submit" class="btn btn-info btn-sm btnanalyze custom-disable" value="Resend">\n\
                                                <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                            } else if (value.survey_done === 2 && value.user_action === 4) {
                                 actionStatus = "<a href='#' data-toggle='collapse' data-target='#review" + surveyUserCnt + "\
                                            ' class='accordion-toggle btn btn-success btn-sm btnanalyze' onclick='analyzeSurveysUserAns(" + value.user_id + ',\n\
                                            ' + value.survey_id + ',' + value.id + ',' + surveyUserCnt + ',\n\
                                            ' + jsonDataAnalyze['type'] + ");'>See More </a> <a href='/ReviewsMgmt/delete/"+ value.id +"' class='btn btn-danger btn-sm btnanalyze' onClick = 'confirmDelete(event);'>Delete</a>";
                          
                            }
                          
                        } else {
                            if (value.survey_done === 1 || value.survey_done === 3) {
                                actionStatus = '<form action="/ReviewsMgmt/resend" method="post">\n\
                                                    <input type="submit" class="btn btn-info btn-sm btnanalyze" value="Resend">\n\
                                                    <input type="hidden" name="recipient_first_name" value='+ value.recipient_first_name+'>\n\
                                                    <input type="hidden" name="recipient_last_name" value='+ value.recipient_last_name+'>\n\
                                                    <input type="hidden" name="recipient_email" value='+ value.recipient_email+'>\n\
                                                    <input type="hidden" name="recipient_phone" value='+ value.recipient_phone+'>\n\
                                                    <input type="hidden" name="survey_id" value='+ value.survey_id+'>\n\
                                                    <input type="hidden" name="user_id" value='+ value.user_id+'>\n\
                                                    <input type="hidden" name="sender_id" value='+ value.sender_id+'>\n\
                                                    <input type="hidden" name="id" value='+ value.id+'>\n\
\n\
                                                    <input type="hidden" name="send_type[]" value="email">\n\
                                                    <input type="hidden" name="send_type[]" value="sms"></form>\n\
\n\                                                 <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                            } else {
                                actionStatus = "<a href='#' data-toggle='collapse' data-target='#review" + surveyUserCnt + "\
                                            ' class='accordion-toggle btn btn-success btn-sm btnanalyze' onclick='analyzeSurveysUserAns(" + value.user_id + ',\n\
                                            ' + value.survey_id + ',' + value.id + ',' + surveyUserCnt + ',\n\
                                            ' + jsonDataAnalyze['type'] + ");'>See More </a> <a href='/ReviewsMgmt/delete/"+ value.id +"' class='btn btn-danger btn-sm btnanalyze' onClick = 'confirmDelete(event);'>Delete</a>";
                            }
                        }
                        var surveyUserId = value.id;

                        analyzeTableReview.row.add(
                                [
                                    value.recipient_first_name +' '+ value.recipient_last_name,
                                    value.recipient_email,
                                    value.recipient_phone,
                                    formatDate(value.created),
                                    reviewType,
                                    rating,
                                    status,
                                    actionStatus
                                ]
                        ).draw();

                        analyzeTableReview.rows().every(function (surveyUserId) {
                            this.child($('<tr><td colspan="8" class="hiddenRow">\n\
                                    <div class="accordian-body collapse" id="review' + surveyUserId + '">\n\
                                    <div class="row"><div class="col-md-11">\n\
                                    <div class="card-body form-horizontal" id="ReviewData' + surveyUserId + '">\n\
                                    </div></div></div></div></td></tr>'
                                    )
                            ).show();
                        });
                    } else if (jsonDataAnalyze['type'] === 2) {

                        $('#DataTables_Table_Review_wrapper').css('display', 'none');
                        $('#DataTables_Table_Survey_wrapper').css('display', 'block');

                        if (value.survey_done === 1 || value.survey_done === 3) {
                            actionStatus = '<form action="/ReviewsMgmt/resend" method="post">\n\
                                                    <input type="submit" class="btn btn-info btn-sm btnanalyze" value="Resend">\n\
                                                    <input type="hidden" name="recipient_first_name" value='+ value.recipient_first_name+'>\n\
                                                    <input type="hidden" name="recipient_last_name" value='+ value.recipient_last_name+'>\n\
                                                    <input type="hidden" name="recipient_email" value='+ value.recipient_email+'>\n\
                                                    <input type="hidden" name="recipient_phone" value='+ value.recipient_phone+'>\n\
                                                    <input type="hidden" name="survey_id" value='+ value.survey_id+'>\n\
                                                    <input type="hidden" name="id" value='+ value.id+'>\n\
                                                    <input type="hidden" name="user_id" value='+ value.user_id+'>\n\
                                                    <input type="hidden" name="sender_id" value='+ value.sender_id+'>\n\
                                                    <input type="hidden" name="send_type[]" value="email">\n\
                                                    <input type="hidden" name="send_type[]" value="sms"></form>\n\
\n\                                                 <a href="/ReviewsMgmt/delete/'+ value.id +'" class="btn btn-danger btn-sm btnanalyze" onClick = "confirmDelete(event);">Delete</a>';
                        } else {
                            actionStatus = "<a href='#' data-toggle='collapse' data-target='#survey" + surveyUserCnt + "\
                                    ' class='accordion-toggle btn btn-success btn-sm btnanalyze' onclick='analyzeSurveysUserAns(" + value.user_id + ',\n\
                                    ' + value.survey_id + ',' + value.id + ',' + surveyUserCnt + ',\n\
                                    ' + jsonDataAnalyze['type'] + ");'>See More</a> <a href='/ReviewsMgmt/delete/"+ value.id +"' class='btn btn-danger btn-sm btnanalyze' onClick = 'confirmDelete(event);'>Delete</a>";
                        }

                        analyzeTableSurvey.row.add([
                            value.recipient_first_name +' '+ value.recipient_last_name,
                            value.recipient_email,
                            value.recipient_phone,
                            formatDate(value.created),
                            status,
                            actionStatus
                        ]).draw();

                        analyzeTableSurvey.rows().every(function (surveyUserId) {
                            this.child($('<tr><td colspan="8" class="hiddenRow">\n\
                                    <div class="accordian-body collapse" id="survey' + surveyUserId + '">\n\
                                    <div class="row"><div class="col-md-11">\n\
                                    <div class="card-body form-horizontal" id="SurveyData' + surveyUserId + '">\n\
                                    </div></div></div></div></td></tr>'
                                    )
                                    ).show();
                        });
                    }
                    surveyUserCnt++;
                    /*************************************************************************************/
                });
            } else {
                analyzeTableReview.clear();
                analyzeTableSurvey.clear();
                $('#DataTables_Table_Review_wrapper').css('display', 'none');
                $('#DataTables_Table_Survey_wrapper').css('display', 'none');
                res = res + "<div class='row'><div class='col-sm-12'>\n\
                            <p class='text-center'>No record found.</p></div></div>";
                $('#surveyAnalyseNull').html(res);
            }
            $('.surveyAnalyze').modal('show');
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.SURVEY_ANALYZE_ERROR_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}

/*Convert date into DD-MM-YYYY*/
function formatDate(value) {
    var d = new Date(value);
    var year = d.getFullYear();
    /// Add 1 because JavaScript months start at 0
    var month = (1 + d.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = d.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    return month + '-' + day + '-' + year;
}

/*get survey answers with analyze data*/
function analyzeSurveysUserAns(userid, surveyid, reviewid, surveyUserCnt, formShowId) {
    $.ajax({
        url: "/SurveyMgmt/surveysUserAns",
        type: "post",
        data: {'userid': userid, 'surveyid': surveyid, 'reviewid': reviewid, 'surveyUserCnt': surveyUserCnt},
        success: function (response) {
            var jsonData = JSON.parse(response);
            var res = '';
            var qustioncount = 1;

            $.each(jsonData, function (index, value) {
                var ans_choices = value.ans_choices.split('|');

                var correct_ans = value.correct_ans.split(',');
                if (value.type == 5) {
                    var addres_val = JSON.parse(value.correct_ans);
                }
                res = res + "<div class='row'>\n\
                        <div class='col-md-12'><h6 class='card-title'>" + qustioncount + ". " + value.question + "</h6></div></div>" +
                        "<div class='col-md-12 form-group'>";

                $.each(ans_choices, function (i) {
                    var correct_checked = 0;
                    $.each(correct_ans, function (l) {
                        if (i == correct_ans[l]) {
                            correct_checked = 1;
                        }
                    });
                    res += (value.type == 1) ? '<label class="checkbox-inline survey-ans" for="inline-checkbox1">\n\
                            <input class="survey-ans" type="radio" ' + (correct_checked == 1 ? 'checked' : '')
                            + ' disabled>  <span class="radiomark"></span>' + ans_choices[i]
                            + '</label>' :
                            (value.type == 2) ? '<label class="checkbox-inline survey-ans" for="inline-checkbox1">\n\
                            <input type="checkbox" class="survey-ans" ' + (correct_checked == 1 ? 'checked' : '')
                            + ' disabled>  <span class="checkmark"></span> ' + ans_choices[i]
                            + '</label>' :
                            (value.type == 4) ? '<div class="form-group">' +
                            (value.correct_ans == 4 ? '<i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i>'
                                    : value.correct_ans == 3 ? '<i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i>'
                                    : value.correct_ans == 2 ? '<i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i>'
                                    : value.correct_ans == 1 ? '<i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i>'
                                    : value.correct_ans == 0 ? '<i class="fa fa-star fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i><i class="fa fa-star-o fa-2x star-color"></i>'
                                    : '') + '</div>'
                            :
                            (value.type == 5) ? '<div class="row">\n\
                                                    <div class="col-md-3 col-sm-3">\n\
                                                        <div class="form-group">\n\
                                                            <textarea type="text" class="form-control"  disabled>'+addres_val.Address+'</textarea>\n\
                                                        </div>\n\
                                                    </div>\n\
\n\                                                 <div class="col-md-3 col-sm-3">\n\
                                                        <div class="form-group">\n\
                                                            <input type="text" class="form-control" value='+addres_val.City+' disabled>\n\
                                                        </div>\n\
                                                    </div>\n\
\n\                                                 <div class="col-md-2 col-sm-2">\n\
                                                        <div class="form-group">\n\
                                                            <input type="text" class="form-control" value='+addres_val.State+' disabled>\n\
                                                        </div>\n\
                                                    </div>\n\
\n\                                                 <div class="col-md-2 col-sm-2">\n\
                                                        <div class="form-group">\n\
                                                            <input type="text" class="form-control" value='+addres_val.Zipcode+' disabled>\n\
                                                        </div>\n\
                                                    </div>\n\
                                                </div>' :
                            '<div class="form-control tempalteQuestionAnswerarea" disabled="">'
                            + value.correct_ans + '</div>';

                });
                res += '</div></div>';
                qustioncount++;
            });
            console.log("#" + formShowId + surveyUserCnt);

            if (formShowId == 1)
            {
                $("#ReviewData" + surveyUserCnt).html(res);
            } else
            {
                $("#SurveyData" + surveyUserCnt).html(res);
            }
        },
        error: function (response) {
            $("#" + formShowId + surveyUserCnt).html(response);
        }
    });
    
    
}
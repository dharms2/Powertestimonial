/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*check Zillow Id is set or not*/
/* global alertify, ERROR_MESSAGES */

function zillowRequest(id, reviewID) {
    $("#zillow-loader").show();
    $(".zillow").hide();
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkZillowApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status == 'OK') {
                window.location = "https://www.zillow.com/reviews/write/?s=" + data.zillowID;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.ZILLOW_API_DETAILS);
            }
        }
    });
}

/*check Facebook Id is set or not*/
function facebookRequest(id, reviewID) {
    $("#facebook-loader").show();
    $(".facebook").hide();
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkFacebookApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status == 'OK') {
                window.location = data.pageUrl;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.FACEBOOK_API_DETAILS);
            }
        }
    });
}

/*check Google Id is set or not*/
function googleRequest(id, reviewID) {
    $("#google-loader").show();
    $(".google-plus").hide();
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkGoogleApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status == 'OK') {
                console.log(data.placeID);
                window.location = 'https://search.google.com/local/writereview?placeid='+data.placeID;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.GOOGLE_API_DETAILS);
            }
        }
    });
}

/*check Yelp Id is set or not*/
function yelpRequest(id, reviewID) {
    $("#yelp-loader").show();
    $(".yelp").hide();
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkYelpApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status == 'OK') {
                window.location = 'https://www.yelp.com/'+data.requestURL;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.YELP_API_DETAILS);
            }
        }
    });
}

/*check Angies List Id is set or not*/
function angiesListRequest(id, reviewID) {
    $("#angies-loader").show();
    $(".angies").hide();
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkAngiesListApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status == 'OK') {
                window.location = 'https://member.angieslist.com/member/reviews/edit?serviceProviderId='+data.businessId;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.ANGIES_API_DETAILS);
            }
        }
    });
}

/*check Angies List Id is set or not*/
function bbbRequest(id, reviewID) {
    $("#bbb-loader").show();
    $(".bbb-business").hide();
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".realtor").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkBBBApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status === 'OK') {
                window.location = 'https://www.bbb.org/alaska/business-reviews/real-estate/'+data.businessName+'/reviews-and-complaints/?review=true';
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.BBB_API_DETAILS);
            }
        }
    });
}

/*check Angies List Id is set or not*/
function realtorRequest(id, reviewID) {
    $("#realtor-loader").show();
    $(".realtor").hide();
    $(".yelp").css({"pointer-events": "none", "opacity": "0.4"});
    $(".google-plus").css({"pointer-events": "none", "opacity": "0.4"});
    $(".facebook").css({"pointer-events": "none", "opacity": "0.4"});
    $(".zillow").css({"pointer-events": "none", "opacity": "0.4"});
    $(".angies").css({"pointer-events": "none", "opacity": "0.4"});
    $(".bbb-business").css({"pointer-events": "none", "opacity": "0.4"});
    $.ajax({
        type: 'POST',
        url: '/ReviewsMgmt/checkRealtorApiDetails',
        data: { uid : id, reviewId: reviewID },
        dataType: 'json',
        success: function (data) {
            if (data.status === 'OK') {
                window.location = 'https://www.realtor.com/realestateagents/'+data.businessName;
            } else {
                alertify.alert("Alert", ERROR_MESSAGES.REALTOR_API_DETAILS);
            }
        }
    });
}

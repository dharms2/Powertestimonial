/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function zillowValidation() 
{
    // Get the value of the input field with id="numb"
    var zillowID = document.getElementById("zillow-screen-name").value;
    
    if (zillowID === '') {
        document.getElementById("zillow-error").innerHTML = ERROR_MESSAGES.ZILLOW_SCREEN_NAME;
        return false;
    } else {
        // If Zillow have value
        document.getElementById("zillow-submit").style.display="none";
        document.getElementById("zillow-loader").style.display="block";
        var zillow = zillowCredential(zillowID);
        if (zillow === true) {
            return true;
        } else {
            document.getElementById("zillow-submit").style.display="block";
            document.getElementById("zillow-loader").style.display="none";
            document.getElementById("zillow-error").innerHTML = ERROR_MESSAGES.WRONG_ZILLOW_SCREEN_NAME;
            return false;
        }
    }
}

function googleValidation() 
{
    // Get the value of the input field with id="numb"
    var googleID = document.getElementById("google-place-id").value;
    
    if (googleID === '') {
        document.getElementById("google-error").innerHTML = ERROR_MESSAGES.GOOGLE_PLACE_ID;
        return false;
    } else {
        // If Google have value
        document.getElementById("google-submit").style.display = "none";
        document.getElementById("google-loader").style.display = "block";
        var google = googleCredential(googleID);
        if (google === true) {
            return true;
        } else {
            document.getElementById("google-submit").style.display = "block";
            document.getElementById("google-loader").style.display = "none";
            document.getElementById("google-error").innerHTML = ERROR_MESSAGES.WRONG_GOOGLE_PLACE_ID;
            return false;
        }
    }
}

function yelpValidation() 
{
    // Get the value of the input field with id="numb"
    var yelpID = document.getElementById("yelp-business-id").value;
    
    if (yelpID === '') {
        document.getElementById("yelp-error").innerHTML = ERROR_MESSAGES.YELP_BUSINESS_ID;
        return false;
    } else {
        // If Yelp have value
        document.getElementById("yelp-submit").style.display = "none";
        document.getElementById("yelp-loader").style.display = "block";
        var yelp = yelpCredential(yelpID);
        if (yelp === true) {
            return true;
        } else {
            document.getElementById("yelp-submit").style.display = "block";
            document.getElementById("yelp-loader").style.display = "none";
            // document.getElementById("yelp-error").innerHTML = ERROR_MESSAGES.WRONG_YELP_BUSSINESS_NAME;
			document.getElementById("yelp-error").innerHTML = yelp;
            return false;
        }
    }
    
}

function angiesListValidation() 
{
    // Get the value of the input field with id="numb"
    var angiesID = document.getElementById("angies-business-id").value;
    
    if (angiesID === '') {
        document.getElementById("angies-error").innerHTML = ERROR_MESSAGES.ANGIES_BUSINESS_ID;
        return false;
    } else {
        return true;
    }
}

function bbbValidation() 
{
    // Get the value of the input field with id="numb"
    var bbbBusinessName = document.getElementById("bbb-business-name").value;
    
    if (bbbBusinessName === '') {
        document.getElementById("bbb-error").innerHTML = ERROR_MESSAGES.BBB_BUSINESS_NAME;
        return false;
    } else {
        return true;
    }
}

function realtorValidation() 
{
    // Get the value of the input field with id="numb"
    var realtorBusinessName = document.getElementById("realtor-business-name").value;
    
    if (realtorBusinessName === '') {
        document.getElementById("realtor-error").innerHTML = ERROR_MESSAGES.REALTOR_BUSINESS_NAME;
        return false;
    } else {
        return true;
    }
}

function facebookValidation() 
{
    // Get the value of the input field with id="numb"
    var pageName = document.getElementById("facebook-page-name").value;
    if (pageName === '') {
        document.getElementById("facebook-page-error").innerHTML = ERROR_MESSAGES.FACEBOOK_PAGE_NAME;
        return false;
    } else {
        return true;
    }
}

/*Check validation of Zillow Credential where Zillow data are exist or not*/
function zillowCredential(value)
{
    var result = false;
    $.ajax({
        type: "POST",
        async: false,
        url: "/ApiConfigurations/checkZillowScreenName",
        data: { zillow : value },
        dataType: 'JSON',
        success: function (data) {
            result = (data.msgCode === 0) ? true : false;
        }
    });
    // return true if value is exist
    return result;
}

/*Check validation of Google Credential where Google Place Id are exist or not*/
function googleCredential(value)
{
    var result = false;
    $.ajax({
        type: "POST",
        async: false,
        url: "/ApiConfigurations/checkGooglePlaceId",
        data: { google_place_id : value},
        dataType: 'JSON',
        success: function (data) {
           result = (data.msgCode === 0) ? true : false;
        }
    });
    // return true if value is exist
    return result;
}

/*Check validation of Yelp Credential where Yelp data are exist or not*/
function yelpCredential(value)
{
    var result = false;
    $.ajax({
        type: "POST",
        async: false,
        url: "/ApiConfigurations/checkYelpBussinessName",
        data: { yelp : value},
        dataType: 'JSON',
        success: function (data) {
            result = (data.msgCode === 0) ? true : data.description;
        }
    });
    // return true if value is exist
    return result;
}

/*Check validation of facebook Credential where facebook data are exist or not*/
function facebookCredential(facebookID, fbUserId, fbAccessToken)
{
    var result = false;
    $.ajax({
        type: "POST",
        async: false,
        url: "/ApiConfigurations/checkFacebookPage",
        data: { facebook : facebookID, userid : fbUserId, accesstoken : fbAccessToken},
        dataType: 'JSON',
        success: function (data) {
            result = (data.msgCode === 0) ? true : false;
        }
    });
    // return true if value is exist
    return result;
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    var max_fields = 10; //maximum input boxes allowed
    var wrapper = $(".input_fields_wrap"); //Fields wrapper
    var add_button = $(".add_field_button"); //Add button ID
    var x = 0; //initlal text box count
    $(add_button).click(function (e) { //on add input button click
        e.preventDefault();
        if ($('#mySelect').val() == 1){
            if (x < max_fields) { //max input box allowed
                x++; //text box increment
                $(wrapper).append(
                    '<div class="row">' 
                        + '<div class="col-md-1">\n\
                                <div class="form-group">' +
                                    '<input type="radio" name="correct_ans[]"\n\
                                    class="form-control ans-radio"\n\
                                    id="radioQuestion_' + x + '" value=' + x + '>' +
                                    '<input type="checkbox" name="correct_ans[]" \n\
                                    class="form-control ans-check" id="checkboxQuestion_'
                                      + x + '" style="display:none;" value=' + x + '>\n\
                                </div>\n\
                            </div>\n\
                            <div class="col-md-6">\n\
                                <div class="form-group">' +
                                    '<input type="text" name="ans_choices[]" \n\
                                    class="form-control" required="required" >\n\
                                </div>\n\
                            </div>\n\
                        <a href="#" class="remove_field btn btn-danger">\n\
                        <i class="fa fa-trash"></i>\n\
                        </a>\n\
                    </div>'
                ); //add input box
            }
        } else {
            
            if (x < max_fields) { //max input box allowed
                x++; //text box increment
                $(wrapper).append(
                    '<div class="row">'
                       +'<div class="col-md-1">\n\
                            <div class="form-group">' +
                                '<input type="radio" name="correct_ans[]"\n\
                                class="form-control ans-radio"\n\
                                id="radioQuestion_' + x + '" style="display:none;"  value=' + x + '>' +
                                '<input type="checkbox" name="correct_ans[]" \n\
                                class="form-control ans-check" \n\
                                id="checkboxQuestion_' + x + '" value=' + x + '>\n\
                            </div>\n\
                        </div>\n\
                        <div class="col-md-6">\n\
                            <div class="form-group">' +
                                '<input type="text" name="ans_choices[]"\n\
                                class="form-control" required="required" >\n\
                            </div>\n\
                        </div>\n\
                        <a href="#" class="remove_field btn btn-danger">\n\
                        <i class="fa fa-trash"></i>\n\
                        </a>\n\
                    </div>'
                ); //add input box
            }
        }
    });
    
    //Remove Fields
    $(wrapper).on("click", ".remove_field", function (e) {
        //user click on remove text
        var pointer = $(this).parent('div').find('.ans-radio').attr('id').split('_');
        pointer = pointer[1];
        e.preventDefault();
        $(this).parent('div').remove();
        var remove_pointer = 0;
        $('.input_fields_wrap').find('.ans-radio').each(function (i, v) {
            var opt_id = $(v).attr('id').split('_');
            if (opt_id[1] > pointer) {
                opt_id[1] = opt_id[1] - 1;
                $(v).val(opt_id[1]);
                opt_id = opt_id[0] + '_' + opt_id[1];
                $(v).attr('id', opt_id);
            }
            remove_pointer++;
        });
        var pointer = $(this).parent('div').find('.ans-check').attr('id').split('_');
        pointer = pointer[1];
        e.preventDefault();
        $(this).parent('div').remove();
        var remove_pointer = 0;
        $('.input_fields_wrap').find('.ans-check').each(function (i, v) {
            var opt_id = $(v).attr('id').split('_');
            if (opt_id[1] > pointer) {
                opt_id[1] = opt_id[1] - 1;
                $(v).val(opt_id[1]);
                opt_id = opt_id[0] + '_' + opt_id[1];
                $(v).attr('id', opt_id);
            }
            remove_pointer++;
        });
        x = remove_pointer - 1;
    })
});
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global ERROR_MESSAGES, TINYMCE_PLUGINS, tinymce, TINYMCE, TINYMCE_TOOLBAR, TINYMCE_CONTENT_CSS */

$(function () {
    
    tinymce.init({ 
        mode : TINYMCE.MODE,
        editor_selector  : TINYMCE.EDITOR_SELECTOR,
        menubar:false,
        plugins: [
          TINYMCE_PLUGINS.PLUGINS_1, 
          TINYMCE_PLUGINS.PLUGINS_2, 
          TINYMCE_PLUGINS.PLUGINS_3, 
          TINYMCE_PLUGINS.PLUGINS_4
        ],
        toolbar1: TINYMCE_TOOLBAR.TOOLBAR_1,
//        toolbar2: TINYMCE_TOOLBAR.TOOLBAR_2,
        content_css: [
          TINYMCE_CONTENT_CSS.FOUNT, 
          TINYMCE_CONTENT_CSS.CODEPEM_MIN
        ],
        setup: function (editor) {
            editor.on('change', function () {
                editor.save();
            });
        }
    });
    
    $('#auto-reminder-form').validate({
        rules: {
            first_reminder_dt: {
                required: true
            },
            second_reminder_dt: {
                required: true
            }
        },
        messages: {
            first_reminder_dt: {
                required: ERROR_MESSAGES.FIRST_REMINDER_DATE
            },
            second_reminder_dt: {
                required: ERROR_MESSAGES.SECOND_REMINDER_DATE
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

    $('#initial-form').validate({
        rules: {
            init_subject: {
                required: true
            },
            init_body: {
                required: true
            }
        },
        messages: {
            init_subject: {
                required: ERROR_MESSAGES.EMAIL_SUBJECT
            },
            init_body: {
                required: ERROR_MESSAGES.EMAIL_BODY
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $('#first-reminder-form').validate({
        rules: {
            first_reminder_days: {
                required: true
            },
            first_subject: {
                required: true
            },
            first_body: {
                required: true
            }
        },
        messages: {
            first_reminder_days: {
                required: ERROR_MESSAGES.REMINDER_DAYS
            },
            first_subject: {
                required: ERROR_MESSAGES.EMAIL_SUBJECT
            },
            first_body: {
                required: ERROR_MESSAGES.EMAIL_BODY
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $('#second-reminder-form').validate({
        rules: {
            second_reminder_days: {
                required: true
            },
            second_subject: {
                required: true
            },
            second_body: {
                required: true
            }
        },
        messages: {
            second_reminder_days: {
                required: ERROR_MESSAGES.REMINDER_DAYS
            },
            second_subject: {
                required: ERROR_MESSAGES.EMAIL_SUBJECT
            },
            second_body: {
                required: ERROR_MESSAGES.EMAIL_BODY
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $('#sms-verbiage-form').validate({
        rules: {
            sms_verbiage: {
                required: true,
                maxlength: 1200
            }
        },
        messages: {
            sms_verbiage: {
                required: ERROR_MESSAGES.SMS_VERBIAGE,
                maxlength: ERROR_MESSAGES.SMS_VERBIAGE_LENGTH,
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

});


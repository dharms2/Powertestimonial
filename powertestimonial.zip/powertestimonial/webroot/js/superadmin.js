/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global ERROR_MESSAGES */

$(function () {
    
    var date_input1 = $('#valid-from-dt');
    var date_input2 = $('#valid-to-dt');
    date_input1.datepicker({
        format: 'mm-dd-yyyy',
        autoclose: true,
        forceParse: false,
        Default: true,
        pickDate: true,
        startDate: '+0d',
        todayHighlight: true
    }).on('changeDate', function(selected){
        startDate = new Date(selected.date.valueOf());
        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
        date_input2.datepicker('setStartDate', startDate);
    });

    date_input2.datepicker({
        format: 'mm-dd-yyyy',
        autoclose: true,
        forceParse: false,
        Default: true,
        pickDate: true,
        startDate: '+0d',
        todayHighlight: true
    }).on('changeDate', function(selected){
        FromEndDate = new Date(selected.date.valueOf());
        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
        date_input1.datepicker('setEndDate', FromEndDate);
    });
    
    
    /*Check Validation of all required field of Coupon Form.*/
    $('#add-coupon').validate({
        rules: {
            code: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                checkCode : function(){ 
                    return [
                        $('[name=code]').val()
                    ]; 
                }
            },
            discount_type: {
                required: true
            },
            discount: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            status: {
                required: true,
            },
            valid_from: {
                required: true,
            },
            valid_to: {
                required: true
            }
        },
        messages: {
            code: {
                required: ERROR_MESSAGES.CODE
            },
            discount_type: {
                required: ERROR_MESSAGES.DISCOUNT_TYPE
            },
            discount: {
                required: ERROR_MESSAGES.DISCOUNT
            },
            status: {
                required: ERROR_MESSAGES.STATUS
            },
            valid_from: {
                required: ERROR_MESSAGES.VALID_FROM
            },
            valid_to: {
                required: ERROR_MESSAGES.VALID_TO
            },
            state: {
                required: ERROR_MESSAGES.LOCATION
            },
            email: {
                required: ERROR_MESSAGES.EMAIL
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            error.addClass('form-control-feedback');
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parent('label'));
            } else if (element.prop('name') === 'valid_from') {
                error.insertAfter(element.parent('#valid-from-dt'));
            } else if (element.prop('name') === 'valid_to') {
                error.insertAfter(element.parent('#valid-to-dt'));
            } else if (element.prop('name') === 'discount') {
                error.insertAfter(element.parent('#discount'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    /*Check validation where rate code and hotel code are unique or not*/
    $.validator.addMethod("checkCode", function(value, element) {
            var result = false;
            $.ajax({
                type:"POST",
                async: false,
                url: "/SuperAdmin/checkCodeIsUnique", // script to validate in server side
                data: { code : value },
                dataType: 'JSON',
                success: function(data) {
                    result = (data.count === 0) ? true : false;
                }
            });
            // return true if Code is exist in database
            return result; 
        }, ERROR_MESSAGES.CODE_EXISTS);
    
    $('#discount-type').on('change', function() {
        var selectedtype = $(this).find('option:selected').val();
        if (selectedtype == "amt") {
            $("#amt").show();
            $("#per").hide();
        } else if (selectedtype == "per") {
            $("#amt").hide();
            $("#per").show();
        } 
    });
    
});
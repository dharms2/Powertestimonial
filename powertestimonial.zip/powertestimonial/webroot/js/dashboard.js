/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global alertify, ERROR_MESSAGES */
$(function () { 
    
    $(document).on("click", "#fetch-review", function() {
        //Select the hotel code which is stored as value for option
        var userId = $(this).attr('user-id');
        var baseUrl = $(this).attr('base-url');
        
        $('#showLaoderHere').html('<div class="loading">Loading&#8230;</div>');
        if (userId) {
            $.ajax({
                url: "/ApiConfigurations/fetchOnlineReview",
                type: "post",
                data: {userId: userId},
                success: function (data) {
                    var jsonData = JSON.parse(data);
                    console.log(jsonData);
                    if (jsonData.success == 'ok') {
                        $('#showLaoderHere').html('');
                        if (jsonData.facebook == 'ok') {
                            alertify.alert("Success", ERROR_MESSAGES.FETCH_ONLINE_REVIEW, function(){ 
                                window.location = baseUrl + "Users";
                            });
                        } else {
                            alertify.alert("Alert", ERROR_MESSAGES.FACEBOOK_FETCH_REVIEW);
                        }
                    } else {
                        alertify.alert("Error", ERROR_MESSAGES.FAILED_ERROR_MESSAGE);
                        console.log('dismissed');
                    }
                }
            });
        }
    });
    
    var $breadcrumb = $('#breadcrumb').val();
    var $overall = $('#overall').val();
    var $userId = $('#user-id').val();
        
    $(document).on("change", "#rating-breakdown", function() {
        var result = '';
        var rating = $('#rating-breakdown').val();
//        alert($userId);
        if (rating == 2) {
            $.ajax({
                url: "/Users/onlineReviewBreakdown",
                type: "post",
                data: {userId: $userId, breadcrumb: $breadcrumb, overall: $overall},
                success: function (data) {
                    var jsonData = JSON.parse(data);
                    
                    result = result + '<div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color"></i> ';
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star5 = (jsonData.online5Star === undefined) ? '0.00' : jsonData.online5Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star5 +'%">';
                    result += '<div class="progress-bar bg-success" style="width: '+ star5 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star4 = (jsonData.online4Star === undefined) ? '0.00' : jsonData.online4Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star4 +'%">';
                    result += '<div class="progress-bar bg-primary" style="width: '+ star4 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star3 = (jsonData.online3Star === undefined) ? '0.00' : jsonData.online3Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star3 +'%">';
                    result += '<div class="progress-bar bg-info" style="width: '+ star3 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star2 = (jsonData.online2Star === undefined) ? '0.00' : jsonData.online2Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star2 +'%">';
                    result += '<div class="progress-bar bg-warning" style="width: '+ star2 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star1 = (jsonData.online1Star === undefined) ? '0.00' : jsonData.online1Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star1 +'%">';
                    result += '<div class="progress-bar bg-danger" style="width: '+ star1 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    $('#review-rating-breakdown').html(result);
                    $('[data-toggle="tooltip"]').tooltip();
                }
            });
        } else if (rating == 1) {
            $.ajax({
                url: "/Users/internalReviewBreakdown",
                type: "post",
                data: {userId: $userId, breadcrumb: $breadcrumb, overall: $overall},
                success: function (data) {
                    var jsonData = JSON.parse(data);
                    
                    result = result + '<div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color"></i> ';
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star5 = (jsonData.internal5Star === undefined) ? '0.00' : jsonData.internal5Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star5 +'%">';
                    result += '<div class="progress-bar bg-success" style="width: '+ star5 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star4 = (jsonData.internal4Star === undefined) ? '0.00' : jsonData.internal4Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star4 +'%">';
                    result += '<div class="progress-bar bg-primary" style="width: '+ star4 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star3 = (jsonData.internal3Star === undefined) ? '0.00' : jsonData.internal3Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star3 +'%">';
                    result += '<div class="progress-bar bg-info" style="width: '+ star3 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star2 = (jsonData.internal2Star === undefined) ? '0.00' : jsonData.internal2Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star2 +'%">';
                    result += '<div class="progress-bar bg-warning" style="width: '+ star2 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    result += '<span class="font-weight-bold float-left progress-star">';
                    result += '<i class="fa fa-star star-color opacity-0"></i> ';
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color opacity-0"></i> '; 
                    result += '<i class="fa fa-star star-color"></i>';
                    result += '</span></div>';
                    var star1 = (jsonData.internal1Star === undefined) ? '0.00' : jsonData.internal1Star;
                    result += '<div class="progress mb-3" data-toggle="tooltip" title="'+ star1 +'%">';
                    result += '<div class="progress-bar bg-danger" style="width: '+ star1 +'%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>';
                    result += '</div>';
                    $('#review-rating-breakdown').html(result);
                    $('[data-toggle="tooltip"]').tooltip();
                }
            });
        }
    });
});
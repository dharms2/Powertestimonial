/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global ERROR_MESSAGES */

$(function () {

    $.validator.addMethod("EMAIL", function (value, element) {
        return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
    }, ERROR_MESSAGES.EMAIL_VALIDATE);
    
    jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
	phone_number = phone_number.replace(/\s+/g, "");
	return this.optional(element) || phone_number.length > 9 &&
		phone_number.match(/^(\+?1-?)?(\([2-9]\d{2}\)|[2-9]\d{2})-?[2-9]\d{2}-?\d{4}$/);
    }, ERROR_MESSAGES.VALID_PHONE_NUMBER);

    $('#request-review-form').validate({
        rules: {
            recipient_first_name: {
                required: {
                    depends:function(){
                        $(this).val($.trim($(this).val()));
                        return true;
                    }
                },
                minlength: 2
            },
            recipient_last_name: {
                required: {
                    depends:function(){
                        $(this).val($.trim($(this).val()));
                        return true;
                    }
                },
                minlength: 2
            },
            recipient_email: {
                required: {
                    depends:function(){
                        $(this).val($.trim($(this).val()));
                        return true;
                    }
                },
                EMAIL: true
            },
            recipient_phone: {
                required: {
                    depends:function(){
                        $(this).val($.trim($(this).val()));
                        return true;
                    }
                },
                phoneUS: true
            },
            survey_id: {
                required: true,
                checkSurvey: function () {
                    return [
                        $('[name=survey_id]').val()
                    ];
                }
            },
            type: {
                required: true
            },
            user_id: {
                required: true
            }
        },
        messages: {
            recipient_first_name: {
                required: ERROR_MESSAGES.REVIEWER_FNAME,
                minlength: ERROR_MESSAGES.REVIEWER_FNAME_MINLENGTH
            },
            recipient_last_name: {
                required: ERROR_MESSAGES.REVIEWER_LNAME,
                minlength: ERROR_MESSAGES.REVIEWER_LNAME_MINLENGTH
            },
            recipient_email: {
                required: ERROR_MESSAGES.REVIEWER_EMAIL
            },
            recipient_phone: {
                required: ERROR_MESSAGES.REVIEWER_PHONE
            },
            survey_id: {
                required: ERROR_MESSAGES.SURVEY_REQUIRED
            },
            type: {
                required: ERROR_MESSAGES.TYPE_REQUIRED
            },
            user_id: {
                required: ERROR_MESSAGES.REVIEW_USER_ID
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.type-checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    /*check Survey where survey are not deleted.*/
    $.validator.addMethod("checkSurvey", function (value, element) {

        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/SurveyMgmt/checkTemplateExist", // script to validate in server side
            data: {survey_id: value},
            dataType: 'JSON',
            success: function (data) {
                result = (data.count === 0) ? false : true;
            }
        });
        // return true if Code is exist in database
        return result;
        }, 
        ERROR_MESSAGES.TEMPLATE_SELECT
    );
    
    /*Hide and show the block of block rate availavility*/
    
    
});
    
function showHideEmail()
{
    if($('.select-email').is(":checked")) {
        $('#recipient-email').prop('disabled', false);
    } else {
        $('#recipient-email').prop('disabled', true);
    }
}

function showHideSms()
{
    if($('.select-sms').is(":checked")) {
        $('#recipient-phone').prop('disabled', false);
    } else {
        $('#recipient-phone').prop('disabled', true);
    }
}
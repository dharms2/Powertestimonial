/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global ERROR_MESSAGES */

$(function () {
    $.validator.addMethod("PASSWORD", function (value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/i.test(value);
    }, ERROR_MESSAGES.PASSWORD_VALIDATE);
    
    /*******************************Change Password****************************************/
    $('#change-password-save').validate({
        rules: {
            old_password: {
                required: true,
                PASSWORD: true,
                checkPassword: function () {
                    return [
                        $('[name=old_password]').val()
                    ];
                }
            },
            new_password: {
                required: true,
                PASSWORD: true,
                checkPasswordMatch: function () {
                    return [
                        $('[name=old_password]').val()
                    ];
                }
            },
            confirm_password: {
                required: true,
                equalTo: '#new-password'
            }
        },
        messages: {
            old_password: {
                required: ERROR_MESSAGES.OLD_PASSWORD
            },
            new_password: {
                required: ERROR_MESSAGES.PASSWORD
            },
            confirm_password: {
                required: ERROR_MESSAGES.CONFIRM_PASSWORD,
                equalTo: ERROR_MESSAGES.CONFIRM_PASSWORD_EQUALTO
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

    /*Check Password where Password is set in database or not*/
    $.validator.addMethod("checkPassword", function (value, element) 
    {
        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/Users/checkPassword", // script to validate in server side
            data: {password: value},
            dataType: 'JSON',
            success: function (data) {
                result = (data.count === false) ? false : true;
            }
        });
        // return true if Code is exist in database
        return result;
    },
    ERROR_MESSAGES.PASSWORD_EXISTS
    );
    
    /*Check Password where Password Match are unique or not*/
    $.validator.addMethod("checkPasswordMatch", function (value, element) 
    {
        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/Users/checkPassword", // script to validate in server side
            data: {password: value},
            dataType: 'JSON',
            success: function (data) {
                result = (data.count === false) ? true : false;
            }
        });
        // return true if Code is exist in database
        return result;
    },
    ERROR_MESSAGES.PASSWORD_EXISTS_MATCH
    );

});

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global ERROR_MESSAGES */

$(function () {    
    
     $.validator.addMethod("ZIP_CODE", function (value, element) {
        var cval = $('#country').val();
        switch (cval) {
            case "US":
                postalCodeRegex = /^([0-9]{5})(?:[-\s]*([0-9]{4}))?$/;
                break;
            case "CA":
                postalCodeRegex = /^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$/;
                break;
            default:
                postalCodeRegex = /^(?:[A-Z0-9]+([- ]?[A-Z0-9]+)*)?$/;
        }
        return this.optional(element) || postalCodeRegex.test(value);
    }, ERROR_MESSAGES.ZIP_CODE_VALIDATE);
    
    
   
    /*Check Survey Form Validation*/
    $('#survey-form').validate({
        rules: {
            name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
//                checkSurveyName : function(){ return [$('[name=user_id]').val()]; }
            },
            description: {
               required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
            },
            survey_template_id: {
                required: true
            },
        },
        messages: {
            name: {
                required: ERROR_MESSAGES.SURVEY_NAME_REQUIRED
            },
            description: {
                required: ERROR_MESSAGES.SURVEY_DISCRIPTION_REQUIRED
            },
            survey_template_id: {
                required: ERROR_MESSAGES.SURVEY_TEMPLATE_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $.validator.addMethod("checkSurveyName", function(value, element, params) 
    {
            var data = {name : value, user_id: params[0]};
            var result = false;
            $.ajax({
                type:"POST",
                async: false,
                url: "/SurveyCategory/checkNameIsUnique", // script to validate in server side
                data: data,
                dataType: 'JSON',
                success: function(data) {
                    result = (data.count === 0) ? true : false;
                }
            });
            // return true if Code is exist in database
            return result; 
        }, 
        ERROR_MESSAGES.CATEGORY_NAME_EXISTS
    );

    /*Check Category Form Validation*/
    $('#category-form').validate({
        rules: {
            name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
//                checkCategoryName : function(){ return [$('[name=user_id]').val()]; }
            },
            description: {
                required: true
            },
        },
        messages: {
            name: {
                required: ERROR_MESSAGES.NAME_REQUIRED
            },
            description: {
                required: ERROR_MESSAGES.DISCRIPTION_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $.validator.addMethod("checkCategoryName", function(value, element, params) 
    {
            var data = {name : value, user_id: params[0]};
            var result = false;
            $.ajax({
                type:"POST",
                async: false,
                url: "/SurveyCategory/checkNameIsUnique", // script to validate in server side
                data: data,
                dataType: 'JSON',
                success: function(data) {
                    result = (data.count === 0) ? true : false;
                }
            });
            // return true if Code is exist in database
            return result; 
        }, 
        ERROR_MESSAGES.CATEGORY_NAME_EXISTS
    );
  
    /*Check Template Form Validation*/
    $('#template-form').validate({
        rules: {
            name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            description: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            greeting: {
               required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            footer: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            qus_types: {
                required: true
            },
            select_qusetion: {
                required: true
            }
        },
        messages: {
            name: {
                required: ERROR_MESSAGES.TEMPLATE_NAME_REQUIRED
            },
            description: {
                required: ERROR_MESSAGES.TEMPLATE_DISCRIPTION_REQUIRED
            },
            greeting: {
                required: ERROR_MESSAGES.TEMPLATE_GREETING_REQUIRED
            },
            footer: {
                required: ERROR_MESSAGES.TEMPLATE_FOOTER_REQUIRED
            },
            qus_types: {
                required: ERROR_MESSAGES.TEMPLATE_QUESTIONTYPE_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });


/***************qUESTION bANK********************************/

    $('#question-form').validate({
        rules: {
            questions: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            ans_types: {
                required: true
            },
            category_id: {
                required: true
            }
        },
        messages: {
            questions: {
                required: ERROR_MESSAGES.QUESTION_NAME_REQUIRED
            },
            ans_types: {
                required: ERROR_MESSAGES.QUESTION_ANS_REQUIRED
            },
            category_id: {
                required: ERROR_MESSAGES.QUESTION_CATEGORY_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

});

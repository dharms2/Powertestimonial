$(function (){
  'use strict';

var ctx = document.getElementById('canvas-3');
if (ctx != null) {
  var facebook = document.getElementById('facebook').value;
  var google = document.getElementById('google').value;
  var zillow = document.getElementById('zillow').value;
  var yelp = document.getElementById('yelp').value;
  var doughnutData = {
    labels: [
      'Facebook',
      'Google',
      'Zillow',
      'Yelp'
    ],
    datasets: [{
      data: [facebook, google, zillow, yelp],
      backgroundColor: [
        '#3b5998',
        '#d34836',
        '#0074E4',
        '#d32323'
      ],
      hoverBackgroundColor: [
        '#3b5998',
        '#d34836',
        '#0074E4',
        '#d32323'
      ]
    }]
  };
  
  var chart = new Chart(ctx, {
    type: 'doughnut',
    data: doughnutData,
    options: {
      responsive: true,
      title:{
        position : 'bottom',
        display:true,
        text:'Facebook: ' + facebook + ',  Google: ' + google + ',  Zillow: ' + zillow + ',  Yelp: ' + yelp
      }
    }
  });
}

var Total = document.getElementById('total').value;
var Complete = document.getElementById('complete').value;
var Incomplete = document.getElementById('incomplete').value;

var pieData = {
  labels: [
    'Total',
    'Complete',
    'Incomplete'
  ],
  datasets: [{
    data: [Total, Complete, Incomplete],
    backgroundColor: [
      '#FF6384',
      '#36A2EB',
      '#FFCE56'
    ],
    hoverBackgroundColor: [
      '#FF6384',
      '#36A2EB',
      '#FFCE56'
    ]
  }]
};
var ctx = document.getElementById('canvas-5');
var chart = new Chart(ctx, {
  type: 'pie',
  data: pieData,
  options: {
    responsive: true
  }
});

});

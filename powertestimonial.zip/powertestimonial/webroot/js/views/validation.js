/* global alertify, ERROR_MESSAGES */

$(function () {
        
    $.validator.addMethod("EMAIL", function(value, element) {
        return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
    }, ERROR_MESSAGES.EMAIL_VALIDATE);

    $.validator.addMethod("PASSWORD",function(value, element){
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/i.test(value);
    }, ERROR_MESSAGES.PASSWORD_VALIDATE);
    
    $('#addAssociateForm').validate({
        rules: {
            first_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            last_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            group_id: {
                required: true
            },
            password: {
                required: true,
                PASSWORD: true
            },
            confirm_password: {
                required: true,
                equalTo: '#password'
            },
            add_location: {
                required: true
            },
            location: {
                required: true
            },
            email: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                EMAIL: true,
                checkEmail : function(){ 
                    return [
                        $('[name=email]').val()
                    ]; 
                }
            }
        },
        messages: {
            first_name: {
                required: ERROR_MESSAGES.FIRST_NAME,
                minlength: ERROR_MESSAGES.FIRST_NAME_MINLENGTH
            },
            last_name: {
                required: ERROR_MESSAGES.LAST_NAME,
                minlength: ERROR_MESSAGES.LAST_NAME_MINLENGTH
            },
            group_id: {
                required: ERROR_MESSAGES.USER_GROUP
            },
            password: {
                required: ERROR_MESSAGES.PASSWORD
            },
            confirm_password: {
                required: ERROR_MESSAGES.CONFIRM_PASSWORD,
                equalTo: ERROR_MESSAGES.CONFIRM_PASSWORD_EQUALTO
            },
            edit_location: {
                required: ERROR_MESSAGES.LOCATION
            },
            location: {
                required: ERROR_MESSAGES.LOCATION
            },
            email: {
                required: ERROR_MESSAGES.EMAIL
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            error.addClass('form-control-feedback');
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parent('label'));
            } else {
                error.insertAfter(element);
            }
        },
        highlight: function (element, errorClass, validClass) {
            $(element).addClass('form-control-danger').removeClass('form-control-success');
            $(element).parents('.form-group').addClass('has-danger').removeClass('has-success');
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).addClass('form-control-success').removeClass('form-control-danger');
            $(element).parents('.form-group').addClass('has-success').removeClass('has-danger');
        }
    });
    
    /*Check validation where rate code and hotel code are unique or not*/
    $.validator.addMethod("checkEmail", function(value, element) {

            var result = false;
            $.ajax({
                type:"POST",
                async: false,
                url: "/Users/checkEmailIsUnique", // script to validate in server side
                data: { email : value },
                dataType: 'JSON',
                success: function(data) {
                    result = (data.count === 0) ? true : false;
                }
            });
            // return true if Code is exist in database
            return result; 
        }, 
        ERROR_MESSAGES.EMAIL_EXISTS
    );
    
    $('#group-id').on('change', function()
    {
        var rollId = $(this).find('option:selected').val();
        var comapnyId = $('#company-id').val();
        
        if (rollId == 7 || rollId == 4) {
            $('#add-parent-id').find('option').remove().end().append('<option value="">No Selection</option>');
            $.ajax({
                url : '/Users/getAllParentUsers', //Write a function in the server side which accepts hotel code as argument
                type : 'POST',
                dataType : 'json',//return type from server side function [return it as JSON object
                data: {rollId: rollId, companyId: comapnyId}, //Pass the data to the function on server side
                success: function (data) { //Array of data returned from server side function
                    $('.text-block').hide();
                    $('.list-block').show();
                    $('.edit-parent-list').hide();
                    $('.edit-location').hide();
                    $.each(data, function(key, value) {
                        $('#add-parent-id').append('<option value="' + key + '">' + value + '</option>');
                    });
                },
                error: function () {
                    //display any unhandled error
                     alertify.set('notifier', 'position', 'top-right');
                     alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 5);
                }
            });
        } else if (rollId == 3) {
            $('.list-block').hide();
            $('.text-block').show();
            $('.edit-parent-list').hide();
            $('.edit-location').hide();
        }
    });
});

$(document).ready(function () {
    var rollId = $('#group-id').find('option:selected').val();
    if (rollId == 7 || rollId == 4) {
        $('.edit-parent-list').show();
        $('.text-block').hide();
        $('.list-block').hide();
        $('.edit-location').hide();
    } else if (rollId == 3) {
        $('.edit-parent-list').hide();
        $('.list-block').hide();
        $('.edit-location').show();
        $('.text-block').hide();
    }
});

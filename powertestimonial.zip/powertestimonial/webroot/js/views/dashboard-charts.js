$(function (){
  'use strict';
  
  var days = document.getElementById('days').value;
  if (days == 0) {
        var months = document.getElementById('months').value;
        var lifetimeReviews = document.getElementById('lifetime-Reviews').value;
        var lifetimeZillow = document.getElementById('lifetime-Zillow').value;
        var lifetimeGoogle = document.getElementById('lifetime-Google').value;
        var lifetimeYelp = document.getElementById('lifetime-Yelp').value;
        var lifetimeFacebook = document.getElementById('lifetime-Facebook').value;

        var lineChartData = {
          labels : months.split(','),
          datasets : [
            {
              label: 'Google',
              backgroundColor : 'rgba(211,72,54,0.2)',
              borderColor : 'rgba(211,72,54,1)',
              pointBackgroundColor : 'rgba(211,72,54,1)',
              pointBorderColor : '#fff',
              data : lifetimeGoogle.split(',')
            },
            {
              label: 'Zillow',
              backgroundColor : 'rgba(0,116,228,0.2)',
              borderColor : 'rgba(0,116,228,1)',
              pointBackgroundColor : 'rgba(0,116,228,1)',
              pointBorderColor : '#fff',
              data : lifetimeZillow.split(',')
            },
            {
              label: 'Yelp',
              backgroundColor : 'rgba(211,35,35,0.2)',
              borderColor : 'rgba(211,35,35,1)',
              pointBackgroundColor : 'rgba(211,35,35,1)',
              pointBorderColor : '#fff',
              data : lifetimeYelp.split(',')
            },
            {
              label: 'Facebook',
              backgroundColor : 'rgba(59,89,152,0.2)',
              borderColor : 'rgba(59,89,152,1)',
              pointBackgroundColor : 'rgba(59,89,152,1)',
              pointBorderColor : '#fff',
              data : lifetimeFacebook.split(',')
            },
            {
              label: 'Internal Review',
              backgroundColor : 'rgba(27,142,183,0.2)',
              borderColor : 'rgba(27,142,183,1)',
              pointBackgroundColor : 'rgba(27,142,183,1)',
              pointBorderColor : '#fff',
              data: lifetimeReviews.split(',')
            }
          ]
        }
    } else if (days == 365) {
        var months = document.getElementById('months').value;
        var past12MonthsReviews = document.getElementById('past-12-months-Reviews').value;
        var past12MonthsZillow = document.getElementById('past-12-months-Zillow').value;
        var past12MonthsGoogle = document.getElementById('past-12-months-Google').value;
        var past12MonthsYelp = document.getElementById('past-12-months-Yelp').value;
        var past12MonthsFacebook = document.getElementById('past-12-months-Facebook').value;

        var lineChartData = {
          labels : months.split(','),
          datasets : [
            {
              label: 'Google',
              backgroundColor : 'rgba(211,72,54,0.2)',
              borderColor : 'rgba(211,72,54,1)',
              pointBackgroundColor : 'rgba(211,72,54,1)',
              pointBorderColor : '#fff',
              data : past12MonthsGoogle.split(',')
            },
            {
              label: 'Zillow',
              backgroundColor : 'rgba(0,116,228,0.2)',
              borderColor : 'rgba(0,116,228,1)',
              pointBackgroundColor : 'rgba(0,116,228,1)',
              pointBorderColor : '#fff',
              data : past12MonthsZillow.split(',')
            },
            {
              label: 'Yelp',
              backgroundColor : 'rgba(211,35,35,0.2)',
              borderColor : 'rgba(211,35,35,1)',
              pointBackgroundColor : 'rgba(211,35,35,1)',
              pointBorderColor : '#fff',
              data : past12MonthsYelp.split(',')
            },
            {
              label: 'Facebook',
              backgroundColor : 'rgba(59,89,152,0.2)',
              borderColor : 'rgba(59,89,152,1)',
              pointBackgroundColor : 'rgba(59,89,152,1)',
              pointBorderColor : '#fff',
              data : past12MonthsFacebook.split(',')
            },
            {
              label: 'Internal Review',
              backgroundColor : 'rgba(27,142,183,0.2)',
              borderColor : 'rgba(27,142,183,1)',
              pointBackgroundColor : 'rgba(27,142,183,1)',
              pointBorderColor : '#fff',
              data: past12MonthsReviews.split(',')
            }
          ]
        }
    } else if (days == 30) {
        var past30DaysReviews = document.getElementById('past-30-Reviews').value;
        var past30DaysZillowReviews = document.getElementById('past-30-Zillow').value;
        var past30DaysYelpReviews = document.getElementById('past-30-Yelp').value;
        var past30DaysGoogleReviews = document.getElementById('past-30-Google').value;
        var past30DaysFacebookReviews = document.getElementById('past-30-Facebook').value;

        var lineChartData = {
//          labels : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30],
          labels : ['Day 1','Day 2','Day 3','Day 4','Day 5','Day 6','Day 7','Day 8','Day 9','Day 10','Day 11','Day 12','Day 13','Day 14','Day 15','Day 16','Day 17','Day 18','Day 19','Day 20','Day 21','Day 22','Day 23','Day 24','Day 25','Day 26','Day 27','Day 28','Day 29','Day 30'],
          datasets : [
            {
              label: 'Google',
              backgroundColor : 'rgba(211,72,54,0.2)',
              borderColor : 'rgba(211,72,54,1)',
              pointBackgroundColor : 'rgba(211,72,54,1)',
              pointBorderColor : '#fff',
              data : past30DaysGoogleReviews.split(',')
            },
            {
              label: 'Zillow',
              backgroundColor : 'rgba(0,116,228,0.2)',
              borderColor : 'rgba(0,116,228,1)',
              pointBackgroundColor : 'rgba(0,116,228,1)',
              pointBorderColor : '#fff',
              data : past30DaysZillowReviews.split(',')
            },
            {
              label: 'Yelp',
              backgroundColor : 'rgba(211,35,35,0.2)',
              borderColor : 'rgba(211,35,35,1)',
              pointBackgroundColor : 'rgba(211,35,35,1)',
              pointBorderColor : '#fff',
              data : past30DaysYelpReviews.split(',')
            },
            {
              label: 'Facebook',
              backgroundColor : 'rgba(59,89,152,0.2)',
              borderColor : 'rgba(59,89,152,1)',
              pointBackgroundColor : 'rgba(59,89,152,1)',
              pointBorderColor : '#fff',
              data : past30DaysFacebookReviews.split(',')
            },
            {
              label: 'Internal Review',
              backgroundColor : 'rgba(27,142,183,0.2)',
              borderColor : 'rgba(27,142,183,1)',
              pointBackgroundColor : 'rgba(27,142,183,1)',
              pointBorderColor : '#fff',
              data : past30DaysReviews.split(',')
            }
          ]
        }
    } else if (days == 7) {
        var daysName = document.getElementById('day-name').value;
        var past7DaysReviews = document.getElementById('past-7-Reviews').value;
        var past7DaysZillowReviews = document.getElementById('past-7-Zillow').value;
        var past7DaysYelpReviews = document.getElementById('past-7-Yelp').value;
        var past7DaysGoogleReviews = document.getElementById('past-7-Google').value;
        var past7DaysFacebookReviews = document.getElementById('past-7-Facebook').value;

        var lineChartData = {
//          labels : daysName.split(','),
          labels : ['Day 1','Day 2','Day 3','Day 4','Day 5','Day 6','Day 7'],
          datasets : [
            {
              label: 'Google',
              backgroundColor : 'rgba(211,72,54,0.2)',
              borderColor : 'rgba(211,72,54,1)',
              pointBackgroundColor : 'rgba(211,72,54,1)',
              pointBorderColor : '#fff',
              data : past7DaysGoogleReviews.split(',')
            },
            {
              label: 'Zillow',
              backgroundColor : 'rgba(0,116,228,0.2)',
              borderColor : 'rgba(0,116,228,1)',
              pointBackgroundColor : 'rgba(0,116,228,1)',
              pointBorderColor : '#fff',
              data : past7DaysZillowReviews.split(',')
            },
            {
              label: 'Yelp',
              backgroundColor : 'rgba(211,35,35,0.2)',
              borderColor : 'rgba(211,35,35,1)',
              pointBackgroundColor : 'rgba(211,35,35,1)',
              pointBorderColor : '#fff',
              data : past7DaysYelpReviews.split(',')
            },
            {
              label: 'Facebook',
              backgroundColor : 'rgba(59,89,152,0.2)',
              borderColor : 'rgba(59,89,152,1)',
              pointBackgroundColor : 'rgba(59,89,152,1)',
              pointBorderColor : '#fff',
              data : past7DaysFacebookReviews.split(',')
            },
            {
              label: 'Internal Review',
              backgroundColor : 'rgba(27,142,183,0.2)',
              borderColor : 'rgba(27,142,183,1)',
              pointBackgroundColor : 'rgba(27,142,183,1)',
              pointBorderColor : '#fff',
              data : past7DaysReviews.split(',')
            }
          ]
        }
    }
    var ctx = document.getElementById('canvas-1');
    var chart = new Chart(ctx, {
      type: 'line',
      data: lineChartData,
      options: {
        responsive: true
      }
    });
  
    var Total = document.getElementById('total').value;
    var Complete = document.getElementById('complete').value;
    var Incomplete = document.getElementById('incomplete').value;
  
    var pieData = {
        labels: [
          'Total',
          'Complete',
          'Incomplete'
        ],
        datasets: [{
          data: [Total, Complete, Incomplete],
          backgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ],
          hoverBackgroundColor: [
            '#FF6384',
            '#36A2EB',
            '#FFCE56'
          ]
        }]
      };
  
    var ctx = document.getElementById('canvas-5');
    var chart = new Chart(ctx, {
      type: 'pie',
      data: pieData,
      options: {
        responsive: true,
        title:{
          position : 'bottom',
          display:true,
          text:'Total: ' + Total + ',  Complete: ' + Complete + ',  Incomplete: ' + Incomplete
        }
      }
    });
});

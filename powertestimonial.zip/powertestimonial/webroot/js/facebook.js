/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//var accountappID = document.getElementById("app-id").value;

var accountappID = '568673573324847';

(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}
(document, 'script', 'facebook-jssdk'));

window.fbAsyncInit = function () {
    FB.init({
        appId: accountappID,
        cookie: true, // This is important, it's not enabled by default
        version: 'v2.2'
    });

    FB.AppEvents.logPageView();
    FB.getLoginStatus(function (response) {
        //alert(response.status);
    });
};

function login() {
    var addedPage = document.getElementById("facebook-page-name").value;
  
    FB.login(function (response) {
        if (response.authResponse) {
            var uid = response.authResponse.userID;
            var accessToken = response.authResponse.accessToken;
            FB.api('/' + uid + '/permissions', 'get', {access_token: accessToken}, function (responsep) {
                if (responsep && !responsep.error) {

                    var permissionPage = responsep.data;
                    var grantPermission = 0;
                    permissionPage.forEach(function (element) {
                        if (element.permission == 'manage_pages' && element.status == 'granted')
                        {
                            var finalDataWithReview = getReviewRating(uid, accessToken, addedPage);
                           // return true;
                           
                        } else 
                        {
                            grantPermission = 1;
                            
                          // return false;
                        }
                        
                    });
                    if (grantPermission === 1) {
                        console.log('permission', 'This page has no permission of Manages Pages!');
                    }
                }
            });
        } else {
             console.log('login', 'User cancelled login or did not fully authorize.');
           
        }
    });
}

function getReviewRating(uid, accessToken, addedPage) {

    FB.api('/' + uid + '/accounts', 'get', {access_token: accessToken}, function (response) {
        var pageName = 0;
        var pagesList = response.data;
        pagesList.forEach(function (element) {

            if (addedPage == element.name)
            {

                //Fetching all ratings and reviewss
                FB.api('/' + element.id + '/ratings', 'get', {access_token: element.access_token}, function (responsedata) {
                    finaldatapass(responsedata);
                });

                //Fetching overall ratings and reviewss
                FB.api('/' + element.id + '/?fields=overall_star_rating,rating_count', 'get', {access_token: element.access_token}, function (responsealldata) {
                 
                     finaldatapass(responsealldata);
                    //var overallratingreview = responsealldata;

                });
                


            } else
            {
                pageName = 1;
                
               
            }
        });
        if (pageName === 1) {
            console.log('invalidpage','Invalid Page Name!');
        }
    });
}

function finaldatapass(finaldata) {

//console.log(finaldata);
        var result = false;
            $.ajax({
                type: "POST",
                async: false,
                url: "/ApiConfigurations/saveFacebookData",
                data: {finaldata : finaldata},
                dataType: 'JSON',
                    success: function (data) {
                        result = (data.msgCode === 0) ? true : false;
                    }
            });
        // return true if value is exist
        return result;

   
}


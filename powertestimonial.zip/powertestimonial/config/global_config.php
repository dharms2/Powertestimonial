<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    //Left Navuigation Menu
    'DashboardMenu' => [
        'Dashboard' => [
            'controller' => 'Users',
            'action' => 'index',
            'icon' => 'icon-speedometer'
        ],
    ],
    
    'SuperAdminMenu' => [
        'User Management' => [
            'controller' => 'SuperAdmin',
            'action' => 'userManagement',
            'icon' => 'fa fa-users'
        ],
        'Plan Upgrade Request' => [
            'controller' => 'SuperAdmin',
            'action' => 'upgradeRequest',
            'icon' => 'fa fa-battery-full'
        ],
        'User Transactions' => [
            'controller' => 'SuperAdmin',
            'action' => 'userTransaction',
            'icon' => 'fa fa-money'
        ],
        'Coupons' => [
            'controller' => 'SuperAdmin',
            'action' => 'coupons',
            'icon' => 'fa fa-tags'
        ],
    ],
    
    'AdminMenu' => [
        'Company Users' => [
            'controller' => 'Users',
            'action' => 'associateDashboard',
            'icon' => 'fa fa-user-circle-o'
        ],
    ],
    
    'SurveysMenu' => [
        'Surveys' => [
            'controller' => 'SurveyMgmt',
            'action' => 'index',
            'icon' => 'fa fa-pencil-square-o'
        ],
        'Templates' => [
            'controller' => 'SurveyTemplates',
            'action' => 'index',
            'icon' => 'fa fa-code'
        ],
        'Questions Bank' => [
            'controller' => 'SurveyQuestion',
            'action' => 'index',
            'icon' => 'fa fa-question-circle'
        ],
        'Survey Categories' => [
            'controller' => 'SurveyCategory',
            'action' => 'index',
            'icon' => 'fa fa-tags'
        ],
    ],
    
    'AdminSettingsMenu' => [
        'API Configuration' => [
            'controller' => 'ApiConfigurations',
            'action' => 'index',
            'icon' => 'fa fa-gear'
        ],
        'Auto Reminders' => [
            'controller' => 'AutoReminders',
            'action' => 'index',
            'icon' => 'fa fa-bell-o'
        ],
        'Custom Email/SMS Templates' => [
            'controller' => 'CustomEmailTemplates',
            'action' => 'index',
            'icon' => 'fa fa-envelope'
        ]
    ],
    
    'CommonSettingsMenu' => [
        'API Configuration' => [
            'controller' => 'ApiConfigurations',
            'action' => 'index',
            'icon' => 'fa fa-gear'
        ]
    ],
    
    'WidgetsMenu' => [
        'Create widgets for website' => [
            'controller' => 'Widgets',
            'action' => 'index',
            'icon' => 'fa fa-tachometer'
        ]
    ],
    
    'ReportsMenu' => [
        'Reports' => [
            'controller' => 'Reports',
            'action' => 'survey',
            'icon' => 'fa fa-bar-chart'
        ]
    ],
    
    'ReviewStatus' => [
        '1' => 'Sent',
        '2' => 'Complete',
        '3' => 'Pending Survey'
    ],
    
    'ansTypeQuestionCategory' => [
        '1' => 'Radio',
        '2' => 'Checkbox',
        '3' => 'Textarea',
        '4' => 'Five Star',
        '5' => 'Address Group Of Fields'
    ],
    
    'AllPlans' => [
        '1' => 'Power',
        '2' => 'Power Plus',
        '3' => 'Ultimate Power'
    ],
    
    'PowerPlanFeatures' => [
        '1' => '1 User Account',
        '2' => '5 star rating system',
        '3' => 'Auto review requests',
        '4' => 'Real time alerts',
        '5' => 'Auto email reminders',
        '6' => 'At a glance analysis',
        '7' => 'Web review widgets',
        '8' => 'Free tech support',
        '9' => 'Custom branded',
        '10' => 'Full device optimization',
        '11' => 'Review request button on your website and emails'
    ],
    
    'PowerPlusPlanFeatures' => [
        '1' => 'Up to 10 User Accounts',
        '2' => '5 star rating system',
        '3' => 'Auto review requests',
        '4' => 'Real time alerts',
        '5' => 'Auto email reminders',
        '6' => 'At a glance analysis',
        '7' => 'Web review widgets',
        '8' => 'Free tech support',
        '9' => 'Custom branded',
        '10' => 'Full device optimization',
        '11' => 'Up to 5 customized surveys/reviews',
        '12' => 'Individual account branding',
        '13' => 'Review request button on your website and emails'
    ],
    
    'UltimatePowerPlanFeatures' => [
        '1' => 'Up to 25 User Accounts',
        '2' => '5 star rating system',
        '3' => 'Auto review requests',
        '4' => 'Real time alerts',
        '5' => 'Auto email reminders',
        '6' => 'At a glance analysis',
        '7' => 'Web review widgets',
        '8' => 'Free tech support',
        '9' => 'Custom branded',
        '10' => 'Full device optimization',
        '11' => 'Individual custom branding',
        '12' => 'Up to 25 customized surveys and reviews',
        '13' => 'Text integration',
        '14' => 'Review analysis',
        '15' => 'Review request button on your website and emails',
        '16' => 'Free Microsite'
    ],
        
    'InitialBody' => '<p>Hello {Recipient_Name},</p>
        <p>Thank you for offering to write a review about your most recent experience with <strong>{Sender_Business_Name}</strong> and <strong>{Sender_Name}</strong>. I hope you had a great experience and are satisfied with the service I provided. Your feedback is very valuable and I appreciate you taking the time to rate your experience.</p>
        <p>{CLICK_HERE_to_rate_your_experience}</p>
        <p>Sincerely,</p></p>{Sender_Name}<br>
        <strong>Email:</strong> {Sender_Email}<br>
        <strong>Phone:</strong> {Sender_Phone}</p>',
        
    'DiscountType' => [
        "per" => "On Percentage",
        "amt" => "On Amount"
    ],
    'Status' => [
        "A" => "Active",
        "I" => "Inactive"
    ]
];

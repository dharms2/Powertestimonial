/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 15, 2017
 */

ALTER TABLE `api_configurations`
	CHANGE COLUMN `realtor_details` `realtor_details` TEXT NULL COMMENT 'Details="Zillow Web Services ID (ZWSID)"' AFTER `zillow_screen_name`;

ALTER TABLE `api_configurations`
	CHANGE COLUMN `google_details` `google_place_id` TEXT NULL AFTER `user_id`;
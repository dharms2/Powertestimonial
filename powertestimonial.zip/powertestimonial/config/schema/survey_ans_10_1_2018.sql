/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Jan 10, 2018
 */

ALTER TABLE `survey_ans` 
    ADD `fourstaroption` TINYINT(1) NULL DEFAULT NULL COMMENT 'if user click four star then fourstaroption = 1->question,2->review' AFTER `survey_qus_id`;
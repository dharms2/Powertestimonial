/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Dec 20, 2017
 */

ALTER TABLE `user_plans`
	CHANGE COLUMN `start_dt` `start_dt` DATE NOT NULL DEFAULT '0000-00-00' AFTER `plan_id`,
	CHANGE COLUMN `end_dt` `end_dt` DATE NOT NULL DEFAULT '0000-00-00' AFTER `start_dt`,
	CHANGE COLUMN `amt` `amt` VARCHAR(50) NULL AFTER `end_dt`,
	CHANGE COLUMN `trans_id` `trans_id` INT(11) NULL AFTER `amt`;
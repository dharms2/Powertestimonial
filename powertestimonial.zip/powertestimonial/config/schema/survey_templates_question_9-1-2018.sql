/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Jan 9, 2018
 */

ALTER TABLE `survey_templates_question` ADD `fouroption` INT(1) NOT NULL AFTER `question`;


ALTER TABLE `survey_templates_question` CHANGE `fouroption` `fouroption` INT(1) NOT NULL DEFAULT '1' COMMENT '1=>question,2=>review chennel';


ALTER TABLE `survey_templates_question` CHANGE `fouroption` `fouroption` INT(1) NOT NULL COMMENT '1=>question,2=>review chennel';


ALTER TABLE `survey_templates_question` CHANGE `question` `question` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL COMMENT 'if star = 5,question ={1=>facebook,2=>yelp,3=>zillow,4=>google-plus,5=>realtor} if star = 4 and fouroption = 2 ,question ={1=>facebook,2=>yelp,3=>zillow,4=>google-plus,5=>realtor}';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Jan 5, 2018
 */

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `recipient_phone` `recipient_phone` VARCHAR(20) NULL DEFAULT NULL AFTER `recipient_email`;
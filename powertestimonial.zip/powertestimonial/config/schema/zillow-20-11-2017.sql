/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 20, 2017
 */

ALTER TABLE `zillow`
	CHANGE COLUMN `avg_rating` `avg_rating` DECIMAL(3,2) NULL DEFAULT '0' AFTER `review_count`,
	CHANGE COLUMN `local_knowledge_rating` `local_knowledge_rating` DECIMAL(3,2) NULL DEFAULT '0' AFTER `avg_rating`,
	CHANGE COLUMN `process_expertise_rating` `process_expertise_rating` DECIMAL(3,2) NULL DEFAULT '0' AFTER `local_knowledge_rating`,
	CHANGE COLUMN `responsiveness_rating` `responsiveness_rating` DECIMAL(3,2) NULL DEFAULT '0' AFTER `process_expertise_rating`,
	CHANGE COLUMN `negotiation_skills_rating` `negotiation_skills_rating` DECIMAL(3,2) NULL DEFAULT '0' AFTER `responsiveness_rating`;
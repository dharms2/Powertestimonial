-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.19-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table powertestimonial.acl_phinxlog
CREATE TABLE IF NOT EXISTS `acl_phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table powertestimonial.acl_phinxlog: ~0 rows (approximately)
/*!40000 ALTER TABLE `acl_phinxlog` DISABLE KEYS */;
INSERT INTO `acl_phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
	(20141229162641, 'CakePhpDbAcl', '2017-10-04 16:30:10', '2017-10-04 16:30:11', 0);
/*!40000 ALTER TABLE `acl_phinxlog` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.acos
CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`,`rght`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;

-- Dumping data for table powertestimonial.acos: ~111 rows (approximately)
/*!40000 ALTER TABLE `acos` DISABLE KEYS */;
INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(1, NULL, NULL, NULL, 'controllers', 1, 224),
	(2, 1, NULL, NULL, 'Error', 2, 3),
	(3, 1, NULL, NULL, 'Groups', 4, 15),
	(4, 3, NULL, NULL, 'index', 5, 6),
	(5, 3, NULL, NULL, 'view', 7, 8),
	(6, 3, NULL, NULL, 'add', 9, 10),
	(7, 3, NULL, NULL, 'edit', 11, 12),
	(8, 3, NULL, NULL, 'delete', 13, 14),
	(9, 1, NULL, NULL, 'Pages', 16, 19),
	(10, 9, NULL, NULL, 'display', 17, 18),
	(11, 1, NULL, NULL, 'Posts', 20, 31),
	(12, 11, NULL, NULL, 'index', 21, 22),
	(13, 11, NULL, NULL, 'view', 23, 24),
	(14, 11, NULL, NULL, 'add', 25, 26),
	(15, 11, NULL, NULL, 'edit', 27, 28),
	(16, 11, NULL, NULL, 'delete', 29, 30),
	(17, 1, NULL, NULL, 'Users', 32, 65),
	(18, 17, NULL, NULL, 'index', 33, 34),
	(22, 17, NULL, NULL, 'delete', 35, 36),
	(23, 17, NULL, NULL, 'login', 37, 38),
	(24, 17, NULL, NULL, 'logout', 39, 40),
	(25, 1, NULL, NULL, 'Acl', 66, 67),
	(26, 1, NULL, NULL, 'Bake', 68, 69),
	(41, 1, NULL, NULL, 'Migrations', 70, 71),
	(44, 17, NULL, NULL, 'associateDashboard', 43, 44),
	(45, 17, NULL, NULL, 'managerDashboard', 45, 46),
	(46, 17, NULL, NULL, 'addAssociate', 47, 48),
	(47, 17, NULL, NULL, 'addManager', 49, 50),
	(48, 17, NULL, NULL, 'editAssociate', 51, 52),
	(49, 17, NULL, NULL, 'editManager', 53, 54),
	(50, 17, NULL, NULL, 'updateStatus', 55, 56),
	(52, 1, NULL, NULL, 'Indexes', 72, 87),
	(53, 52, NULL, NULL, 'index', 73, 74),
	(54, 52, NULL, NULL, 'price', 75, 76),
	(55, 52, NULL, NULL, 'howItWork', 77, 78),
	(56, 52, NULL, NULL, 'contact', 79, 80),
	(57, 52, NULL, NULL, 'confirmSignup', 81, 82),
	(58, 17, NULL, NULL, 'emailTemplate', 57, 58),
	(59, 17, NULL, NULL, 'checkEmailIsUnique', 59, 60),
	(60, 1, NULL, NULL, 'Categories', 88, 105),
	(61, 60, NULL, NULL, 'viewCategory', 89, 90),
	(62, 60, NULL, NULL, 'editCategory', 91, 92),
	(63, 60, NULL, NULL, 'addCategory', 93, 94),
	(64, 60, NULL, NULL, 'addCategoryForm', 95, 96),
	(65, 60, NULL, NULL, 'editCategoryForm', 97, 98),
	(66, 60, NULL, NULL, 'deleteCategory', 99, 100),
	(67, 60, NULL, NULL, 'inactiveCategory', 101, 102),
	(68, 60, NULL, NULL, 'activeCategory', 103, 104),
	(69, 1, NULL, NULL, 'Questions', 106, 123),
	(70, 69, NULL, NULL, 'viewQuestion', 107, 108),
	(71, 69, NULL, NULL, 'editQuestion', 109, 110),
	(72, 69, NULL, NULL, 'addQuestion', 111, 112),
	(73, 69, NULL, NULL, 'addQuestionForm', 113, 114),
	(74, 69, NULL, NULL, 'editQuestionForm', 115, 116),
	(75, 69, NULL, NULL, 'deleteQuestion', 117, 118),
	(76, 69, NULL, NULL, 'inactiveQuestion', 119, 120),
	(77, 69, NULL, NULL, 'activeQuestion', 121, 122),
	(78, 1, NULL, NULL, 'Surveys', 124, 137),
	(79, 78, NULL, NULL, 'viewSurvey', 125, 126),
	(80, 78, NULL, NULL, 'addSurveys', 127, 128),
	(81, 78, NULL, NULL, 'editSurveys', 129, 130),
	(82, 78, NULL, NULL, 'addSurveysForm', 131, 132),
	(83, 78, NULL, NULL, 'editSurveysForm', 133, 134),
	(84, 78, NULL, NULL, 'deleteSurveys', 135, 136),
	(85, 1, NULL, NULL, 'Templates', 138, 143),
	(86, 85, NULL, NULL, 'viewTemplates', 139, 140),
	(87, 85, NULL, NULL, 'addTemplates', 141, 142),
	(88, 1, NULL, NULL, 'SurveyCategory', 144, 157),
	(89, 88, NULL, NULL, 'index', 145, 146),
	(90, 88, NULL, NULL, 'view', 147, 148),
	(91, 88, NULL, NULL, 'add', 149, 150),
	(92, 88, NULL, NULL, 'edit', 151, 152),
	(93, 88, NULL, NULL, 'delete', 153, 154),
	(94, 1, NULL, NULL, 'ReviewsMgmt', 158, 179),
	(95, 94, NULL, NULL, 'index', 159, 160),
	(96, 94, NULL, NULL, 'view', 161, 162),
	(97, 94, NULL, NULL, 'add', 163, 164),
	(98, 94, NULL, NULL, 'edit', 165, 166),
	(99, 94, NULL, NULL, 'delete', 167, 168),
	(100, 94, NULL, NULL, 'reviewStepOne', 169, 170),
	(101, 94, NULL, NULL, 'reviewStepTwo', 171, 172),
	(102, 52, NULL, NULL, 'invoice', 83, 84),
	(103, 17, NULL, NULL, 'getName', 61, 62),
	(104, 88, NULL, NULL, 'updateStatus', 155, 156),
	(105, 17, NULL, NULL, 'register', 63, 64),
	(106, 52, NULL, NULL, 'emailContact', 85, 86),
	(107, 94, NULL, NULL, 'emailReview', 173, 174),
	(108, 94, NULL, NULL, 'rating', 175, 176),
	(109, 1, NULL, NULL, 'SurveyMgmt', 180, 193),
	(110, 109, NULL, NULL, 'index', 181, 182),
	(111, 109, NULL, NULL, 'view', 183, 184),
	(112, 109, NULL, NULL, 'add', 185, 186),
	(113, 109, NULL, NULL, 'edit', 187, 188),
	(114, 109, NULL, NULL, 'delete', 189, 190),
	(115, 109, NULL, NULL, 'updateStatus', 191, 192),
	(116, 1, NULL, NULL, 'SurveyQuestion', 194, 207),
	(117, 116, NULL, NULL, 'index', 195, 196),
	(118, 116, NULL, NULL, 'view', 197, 198),
	(119, 116, NULL, NULL, 'add', 199, 200),
	(120, 116, NULL, NULL, 'edit', 201, 202),
	(121, 116, NULL, NULL, 'delete', 203, 204),
	(122, 116, NULL, NULL, 'updateStatus', 205, 206),
	(123, 1, NULL, NULL, 'SurveyTemplates', 208, 223),
	(124, 123, NULL, NULL, 'index', 209, 210),
	(125, 123, NULL, NULL, 'view', 211, 212),
	(126, 123, NULL, NULL, 'add', 213, 214),
	(127, 123, NULL, NULL, 'edit', 215, 216),
	(128, 123, NULL, NULL, 'delete', 217, 218),
	(129, 123, NULL, NULL, 'updateStatus', 219, 220),
	(130, 94, NULL, NULL, 'getNextQuestion', 177, 178),
	(131, 123, NULL, NULL, 'chooseQuestion', 221, 222);
/*!40000 ALTER TABLE `acos` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.api_services
CREATE TABLE IF NOT EXISTS `api_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `api` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `api_url` text COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table powertestimonial.api_services: ~4 rows (approximately)
/*!40000 ALTER TABLE `api_services` DISABLE KEYS */;
INSERT INTO `api_services` (`id`, `api`, `api_url`, `created`, `modified`) VALUES
	(1, 'google', 'www.google.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(2, 'yelp', 'www.yelp.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(3, 'facebook', 'www.facebook.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(4, 'zillow', 'www.zillow.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `api_services` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.aros
CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`,`rght`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

-- Dumping data for table powertestimonial.aros: ~62 rows (approximately)
/*!40000 ALTER TABLE `aros` DISABLE KEYS */;
INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(2, NULL, 'Groups', 1, NULL, 1, 4),
	(3, NULL, 'Groups', 2, NULL, 5, 110),
	(4, NULL, 'Groups', 3, NULL, 111, 120),
	(5, NULL, 'Groups', 4, NULL, 121, 146),
	(17, 3, 'Users', 10, NULL, 20, 21),
	(18, 3, 'Users', 11, NULL, 22, 23),
	(20, 4, 'Users', 13, NULL, 116, 117),
	(25, 4, 'Users', 18, NULL, 118, 119),
	(26, 5, 'Users', 19, NULL, 124, 125),
	(27, 3, 'Users', 20, NULL, 24, 25),
	(28, 3, 'Users', 21, NULL, 26, 27),
	(29, 5, 'Users', 22, NULL, 126, 127),
	(31, 5, 'Users', 24, NULL, 128, 129),
	(32, 3, 'Users', 25, NULL, 28, 29),
	(33, 3, 'Users', 26, NULL, 30, 31),
	(34, 5, 'Users', 27, NULL, 130, 131),
	(35, 3, 'Users', 28, NULL, 32, 33),
	(36, 3, 'Users', 29, NULL, 34, 35),
	(37, 5, 'Users', 30, NULL, 132, 133),
	(38, 3, 'Users', 31, NULL, 36, 37),
	(39, 3, 'Users', 32, NULL, 38, 39),
	(40, 3, 'Users', 33, NULL, 40, 41),
	(41, 5, 'Users', 34, NULL, 134, 135),
	(42, 3, 'Users', 35, NULL, 42, 43),
	(43, 3, 'Users', 36, NULL, 44, 45),
	(44, 3, 'Users', 37, NULL, 46, 47),
	(45, 5, 'Users', 38, NULL, 136, 137),
	(46, 3, 'Users', 39, NULL, 48, 49),
	(47, 5, 'Users', 40, NULL, 138, 139),
	(48, 5, 'Users', 41, NULL, 140, 141),
	(49, 3, 'Users', 42, NULL, 50, 51),
	(50, 3, 'Users', 43, NULL, 52, 53),
	(51, 3, 'Users', 44, NULL, 54, 55),
	(52, 3, 'Users', 45, NULL, 56, 57),
	(53, 3, 'Users', 46, NULL, 58, 59),
	(54, 3, 'Users', 47, NULL, 60, 61),
	(55, 3, 'Users', 48, NULL, 62, 63),
	(56, 3, 'Users', 49, NULL, 64, 65),
	(57, 3, 'Users', 50, NULL, 66, 67),
	(58, 3, 'Users', 51, NULL, 68, 69),
	(59, 3, 'Users', 52, NULL, 70, 71),
	(60, 3, 'Users', 53, NULL, 72, 73),
	(61, 3, 'Users', 54, NULL, 74, 75),
	(62, 3, 'Users', 55, NULL, 76, 77),
	(63, 3, 'Users', 56, NULL, 78, 79),
	(64, 3, 'Users', 57, NULL, 80, 81),
	(65, 3, 'Users', 58, NULL, 82, 83),
	(66, 3, 'Users', 59, NULL, 84, 85),
	(67, 3, 'Users', 60, NULL, 86, 87),
	(68, 3, 'Users', 61, NULL, 88, 89),
	(69, 3, 'Users', 62, NULL, 90, 91),
	(70, 3, 'Users', 63, NULL, 92, 93),
	(71, 3, 'Users', 64, NULL, 94, 95),
	(72, 3, 'Users', 65, NULL, 96, 97),
	(73, 5, 'Users', 66, NULL, 142, 143),
	(74, 3, 'Users', 67, NULL, 98, 99),
	(75, 3, 'Users', 68, NULL, 100, 101),
	(76, 3, 'Users', 69, NULL, 102, 103),
	(77, 5, 'Users', 70, NULL, 144, 145),
	(79, 3, 'Users', 72, NULL, 104, 105),
	(80, 3, 'Users', 73, NULL, 106, 107),
	(81, 3, 'Users', 74, NULL, 108, 109);
/*!40000 ALTER TABLE `aros` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.aros_acos
CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aro_id` int(11) NOT NULL,
  `aco_id` int(11) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `aro_id` (`aro_id`,`aco_id`),
  KEY `aco_id` (`aco_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table powertestimonial.aros_acos: ~8 rows (approximately)
/*!40000 ALTER TABLE `aros_acos` DISABLE KEYS */;
INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
	(1, 2, 1, '1', '1', '1', '1'),
	(2, 3, 1, '1', '1', '1', '1'),
	(3, 3, 24, '1', '1', '1', '1'),
	(4, 2, 24, '1', '1', '1', '1'),
	(5, 5, 1, '1', '1', '1', '1'),
	(6, 5, 44, '-1', '-1', '-1', '-1'),
	(7, 5, 48, '-1', '-1', '-1', '-1'),
	(8, 5, 46, '-1', '-1', '-1', '-1');
/*!40000 ALTER TABLE `aros_acos` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.contact_us
CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(14) NOT NULL,
  `content` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.contact_us: ~8 rows (approximately)
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `content`, `created`) VALUES
	(1, 'fdhfdbhg', 'gfhf@gmail.com', 1234567890, 'gfgfgfdnhg', '2017-10-26 18:23:41'),
	(2, 'Dharm', 'dharmveer@gmail.com', 1234567890, 'sdffbvgfds', '2017-10-26 18:25:21'),
	(3, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:24:07'),
	(4, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:24:16'),
	(5, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:25:08'),
	(6, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:26:06'),
	(7, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:27:28'),
	(8, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:28:01'),
	(9, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:28:49');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.country
CREATE TABLE IF NOT EXISTS `country` (
  `cty_iso_code` varchar(3) NOT NULL,
  `cty_desc` varchar(40) NOT NULL,
  `cty_phone_code` varchar(6) NOT NULL,
  `cty_code` varchar(20) NOT NULL,
  PRIMARY KEY (`cty_iso_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.country: ~236 rows (approximately)
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`cty_iso_code`, `cty_desc`, `cty_phone_code`, `cty_code`) VALUES
	('AD', 'ANDORRA', '376', 'AD'),
	('AE', 'UNITED ARAB EMIRATES', '971', 'AE'),
	('AF', 'AFGHANISTAN', '93', 'AF'),
	('AG', 'ANTIGUA AND BARBUDA', '809', 'ATG'),
	('AI', 'ANGUILLA', '809', 'AI'),
	('AL', 'ALBANIA', '355', 'AL'),
	('AM', 'ARMENIA', '374', 'AM'),
	('AN', 'NETHERLANDS ANTILLES', '599', 'AN'),
	('AO', 'ANGOLA', '244', 'AO'),
	('AQ', 'ANTARCTICA', '672', 'AQ'),
	('AR', 'ARGENTINA', '54', 'ARG'),
	('AS', 'AMERICAN SAMOA', '684', 'AS'),
	('AT', 'AUSTRIA', '43', 'AUT'),
	('AU', 'AUSTRALIA', '61', 'AUS'),
	('AW', 'ARUBA', '297', 'ABW'),
	('AZ', 'AZERBAIJAN', '994', 'AZ'),
	('BA', 'BOSNIA AND HERZEGOVINA', '387', 'BA'),
	('BB', 'BARBADOS', '809', 'BRB'),
	('BD', 'BANGLADESH', '880', 'BD'),
	('BE', 'BELGIUM', '321', 'BEL'),
	('BF', 'BURKINA FASO', '226', 'BF'),
	('BG', 'BULGARIA', '359', 'BG'),
	('BH', 'BAHRAIN', '973', 'BH'),
	('BI', 'BURUNDI', '257', 'BI'),
	('BJ', 'BENIN', '229', 'BJ'),
	('BM', 'BERMUDA', '809', 'BMU'),
	('BN', 'BRUNEI DARUSSALAM', '673', 'BN'),
	('BO', 'BOLIVIA', '591', 'BO'),
	('BR', 'BRAZIL', '55', 'BRA'),
	('BS', 'BAHAMAS', '1', 'BHS'),
	('BT', 'BHUTAN', '975', 'BT'),
	('BV', 'BOUVET ISLAND', '', 'BV'),
	('BW', 'BOTSWANA', '267', 'BW'),
	('BY', 'BELARUS', '375', 'BY'),
	('BZ', 'BELIZE', '501', 'BZ'),
	('CA', 'CANADA', '1', 'CA'),
	('CC', 'COCOS (KEELING) ISLANDS', '672', 'CCK'),
	('CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', '242', 'CD'),
	('CF', 'CENTRAL AFRICAN REPUBLIC', '236', 'CF'),
	('CG', 'CONGO', '242', 'CG'),
	('CH', 'SWITZERLAND', '41', 'CH'),
	('CI', 'COTE D\'IVOIRE', '225', 'CI'),
	('CK', 'COOK ISLANDS', '682', 'CK'),
	('CL', 'CHILE', '56', 'CL'),
	('CM', 'CAMEROON', '237', 'CM'),
	('CN', 'CHINA', '86', 'CN'),
	('CO', 'COLOMBIA', '57', 'COL'),
	('CR', 'COSTA RICA', '506', 'CRI'),
	('CU', 'CUBA', '53', 'CU'),
	('CV', 'CAPE VERDE', '809', 'CV'),
	('CX', 'CHRISTMAS ISLAND', '672', 'CX'),
	('CY', 'CYPRUS', '357', 'CY'),
	('CZ', 'CZECH REPUBLIC', '42', 'CZ'),
	('DE', 'GERMANY', '49', 'DEU'),
	('DJ', 'DJIBOUTI', '253', 'DJ'),
	('DK', 'DENMARK', '45', 'DNK'),
	('DM', 'DOMINICA', '809', 'DM'),
	('DO', 'DOMINICAN REPUBLIC', '809', 'DO'),
	('DZ', 'ALGERIA', '213', 'DZ'),
	('EC', 'ECUADOR', '592', 'EC'),
	('EE', 'ESTONIA', '372', 'EE'),
	('EG', 'EGYPT', '20', 'EG'),
	('EH', 'WESTERN SAHARA', '', 'EH'),
	('ER', 'ERITREA', '291', 'ER'),
	('ES', 'SPAIN', '349', 'ES'),
	('ET', 'ETHIOPIA', '251', 'ET'),
	('FI', 'FINLAND', '358', 'FI'),
	('FJ', 'FIJI', '679', 'FJ'),
	('FK', 'FALKLAND ISLANDS (MALVINAS)', '500', 'FK'),
	('FM', 'MICRONESIA, FEDERATED STATES OF', '691', 'FM'),
	('FO', 'FAROE ISLANDS', '298', 'FO'),
	('FR', 'FRANCE', '33', 'FR'),
	('GA', 'GABON', '241', 'GA'),
	('GB', 'UNITED KINGDOM', '44', 'GB'),
	('GD', 'GRENADA', '809', 'GD'),
	('GE', 'GEORGIA', '995', 'GE'),
	('GF', 'FRENCH GUIANA', '594', 'GF'),
	('GH', 'GHANA', '233', 'GH'),
	('GI', 'GIBRALTAR', '350', 'GI'),
	('GL', 'GREENLAND', '299', 'GL'),
	('GM', 'GAMBIA', '220', 'GM'),
	('GN', 'GUINEA', '224', 'GN'),
	('GP', 'GUADELOUPE', '590', 'GP'),
	('GQ', 'EQUATORIAL GUINEA', '240', 'GQ'),
	('GR', 'GREECE', '30', 'GR'),
	('GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISL', '', 'GS'),
	('GT', 'GUATEMALA', '502', 'GT'),
	('GW', 'GUINEA-BISSAU', '245', 'GW'),
	('GY', 'GUYANA', '592', 'GY'),
	('HK', 'HONG KONG', '852', 'HK'),
	('HM', 'HEARD ISLAND AND MCDONALD ISLANDS', '', 'HM'),
	('HN', 'HONDURAS', '504', 'HN'),
	('HR', 'CROATIA', '385', 'HR'),
	('HT', 'HAITI', '509', 'HT'),
	('HU', 'HUNGARY', '36', 'HU'),
	('ID', 'INDONESIA', '62', 'ID'),
	('IE', 'IRELAND', '353', 'IE'),
	('IL', 'ISRAEL', '972', 'IL'),
	('IN', 'INDIA', '91', 'IN'),
	('IO', 'BRITISH INDIAN OCEAN TERRITORY', '0', 'IO'),
	('IQ', 'IRAQ', '964', 'IQ'),
	('IR', 'IRAN, ISLAMIC REPUBLIC OF', '98', 'IR'),
	('IS', 'ICELAND', '354', 'IS'),
	('IT', 'ITALY', '39', 'IT'),
	('JM', 'JAMAICA', '809', 'JM'),
	('JO', 'JORDAN', '962', 'JO'),
	('JP', 'JAPAN', '81', 'JP'),
	('KE', 'KENYA', '254', 'KE'),
	('KG', 'KYRGYZSTAN', '7', 'KG'),
	('KH', 'CAMBODIA', '855', 'KH'),
	('KI', 'KIRIBATI', '686', 'KI'),
	('KM', 'COMOROS', '269', 'KM'),
	('KN', 'SAINT KITTS AND NEVIS', '809', 'KN'),
	('KP', 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', '82', 'KP'),
	('KR', 'KOREA, REPUBLIC OF', '82', 'KR'),
	('KW', 'KUWAIT', '965', 'KW'),
	('KY', 'CAYMAN ISLANDS', '809', 'KY'),
	('KZ', 'KAZAKHSTAN', '7', 'KZ'),
	('LA', 'LAO PEOPLE\'S DEMOCRATIC REPUBLIC', '21', 'LA'),
	('LB', 'LEBANON', '961', 'LB'),
	('LC', 'SAINT LUCIA', '809', 'LC'),
	('LI', 'LIECHTENSTEIN', '417', 'LI'),
	('LK', 'SRI LANKA', '94', 'LK'),
	('LR', 'LIBERIA', '231', 'LR'),
	('LS', 'LESOTHO', '266', 'LS'),
	('LT', 'LITHUANIA', '370', 'LT'),
	('LU', 'LUXEMBOURG', '352', 'LU'),
	('LV', 'LATVIA', '371', 'LV'),
	('LY', 'LIBYAN ARAB JAMAHIRIYA', '218', 'LY'),
	('MA', 'MOROCCO', '212', 'MA'),
	('MC', 'MONACO', '339', 'MC'),
	('MD', 'MOLDOVA, REPUBLIC OF', '373', 'MD'),
	('MG', 'MADAGASCAR', '261', 'MG'),
	('MH', 'MARSHALL ISLANDS', '692', 'MH'),
	('MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC', '389', 'MK'),
	('ML', 'MALI', '223', 'ML'),
	('MM', 'MYANMAR', '95', 'MM'),
	('MN', 'MONGOLIA', '976', 'MN'),
	('MO', 'MACAO', '853', 'MO'),
	('MP', 'NORTHERN MARIANA ISLANDS', '670', 'MP'),
	('MQ', 'MARTINIQUE', '596', 'MQ'),
	('MR', 'MAURITANIA', '222', 'MR'),
	('MS', 'MONTSERRAT', '809', 'MS'),
	('MT', 'MALTA', '356', 'MT'),
	('MU', 'MAURITIUS', '230', 'MU'),
	('MV', 'MALDIVES', '960', 'MV'),
	('MW', 'MALAWI', '265', 'MW'),
	('MX', 'MEXICO', '52', 'MX'),
	('MY', 'MALAYSIA', '60', 'MY'),
	('MZ', 'MOZAMBIQUE', '258', 'MZ'),
	('NA', 'NAMIBIA', '264', 'NA'),
	('NC', 'NEW CALEDONIA', '687', 'NC'),
	('NE', 'NIGER', '227', 'NE'),
	('NF', 'NORFOLK ISLAND', '6723', 'NF'),
	('NG', 'NIGERIA', '234', 'NG'),
	('NI', 'NICARAGUA', '505', 'NI'),
	('NL', 'NETHERLANDS', '31', 'NL'),
	('NO', 'NORWAY', '47', 'NO'),
	('NP', 'NEPAL', '977', 'NP'),
	('NR', 'NAURU', '674', 'NR'),
	('NU', 'NIUE', '683', 'NU'),
	('NZ', 'NEW ZEALAND', '64', 'NZ'),
	('OM', 'OMAN', '968', 'OM'),
	('PA', 'PANAMA', '507', 'PA'),
	('PE', 'PERU', '51', 'PE'),
	('PF', 'FRENCH POLYNESIA', '689', 'PF'),
	('PG', 'PAPUA NEW GUINEA', '675', 'PG'),
	('PH', 'PHILIPPINES', '63', 'PH'),
	('PK', 'PAKISTAN', '92', 'PK'),
	('PL', 'POLAND', '48', 'PL'),
	('PM', 'SAINT PIERRE AND MIQUELON', '508', 'PM'),
	('PN', 'PITCAIRN', '', 'PN'),
	('PS', 'PALESTINIAN TERRITORY, OCCUPIED', '970', 'PS'),
	('PT', 'PORTUGAL', '351', 'PT'),
	('PW', 'PALAU', '680', 'PW'),
	('PY', 'PARAGUAY', '595', 'PY'),
	('QA', 'QATAR', '974', 'QA'),
	('RE', 'REUNION', '262', 'RE'),
	('RO', 'ROMANIA', '40', 'RO'),
	('RU', 'RUSSIAN FEDERATION', '7', 'RU'),
	('RW', 'RWANDA', '250', 'RW'),
	('SA', 'SAUDI ARABIA', '966', 'SA'),
	('SB', 'SOLOMON ISLANDS', '677', 'SB'),
	('SC', 'SEYCHELLES', '248', 'SC'),
	('SD', 'SUDAN', '249', 'SD'),
	('SE', 'SWEDEN', '46', 'SE'),
	('SG', 'SINGAPORE', '65', 'SG'),
	('SH', 'SAINT HELENA', '290', 'SH'),
	('SI', 'SLOVENIA', '386', 'SI'),
	('SJ', 'SVALBARD AND JAN MAYEN', '47', 'SJ'),
	('SK', 'SLOVAKIA', '42', 'SK'),
	('SL', 'SIERRA LEONE', '232', 'SL'),
	('SM', 'SAN MARINO', '395', 'SM'),
	('SN', 'SENEGAL', '221', 'SN'),
	('SO', 'SOMALIA', '252', 'SO'),
	('SR', 'SURINAME', '597', 'SR'),
	('ST', 'SAO TOME AND PRINCIPE', '239', 'ST'),
	('SV', 'EL SALVADOR', '503', 'SV'),
	('SY', 'SYRIAN ARAB REPUBLIC', '963', 'SY'),
	('SZ', 'SWAZILAND', '268', 'SZ'),
	('TC', 'TURKS AND CAICOS ISLANDS', '809', 'TC'),
	('TD', 'CHAD', '235', 'TD'),
	('TF', 'FRENCH SOUTHERN TERRITORIES', '', 'TF'),
	('TG', 'TOGO', '228', 'TG'),
	('TH', 'THAILAND', '66', 'TH'),
	('TJ', 'TAJIKISTAN', '7', 'TJ'),
	('TK', 'TOKELAU', '690', 'TK'),
	('TL', 'TIMOR-LESTE', '670', 'TL'),
	('TM', 'TURKMENISTAN', '7', 'TM'),
	('TN', 'TUNISIA', '216', 'TN'),
	('TO', 'TONGA', '676', 'TO'),
	('TR', 'TURKEY', '90', 'TR'),
	('TT', 'TRINIDAD AND TOBAGO', '868', 'TT'),
	('TV', 'TUVALU', '688', 'TV'),
	('TW', 'TAIWAN, PROVINCE OF CHINA', '886', 'TW'),
	('TZ', 'TANZANIA, UNITED REPUBLIC OF', '255', 'TZ'),
	('UA', 'UKRAINE', '380', 'UA'),
	('UG', 'UGANDA', '256', 'UG'),
	('UM', 'UNITED STATES MINOR OUTLYING ISLANDS', '', 'UM'),
	('US', 'UNITED STATES', '1', 'US'),
	('UY', 'URUGUAY', '598', 'UY'),
	('UZ', 'UZBEKISTAN', '7', 'UZ'),
	('VA', 'HOLY SEE (VATICAN CITY STATE)', '396', 'VA'),
	('VC', 'SAINT VINCENT AND THE GRENADINES', '809', 'VC'),
	('VE', 'VENEZUELA', '58', 'VE'),
	('VG', 'VIRGIN ISLANDS, BRITISH', '340', 'VG'),
	('VN', 'VIETNAM', '84', 'VN'),
	('VU', 'VANUATU', '678', 'VU'),
	('WF', 'WALLIS AND FUTUNA', '681', 'WF'),
	('WS', 'SAMOA', '684', 'WS'),
	('YE', 'YEMEN', '967', 'YE'),
	('YT', 'MAYOTTE', '2696', 'YT'),
	('YU', 'YUGOSLAVIA', '381', 'YU'),
	('ZA', 'SOUTH AFRICA', '27', 'ZA'),
	('ZM', 'ZAMBIA', '260', 'ZM'),
	('ZW', 'ZIMBABWE', '263', 'ZW');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.coupons
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(150) NOT NULL,
  `max_amt` int(11) NOT NULL,
  `percentage` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.coupons: ~0 rows (approximately)
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`id`, `code`, `max_amt`, `percentage`, `description`, `created`, `modified`) VALUES
	(1, 'ABCD', 10, 5, 'Testing', '2017-10-16 10:10:10', '2017-10-16 10:10:10');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.googles
CREATE TABLE IF NOT EXISTS `googles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `google_place_id` text COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table powertestimonial.googles: ~0 rows (approximately)
/*!40000 ALTER TABLE `googles` DISABLE KEYS */;
/*!40000 ALTER TABLE `googles` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.groups
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.groups: ~4 rows (approximately)
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`id`, `name`, `created`, `modified`) VALUES
	(1, 'Super Admin ', '2017-10-04 22:10:12', '2017-10-12 15:29:08'),
	(2, 'Company Representative', '2017-10-04 22:10:32', '2017-10-12 15:29:10'),
	(3, 'Company Managers', '2017-10-04 22:10:55', '2017-10-12 15:29:12'),
	(4, 'Associates/Agents ', '2017-10-04 22:11:19', '2017-10-12 15:29:15');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.payment_details
CREATE TABLE IF NOT EXISTS `payment_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `card_num` int(16) NOT NULL,
  `expiry_date` varchar(50) NOT NULL,
  `security_code` varchar(5) NOT NULL,
  `card_holder_name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_payment_details_users` (`user_id`),
  CONSTRAINT `FK_payment_details_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.payment_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `payment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_details` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.personal_site_reviews
CREATE TABLE IF NOT EXISTS `personal_site_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratings` int(5) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `completion_date` date NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.personal_site_reviews: ~0 rows (approximately)
/*!40000 ALTER TABLE `personal_site_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_site_reviews` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.plans
CREATE TABLE IF NOT EXISTS `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `amt` decimal(10,2) NOT NULL DEFAULT '0.00',
  `setup_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.plans: ~3 rows (approximately)
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` (`id`, `name`, `amt`, `setup_fee`, `created`, `modified`) VALUES
	(1, 'Power', 49.00, 50.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(2, 'Power Plus', 129.00, 50.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(3, 'Ultimate Power', 249.00, 100.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.plan_features
CREATE TABLE IF NOT EXISTS `plan_features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.plan_features: ~18 rows (approximately)
/*!40000 ALTER TABLE `plan_features` DISABLE KEYS */;
INSERT INTO `plan_features` (`id`, `name`, `created`, `modified`) VALUES
	(1, '1 User Account', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(2, '5 star rating system', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(3, 'Auto review requests', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(4, 'Real time alerts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(5, 'Auto email reminders', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(6, 'At a glance analysis', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(7, 'Web review widgets', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(8, 'Free tech support', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(9, 'Custom branded', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(10, 'Full device optimization', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(11, 'Review request button on your website and emails', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(12, 'Up to 10 User Accounts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(13, 'Up to 5 customized surveys/reviews', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(14, 'Individual account branding', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(15, 'Up to 25 User Accounts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(16, 'Individual custom branding', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(17, 'Up to 25 customized surveys and reviews', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(18, 'Text integration', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(19, 'Review analysis', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(20, 'Free Microsite', '2017-10-13 10:10:10', '2017-10-13 10:10:10');
/*!40000 ALTER TABLE `plan_features` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.plan_features_xref
CREATE TABLE IF NOT EXISTS `plan_features_xref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `plan_features_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_plan_features_xref_plans` (`plan_id`),
  KEY `FK_plan_features_xref_plan_features` (`plan_features_id`),
  CONSTRAINT `FK_plan_features_xref_plan_features` FOREIGN KEY (`plan_features_id`) REFERENCES `plan_features` (`id`),
  CONSTRAINT `FK_plan_features_xref_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.plan_features_xref: ~2 rows (approximately)
/*!40000 ALTER TABLE `plan_features_xref` DISABLE KEYS */;
INSERT INTO `plan_features_xref` (`id`, `plan_id`, `plan_features_id`) VALUES
	(1, 1, 1),
	(2, 1, 2),
	(3, 1, 2);
/*!40000 ALTER TABLE `plan_features_xref` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.posts
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_posts_users` (`user_id`),
  CONSTRAINT `FK_posts_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.posts: ~0 rows (approximately)
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.post_rating
CREATE TABLE IF NOT EXISTS `post_rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `rating_number` int(11) NOT NULL,
  `total_points` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = Block, 0 = Unblock',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table powertestimonial.post_rating: ~0 rows (approximately)
/*!40000 ALTER TABLE `post_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_rating` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.profile_images
CREATE TABLE IF NOT EXISTS `profile_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `img_url` varchar(500) DEFAULT NULL,
  `business_img_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_profile_images_users` (`user_id`),
  CONSTRAINT `FK_profile_images_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.profile_images: ~0 rows (approximately)
/*!40000 ALTER TABLE `profile_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_images` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.reviews_mgmt
CREATE TABLE IF NOT EXISTS `reviews_mgmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_first_name` varchar(50) NOT NULL,
  `recipient_last_name` varchar(50) NOT NULL,
  `recipient_email` varchar(50) NOT NULL,
  `recipient_phone` bigint(14) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=Sent, 2=Complete, 3=Pending Survey',
  `user_action` int(1) NOT NULL COMMENT '1=Google Review, 2=Facebook Review, 3=Yelp Review, 4=Zillow Review, 5=Survey, 6=Realtor Review',
  `ratings` int(5) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_reviews_mgmt_users` (`user_id`),
  KEY `FK_reviews_mgmt_survey_mgmt` (`survey_id`),
  CONSTRAINT `FK_reviews_mgmt_survey_mgmt` FOREIGN KEY (`survey_id`) REFERENCES `survey_mgmt` (`id`),
  CONSTRAINT `FK_reviews_mgmt_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.reviews_mgmt: ~14 rows (approximately)
/*!40000 ALTER TABLE `reviews_mgmt` DISABLE KEYS */;
INSERT INTO `reviews_mgmt` (`id`, `recipient_first_name`, `recipient_last_name`, `recipient_email`, `recipient_phone`, `survey_id`, `user_id`, `status`, `user_action`, `ratings`, `created`, `modified`) VALUES
	(1, 'test', 'user', 'test@yopmail.com', 1234567890, 4, 11, 2, 0, 5, '2017-10-25 06:25:25', '2017-10-25 06:25:25'),
	(2, 'test1', 'user2', 'test1@yopmail.com', 1234567890, 4, 11, 2, 0, 5, '2017-10-25 06:25:25', '2017-10-25 06:25:25'),
	(3, 'dsfsdg', 'fsdgbv', 'sdfgsdf@gmail.com', 0, 4, 10, 1, 0, 0, '2017-10-25 21:46:19', '2017-10-25 21:46:19'),
	(4, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 10, 1, 0, 0, '2017-10-25 21:47:06', '2017-10-25 21:47:06'),
	(5, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, '2017-10-26 19:44:04', '2017-10-26 19:44:04'),
	(6, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, '2017-10-26 19:45:11', '2017-10-26 19:45:11'),
	(7, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, '2017-10-26 19:45:43', '2017-10-26 19:45:43'),
	(8, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, '2017-10-26 19:50:28', '2017-10-26 19:50:28'),
	(9, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, '2017-10-26 19:51:22', '2017-10-26 19:51:22'),
	(10, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 5, '2017-10-26 19:52:11', '2017-10-27 18:28:27'),
	(11, 'Dharm', 'Singh', 'dharmveer@gmail.com', 2147483647, 4, 33, 1, 1, 4, '2017-10-26 19:53:47', '2017-10-27 18:29:42'),
	(12, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 33, 1, 0, 0, '2017-10-26 19:55:22', '2017-10-26 19:55:22'),
	(13, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 4, 33, 1, 1, 4, '2017-10-26 19:58:05', '2017-10-27 17:21:58'),
	(14, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 33, 1, 1, 5, '2017-10-26 20:00:30', '2017-10-27 17:19:55'),
	(15, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 34, 1, 1, 3, '2017-10-26 20:02:34', '2017-10-27 16:26:00');
/*!40000 ALTER TABLE `reviews_mgmt` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.settings
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_details` text NOT NULL,
  `google_end_url` text NOT NULL,
  `google_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `facebook_details` text NOT NULL,
  `facebook_end_url` text NOT NULL,
  `facebook_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `yelp_details` text NOT NULL,
  `yelp_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `zillow_details` text NOT NULL,
  `zillow_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `realtor_details` text NOT NULL,
  `realtor_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.settings: ~0 rows (approximately)
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_ans
CREATE TABLE IF NOT EXISTS `survey_ans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_mgmt_id` int(11) NOT NULL,
  `survey_qus_id` int(11) NOT NULL,
  `answers` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_survey_ans_survey_mgmt` (`survey_mgmt_id`),
  KEY `FK_survey_ans_survey_qus` (`survey_qus_id`),
  CONSTRAINT `FK_survey_ans_survey_mgmt` FOREIGN KEY (`survey_mgmt_id`) REFERENCES `survey_mgmt` (`id`),
  CONSTRAINT `FK_survey_ans_survey_qus` FOREIGN KEY (`survey_qus_id`) REFERENCES `survey_qus_old` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_ans: ~0 rows (approximately)
/*!40000 ALTER TABLE `survey_ans` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_ans` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_category
CREATE TABLE IF NOT EXISTS `survey_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_category: ~7 rows (approximately)
/*!40000 ALTER TABLE `survey_category` DISABLE KEYS */;
INSERT INTO `survey_category` (`id`, `name`, `description`, `status`, `created`, `modified`) VALUES
	(3, 'New Category1', 'Best Category of Question123123', 0, '2017-10-23 12:27:11', '2017-10-26 15:02:27'),
	(4, 'Baum category', 'Best Category of the year', 0, '2017-10-18 11:31:35', '2017-10-26 14:59:52'),
	(5, 'Test Category1', 'Best category', 0, '2017-10-23 10:34:49', '2017-10-23 10:34:49'),
	(6, 'Test category New1', 'Test123', 0, '2017-10-23 12:26:20', '2017-10-23 12:26:20'),
	(7, 'Category1', 'testing data', 0, '2017-10-23 14:01:52', '2017-10-23 14:01:52'),
	(8, 'new catogry', 'testing', 1, '2017-10-23 14:01:52', '2017-10-23 14:01:52');
/*!40000 ALTER TABLE `survey_category` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_mgmt
CREATE TABLE IF NOT EXISTS `survey_mgmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `survey_template_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_mgmt: ~4 rows (approximately)
/*!40000 ALTER TABLE `survey_mgmt` DISABLE KEYS */;
INSERT INTO `survey_mgmt` (`id`, `user_id`, `name`, `description`, `survey_template_id`, `status`, `created`, `modified`) VALUES
	(4, 11, ' Health Literacy Assessment', 'cdsgzdhdrh', 1, 1, '2017-10-22 18:30:00', '0000-00-00 00:00:00'),
	(6, 11, 'Test Survey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, '2017-10-24 08:52:44', '2017-10-24 08:52:44'),
	(8, 11, 'Testing Suirvey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, '2017-10-24 08:53:35', '2017-10-24 08:53:35'),
	(9, 11, 'Test Category Survey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, '2017-10-24 09:06:34', '2017-10-24 09:06:34');
/*!40000 ALTER TABLE `survey_mgmt` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_question
CREATE TABLE IF NOT EXISTS `survey_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `questions` varchar(500) NOT NULL,
  `qus_types` int(1) NOT NULL COMMENT '1=Radio, 2=Checkbox',
  `ans_choices` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_question: ~5 rows (approximately)
/*!40000 ALTER TABLE `survey_question` DISABLE KEYS */;
INSERT INTO `survey_question` (`id`, `category_id`, `questions`, `qus_types`, `ans_choices`, `correct_ans`, `status`, `created`, `modified`) VALUES
	(1, 5, 'Is test questions ?', 0, 'A,B,C,Yes', '1', 1, '2017-10-27 18:32:31', '2017-10-27 19:35:02'),
	(2, 5, 'What is your name 1 ?', 0, 'Dharm,Veer,Singh,Dharm Veer Singh', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:29:05'),
	(3, 5, 'What is your name 2 ?', 0, 'Dharm2,Veer2,Singh2,Dharm Veer Singh2', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:33:56'),
	(4, 5, 'What is your name 3 ?', 0, 'Dharm3,Veer3,Singh3,Dharm Veer Singh3', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:34:18'),
	(5, 5, 'What is your name 3 ?', 0, 'Dharm3,Veer3,Singh3,Dharm Veer Singh3', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:34:18');
/*!40000 ALTER TABLE `survey_question` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_qus_old
CREATE TABLE IF NOT EXISTS `survey_qus_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_mgmt_id` int(11) NOT NULL,
  `questions` varchar(500) NOT NULL,
  `qus_types` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Enable, 0=Disable',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_survey_qus_survey_mgmt` (`survey_mgmt_id`),
  CONSTRAINT `FK_survey_qus_survey_mgmt` FOREIGN KEY (`survey_mgmt_id`) REFERENCES `survey_mgmt` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_qus_old: ~0 rows (approximately)
/*!40000 ALTER TABLE `survey_qus_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_qus_old` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_templates
CREATE TABLE IF NOT EXISTS `survey_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `category` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `greeting` text NOT NULL,
  `footer` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_templates: ~2 rows (approximately)
/*!40000 ALTER TABLE `survey_templates` DISABLE KEYS */;
INSERT INTO `survey_templates` (`id`, `name`, `category`, `description`, `greeting`, `footer`, `status`, `is_deleted`, `created`, `modified`) VALUES
	(1, 'Test Template', '1', 'Based on your experience how would you rate us:', 'Thank you for rating your experience with us.  Client satisfaction is our #1 priority.  We would love to hear a little more about your experience and ask that you take a quick moment to answer the questions on this page and provide any additional information you may feel is important.  Your feedback helps us ensure that we continue to provide the best service possible to our clients.  Thank you for taking the time to help us out.', 'Thank you for taking the time to complete our survey!', 1, 0, '2017-10-22 18:30:00', '0000-00-00 00:00:00'),
	(2, 'test2', '1', 'bets', '', 'gfgfd', 1, 0, '2017-10-22 18:30:00', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `survey_templates` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.survey_templates_question
CREATE TABLE IF NOT EXISTS `survey_templates_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_templates_id` int(11) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1=review,2=survey',
  `star` int(1) DEFAULT NULL,
  `question` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.survey_templates_question: ~8 rows (approximately)
/*!40000 ALTER TABLE `survey_templates_question` DISABLE KEYS */;
INSERT INTO `survey_templates_question` (`id`, `survey_templates_id`, `type`, `star`, `question`, `created`, `modified`) VALUES
	(1, 1, 1, 4, '1', '2017-10-27 13:57:59', '0000-00-00 00:00:00'),
	(2, 1, 1, 4, '2', '2017-10-27 13:58:02', '0000-00-00 00:00:00'),
	(3, 1, 1, 4, '3', '2017-10-27 13:58:05', '0000-00-00 00:00:00'),
	(4, 1, 1, 4, '4', '2017-10-27 19:33:17', '0000-00-00 00:00:00'),
	(5, 1, 1, 3, '5', '2017-10-27 13:58:11', '0000-00-00 00:00:00'),
	(6, 1, 1, 3, '2', '2017-10-27 13:58:13', '0000-00-00 00:00:00'),
	(7, 1, 1, 3, '4', '2017-10-27 13:58:15', '0000-00-00 00:00:00'),
	(8, 1, 2, 0, '4', '2017-10-27 13:58:36', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `survey_templates_question` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_details_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `pyment_gatway_id` int(11) NOT NULL,
  `transaction_responce` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_transactions_users` (`user_id`),
  KEY `FK_transactions_plans` (`plan_id`),
  KEY `FK_transactions_payment_details` (`payment_details_id`),
  CONSTRAINT `FK_transactions_payment_details` FOREIGN KEY (`payment_details_id`) REFERENCES `payment_details` (`id`),
  CONSTRAINT `FK_transactions_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `FK_transactions_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.transactions: ~0 rows (approximately)
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `password` char(60) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` bigint(14) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `address_line1` varchar(100) DEFAULT NULL,
  `address_line2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip_code` int(6) DEFAULT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `business_phone` bigint(20) DEFAULT NULL,
  `business_address_line1` varchar(255) DEFAULT NULL,
  `business_address_line2` varchar(255) DEFAULT NULL,
  `business_city` varchar(100) DEFAULT NULL,
  `business_state` varchar(100) DEFAULT NULL,
  `business_country` varchar(100) DEFAULT NULL,
  `business_zip_code` int(6) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `term_condition` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `FK_users_groups` (`group_id`),
  CONSTRAINT `FK_users_groups` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.users: ~58 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `password`, `email`, `phone`, `birth_date`, `address_line1`, `address_line2`, `city`, `state`, `country`, `zip_code`, `business_name`, `business_phone`, `business_address_line1`, `business_address_line2`, `business_city`, `business_state`, `business_country`, `business_zip_code`, `group_id`, `parent_id`, `is_active`, `term_condition`, `created`, `modified`) VALUES
	(10, 'Supar', 'Admin', '$2y$10$D0poZfCSR0SpYe5VsJFdc.u7pNb.5hVl.8QSJdNq5XAO2rosohRF6', 'suparadmin@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, '2017-10-12 15:41:45', '2017-10-17 16:35:51'),
	(11, 'Company', 'Admin', '$2y$10$nFqWB17uUz82uUDN/5LN4.wAJJIhtGz819vUaP1uvOXk6mppqKNrK', 'companyadmin@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-12 15:44:51', '2017-10-17 16:35:53'),
	(13, 'dgfasd', 'sdafaf', '$2y$10$sQnurETlrYTNMrYqf3VIVOqDFaptUnWDB1YQ9gnlj3H2vcM1Fzidq', 'dv@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, 1, 0, '2017-10-12 21:51:29', '2017-10-16 14:38:00'),
	(18, 'test2', 'user2', '$2y$10$5DDtRREjakr9Lcl2DNNukeLHHMW7jWjH2wZOlWrs13fEj5XDTIDza', 'test12@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, 1, 0, '2017-10-13 14:21:53', '2017-10-16 14:37:51'),
	(19, 'Rajesh', 'Singh', '$2y$10$BtHkCUyxh8ua63dFgtn.2.bi36LXJXq.zmDcM1p/TPH51vshIYcwq', 'rajeshs2@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 0, 0, '2017-10-13 23:33:52', '2017-10-25 23:09:54'),
	(20, 'fdgfzds', 'dfgfdbg', '$2y$10$nuKI06uvqU.JxijFDwddIOhtNpp0b.RhEfNo8AIvfnJ2keOavfTue', 'dgfdsg@dsgfd.dfgd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, 1, 0, '2017-10-16 23:42:55', '2017-10-16 23:42:55'),
	(21, 'fsdj', 'vhjv', '$2y$10$eOdf9nZN1SuHjucdiqmIhuAzGK2wYaAGWAiFv20GmLmHuAdttz7Mu', 'dfgzsfdgzsdf@fdsgf.gh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, 1, 0, '2017-10-17 15:49:40', '2017-10-17 15:49:40'),
	(22, 'cvzdfsv', 'dfsgbvsdf', '$2y$10$puFog7L4iFEVsFwxsiNRgeTUu8LjHt15RaGoAgMLg1kbDHjTQQBKG', 'adsgsdf@dgdf.dehyt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 21, 1, 0, '2017-10-17 16:03:27', '2017-10-17 16:17:49'),
	(24, 'test', 'user', '$2y$10$O.FGr/JCxGuIbEfA83PjaunzEvNFoUVFY4QksWq1tOFa2k7bOOqxK', 'testing1@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 21, 0, 0, '2017-10-17 16:43:57', '2017-10-17 16:44:02'),
	(25, 'Sanda', 'Moldovan', '$2y$10$qkQPaklmPFFr6TzpQ0mEy.N3UCbytc4KeWdVLIm0NjmLa4IUG/rxm', 'smmoldovan1@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-17 17:12:39', '2017-10-17 17:12:39'),
	(26, 'fdgxdfb', 'fdbgxdf', '$2y$10$Oe.UY3eHm2hyDwM5Xl0xu.SMSC6SMBctydbZFQ26Lh2n/I3iUdTT6', 'gxbgxf@fgdf.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-17 17:21:10', '2017-10-17 17:21:10'),
	(27, 'vgzsdfvgsdfb1', 'dfsbvgsdb1', '$2y$10$jM5dNA3IWrY9dbL6hC5ISexUUPFHv.sgQZwCYWg7Yc5H6UCKHucta', 'fsdbgsdf@vgff.vcihyoiyo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 26, 1, 0, '2017-10-17 17:21:40', '2017-10-17 17:47:32'),
	(28, 'Sanda', 'Moldovan', '$2y$10$OGa.HR0jjNOLIeOWKZoBnO3sBmLOmd/OE4JOB1H.rvlktNyQQpk/K', 'smmoldovan@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-17 18:32:36', '2017-10-17 18:32:36'),
	(29, 'Test', 'User', '$2y$10$RMfkb9huU3vm7cL9VUVw8ev8KLqc9mpjbPlftqOksgCplQRmS5iDK', 'dharmtset@gmail.co', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-17 19:40:00', '2017-10-17 19:40:00'),
	(30, 'Dharm', 'Singh', '$2y$10$8jxm3MPVecCBkmPJA0DYtuIRQaZfR54Cc9OEw3Usrt9adzZngbqTu', 'dharm12@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 1, 0, '2017-10-23 15:48:19', '2017-10-23 15:48:19'),
	(31, 'Dharm', 'Veer', '$2y$10$KR9yEiXIezZNVdQqMOXL0.lIWvLqfC7HYttaLptxGIwDL6od8R6Xu', 'dharmveer@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:13:39', '2017-10-23 17:13:39'),
	(32, 'fgbshdfjg', 'ghjghjgjh', '$2y$10$BjkMxiZNRTVfoRxnCPcy.uxAFzT0MkVYKT8JtQ2f7sw56ieG5A2rK', 'gghghj@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:18:37', '2017-10-23 17:18:37'),
	(33, 'Veer', 'Singh', '$2y$10$jys5BPmoY3T2nl/vk6RJF.XahNdNYtVHpPHBSsEJc4JnVB9lbRDLC', 'ragesh12@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:47:03', '2017-10-23 17:47:03'),
	(34, 'ragesh1', 'singh', '$2y$10$rRyDzFhVppdu3drXNw.NtO1WlrLX3fSzz.9QIkiU1p4xS9dbpgT.O', 'ragesh012@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 33, 1, 0, '2017-10-23 17:48:46', '2017-10-23 17:50:13'),
	(35, 'efawefaer', 'deaferas', '$2y$10$5xQI2QalZTmAB9qwV2rSt.n4t7KUeHBjml7hpAVSKXUwW7wIJAfn.', 'asdfdasf@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:15:48', '2017-10-23 18:15:48'),
	(36, 'efawefaer', 'deaferas', '$2y$10$/fYqbd3SaglLWBCxgVm.1OsA9BtLoY.6k2DFc5v6vZpHECYamBiCi', 'asdfdasfq@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:17:22', '2017-10-23 18:17:22'),
	(37, 'dharm', 'singn', '$2y$10$h3BWkBhNK8pifh0dR6IS8OG1WfZfs6q/NhcXOepOsgT4k7VLlr81S', 'dharm@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:24:16', '2017-10-23 18:24:16'),
	(38, 'fdgfds', 'sdfds', '$2y$10$azILAV1CUN0SkG7Fv6T/..LXxiwExci8Z/smslDx8HUZHvtHfmeYi', 'companyadmin1@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 37, 1, 0, '2017-10-23 18:27:51', '2017-10-23 18:27:51'),
	(39, 'Matthew ', 'j Bate', '$2y$10$3hwcCsQKoolFlfVY0SJlEe/AEqPabnCUcPcajo.e9ihETjbpRFdCK', 'mathewj2@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 19:22:02', '2017-10-23 19:22:02'),
	(40, 'Ralph', 'Samy', '$2y$10$N.Xb91aXPBcRwOWb5dr9MeNf7TsAggM.LnSgLLW6R3ETjCWEScORq', 'ralphs@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 39, 1, 0, '2017-10-23 19:24:50', '2017-10-23 19:25:43'),
	(41, 'Sammy', 'j Bate', '$2y$10$EXaNVngmkJEvnS0Tn0TnFO3Y.nKY3wxM7AjpZAooTNOxSPs4fN4NW', 'sammyj@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 39, 1, 0, '2017-10-23 19:27:58', '2017-10-23 19:27:58'),
	(42, 'Sanda', 'Moldovan', '$2y$10$2CGCoX/XmE5NM1wAzYj3jelhxlSroTyGqeF4wNHHhIeemAJHQENUu', 'smmoldovan10@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:45:23', '2017-10-23 21:45:23'),
	(43, 'Sanda', 'Moldovan', '$2y$10$c5PGzv3Wd63HYDhF7zy8Ju.T30cZwM7DuxVsoRX0rnJsEwloGHrlK', 'smmoldovan101@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:47:51', '2017-10-23 21:47:51'),
	(44, 'Sanda', 'Moldovan', '$2y$10$Ke.9WQ6cfYU7c4NeZKrRh.41XSEjULDboExrEKjj8q74IaOoWGHbm', 'smmoldovan12@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:49:03', '2017-10-23 21:49:03'),
	(45, 'Sanda', 'Moldovan', '$2y$10$hxN09futAZcI1lYZ7vxeeOdlOMqgtuHQdJLIIK3HozbRYFBljT5Ce', 'smmoldovan13@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:51:23', '2017-10-23 21:51:23'),
	(46, 'Sanda', 'Moldovan', '$2y$10$0avE.Xqz6jhp33IvQBE9HeLfRjFYPXp0Ct5ue4X6Ujy84Z99O4oku', 'smmoldovan14@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:55:07', '2017-10-23 21:55:07'),
	(47, 'Sanda', 'Moldovan', '$2y$10$DuNhzXsDtwjYBZumgnk9sueE69bKA2VH3UoEaUIl7GEZ8N1S0Z6Ia', 'smmoldovan15@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:57:03', '2017-10-23 21:57:03'),
	(48, 'Sanda', 'Moldovan', '$2y$10$K0Bgg.28ADKSGUvoY99UnubTKHJu1SjsmrRD8A0OO6z9.3VBIOVDS', 'smmoldovan16@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:59:47', '2017-10-23 21:59:47'),
	(49, 'Sanda', 'Moldovan', '$2y$10$Jy4NH/RKaLzmZCVBX1G3Y.xrkKJGON2rauwVxdrF32Qy4.ESLGys6', 'smmoldovan17@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 22:08:47', '2017-10-23 22:08:47'),
	(50, 'Sanda', 'Moldovan', '$2y$10$ngFOy61DnV2Qfi4hmNwOceOdlxGJLRU.9v7BZlfqQSqk.k57j3xda', 'smmoldovan20@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 23:15:31', '2017-10-23 23:15:31'),
	(51, 'Sanda', 'Moldovan', '$2y$10$Oec8bF.kOrudJLX9njFZhuaKCZVXTFBaohlZkw7ebtMTU7kcVZcta', 'dharms21@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:31:31', '2017-10-24 13:35:41'),
	(52, 'Matthew', 'j Bate', '$2y$10$Qo9XNHWuEwzMK87Q4tT48OlLUbHRHLFF74s8xWeUpaktjV1ipxf52', 'dharms22@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:36:28', '2017-10-24 13:38:40'),
	(53, 'Matthew', 'j Bate', '$2y$10$04AbT6nYVkngUtD0SdhPme.bku.cWrA8r0am0z/wT/vknh1F4P4ei', 'dharms23@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:38:55', '2017-10-24 13:39:54'),
	(54, 'Matthew', 'j Bate', '$2y$10$a.wp.Bcvmbytu6/e4qveC.uBEbGI23KCson2SZNg9xDvqiDI1TOIi', 'dharms24@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:39:58', '2017-10-24 13:40:28'),
	(55, 'Matthew', 'j Bate', '$2y$10$B0cNj/VQbv35eSpurHlgWOPvMZhCGO2Jth5F74TySP9aqYivkRf0i', 'dharms25@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:40:31', '2017-10-24 13:41:46'),
	(56, 'Matthew', 'j Bate', '$2y$10$hJkiipIlYLX39L8VqXjbtu3XGa7LdkYQL7/u8c5DSnI/XgvAaj/Iy', 'dharms26@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:41:51', '2017-10-24 13:43:09'),
	(57, 'Matthew', 'j Bate', '$2y$10$KjfK8/BDnkGIot7cD3pai.zcPH/OZ74HfZVCmyr8Ikhjq3vrj6i0u', 'dharms27@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:43:21', '2017-10-24 13:44:24'),
	(58, 'Matthew', 'j Bate', '$2y$10$4X5SJQNWmEN8XBO0yjox2uFxFvL8QSpTU16ongO8ji4.5mrVX8l7.', 'dharms28@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:44:50', '2017-10-24 13:45:51'),
	(59, 'Matthew', 'j Bate', '$2y$10$z63CKzq1JNU/eD7/VeC6juQDUPXlaWyg89AzNE61TXNx4asGsLBI.', 'dharms29@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:45:56', '2017-10-24 13:46:29'),
	(60, 'Matthew', 'j Bate', '$2y$10$Qit1ZeENzd1MA28jESRe4e/N06W1SvGzixjzRR57JbGND42QN6Yz6', 'dharms20@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:46:33', '2017-10-24 13:47:26'),
	(61, 'Matthew', 'j Bate', '$2y$10$Tfr1H4Ky2UFZiy.KHIcHhecRYVoiByRtXqVaZTTh/7BM3YiQCZd/K', 'dharms12@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:47:29', '2017-10-24 13:51:47'),
	(62, 'Matthew', 'j Bate', '$2y$10$Y4nsqFhRBH/TTk79R5A6D.jGzHO6t1UiDJaTxsFz.m0u2bb9ky5uq', 'dharms32@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:51:53', '2017-10-24 14:23:52'),
	(63, 'Sanda', 'Moldovan', '$2y$10$jUsRZR6z2v1wNUiW9.f/Uu9tfCCe5HHcwJ4fQCLeKLr3rA9nSBWB6', 'dharms42@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 14:24:32', '2017-10-24 14:28:58'),
	(64, 'Sanda', 'Moldovan', '$2y$10$prw/LvY8fLcvdPaG9amhnOePjAY6GF3uXJyQ78MEghddgwfcYRUKu', 'dharms52@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 14:33:19', '2017-10-24 15:08:32'),
	(65, 'Sanda', 'Moldovan', '$2y$10$GeWTPiegO8/THoI48PDqP.hyme..78bGEklqplZGIWRqgGZzMQQr6', 'dharms62@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:08:44', '2017-10-24 15:12:53'),
	(66, 'Sanda', 'Moldovan', '$2y$10$nDvffe/lRMrNal44HCcSy.TV5l7R0ON.anndY/9aRjrw594Ob54I.', 'dharms200@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 51, 1, 0, '2017-10-24 15:13:19', '2017-10-26 16:05:08'),
	(67, 'Dharm', 'Singh', '$2y$10$xfxIC7EevL6HVkbhmXUkreLBxIeRfwx6bE.i33tBKuKBpWVIoQV9K', 'dv.singh008@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:23:31', '2017-10-24 15:33:39'),
	(68, 'Dharm', 'Singh', '$2y$10$./mJf1J2wz2lYLqTJJsk1uwPqp9WY4UaHHHYYRDMiUe9jWy.hSnNW', 'dv.singh08@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:33:53', '2017-10-24 15:35:13'),
	(69, 'Dharm', 'Singh', '$2y$10$oKMh3E2vmnqSxDjlgrRMjelGYIpTPxeDOWKaNAPcwOZ/KlkhlLU9u', 'dv.singh0088@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:35:21', '2017-10-24 15:35:21'),
	(70, 'Matthew', 'Bate', '$2y$10$CsWATsGqud6trBq2WxM6.OWa297BBqzSHeIoYSN4EnpOvTlv3Vyv2', 'dharms247@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 1, 0, '2017-10-24 19:34:03', '2017-10-25 19:36:46'),
	(72, 'Dharm', 'Singh', '$2y$10$dFckDFEjieSsZUCXqDbycucpfLOD2Llep7LckZMtkpRbMdvgo8RaO', 'dharms211@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 12345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 16:05:37', '2017-10-26 16:06:40'),
	(73, 'Dharm', 'Singh', '$2y$10$Exg4QIpz1ASaxwL0So74LOh9k8S.VLfRLy6lTY67y2KtzBBrgZnT2', 'dharms2@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 16:07:18', '2017-10-26 16:07:18'),
	(74, 'Sanda', 'Moldovan', '$2y$10$D6kpRtVrY5YyZWKUfSgqA.71YfnRwZawxCnc4W/buxV459r/Kzz3C', 'smmoldovan1q@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 17:29:58', '2017-10-26 17:29:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.user_plans
CREATE TABLE IF NOT EXISTS `user_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `start_dt` date NOT NULL,
  `end_dt` date NOT NULL,
  `amt` varchar(50) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Paid, 0=Pending',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_user_plans_users` (`user_id`),
  KEY `FK_user_plans_plans` (`plan_id`),
  KEY `FK_user_plans_transactions` (`trans_id`),
  CONSTRAINT `FK_user_plans_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `FK_user_plans_transactions` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`id`),
  CONSTRAINT `FK_user_plans_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table powertestimonial.user_plans: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_plans` ENABLE KEYS */;

-- Dumping structure for table powertestimonial.yelps
CREATE TABLE IF NOT EXISTS `yelps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `yelp_term` text COLLATE utf8_unicode_ci NOT NULL,
  `yelp_location` text COLLATE utf8_unicode_ci NOT NULL,
  `yelp_limit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table powertestimonial.yelps: ~0 rows (approximately)
/*!40000 ALTER TABLE `yelps` DISABLE KEYS */;
/*!40000 ALTER TABLE `yelps` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

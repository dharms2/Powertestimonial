/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Dec 13, 2017
 */

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `recipient_phone` `recipient_phone` VARCHAR(16) NULL AFTER `recipient_email`,
	ADD COLUMN `send_type` VARCHAR(50) NOT NULL AFTER `status`;

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `send_type` `send_type` VARCHAR(50) NOT NULL AFTER `recipient_phone`;

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `recipient_phone` `recipient_phone` VARCHAR(16) NOT NULL AFTER `recipient_email`;

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `recipient_email` `recipient_email` VARCHAR(50) NULL AFTER `recipient_last_name`;
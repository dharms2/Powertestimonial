/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Dec 21, 2017
 */

ALTER TABLE `survey_templates` ADD `is_edited` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '0=>edit,1=>nonedit' AFTER `is_deleted`;
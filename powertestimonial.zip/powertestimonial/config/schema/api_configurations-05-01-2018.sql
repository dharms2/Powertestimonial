/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Jan 5, 2018
 */

ALTER TABLE `api_configurations`
	ADD COLUMN `angies_business_id` VARCHAR(500) NULL DEFAULT NULL AFTER `facebook_app_secret`;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Nov 20, 2017
 */

ALTER TABLE `users` ADD `additional_email` VARCHAR(255) NOT NULL AFTER `email`;
ALTER TABLE `users` ADD `birth_date` DATE NULL AFTER `email`;
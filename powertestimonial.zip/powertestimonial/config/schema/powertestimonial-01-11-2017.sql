-- --------------------------------------------------------
-- Host:                         powertest.chetu.com
-- Server version:               5.6.36 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table PowerDB.acl_phinxlog
CREATE TABLE IF NOT EXISTS `acl_phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table PowerDB.acl_phinxlog: ~0 rows (approximately)
/*!40000 ALTER TABLE `acl_phinxlog` DISABLE KEYS */;
INSERT INTO `acl_phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
	(20141229162641, 'CakePhpDbAcl', '2017-10-04 16:30:10', '2017-10-04 16:30:11', 0);
/*!40000 ALTER TABLE `acl_phinxlog` ENABLE KEYS */;

-- Dumping structure for table PowerDB.acos
CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`,`rght`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8;

-- Dumping data for table PowerDB.acos: ~90 rows (approximately)
/*!40000 ALTER TABLE `acos` DISABLE KEYS */;
INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(1, NULL, NULL, NULL, 'controllers', 1, 182),
	(2, 1, NULL, NULL, 'Error', 2, 3),
	(3, 1, NULL, NULL, 'Groups', 4, 15),
	(4, 3, NULL, NULL, 'index', 5, 6),
	(5, 3, NULL, NULL, 'view', 7, 8),
	(6, 3, NULL, NULL, 'add', 9, 10),
	(7, 3, NULL, NULL, 'edit', 11, 12),
	(8, 3, NULL, NULL, 'delete', 13, 14),
	(9, 1, NULL, NULL, 'Pages', 16, 19),
	(10, 9, NULL, NULL, 'display', 17, 18),
	(11, 1, NULL, NULL, 'Posts', 20, 31),
	(12, 11, NULL, NULL, 'index', 21, 22),
	(13, 11, NULL, NULL, 'view', 23, 24),
	(14, 11, NULL, NULL, 'add', 25, 26),
	(15, 11, NULL, NULL, 'edit', 27, 28),
	(16, 11, NULL, NULL, 'delete', 29, 30),
	(17, 1, NULL, NULL, 'Users', 32, 65),
	(18, 17, NULL, NULL, 'index', 33, 34),
	(22, 17, NULL, NULL, 'delete', 35, 36),
	(23, 17, NULL, NULL, 'login', 37, 38),
	(24, 17, NULL, NULL, 'logout', 39, 40),
	(25, 1, NULL, NULL, 'Acl', 66, 67),
	(26, 1, NULL, NULL, 'Bake', 68, 69),
	(41, 1, NULL, NULL, 'Migrations', 70, 71),
	(44, 17, NULL, NULL, 'associateDashboard', 43, 44),
	(45, 17, NULL, NULL, 'managerDashboard', 45, 46),
	(46, 17, NULL, NULL, 'addAssociate', 47, 48),
	(47, 17, NULL, NULL, 'addManager', 49, 50),
	(48, 17, NULL, NULL, 'editAssociate', 51, 52),
	(49, 17, NULL, NULL, 'editManager', 53, 54),
	(50, 17, NULL, NULL, 'updateStatus', 55, 56),
	(52, 1, NULL, NULL, 'Indexes', 72, 87),
	(53, 52, NULL, NULL, 'index', 73, 74),
	(54, 52, NULL, NULL, 'price', 75, 76),
	(55, 52, NULL, NULL, 'howItWork', 77, 78),
	(56, 52, NULL, NULL, 'contact', 79, 80),
	(57, 52, NULL, NULL, 'confirmSignup', 81, 82),
	(58, 17, NULL, NULL, 'emailTemplate', 57, 58),
	(59, 17, NULL, NULL, 'checkEmailIsUnique', 59, 60),
	(88, 1, NULL, NULL, 'SurveyCategory', 88, 101),
	(89, 88, NULL, NULL, 'index', 89, 90),
	(90, 88, NULL, NULL, 'view', 91, 92),
	(91, 88, NULL, NULL, 'add', 93, 94),
	(92, 88, NULL, NULL, 'edit', 95, 96),
	(93, 88, NULL, NULL, 'delete', 97, 98),
	(94, 1, NULL, NULL, 'ReviewsMgmt', 102, 123),
	(95, 94, NULL, NULL, 'index', 103, 104),
	(96, 94, NULL, NULL, 'view', 105, 106),
	(97, 94, NULL, NULL, 'add', 107, 108),
	(98, 94, NULL, NULL, 'edit', 109, 110),
	(99, 94, NULL, NULL, 'delete', 111, 112),
	(100, 94, NULL, NULL, 'reviewStepOne', 113, 114),
	(101, 94, NULL, NULL, 'reviewStepTwo', 115, 116),
	(102, 52, NULL, NULL, 'invoice', 83, 84),
	(103, 17, NULL, NULL, 'getName', 61, 62),
	(104, 88, NULL, NULL, 'updateStatus', 99, 100),
	(105, 17, NULL, NULL, 'register', 63, 64),
	(106, 52, NULL, NULL, 'emailContact', 85, 86),
	(107, 94, NULL, NULL, 'emailReview', 117, 118),
	(108, 94, NULL, NULL, 'rating', 119, 120),
	(109, 1, NULL, NULL, 'SurveyMgmt', 124, 139),
	(110, 109, NULL, NULL, 'index', 125, 126),
	(111, 109, NULL, NULL, 'view', 127, 128),
	(112, 109, NULL, NULL, 'add', 129, 130),
	(113, 109, NULL, NULL, 'edit', 131, 132),
	(114, 109, NULL, NULL, 'delete', 133, 134),
	(115, 109, NULL, NULL, 'updateStatus', 135, 136),
	(116, 1, NULL, NULL, 'SurveyQuestion', 140, 153),
	(117, 116, NULL, NULL, 'index', 141, 142),
	(118, 116, NULL, NULL, 'view', 143, 144),
	(119, 116, NULL, NULL, 'add', 145, 146),
	(120, 116, NULL, NULL, 'edit', 147, 148),
	(121, 116, NULL, NULL, 'delete', 149, 150),
	(122, 116, NULL, NULL, 'updateStatus', 151, 152),
	(123, 1, NULL, NULL, 'SurveyTemplates', 154, 169),
	(124, 123, NULL, NULL, 'index', 155, 156),
	(125, 123, NULL, NULL, 'view', 157, 158),
	(126, 123, NULL, NULL, 'add', 159, 160),
	(127, 123, NULL, NULL, 'edit', 161, 162),
	(128, 123, NULL, NULL, 'delete', 163, 164),
	(129, 123, NULL, NULL, 'updateStatus', 165, 166),
	(131, 123, NULL, NULL, 'chooseQuestion', 167, 168),
	(132, 94, NULL, NULL, 'submitSurveyAnswer', 121, 122),
	(140, 1, NULL, NULL, 'ApiConfigurations', 170, 181),
	(141, 140, NULL, NULL, 'index', 171, 172),
	(142, 140, NULL, NULL, 'view', 173, 174),
	(143, 140, NULL, NULL, 'add', 175, 176),
	(144, 140, NULL, NULL, 'edit', 177, 178),
	(145, 140, NULL, NULL, 'delete', 179, 180),
	(146, 109, NULL, NULL, 'getAnalyzeData', 137, 138);
/*!40000 ALTER TABLE `acos` ENABLE KEYS */;

-- Dumping structure for table PowerDB.api_configurations
CREATE TABLE IF NOT EXISTS `api_configurations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_details` text NOT NULL,
  `google_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `facebook_details` text NOT NULL,
  `facebook_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `yelp_details` text NOT NULL,
  `yelp_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `zillow_details` text NOT NULL,
  `zillow_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `realtor_details` text NOT NULL,
  `realtor_include_in_survey` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=>not delete, 1=> delete',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.api_configurations: ~0 rows (approximately)
/*!40000 ALTER TABLE `api_configurations` DISABLE KEYS */;
INSERT INTO `api_configurations` (`id`, `google_details`, `google_include_in_survey`, `facebook_details`, `facebook_include_in_survey`, `yelp_details`, `yelp_include_in_survey`, `zillow_details`, `zillow_include_in_survey`, `realtor_details`, `realtor_include_in_survey`, `is_deleted`, `status`, `created`, `modified`) VALUES
	(1, 'ChIJ07HFQ1Z_24ARf2QSDb35NDU', 1, 'T-Square-Properties-325682215701/reviews/?ref=page_internal&mt_nav=1', 1, 'team-flores-real-estate-coldwell-banker-san-diego-2', 1, 'X1-ZUzj46f51zd2ix_3wgux', 1, 'test', 1, 0, 1, '2017-10-31 14:14:46', '2017-10-31 14:14:46');
/*!40000 ALTER TABLE `api_configurations` ENABLE KEYS */;

-- Dumping structure for table PowerDB.api_services
CREATE TABLE IF NOT EXISTS `api_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `api` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `api_url` text COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table PowerDB.api_services: ~4 rows (approximately)
/*!40000 ALTER TABLE `api_services` DISABLE KEYS */;
INSERT INTO `api_services` (`id`, `api`, `api_url`, `created`, `modified`) VALUES
	(1, 'google', 'www.google.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(2, 'yelp', 'www.yelp.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(3, 'facebook', 'www.facebook.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00'),
	(4, 'zillow', 'www.zillow.com', '2017-10-04 11:04:14', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `api_services` ENABLE KEYS */;

-- Dumping structure for table PowerDB.aros
CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`,`rght`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- Dumping data for table PowerDB.aros: ~69 rows (approximately)
/*!40000 ALTER TABLE `aros` DISABLE KEYS */;
INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
	(2, NULL, 'Groups', 1, NULL, 1, 4),
	(3, NULL, 'Groups', 2, NULL, 5, 118),
	(4, NULL, 'Groups', 3, NULL, 119, 128),
	(5, NULL, 'Groups', 4, NULL, 129, 160),
	(17, 3, 'Users', 10, NULL, 20, 21),
	(18, 3, 'Users', 11, NULL, 22, 23),
	(20, 4, 'Users', 13, NULL, 124, 125),
	(25, 4, 'Users', 18, NULL, 126, 127),
	(26, 5, 'Users', 19, NULL, 132, 133),
	(27, 3, 'Users', 20, NULL, 24, 25),
	(28, 3, 'Users', 21, NULL, 26, 27),
	(29, 5, 'Users', 22, NULL, 134, 135),
	(31, 5, 'Users', 24, NULL, 136, 137),
	(32, 3, 'Users', 25, NULL, 28, 29),
	(33, 3, 'Users', 26, NULL, 30, 31),
	(34, 5, 'Users', 27, NULL, 138, 139),
	(35, 3, 'Users', 28, NULL, 32, 33),
	(36, 3, 'Users', 29, NULL, 34, 35),
	(37, 5, 'Users', 30, NULL, 140, 141),
	(38, 3, 'Users', 31, NULL, 36, 37),
	(39, 3, 'Users', 32, NULL, 38, 39),
	(40, 3, 'Users', 33, NULL, 40, 41),
	(41, 5, 'Users', 34, NULL, 142, 143),
	(42, 3, 'Users', 35, NULL, 42, 43),
	(43, 3, 'Users', 36, NULL, 44, 45),
	(44, 3, 'Users', 37, NULL, 46, 47),
	(45, 5, 'Users', 38, NULL, 144, 145),
	(46, 3, 'Users', 39, NULL, 48, 49),
	(47, 5, 'Users', 40, NULL, 146, 147),
	(48, 5, 'Users', 41, NULL, 148, 149),
	(49, 3, 'Users', 42, NULL, 50, 51),
	(50, 3, 'Users', 43, NULL, 52, 53),
	(51, 3, 'Users', 44, NULL, 54, 55),
	(52, 3, 'Users', 45, NULL, 56, 57),
	(53, 3, 'Users', 46, NULL, 58, 59),
	(54, 3, 'Users', 47, NULL, 60, 61),
	(55, 3, 'Users', 48, NULL, 62, 63),
	(56, 3, 'Users', 49, NULL, 64, 65),
	(57, 3, 'Users', 50, NULL, 66, 67),
	(58, 3, 'Users', 51, NULL, 68, 69),
	(59, 3, 'Users', 52, NULL, 70, 71),
	(60, 3, 'Users', 53, NULL, 72, 73),
	(61, 3, 'Users', 54, NULL, 74, 75),
	(62, 3, 'Users', 55, NULL, 76, 77),
	(63, 3, 'Users', 56, NULL, 78, 79),
	(64, 3, 'Users', 57, NULL, 80, 81),
	(65, 3, 'Users', 58, NULL, 82, 83),
	(66, 3, 'Users', 59, NULL, 84, 85),
	(67, 3, 'Users', 60, NULL, 86, 87),
	(68, 3, 'Users', 61, NULL, 88, 89),
	(69, 3, 'Users', 62, NULL, 90, 91),
	(70, 3, 'Users', 63, NULL, 92, 93),
	(71, 3, 'Users', 64, NULL, 94, 95),
	(72, 3, 'Users', 65, NULL, 96, 97),
	(73, 5, 'Users', 66, NULL, 150, 151),
	(74, 3, 'Users', 67, NULL, 98, 99),
	(75, 3, 'Users', 68, NULL, 100, 101),
	(76, 3, 'Users', 69, NULL, 102, 103),
	(77, 5, 'Users', 70, NULL, 152, 153),
	(79, 3, 'Users', 72, NULL, 104, 105),
	(80, 3, 'Users', 73, NULL, 106, 107),
	(81, 3, 'Users', 74, NULL, 108, 109),
	(82, 3, 'Users', 75, NULL, 110, 111),
	(83, 5, 'Users', 76, NULL, 154, 155),
	(84, 3, 'Users', 77, NULL, 112, 113),
	(85, 3, 'Users', 78, NULL, 114, 115),
	(86, 5, 'Users', 79, NULL, 156, 157),
	(87, 5, 'Users', 80, NULL, 158, 159),
	(88, 3, 'Users', 81, NULL, 116, 117);
/*!40000 ALTER TABLE `aros` ENABLE KEYS */;

-- Dumping structure for table PowerDB.aros_acos
CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aro_id` int(11) NOT NULL,
  `aco_id` int(11) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `aro_id` (`aro_id`,`aco_id`),
  KEY `aco_id` (`aco_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table PowerDB.aros_acos: ~8 rows (approximately)
/*!40000 ALTER TABLE `aros_acos` DISABLE KEYS */;
INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
	(1, 2, 1, '1', '1', '1', '1'),
	(2, 3, 1, '1', '1', '1', '1'),
	(3, 3, 24, '1', '1', '1', '1'),
	(4, 2, 24, '1', '1', '1', '1'),
	(5, 5, 1, '1', '1', '1', '1'),
	(6, 5, 44, '-1', '-1', '-1', '-1'),
	(7, 5, 48, '-1', '-1', '-1', '-1'),
	(8, 5, 46, '-1', '-1', '-1', '-1');
/*!40000 ALTER TABLE `aros_acos` ENABLE KEYS */;

-- Dumping structure for table PowerDB.contact_us
CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(14) NOT NULL,
  `content` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.contact_us: ~9 rows (approximately)
/*!40000 ALTER TABLE `contact_us` DISABLE KEYS */;
INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `content`, `created`) VALUES
	(1, 'fdhfdbhg', 'gfhf@gmail.com', 1234567890, 'gfgfgfdnhg', '2017-10-26 18:23:41'),
	(2, 'Dharm', 'dharmveer@gmail.com', 1234567890, 'sdffbvgfds', '2017-10-26 18:25:21'),
	(3, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:24:07'),
	(4, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:24:16'),
	(5, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:25:08'),
	(6, 'Dharm', 'dharmveer@gmail.com', 2147483647, 'dvgfdbg gf ffgx gfxd vgvgvgvg  hgsdfha jkhgasdjghf nbhjbg', '2017-10-26 19:26:06'),
	(7, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:27:28'),
	(8, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:28:01'),
	(9, 'Sanda Moldovan', 'smmoldovan@hotmail.com', 2147483647, 'hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf hjdfsjkg jkbgkbh hjbhjs hjbhj hjbhjbgf ', '2017-10-26 19:28:49');
/*!40000 ALTER TABLE `contact_us` ENABLE KEYS */;

-- Dumping structure for table PowerDB.country
CREATE TABLE IF NOT EXISTS `country` (
  `cty_iso_code` varchar(3) NOT NULL,
  `cty_desc` varchar(40) NOT NULL,
  `cty_phone_code` varchar(6) NOT NULL,
  `cty_code` varchar(20) NOT NULL,
  PRIMARY KEY (`cty_iso_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.country: ~236 rows (approximately)
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`cty_iso_code`, `cty_desc`, `cty_phone_code`, `cty_code`) VALUES
	('AD', 'ANDORRA', '376', 'AD'),
	('AE', 'UNITED ARAB EMIRATES', '971', 'AE'),
	('AF', 'AFGHANISTAN', '93', 'AF'),
	('AG', 'ANTIGUA AND BARBUDA', '809', 'ATG'),
	('AI', 'ANGUILLA', '809', 'AI'),
	('AL', 'ALBANIA', '355', 'AL'),
	('AM', 'ARMENIA', '374', 'AM'),
	('AN', 'NETHERLANDS ANTILLES', '599', 'AN'),
	('AO', 'ANGOLA', '244', 'AO'),
	('AQ', 'ANTARCTICA', '672', 'AQ'),
	('AR', 'ARGENTINA', '54', 'ARG'),
	('AS', 'AMERICAN SAMOA', '684', 'AS'),
	('AT', 'AUSTRIA', '43', 'AUT'),
	('AU', 'AUSTRALIA', '61', 'AUS'),
	('AW', 'ARUBA', '297', 'ABW'),
	('AZ', 'AZERBAIJAN', '994', 'AZ'),
	('BA', 'BOSNIA AND HERZEGOVINA', '387', 'BA'),
	('BB', 'BARBADOS', '809', 'BRB'),
	('BD', 'BANGLADESH', '880', 'BD'),
	('BE', 'BELGIUM', '321', 'BEL'),
	('BF', 'BURKINA FASO', '226', 'BF'),
	('BG', 'BULGARIA', '359', 'BG'),
	('BH', 'BAHRAIN', '973', 'BH'),
	('BI', 'BURUNDI', '257', 'BI'),
	('BJ', 'BENIN', '229', 'BJ'),
	('BM', 'BERMUDA', '809', 'BMU'),
	('BN', 'BRUNEI DARUSSALAM', '673', 'BN'),
	('BO', 'BOLIVIA', '591', 'BO'),
	('BR', 'BRAZIL', '55', 'BRA'),
	('BS', 'BAHAMAS', '1', 'BHS'),
	('BT', 'BHUTAN', '975', 'BT'),
	('BV', 'BOUVET ISLAND', '', 'BV'),
	('BW', 'BOTSWANA', '267', 'BW'),
	('BY', 'BELARUS', '375', 'BY'),
	('BZ', 'BELIZE', '501', 'BZ'),
	('CA', 'CANADA', '1', 'CA'),
	('CC', 'COCOS (KEELING) ISLANDS', '672', 'CCK'),
	('CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', '242', 'CD'),
	('CF', 'CENTRAL AFRICAN REPUBLIC', '236', 'CF'),
	('CG', 'CONGO', '242', 'CG'),
	('CH', 'SWITZERLAND', '41', 'CH'),
	('CI', 'COTE D\'IVOIRE', '225', 'CI'),
	('CK', 'COOK ISLANDS', '682', 'CK'),
	('CL', 'CHILE', '56', 'CL'),
	('CM', 'CAMEROON', '237', 'CM'),
	('CN', 'CHINA', '86', 'CN'),
	('CO', 'COLOMBIA', '57', 'COL'),
	('CR', 'COSTA RICA', '506', 'CRI'),
	('CU', 'CUBA', '53', 'CU'),
	('CV', 'CAPE VERDE', '809', 'CV'),
	('CX', 'CHRISTMAS ISLAND', '672', 'CX'),
	('CY', 'CYPRUS', '357', 'CY'),
	('CZ', 'CZECH REPUBLIC', '42', 'CZ'),
	('DE', 'GERMANY', '49', 'DEU'),
	('DJ', 'DJIBOUTI', '253', 'DJ'),
	('DK', 'DENMARK', '45', 'DNK'),
	('DM', 'DOMINICA', '809', 'DM'),
	('DO', 'DOMINICAN REPUBLIC', '809', 'DO'),
	('DZ', 'ALGERIA', '213', 'DZ'),
	('EC', 'ECUADOR', '592', 'EC'),
	('EE', 'ESTONIA', '372', 'EE'),
	('EG', 'EGYPT', '20', 'EG'),
	('EH', 'WESTERN SAHARA', '', 'EH'),
	('ER', 'ERITREA', '291', 'ER'),
	('ES', 'SPAIN', '349', 'ES'),
	('ET', 'ETHIOPIA', '251', 'ET'),
	('FI', 'FINLAND', '358', 'FI'),
	('FJ', 'FIJI', '679', 'FJ'),
	('FK', 'FALKLAND ISLANDS (MALVINAS)', '500', 'FK'),
	('FM', 'MICRONESIA, FEDERATED STATES OF', '691', 'FM'),
	('FO', 'FAROE ISLANDS', '298', 'FO'),
	('FR', 'FRANCE', '33', 'FR'),
	('GA', 'GABON', '241', 'GA'),
	('GB', 'UNITED KINGDOM', '44', 'GB'),
	('GD', 'GRENADA', '809', 'GD'),
	('GE', 'GEORGIA', '995', 'GE'),
	('GF', 'FRENCH GUIANA', '594', 'GF'),
	('GH', 'GHANA', '233', 'GH'),
	('GI', 'GIBRALTAR', '350', 'GI'),
	('GL', 'GREENLAND', '299', 'GL'),
	('GM', 'GAMBIA', '220', 'GM'),
	('GN', 'GUINEA', '224', 'GN'),
	('GP', 'GUADELOUPE', '590', 'GP'),
	('GQ', 'EQUATORIAL GUINEA', '240', 'GQ'),
	('GR', 'GREECE', '30', 'GR'),
	('GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISL', '', 'GS'),
	('GT', 'GUATEMALA', '502', 'GT'),
	('GW', 'GUINEA-BISSAU', '245', 'GW'),
	('GY', 'GUYANA', '592', 'GY'),
	('HK', 'HONG KONG', '852', 'HK'),
	('HM', 'HEARD ISLAND AND MCDONALD ISLANDS', '', 'HM'),
	('HN', 'HONDURAS', '504', 'HN'),
	('HR', 'CROATIA', '385', 'HR'),
	('HT', 'HAITI', '509', 'HT'),
	('HU', 'HUNGARY', '36', 'HU'),
	('ID', 'INDONESIA', '62', 'ID'),
	('IE', 'IRELAND', '353', 'IE'),
	('IL', 'ISRAEL', '972', 'IL'),
	('IN', 'INDIA', '91', 'IN'),
	('IO', 'BRITISH INDIAN OCEAN TERRITORY', '0', 'IO'),
	('IQ', 'IRAQ', '964', 'IQ'),
	('IR', 'IRAN, ISLAMIC REPUBLIC OF', '98', 'IR'),
	('IS', 'ICELAND', '354', 'IS'),
	('IT', 'ITALY', '39', 'IT'),
	('JM', 'JAMAICA', '809', 'JM'),
	('JO', 'JORDAN', '962', 'JO'),
	('JP', 'JAPAN', '81', 'JP'),
	('KE', 'KENYA', '254', 'KE'),
	('KG', 'KYRGYZSTAN', '7', 'KG'),
	('KH', 'CAMBODIA', '855', 'KH'),
	('KI', 'KIRIBATI', '686', 'KI'),
	('KM', 'COMOROS', '269', 'KM'),
	('KN', 'SAINT KITTS AND NEVIS', '809', 'KN'),
	('KP', 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', '82', 'KP'),
	('KR', 'KOREA, REPUBLIC OF', '82', 'KR'),
	('KW', 'KUWAIT', '965', 'KW'),
	('KY', 'CAYMAN ISLANDS', '809', 'KY'),
	('KZ', 'KAZAKHSTAN', '7', 'KZ'),
	('LA', 'LAO PEOPLE\'S DEMOCRATIC REPUBLIC', '21', 'LA'),
	('LB', 'LEBANON', '961', 'LB'),
	('LC', 'SAINT LUCIA', '809', 'LC'),
	('LI', 'LIECHTENSTEIN', '417', 'LI'),
	('LK', 'SRI LANKA', '94', 'LK'),
	('LR', 'LIBERIA', '231', 'LR'),
	('LS', 'LESOTHO', '266', 'LS'),
	('LT', 'LITHUANIA', '370', 'LT'),
	('LU', 'LUXEMBOURG', '352', 'LU'),
	('LV', 'LATVIA', '371', 'LV'),
	('LY', 'LIBYAN ARAB JAMAHIRIYA', '218', 'LY'),
	('MA', 'MOROCCO', '212', 'MA'),
	('MC', 'MONACO', '339', 'MC'),
	('MD', 'MOLDOVA, REPUBLIC OF', '373', 'MD'),
	('MG', 'MADAGASCAR', '261', 'MG'),
	('MH', 'MARSHALL ISLANDS', '692', 'MH'),
	('MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC', '389', 'MK'),
	('ML', 'MALI', '223', 'ML'),
	('MM', 'MYANMAR', '95', 'MM'),
	('MN', 'MONGOLIA', '976', 'MN'),
	('MO', 'MACAO', '853', 'MO'),
	('MP', 'NORTHERN MARIANA ISLANDS', '670', 'MP'),
	('MQ', 'MARTINIQUE', '596', 'MQ'),
	('MR', 'MAURITANIA', '222', 'MR'),
	('MS', 'MONTSERRAT', '809', 'MS'),
	('MT', 'MALTA', '356', 'MT'),
	('MU', 'MAURITIUS', '230', 'MU'),
	('MV', 'MALDIVES', '960', 'MV'),
	('MW', 'MALAWI', '265', 'MW'),
	('MX', 'MEXICO', '52', 'MX'),
	('MY', 'MALAYSIA', '60', 'MY'),
	('MZ', 'MOZAMBIQUE', '258', 'MZ'),
	('NA', 'NAMIBIA', '264', 'NA'),
	('NC', 'NEW CALEDONIA', '687', 'NC'),
	('NE', 'NIGER', '227', 'NE'),
	('NF', 'NORFOLK ISLAND', '6723', 'NF'),
	('NG', 'NIGERIA', '234', 'NG'),
	('NI', 'NICARAGUA', '505', 'NI'),
	('NL', 'NETHERLANDS', '31', 'NL'),
	('NO', 'NORWAY', '47', 'NO'),
	('NP', 'NEPAL', '977', 'NP'),
	('NR', 'NAURU', '674', 'NR'),
	('NU', 'NIUE', '683', 'NU'),
	('NZ', 'NEW ZEALAND', '64', 'NZ'),
	('OM', 'OMAN', '968', 'OM'),
	('PA', 'PANAMA', '507', 'PA'),
	('PE', 'PERU', '51', 'PE'),
	('PF', 'FRENCH POLYNESIA', '689', 'PF'),
	('PG', 'PAPUA NEW GUINEA', '675', 'PG'),
	('PH', 'PHILIPPINES', '63', 'PH'),
	('PK', 'PAKISTAN', '92', 'PK'),
	('PL', 'POLAND', '48', 'PL'),
	('PM', 'SAINT PIERRE AND MIQUELON', '508', 'PM'),
	('PN', 'PITCAIRN', '', 'PN'),
	('PS', 'PALESTINIAN TERRITORY, OCCUPIED', '970', 'PS'),
	('PT', 'PORTUGAL', '351', 'PT'),
	('PW', 'PALAU', '680', 'PW'),
	('PY', 'PARAGUAY', '595', 'PY'),
	('QA', 'QATAR', '974', 'QA'),
	('RE', 'REUNION', '262', 'RE'),
	('RO', 'ROMANIA', '40', 'RO'),
	('RU', 'RUSSIAN FEDERATION', '7', 'RU'),
	('RW', 'RWANDA', '250', 'RW'),
	('SA', 'SAUDI ARABIA', '966', 'SA'),
	('SB', 'SOLOMON ISLANDS', '677', 'SB'),
	('SC', 'SEYCHELLES', '248', 'SC'),
	('SD', 'SUDAN', '249', 'SD'),
	('SE', 'SWEDEN', '46', 'SE'),
	('SG', 'SINGAPORE', '65', 'SG'),
	('SH', 'SAINT HELENA', '290', 'SH'),
	('SI', 'SLOVENIA', '386', 'SI'),
	('SJ', 'SVALBARD AND JAN MAYEN', '47', 'SJ'),
	('SK', 'SLOVAKIA', '42', 'SK'),
	('SL', 'SIERRA LEONE', '232', 'SL'),
	('SM', 'SAN MARINO', '395', 'SM'),
	('SN', 'SENEGAL', '221', 'SN'),
	('SO', 'SOMALIA', '252', 'SO'),
	('SR', 'SURINAME', '597', 'SR'),
	('ST', 'SAO TOME AND PRINCIPE', '239', 'ST'),
	('SV', 'EL SALVADOR', '503', 'SV'),
	('SY', 'SYRIAN ARAB REPUBLIC', '963', 'SY'),
	('SZ', 'SWAZILAND', '268', 'SZ'),
	('TC', 'TURKS AND CAICOS ISLANDS', '809', 'TC'),
	('TD', 'CHAD', '235', 'TD'),
	('TF', 'FRENCH SOUTHERN TERRITORIES', '', 'TF'),
	('TG', 'TOGO', '228', 'TG'),
	('TH', 'THAILAND', '66', 'TH'),
	('TJ', 'TAJIKISTAN', '7', 'TJ'),
	('TK', 'TOKELAU', '690', 'TK'),
	('TL', 'TIMOR-LESTE', '670', 'TL'),
	('TM', 'TURKMENISTAN', '7', 'TM'),
	('TN', 'TUNISIA', '216', 'TN'),
	('TO', 'TONGA', '676', 'TO'),
	('TR', 'TURKEY', '90', 'TR'),
	('TT', 'TRINIDAD AND TOBAGO', '868', 'TT'),
	('TV', 'TUVALU', '688', 'TV'),
	('TW', 'TAIWAN, PROVINCE OF CHINA', '886', 'TW'),
	('TZ', 'TANZANIA, UNITED REPUBLIC OF', '255', 'TZ'),
	('UA', 'UKRAINE', '380', 'UA'),
	('UG', 'UGANDA', '256', 'UG'),
	('UM', 'UNITED STATES MINOR OUTLYING ISLANDS', '', 'UM'),
	('US', 'UNITED STATES', '1', 'US'),
	('UY', 'URUGUAY', '598', 'UY'),
	('UZ', 'UZBEKISTAN', '7', 'UZ'),
	('VA', 'HOLY SEE (VATICAN CITY STATE)', '396', 'VA'),
	('VC', 'SAINT VINCENT AND THE GRENADINES', '809', 'VC'),
	('VE', 'VENEZUELA', '58', 'VE'),
	('VG', 'VIRGIN ISLANDS, BRITISH', '340', 'VG'),
	('VN', 'VIETNAM', '84', 'VN'),
	('VU', 'VANUATU', '678', 'VU'),
	('WF', 'WALLIS AND FUTUNA', '681', 'WF'),
	('WS', 'SAMOA', '684', 'WS'),
	('YE', 'YEMEN', '967', 'YE'),
	('YT', 'MAYOTTE', '2696', 'YT'),
	('YU', 'YUGOSLAVIA', '381', 'YU'),
	('ZA', 'SOUTH AFRICA', '27', 'ZA'),
	('ZM', 'ZAMBIA', '260', 'ZM'),
	('ZW', 'ZIMBABWE', '263', 'ZW');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;

-- Dumping structure for table PowerDB.coupons
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(150) NOT NULL,
  `max_amt` int(11) NOT NULL,
  `percentage` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.coupons: ~0 rows (approximately)
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`id`, `code`, `max_amt`, `percentage`, `description`, `created`, `modified`) VALUES
	(1, 'ABCD', 10, 5, 'Testing', '2017-10-16 10:10:10', '2017-10-16 10:10:10');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;

-- Dumping structure for table PowerDB.googles
CREATE TABLE IF NOT EXISTS `googles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `google_place_id` text COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table PowerDB.googles: ~0 rows (approximately)
/*!40000 ALTER TABLE `googles` DISABLE KEYS */;
/*!40000 ALTER TABLE `googles` ENABLE KEYS */;

-- Dumping structure for table PowerDB.groups
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.groups: ~4 rows (approximately)
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`id`, `name`, `created`, `modified`) VALUES
	(1, 'Super Admin ', '2017-10-04 22:10:12', '2017-10-12 15:29:08'),
	(2, 'Company Representative', '2017-10-04 22:10:32', '2017-10-12 15:29:10'),
	(3, 'Company Managers', '2017-10-04 22:10:55', '2017-10-12 15:29:12'),
	(4, 'Associates/Agents ', '2017-10-04 22:11:19', '2017-10-12 15:29:15');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;

-- Dumping structure for table PowerDB.payment_details
CREATE TABLE IF NOT EXISTS `payment_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `card_num` int(16) NOT NULL,
  `expiry_date` varchar(50) NOT NULL,
  `security_code` varchar(5) NOT NULL,
  `card_holder_name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_payment_details_users` (`user_id`),
  CONSTRAINT `FK_payment_details_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.payment_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `payment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_details` ENABLE KEYS */;

-- Dumping structure for table PowerDB.personal_site_reviews
CREATE TABLE IF NOT EXISTS `personal_site_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratings` int(5) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `completion_date` date NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.personal_site_reviews: ~0 rows (approximately)
/*!40000 ALTER TABLE `personal_site_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_site_reviews` ENABLE KEYS */;

-- Dumping structure for table PowerDB.plans
CREATE TABLE IF NOT EXISTS `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `amt` decimal(10,2) NOT NULL DEFAULT '0.00',
  `setup_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.plans: ~3 rows (approximately)
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` (`id`, `name`, `amt`, `setup_fee`, `created`, `modified`) VALUES
	(1, 'Power', 49.00, 50.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(2, 'Power Plus', 129.00, 50.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(3, 'Ultimate Power', 249.00, 100.00, '2017-10-13 10:10:10', '2017-10-13 10:10:10');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;

-- Dumping structure for table PowerDB.plan_features
CREATE TABLE IF NOT EXISTS `plan_features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.plan_features: ~20 rows (approximately)
/*!40000 ALTER TABLE `plan_features` DISABLE KEYS */;
INSERT INTO `plan_features` (`id`, `name`, `created`, `modified`) VALUES
	(1, '1 User Account', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(2, '5 star rating system', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(3, 'Auto review requests', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(4, 'Real time alerts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(5, 'Auto email reminders', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(6, 'At a glance analysis', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(7, 'Web review widgets', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(8, 'Free tech support', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(9, 'Custom branded', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(10, 'Full device optimization', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(11, 'Review request button on your website and emails', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(12, 'Up to 10 User Accounts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(13, 'Up to 5 customized surveys/reviews', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(14, 'Individual account branding', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(15, 'Up to 25 User Accounts', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(16, 'Individual custom branding', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(17, 'Up to 25 customized surveys and reviews', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(18, 'Text integration', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(19, 'Review analysis', '2017-10-13 10:10:10', '2017-10-13 10:10:10'),
	(20, 'Free Microsite', '2017-10-13 10:10:10', '2017-10-13 10:10:10');
/*!40000 ALTER TABLE `plan_features` ENABLE KEYS */;

-- Dumping structure for table PowerDB.plan_features_xref
CREATE TABLE IF NOT EXISTS `plan_features_xref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `plan_features_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_plan_features_xref_plans` (`plan_id`),
  KEY `FK_plan_features_xref_plan_features` (`plan_features_id`),
  CONSTRAINT `FK_plan_features_xref_plan_features` FOREIGN KEY (`plan_features_id`) REFERENCES `plan_features` (`id`),
  CONSTRAINT `FK_plan_features_xref_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.plan_features_xref: ~41 rows (approximately)
/*!40000 ALTER TABLE `plan_features_xref` DISABLE KEYS */;
INSERT INTO `plan_features_xref` (`id`, `plan_id`, `plan_features_id`) VALUES
	(1, 1, 1),
	(2, 1, 2),
	(3, 1, 3),
	(4, 1, 4),
	(5, 1, 5),
	(6, 1, 6),
	(7, 1, 7),
	(8, 1, 8),
	(9, 1, 9),
	(10, 1, 10),
	(11, 1, 11),
	(12, 2, 13),
	(13, 2, 2),
	(14, 2, 3),
	(15, 2, 4),
	(16, 2, 5),
	(17, 2, 6),
	(18, 2, 7),
	(19, 2, 8),
	(20, 2, 9),
	(21, 2, 10),
	(22, 2, 11),
	(23, 2, 12),
	(24, 2, 14),
	(25, 3, 15),
	(26, 3, 2),
	(27, 3, 3),
	(28, 3, 4),
	(29, 3, 5),
	(30, 3, 6),
	(31, 3, 7),
	(32, 3, 8),
	(33, 3, 9),
	(34, 3, 10),
	(35, 3, 11),
	(36, 3, 15),
	(37, 3, 16),
	(38, 3, 17),
	(39, 3, 18),
	(40, 3, 19),
	(41, 3, 20);
/*!40000 ALTER TABLE `plan_features_xref` ENABLE KEYS */;

-- Dumping structure for table PowerDB.post_rating
CREATE TABLE IF NOT EXISTS `post_rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `rating_number` int(11) NOT NULL,
  `total_points` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = Block, 0 = Unblock',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`rating_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table PowerDB.post_rating: ~0 rows (approximately)
/*!40000 ALTER TABLE `post_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_rating` ENABLE KEYS */;

-- Dumping structure for table PowerDB.profile_images
CREATE TABLE IF NOT EXISTS `profile_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `img_url` varchar(500) DEFAULT NULL,
  `business_img_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_profile_images_users` (`user_id`),
  CONSTRAINT `FK_profile_images_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.profile_images: ~0 rows (approximately)
/*!40000 ALTER TABLE `profile_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_images` ENABLE KEYS */;

-- Dumping structure for table PowerDB.reviews_mgmt
CREATE TABLE IF NOT EXISTS `reviews_mgmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_first_name` varchar(50) NOT NULL,
  `recipient_last_name` varchar(50) NOT NULL,
  `recipient_email` varchar(50) NOT NULL,
  `recipient_phone` bigint(14) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=Sent, 2=Complete, 3=Pending Survey',
  `user_action` int(1) DEFAULT NULL COMMENT '1=Google Review, 2=Facebook Review, 3=Yelp Review, 4=Zillow Review, 5=Survey, 6=Realtor Review',
  `ratings` int(5) DEFAULT NULL,
  `survey_done` int(1) NOT NULL DEFAULT '1' COMMENT '1=>send,2=>complete,3=>pending',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_reviews_mgmt_users` (`user_id`),
  KEY `FK_reviews_mgmt_survey_mgmt` (`survey_id`),
  CONSTRAINT `FK_reviews_mgmt_survey_mgmt` FOREIGN KEY (`survey_id`) REFERENCES `survey_mgmt` (`id`),
  CONSTRAINT `FK_reviews_mgmt_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.reviews_mgmt: ~18 rows (approximately)
/*!40000 ALTER TABLE `reviews_mgmt` DISABLE KEYS */;
INSERT INTO `reviews_mgmt` (`id`, `recipient_first_name`, `recipient_last_name`, `recipient_email`, `recipient_phone`, `survey_id`, `user_id`, `status`, `user_action`, `ratings`, `survey_done`, `created`, `modified`) VALUES
	(1, 'test', 'user', 'test@yopmail.com', 1234567890, 4, 11, 2, 0, 5, 2, '2017-10-25 06:25:25', '2017-10-25 06:25:25'),
	(2, 'test1', 'user2', 'test1@yopmail.com', 1234567890, 4, 11, 2, 0, 5, 2, '2017-10-25 06:25:25', '2017-10-25 06:25:25'),
	(3, 'dsfsdg', 'fsdgbv', 'sdfgsdf@gmail.com', 0, 4, 80, 1, 1, 4, 2, '2017-10-25 21:46:19', '2017-11-01 13:36:57'),
	(4, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 10, 1, 0, 0, 1, '2017-10-25 21:47:06', '2017-10-25 21:47:06'),
	(5, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:44:04', '2017-10-31 12:25:28'),
	(6, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:45:11', '2017-10-31 09:13:44'),
	(7, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:45:43', '2017-10-30 23:05:16'),
	(8, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:50:28', '2017-10-30 22:30:29'),
	(9, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 0, 0, 2, '2017-10-26 19:51:22', '2017-10-26 19:51:22'),
	(10, 'Sanda', 'Moldovan', 'smmoldovan@hotmail.com', 2147483647, 4, 33, 1, 1, 5, 2, '2017-10-26 19:52:11', '2017-10-27 18:28:27'),
	(11, 'Dharm', 'Singh', 'dharmveer@gmail.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:53:47', '2017-10-27 18:29:42'),
	(12, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 33, 1, 0, 0, 2, '2017-10-26 19:55:22', '2017-10-26 19:55:22'),
	(13, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 4, 33, 1, 1, 4, 2, '2017-10-26 19:58:05', '2017-10-27 17:21:58'),
	(14, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 33, 1, 1, 5, 2, '2017-10-26 20:00:30', '2017-10-27 17:19:55'),
	(15, 'Matthew', 'Bate', 'dharms2@chetu.com', 2147483647, 6, 34, 1, 1, 3, 2, '2017-10-26 20:02:34', '2017-10-27 16:26:00'),
	(16, 'Dharm', 'Singh', 'dharms2@chetu.com', 2147483647, 4, 10, 1, 1, 5, 2, '2017-10-30 22:28:58', '2017-10-30 22:29:42'),
	(17, 'Rajesh', 'Singh', 'rajeshs@yopmail.com', 2147483647, 4, 19, 1, 1, 5, 2, '2017-10-30 23:00:56', '2017-10-30 23:02:23'),
	(22, 'Dharm', 'Singh', 'dharmveer@yopmail.com', 2147483647, 6, 11, 1, 1, 4, 2, '2017-11-01 14:07:20', '2017-11-01 14:10:39');
/*!40000 ALTER TABLE `reviews_mgmt` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_ans
CREATE TABLE IF NOT EXISTS `survey_ans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_mgmt_id` int(11) DEFAULT NULL,
  `review_mgmt_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `survey_qus_id` int(11) DEFAULT NULL,
  `answers` text NOT NULL,
  `survey_done` int(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_survey_ans_survey_mgmt` (`survey_mgmt_id`),
  KEY `FK_survey_ans_survey_qus` (`survey_qus_id`),
  CONSTRAINT `FK_survey_ans_survey_qus` FOREIGN KEY (`survey_qus_id`) REFERENCES `survey_question` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_ans: ~65 rows (approximately)
/*!40000 ALTER TABLE `survey_ans` DISABLE KEYS */;
INSERT INTO `survey_ans` (`id`, `survey_mgmt_id`, `review_mgmt_id`, `user_id`, `survey_qus_id`, `answers`, `survey_done`, `created`, `modified`) VALUES
	(41, 4, 7, 11, 1, '0,1,2,3', 1, '2017-10-31 09:07:24', '2017-10-31 09:07:24'),
	(42, 4, 7, 11, 2, '0', 1, '2017-10-31 09:07:24', '2017-10-31 09:07:24'),
	(43, 4, 7, 11, 3, '1', 1, '2017-10-31 09:07:24', '2017-10-31 09:07:24'),
	(44, 4, 7, 11, 4, '2', 1, '2017-10-31 09:07:24', '2017-10-31 09:07:24'),
	(45, 4, 7, 11, 5, '1,2,3', 1, '2017-10-31 09:07:24', '2017-10-31 09:07:24'),
	(51, 4, 6, 12, 1, '1,2,3', 1, '2017-10-31 09:18:47', '2017-10-31 09:18:47'),
	(52, 4, 6, 12, 2, '1', 1, '2017-10-31 09:18:47', '2017-10-31 09:18:47'),
	(53, 4, 6, 12, 3, '2', 1, '2017-10-31 09:18:47', '2017-10-31 09:18:47'),
	(54, 4, 6, 12, 4, '3', 1, '2017-10-31 09:18:47', '2017-10-31 09:18:47'),
	(55, 4, 6, 12, 5, '0,1,2,3', 1, '2017-10-31 09:18:47', '2017-10-31 09:18:47'),
	(56, 6, 18, 11, 1, '1,3', 1, '2017-11-01 12:51:25', '2017-11-01 12:51:25'),
	(57, 6, 18, 11, 2, '3', 1, '2017-11-01 12:51:25', '2017-11-01 12:51:25'),
	(58, 6, 18, 11, 3, '3', 1, '2017-11-01 12:51:25', '2017-11-01 12:51:25'),
	(59, 6, 18, 11, 4, '3', 1, '2017-11-01 12:51:25', '2017-11-01 12:51:25'),
	(60, 6, 18, 11, 5, '1,3', 1, '2017-11-01 12:51:25', '2017-11-01 12:51:25'),
	(61, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:56:56', '2017-11-01 12:56:56'),
	(62, 6, 19, 11, 2, '1', 1, '2017-11-01 12:56:56', '2017-11-01 12:56:56'),
	(63, 6, 19, 11, 3, '3', 1, '2017-11-01 12:56:56', '2017-11-01 12:56:56'),
	(64, 6, 19, 11, 4, '3', 1, '2017-11-01 12:56:56', '2017-11-01 12:56:56'),
	(65, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:56:56', '2017-11-01 12:56:56'),
	(66, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:57:15', '2017-11-01 12:57:15'),
	(67, 6, 19, 11, 2, '1', 1, '2017-11-01 12:57:15', '2017-11-01 12:57:15'),
	(68, 6, 19, 11, 3, '3', 1, '2017-11-01 12:57:15', '2017-11-01 12:57:15'),
	(69, 6, 19, 11, 4, '3', 1, '2017-11-01 12:57:15', '2017-11-01 12:57:15'),
	(70, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:57:15', '2017-11-01 12:57:15'),
	(71, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:58:02', '2017-11-01 12:58:02'),
	(72, 6, 19, 11, 2, '1', 1, '2017-11-01 12:58:02', '2017-11-01 12:58:02'),
	(73, 6, 19, 11, 3, '3', 1, '2017-11-01 12:58:02', '2017-11-01 12:58:02'),
	(74, 6, 19, 11, 4, '3', 1, '2017-11-01 12:58:02', '2017-11-01 12:58:02'),
	(75, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:58:02', '2017-11-01 12:58:02'),
	(76, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:58:22', '2017-11-01 12:58:22'),
	(77, 6, 19, 11, 2, '1', 1, '2017-11-01 12:58:22', '2017-11-01 12:58:22'),
	(78, 6, 19, 11, 3, '3', 1, '2017-11-01 12:58:22', '2017-11-01 12:58:22'),
	(79, 6, 19, 11, 4, '3', 1, '2017-11-01 12:58:22', '2017-11-01 12:58:22'),
	(80, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:58:22', '2017-11-01 12:58:22'),
	(81, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:58:59', '2017-11-01 12:58:59'),
	(82, 6, 19, 11, 2, '1', 1, '2017-11-01 12:58:59', '2017-11-01 12:58:59'),
	(83, 6, 19, 11, 3, '3', 1, '2017-11-01 12:58:59', '2017-11-01 12:58:59'),
	(84, 6, 19, 11, 4, '3', 1, '2017-11-01 12:58:59', '2017-11-01 12:58:59'),
	(85, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:58:59', '2017-11-01 12:58:59'),
	(86, 6, 19, 11, 1, '1,3', 1, '2017-11-01 12:59:22', '2017-11-01 12:59:22'),
	(87, 6, 19, 11, 2, '1', 1, '2017-11-01 12:59:22', '2017-11-01 12:59:22'),
	(88, 6, 19, 11, 3, '3', 1, '2017-11-01 12:59:22', '2017-11-01 12:59:22'),
	(89, 6, 19, 11, 4, '3', 1, '2017-11-01 12:59:22', '2017-11-01 12:59:22'),
	(90, 6, 19, 11, 5, '1,3', 1, '2017-11-01 12:59:22', '2017-11-01 12:59:22'),
	(91, 6, 20, 11, 1, '1,3', 1, '2017-11-01 13:05:42', '2017-11-01 13:05:42'),
	(92, 6, 20, 11, 2, '3', 1, '2017-11-01 13:05:42', '2017-11-01 13:05:42'),
	(93, 6, 20, 11, 3, '3', 1, '2017-11-01 13:05:42', '2017-11-01 13:05:42'),
	(94, 6, 20, 11, 4, '3', 1, '2017-11-01 13:05:42', '2017-11-01 13:05:42'),
	(95, 6, 20, 11, 5, '1,3', 1, '2017-11-01 13:05:42', '2017-11-01 13:05:42'),
	(96, 4, 3, 80, 1, '1,3', 1, '2017-11-01 13:36:57', '2017-11-01 13:36:57'),
	(97, 4, 3, 80, 2, '1', 1, '2017-11-01 13:36:57', '2017-11-01 13:36:57'),
	(98, 4, 3, 80, 3, '3', 1, '2017-11-01 13:36:57', '2017-11-01 13:36:57'),
	(99, 4, 3, 80, 4, '3', 1, '2017-11-01 13:36:57', '2017-11-01 13:36:57'),
	(100, 4, 3, 80, 5, '1,3', 1, '2017-11-01 13:36:57', '2017-11-01 13:36:57'),
	(101, 6, 21, 11, 1, '1,3', 1, '2017-11-01 13:58:19', '2017-11-01 13:58:19'),
	(102, 6, 21, 11, 2, '3', 1, '2017-11-01 13:58:20', '2017-11-01 13:58:20'),
	(103, 6, 21, 11, 3, '3', 1, '2017-11-01 13:58:20', '2017-11-01 13:58:20'),
	(104, 6, 21, 11, 4, '3', 1, '2017-11-01 13:58:20', '2017-11-01 13:58:20'),
	(105, 6, 21, 11, 5, '1,3', 1, '2017-11-01 13:58:20', '2017-11-01 13:58:20'),
	(106, 6, 22, 11, 1, '1,3', 1, '2017-11-01 14:10:39', '2017-11-01 14:10:39'),
	(107, 6, 22, 11, 2, '3', 1, '2017-11-01 14:10:39', '2017-11-01 14:10:39'),
	(108, 6, 22, 11, 3, '3', 1, '2017-11-01 14:10:39', '2017-11-01 14:10:39'),
	(109, 6, 22, 11, 4, '3', 1, '2017-11-01 14:10:39', '2017-11-01 14:10:39'),
	(110, 6, 22, 11, 5, '', 1, '2017-11-01 14:10:39', '2017-11-01 14:10:39');
/*!40000 ALTER TABLE `survey_ans` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_category
CREATE TABLE IF NOT EXISTS `survey_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_category: ~6 rows (approximately)
/*!40000 ALTER TABLE `survey_category` DISABLE KEYS */;
INSERT INTO `survey_category` (`id`, `name`, `description`, `status`, `is_deleted`, `created`, `modified`) VALUES
	(3, 'New Category1', 'Best Category of Question123123', 0, 0, '2017-10-23 12:27:11', '2017-10-26 15:02:27'),
	(4, 'Baum category', 'Best Category of the year', 0, 0, '2017-10-18 11:31:35', '2017-10-26 14:59:52'),
	(5, 'Test Category1', 'Best category', 0, 0, '2017-10-23 10:34:49', '2017-10-23 10:34:49'),
	(6, 'Test category New1', 'Test123', 0, 0, '2017-10-23 12:26:20', '2017-10-23 12:26:20'),
	(7, 'Category1', 'testing data', 0, 0, '2017-10-23 14:01:52', '2017-10-23 14:01:52'),
	(8, 'new catogry', 'testing', 1, 0, '2017-10-23 14:01:52', '2017-10-23 14:01:52');
/*!40000 ALTER TABLE `survey_category` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_mgmt
CREATE TABLE IF NOT EXISTS `survey_mgmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `survey_template_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_mgmt: ~4 rows (approximately)
/*!40000 ALTER TABLE `survey_mgmt` DISABLE KEYS */;
INSERT INTO `survey_mgmt` (`id`, `user_id`, `name`, `description`, `survey_template_id`, `status`, `is_deleted`, `created`, `modified`) VALUES
	(4, 11, ' Health Literacy Assessment', 'cdsgzdhdrh', 1, 1, 0, '2017-10-22 18:30:00', '2017-11-01 00:00:00'),
	(6, 11, 'Test Survey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, 0, '2017-10-24 08:52:44', '2017-10-24 08:52:44'),
	(8, 11, 'Testing Suirvey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, 0, '2017-10-24 08:53:35', '2017-10-24 08:53:35'),
	(9, 11, 'Test Category Survey', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 2, 1, 0, '2017-10-24 09:06:34', '2017-10-24 09:06:34'),
	(10, 11, 'manan test', 'dsafdsf', 1, 1, 0, '2017-10-31 11:24:50', '2017-10-31 11:24:50');
/*!40000 ALTER TABLE `survey_mgmt` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_question
CREATE TABLE IF NOT EXISTS `survey_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `questions` varchar(500) NOT NULL,
  `ans_types` int(1) NOT NULL COMMENT '1=Radio, 2=Checkbox',
  `ans_choices` varchar(255) NOT NULL,
  `correct_ans` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_question: ~5 rows (approximately)
/*!40000 ALTER TABLE `survey_question` DISABLE KEYS */;
INSERT INTO `survey_question` (`id`, `category_id`, `questions`, `ans_types`, `ans_choices`, `correct_ans`, `status`, `created`, `modified`) VALUES
	(1, 5, 'Is test questions ?', 2, 'A,B,C,Yes', '1', 1, '2017-10-27 18:32:31', '2017-10-27 19:35:02'),
	(2, 5, 'What is your name 1 ?', 1, 'Dharm,Veer,Singh,Dharm Veer Singh', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:29:05'),
	(3, 5, 'What is your name 2 ?', 1, 'Dharm2,Veer2,Singh2,Dharm Veer Singh2', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:33:56'),
	(4, 5, 'What is your name 3 ?', 1, 'Dharm3,Veer3,Singh3,Dharm Veer Singh3', '3', 1, '2017-10-27 19:29:05', '2017-10-27 19:34:18'),
	(5, 5, 'What is your name 3 ?', 2, 'Dharm3,Veer3,Singh3,Dharm Veer Singh3', '2,3', 1, '2017-10-27 19:29:05', '2017-10-27 19:34:18');
/*!40000 ALTER TABLE `survey_question` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_templates
CREATE TABLE IF NOT EXISTS `survey_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `category` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `greeting` text NOT NULL,
  `footer` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_templates: ~2 rows (approximately)
/*!40000 ALTER TABLE `survey_templates` DISABLE KEYS */;
INSERT INTO `survey_templates` (`id`, `name`, `category`, `description`, `greeting`, `footer`, `status`, `is_deleted`, `created`, `modified`) VALUES
	(1, 'Test Template', '1', 'Based on your experience how would you rate us:', 'Thank you for rating your experience with us.  Client satisfaction is our #1 priority.  We would love to hear a little more about your experience and ask that you take a quick moment to answer the questions on this page and provide any additional information you may feel is important.  Your feedback helps us ensure that we continue to provide the best service possible to our clients.  Thank you for taking the time to help us out.', 'Thank you for taking the time to complete our survey!', 1, 0, '2017-10-22 18:30:00', '0000-00-00 00:00:00'),
	(2, 'test2', '1', 'bets', '', 'gfgfd', 1, 0, '2017-10-22 18:30:00', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `survey_templates` ENABLE KEYS */;

-- Dumping structure for table PowerDB.survey_templates_question
CREATE TABLE IF NOT EXISTS `survey_templates_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_templates_id` int(11) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1=review, 2=survey',
  `star` int(1) NOT NULL,
  `question` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.survey_templates_question: ~10 rows (approximately)
/*!40000 ALTER TABLE `survey_templates_question` DISABLE KEYS */;
INSERT INTO `survey_templates_question` (`id`, `survey_templates_id`, `type`, `star`, `question`, `created`, `modified`) VALUES
	(1, 1, 2, 4, '1', '2017-10-27 13:57:59', '0000-00-00 00:00:00'),
	(2, 1, 1, 4, '2', '2017-10-27 13:58:02', '0000-00-00 00:00:00'),
	(3, 1, 1, 4, '3', '2017-10-27 13:58:05', '0000-00-00 00:00:00'),
	(4, 1, 1, 4, '4', '2017-10-27 19:33:17', '0000-00-00 00:00:00'),
	(5, 1, 2, 4, '5', '2017-10-31 14:32:59', '0000-00-00 00:00:00'),
	(6, 2, 1, 4, '1', '2017-10-27 13:58:13', '0000-00-00 00:00:00'),
	(7, 2, 2, 4, '2', '2017-10-27 13:58:15', '0000-00-00 00:00:00'),
	(8, 2, 1, 4, '3', '2017-10-27 13:58:15', '0000-00-00 00:00:00'),
	(9, 2, 1, 4, '4', '2017-10-27 13:58:15', '0000-00-00 00:00:00'),
	(10, 2, 2, 4, '5', '2017-10-27 13:58:15', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `survey_templates_question` ENABLE KEYS */;

-- Dumping structure for table PowerDB.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_details_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `pyment_gatway_id` int(11) NOT NULL,
  `transaction_responce` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_transactions_users` (`user_id`),
  KEY `FK_transactions_plans` (`plan_id`),
  KEY `FK_transactions_payment_details` (`payment_details_id`),
  CONSTRAINT `FK_transactions_payment_details` FOREIGN KEY (`payment_details_id`) REFERENCES `payment_details` (`id`),
  CONSTRAINT `FK_transactions_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `FK_transactions_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.transactions: ~0 rows (approximately)
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;

-- Dumping structure for table PowerDB.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `password` char(60) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` bigint(14) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `address_line1` varchar(100) DEFAULT NULL,
  `address_line2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip_code` int(6) DEFAULT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `business_phone` bigint(20) DEFAULT NULL,
  `business_address_line1` varchar(255) DEFAULT NULL,
  `business_address_line2` varchar(255) DEFAULT NULL,
  `business_city` varchar(100) DEFAULT NULL,
  `business_state` varchar(100) DEFAULT NULL,
  `business_country` varchar(100) DEFAULT NULL,
  `business_zip_code` int(6) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `term_condition` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `FK_users_groups` (`group_id`),
  CONSTRAINT `FK_users_groups` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.users: ~64 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `password`, `email`, `phone`, `birth_date`, `address_line1`, `address_line2`, `city`, `state`, `country`, `zip_code`, `business_name`, `business_phone`, `business_address_line1`, `business_address_line2`, `business_city`, `business_state`, `business_country`, `business_zip_code`, `group_id`, `parent_id`, `is_active`, `term_condition`, `created`, `modified`) VALUES
	(10, 'Supar', 'Admin', '$2y$10$D0poZfCSR0SpYe5VsJFdc.u7pNb.5hVl.8QSJdNq5XAO2rosohRF6', 'suparadmin@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, '2017-10-12 15:41:45', '2017-10-17 16:35:51'),
	(11, 'Company', 'Admin', '$2y$10$nFqWB17uUz82uUDN/5LN4.wAJJIhtGz819vUaP1uvOXk6mppqKNrK', 'companyadmin@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-12 15:44:51', '2017-10-17 16:35:53'),
	(13, 'dgfasd', 'sdafaf', '$2y$10$sQnurETlrYTNMrYqf3VIVOqDFaptUnWDB1YQ9gnlj3H2vcM1Fzidq', 'dv@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, 1, 0, '2017-10-12 21:51:29', '2017-10-16 14:38:00'),
	(18, 'test2', 'user2', '$2y$10$5DDtRREjakr9Lcl2DNNukeLHHMW7jWjH2wZOlWrs13fEj5XDTIDza', 'test12@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, 1, 0, '2017-10-13 14:21:53', '2017-10-16 14:37:51'),
	(19, 'Rajesh', 'Singh', '$2y$10$BtHkCUyxh8ua63dFgtn.2.bi36LXJXq.zmDcM1p/TPH51vshIYcwq', 'rajeshs2@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 0, 0, '2017-10-13 23:33:52', '2017-10-25 23:09:54'),
	(20, 'fdgfzds', 'dfgfdbg', '$2y$10$nuKI06uvqU.JxijFDwddIOhtNpp0b.RhEfNo8AIvfnJ2keOavfTue', 'dgfdsg@dsgfd.dfgd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, 1, 0, '2017-10-16 23:42:55', '2017-10-16 23:42:55'),
	(21, 'fsdj', 'vhjv', '$2y$10$eOdf9nZN1SuHjucdiqmIhuAzGK2wYaAGWAiFv20GmLmHuAdttz7Mu', 'dfgzsfdgzsdf@fdsgf.gh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, 1, 0, '2017-10-17 15:49:40', '2017-10-17 15:49:40'),
	(22, 'cvzdfsv', 'dfsgbvsdf', '$2y$10$puFog7L4iFEVsFwxsiNRgeTUu8LjHt15RaGoAgMLg1kbDHjTQQBKG', 'adsgsdf@dgdf.dehyt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 21, 1, 0, '2017-10-17 16:03:27', '2017-10-17 16:17:49'),
	(24, 'test', 'user', '$2y$10$O.FGr/JCxGuIbEfA83PjaunzEvNFoUVFY4QksWq1tOFa2k7bOOqxK', 'testing1@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 21, 0, 0, '2017-10-17 16:43:57', '2017-10-17 16:44:02'),
	(25, 'Sanda', 'Moldovan', '$2y$10$qkQPaklmPFFr6TzpQ0mEy.N3UCbytc4KeWdVLIm0NjmLa4IUG/rxm', 'smmoldovan1@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-17 17:12:39', '2017-10-17 17:12:39'),
	(26, 'fdgxdfb', 'fdbgxdf', '$2y$10$Oe.UY3eHm2hyDwM5Xl0xu.SMSC6SMBctydbZFQ26Lh2n/I3iUdTT6', 'gxbgxf@fgdf.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 0, '2017-10-17 17:21:10', '2017-10-17 17:21:10'),
	(27, 'vgzsdfvgsdfb1', 'dfsbvgsdb1', '$2y$10$jM5dNA3IWrY9dbL6hC5ISexUUPFHv.sgQZwCYWg7Yc5H6UCKHucta', 'fsdbgsdf@vgff.vcihyoiyo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 26, 1, 0, '2017-10-17 17:21:40', '2017-10-17 17:47:32'),
	(28, 'Sanda', 'Moldovan', '$2y$10$OGa.HR0jjNOLIeOWKZoBnO3sBmLOmd/OE4JOB1H.rvlktNyQQpk/K', 'smmoldovan@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-17 18:32:36', '2017-10-17 18:32:36'),
	(29, 'Test', 'User', '$2y$10$RMfkb9huU3vm7cL9VUVw8ev8KLqc9mpjbPlftqOksgCplQRmS5iDK', 'dharmtset@gmail.co', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-17 19:40:00', '2017-10-17 19:40:00'),
	(30, 'Dharm', 'Singh', '$2y$10$8jxm3MPVecCBkmPJA0DYtuIRQaZfR54Cc9OEw3Usrt9adzZngbqTu', 'dharm12@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 1, 0, '2017-10-23 15:48:19', '2017-10-23 15:48:19'),
	(31, 'Dharm', 'Veer', '$2y$10$KR9yEiXIezZNVdQqMOXL0.lIWvLqfC7HYttaLptxGIwDL6od8R6Xu', 'dharmveer@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:13:39', '2017-10-23 17:13:39'),
	(32, 'fgbshdfjg', 'ghjghjgjh', '$2y$10$BjkMxiZNRTVfoRxnCPcy.uxAFzT0MkVYKT8JtQ2f7sw56ieG5A2rK', 'gghghj@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:18:37', '2017-10-23 17:18:37'),
	(33, 'Veer', 'Singh', '$2y$10$jys5BPmoY3T2nl/vk6RJF.XahNdNYtVHpPHBSsEJc4JnVB9lbRDLC', 'ragesh12@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 17:47:03', '2017-10-23 17:47:03'),
	(34, 'ragesh1', 'singh', '$2y$10$rRyDzFhVppdu3drXNw.NtO1WlrLX3fSzz.9QIkiU1p4xS9dbpgT.O', 'ragesh012@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 33, 1, 0, '2017-10-23 17:48:46', '2017-10-23 17:50:13'),
	(35, 'efawefaer', 'deaferas', '$2y$10$5xQI2QalZTmAB9qwV2rSt.n4t7KUeHBjml7hpAVSKXUwW7wIJAfn.', 'asdfdasf@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:15:48', '2017-10-23 18:15:48'),
	(36, 'efawefaer', 'deaferas', '$2y$10$/fYqbd3SaglLWBCxgVm.1OsA9BtLoY.6k2DFc5v6vZpHECYamBiCi', 'asdfdasfq@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:17:22', '2017-10-23 18:17:22'),
	(37, 'dharm', 'singn', '$2y$10$h3BWkBhNK8pifh0dR6IS8OG1WfZfs6q/NhcXOepOsgT4k7VLlr81S', 'dharm@powertestimonial.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 18:24:16', '2017-10-23 18:24:16'),
	(38, 'fdgfds', 'sdfds', '$2y$10$azILAV1CUN0SkG7Fv6T/..LXxiwExci8Z/smslDx8HUZHvtHfmeYi', 'companyadmin1@powertestimonial.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 37, 1, 0, '2017-10-23 18:27:51', '2017-10-23 18:27:51'),
	(39, 'Matthew ', 'j Bate', '$2y$10$3hwcCsQKoolFlfVY0SJlEe/AEqPabnCUcPcajo.e9ihETjbpRFdCK', 'mathewj2@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 19:22:02', '2017-10-23 19:22:02'),
	(40, 'Ralph', 'Samy', '$2y$10$N.Xb91aXPBcRwOWb5dr9MeNf7TsAggM.LnSgLLW6R3ETjCWEScORq', 'ralphs@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 39, 1, 0, '2017-10-23 19:24:50', '2017-10-23 19:25:43'),
	(41, 'Sammy', 'j Bate', '$2y$10$EXaNVngmkJEvnS0Tn0TnFO3Y.nKY3wxM7AjpZAooTNOxSPs4fN4NW', 'sammyj@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 39, 1, 0, '2017-10-23 19:27:58', '2017-10-23 19:27:58'),
	(42, 'Sanda', 'Moldovan', '$2y$10$2CGCoX/XmE5NM1wAzYj3jelhxlSroTyGqeF4wNHHhIeemAJHQENUu', 'smmoldovan10@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:45:23', '2017-10-23 21:45:23'),
	(43, 'Sanda', 'Moldovan', '$2y$10$c5PGzv3Wd63HYDhF7zy8Ju.T30cZwM7DuxVsoRX0rnJsEwloGHrlK', 'smmoldovan101@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:47:51', '2017-10-23 21:47:51'),
	(44, 'Sanda', 'Moldovan', '$2y$10$Ke.9WQ6cfYU7c4NeZKrRh.41XSEjULDboExrEKjj8q74IaOoWGHbm', 'smmoldovan12@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:49:03', '2017-10-23 21:49:03'),
	(45, 'Sanda', 'Moldovan', '$2y$10$hxN09futAZcI1lYZ7vxeeOdlOMqgtuHQdJLIIK3HozbRYFBljT5Ce', 'smmoldovan13@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:51:23', '2017-10-23 21:51:23'),
	(46, 'Sanda', 'Moldovan', '$2y$10$0avE.Xqz6jhp33IvQBE9HeLfRjFYPXp0Ct5ue4X6Ujy84Z99O4oku', 'smmoldovan14@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:55:07', '2017-10-23 21:55:07'),
	(47, 'Sanda', 'Moldovan', '$2y$10$DuNhzXsDtwjYBZumgnk9sueE69bKA2VH3UoEaUIl7GEZ8N1S0Z6Ia', 'smmoldovan15@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:57:03', '2017-10-23 21:57:03'),
	(48, 'Sanda', 'Moldovan', '$2y$10$K0Bgg.28ADKSGUvoY99UnubTKHJu1SjsmrRD8A0OO6z9.3VBIOVDS', 'smmoldovan16@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 21:59:47', '2017-10-23 21:59:47'),
	(49, 'Sanda', 'Moldovan', '$2y$10$Jy4NH/RKaLzmZCVBX1G3Y.xrkKJGON2rauwVxdrF32Qy4.ESLGys6', 'smmoldovan17@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 22:08:47', '2017-10-23 22:08:47'),
	(50, 'Sanda', 'Moldovan', '$2y$10$ngFOy61DnV2Qfi4hmNwOceOdlxGJLRU.9v7BZlfqQSqk.k57j3xda', 'smmoldovan20@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-23 23:15:31', '2017-10-23 23:15:31'),
	(51, 'Sanda', 'Moldovan', '$2y$10$Oec8bF.kOrudJLX9njFZhuaKCZVXTFBaohlZkw7ebtMTU7kcVZcta', 'dharms21@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:31:31', '2017-10-24 13:35:41'),
	(52, 'Matthew', 'j Bate', '$2y$10$Qo9XNHWuEwzMK87Q4tT48OlLUbHRHLFF74s8xWeUpaktjV1ipxf52', 'dharms22@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:36:28', '2017-10-24 13:38:40'),
	(53, 'Matthew', 'j Bate', '$2y$10$04AbT6nYVkngUtD0SdhPme.bku.cWrA8r0am0z/wT/vknh1F4P4ei', 'dharms23@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:38:55', '2017-10-24 13:39:54'),
	(54, 'Matthew', 'j Bate', '$2y$10$a.wp.Bcvmbytu6/e4qveC.uBEbGI23KCson2SZNg9xDvqiDI1TOIi', 'dharms24@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:39:58', '2017-10-24 13:40:28'),
	(55, 'Matthew', 'j Bate', '$2y$10$B0cNj/VQbv35eSpurHlgWOPvMZhCGO2Jth5F74TySP9aqYivkRf0i', 'dharms25@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:40:31', '2017-10-24 13:41:46'),
	(56, 'Matthew', 'j Bate', '$2y$10$hJkiipIlYLX39L8VqXjbtu3XGa7LdkYQL7/u8c5DSnI/XgvAaj/Iy', 'dharms26@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:41:51', '2017-10-24 13:43:09'),
	(57, 'Matthew', 'j Bate', '$2y$10$KjfK8/BDnkGIot7cD3pai.zcPH/OZ74HfZVCmyr8Ikhjq3vrj6i0u', 'dharms27@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:43:21', '2017-10-24 13:44:24'),
	(58, 'Matthew', 'j Bate', '$2y$10$4X5SJQNWmEN8XBO0yjox2uFxFvL8QSpTU16ongO8ji4.5mrVX8l7.', 'dharms28@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:44:50', '2017-10-24 13:45:51'),
	(59, 'Matthew', 'j Bate', '$2y$10$z63CKzq1JNU/eD7/VeC6juQDUPXlaWyg89AzNE61TXNx4asGsLBI.', 'dharms29@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:45:56', '2017-10-24 13:46:29'),
	(60, 'Matthew', 'j Bate', '$2y$10$Qit1ZeENzd1MA28jESRe4e/N06W1SvGzixjzRR57JbGND42QN6Yz6', 'dharms20@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:46:33', '2017-10-24 13:47:26'),
	(61, 'Matthew', 'j Bate', '$2y$10$Tfr1H4Ky2UFZiy.KHIcHhecRYVoiByRtXqVaZTTh/7BM3YiQCZd/K', 'dharms12@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:47:29', '2017-10-24 13:51:47'),
	(62, 'Matthew', 'j Bate', '$2y$10$Y4nsqFhRBH/TTk79R5A6D.jGzHO6t1UiDJaTxsFz.m0u2bb9ky5uq', 'dharms32@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 13:51:53', '2017-10-24 14:23:52'),
	(63, 'Sanda', 'Moldovan', '$2y$10$jUsRZR6z2v1wNUiW9.f/Uu9tfCCe5HHcwJ4fQCLeKLr3rA9nSBWB6', 'dharms42@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 14:24:32', '2017-10-24 14:28:58'),
	(64, 'Sanda', 'Moldovan', '$2y$10$prw/LvY8fLcvdPaG9amhnOePjAY6GF3uXJyQ78MEghddgwfcYRUKu', 'dharms52@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 14:33:19', '2017-10-24 15:08:32'),
	(65, 'Sanda', 'Moldovan', '$2y$10$GeWTPiegO8/THoI48PDqP.hyme..78bGEklqplZGIWRqgGZzMQQr6', 'dharms62@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:08:44', '2017-10-24 15:12:53'),
	(66, 'Sanda', 'Moldovan', '$2y$10$nDvffe/lRMrNal44HCcSy.TV5l7R0ON.anndY/9aRjrw594Ob54I.', 'dharms200@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 51, 1, 0, '2017-10-24 15:13:19', '2017-10-26 16:05:08'),
	(67, 'Dharm', 'Singh', '$2y$10$xfxIC7EevL6HVkbhmXUkreLBxIeRfwx6bE.i33tBKuKBpWVIoQV9K', 'dv.singh008@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:23:31', '2017-10-24 15:33:39'),
	(68, 'Dharm', 'Singh', '$2y$10$./mJf1J2wz2lYLqTJJsk1uwPqp9WY4UaHHHYYRDMiUe9jWy.hSnNW', 'dv.singh08@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:33:53', '2017-10-24 15:35:13'),
	(69, 'Dharm', 'Singh', '$2y$10$oKMh3E2vmnqSxDjlgrRMjelGYIpTPxeDOWKaNAPcwOZ/KlkhlLU9u', 'dv.singh0088@gmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'United States', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-24 15:35:21', '2017-10-24 15:35:21'),
	(70, 'Matthew', 'Bate', '$2y$10$CsWATsGqud6trBq2WxM6.OWa297BBqzSHeIoYSN4EnpOvTlv3Vyv2', 'dharms247@chetu.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 11, 1, 0, '2017-10-24 19:34:03', '2017-10-25 19:36:46'),
	(72, 'Dharm', 'Singh', '$2y$10$dFckDFEjieSsZUCXqDbycucpfLOD2Llep7LckZMtkpRbMdvgo8RaO', 'dharms211@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 12345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 16:05:37', '2017-10-26 16:06:40'),
	(73, 'Dharm', 'Singh', '$2y$10$Exg4QIpz1ASaxwL0So74LOh9k8S.VLfRLy6lTY67y2KtzBBrgZnT2', 'dharms2@chetu.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 16:07:18', '2017-10-26 16:07:18'),
	(74, 'Sanda', 'Moldovan', '$2y$10$D6kpRtVrY5YyZWKUfSgqA.71YfnRwZawxCnc4W/buxV459r/Kzz3C', 'smmoldovan1q@hotmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-26 17:29:58', '2017-10-26 17:29:58'),
	(75, 'John ', 'Snow', '$2y$10$niOAioKUFCrenDH906UBm.Uqto/LP.dBsth27soILsYYC3DrgexZ6', 'dharms2@yopmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-30 22:17:07', '2017-10-30 22:17:07'),
	(76, 'John', 'Smith', '$2y$10$5ft8cSguEPMFUE.6XHbYMOP/x0Opv9vgB.f9FQnHYyG/YKfwAsvgG', 'john@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 75, 1, 0, '2017-10-30 22:24:21', '2017-10-30 22:24:21'),
	(77, 'jhonny', 'salmon', '$2y$10$9qjiQL6sKx9fGLqWJxrmtOoIgH30b.85j3RMPeF3rM1.RsBqgIcge', 'johnnys@yopmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-30 22:37:35', '2017-10-30 22:37:35'),
	(78, 'jhonny', 'salmon', '$2y$10$3xwEEqcBUR.4iNO7lgZ9DO0TXtsXOkuG2DeMAWSmqQYNBgCnrmthS', 'johnnys2@yopmail.com', NULL, NULL, '1344 Goucher ST', '', 'Pacific Palisades', 'CA', 'US', 90272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-30 22:39:09', '2017-10-30 22:39:09'),
	(79, 'Sam', 'Thorud', '$2y$10$xcOViOWgOyDsKdX8Ft/3JOOD3MImvqyuMRTcDjk2HgB2FU/k3.CEK', 'samt@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 78, 1, 0, '2017-10-30 22:43:55', '2017-10-30 22:43:55'),
	(80, 'Ray', 'Raffaty', '$2y$10$w.GDXzs74PTy0AtMnepNC.0AF55MV7D3EdbzVII7s5TAd/0cQ.Hoy', 'rayr@yopmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 78, 1, 0, '2017-10-30 22:45:44', '2017-10-30 22:45:44'),
	(81, 'test', 'test', '$2y$10$DrP0x12k/.aLlTQ1/ax2CeeNh8PAtbCqYsYdbvCsIdfgMpvUfkbqG', 'rishirajs97@yopmail.com', NULL, NULL, 'a-50', 'sector 56', 'noida', 'up', 'US', 201301, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 10, 1, 1, '2017-10-31 09:37:34', '2017-10-31 09:37:34');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table PowerDB.user_plans
CREATE TABLE IF NOT EXISTS `user_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `start_dt` date NOT NULL,
  `end_dt` date NOT NULL,
  `amt` varchar(50) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Paid, 0=Pending',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `FK_user_plans_users` (`user_id`),
  KEY `FK_user_plans_plans` (`plan_id`),
  KEY `FK_user_plans_transactions` (`trans_id`),
  CONSTRAINT `FK_user_plans_plans` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `FK_user_plans_transactions` FOREIGN KEY (`trans_id`) REFERENCES `transactions` (`id`),
  CONSTRAINT `FK_user_plans_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.user_plans: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_plans` ENABLE KEYS */;

-- Dumping structure for table PowerDB.yelps
CREATE TABLE IF NOT EXISTS `yelps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `yelp_term` text COLLATE utf8_unicode_ci NOT NULL,
  `yelp_location` text COLLATE utf8_unicode_ci NOT NULL,
  `yelp_limit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table PowerDB.yelps: ~0 rows (approximately)
/*!40000 ALTER TABLE `yelps` DISABLE KEYS */;
/*!40000 ALTER TABLE `yelps` ENABLE KEYS */;

-- Dumping structure for table PowerDB.zillow
CREATE TABLE IF NOT EXISTS `zillow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `screen_name` varchar(500) DEFAULT NULL,
  `img_url` varchar(500) DEFAULT NULL,
  `profile_url` varchar(500) DEFAULT NULL,
  `business_name` varchar(500) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `review_request_url` varchar(500) DEFAULT NULL,
  `review_count` int(11) DEFAULT NULL,
  `avg_rating` double DEFAULT '0',
  `local_knowledge_rating` double DEFAULT '0',
  `process_expertise_rating` double DEFAULT '0',
  `responsiveness_rating` double DEFAULT '0',
  `negotiation_skills_rating` float DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.zillow: ~2 rows (approximately)
/*!40000 ALTER TABLE `zillow` DISABLE KEYS */;
INSERT INTO `zillow` (`id`, `user_id`, `screen_name`, `img_url`, `profile_url`, `business_name`, `address`, `phone`, `review_request_url`, `review_count`, `avg_rating`, `local_knowledge_rating`, `process_expertise_rating`, `responsiveness_rating`, `negotiation_skills_rating`, `created`, `modified`) VALUES
	(2, 11, 'Team Flores', 'https://photos.zillowstatic.com/h_g/IS2bxv3klnb8w11000000000.jpg', 'http://www.zillow.com/profile/Team-Flores/', 'TEAM FLORES - Coldwell Banker Residential Brokerage', '32675 Temecula Pkwy Ste. A, Temecula, CA 92592', '(858) 243-2043', 'http://www.zillow.com/reviews/write/?s=X1-ZUzj46f51zd2ix_3wgux', 5, 5, 4.8, 5, 5, 5, '2017-10-31 13:17:49', '2017-11-01 10:08:54');
/*!40000 ALTER TABLE `zillow` ENABLE KEYS */;

-- Dumping structure for table PowerDB.zillow_reviews
CREATE TABLE IF NOT EXISTS `zillow_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) DEFAULT NULL,
  `zillow_img` varchar(250) DEFAULT NULL,
  `zillow_reviewer` varchar(150) DEFAULT NULL,
  `zillow_reviewerLink` varchar(500) DEFAULT NULL,
  `zillow_reviewURL` varchar(500) DEFAULT NULL,
  `zillow_reviewDate` date DEFAULT NULL,
  `zillow_reviewSummary` text,
  `zillow_rating` float DEFAULT NULL,
  `zillow_description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

-- Dumping data for table PowerDB.zillow_reviews: ~5 rows (approximately)
/*!40000 ALTER TABLE `zillow_reviews` DISABLE KEYS */;
INSERT INTO `zillow_reviews` (`id`, `review_id`, `zillow_img`, `zillow_reviewer`, `zillow_reviewerLink`, `zillow_reviewURL`, `zillow_reviewDate`, `zillow_reviewSummary`, `zillow_rating`, `zillow_description`) VALUES
	(47, 3593983, '/img/zillow.png', 'adepascale78', 'http://www.zillow.com/profile/adepascale78/', 'http://www.zillow.com/profile/Team-Flores/Reviews/?review=3593983', '2017-09-01', 'Bought a Single Family home in 2014 for approximately $325K in Northwest, Chula Vista, CA.', 5, 'Saundra and Lorraine are great realtors. They helped me find the perfect home for me at the time. They always kept me motivated during my home search and did not get sidetracked when dealing with a difficult ...'),
	(48, 3584135, '/img/zillow.png', 'rdroman99', 'http://www.zillow.com/profile/rdroman99/', 'http://www.zillow.com/profile/Team-Flores/Reviews/?review=3584135', '2017-08-28', 'Bought a Condo home in 2017 for approximately $350K in Mira Mesa, San Diego, CA.', 5, 'Extensive knowledge of the real estate business. Walks you through the process and ensures you have a proper understanding of the processes at all stages. Willing to visit multiple homes and extremely ...'),
	(49, 3510722, '/img/zillow.png', 'jamesrh88', 'http://www.zillow.com/profile/jamesrh88/', 'http://www.zillow.com/profile/Team-Flores/Reviews/?review=3510722', '2017-07-28', 'Bought a Condo home in 2016 for approximately $300K in Temecula, CA.', 5, '"Quick and painless" as my dad put it. Being my first time buying I had no idea but team Flores was very knowledgeable and patient with me, worked tirelessly to find the right home for me, and fought ...'),
	(50, 3438239, '/img/zillow.png', 'jeffman27', 'http://www.zillow.com/profile/jeffman27/', 'http://www.zillow.com/profile/Team-Flores/Reviews/?review=3438239', '2017-06-28', 'Bought a Condo home in 2017 in Temecula, CA.', 5, 'Our long time realtor moved back east and we were very fortunate to be pointed in Lorraine\'s direction. She worked hard to find the perfect home. The transaction was seamless due in large part to their ...'),
	(51, 3420525, '/img/zillow.png', 'Roo92366', 'http://www.zillow.com/profile/Roo92366/', 'http://www.zillow.com/profile/Team-Flores/Reviews/?review=3420525', '2017-06-21', 'Sold a Single Family home in 2014 for approximately $525K in Rosemead, CA.', 5, 'Team Flores was fantastic to work with!  Lorraine and Saundra sold our house on the first day it was listed, and they got us an even better price than we asked for.  They resolved a problem with the title ...');
/*!40000 ALTER TABLE `zillow_reviews` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

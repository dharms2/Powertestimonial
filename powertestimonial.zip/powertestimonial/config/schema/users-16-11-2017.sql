/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 16, 2017
 */

ALTER TABLE `users` ADD `token` VARCHAR(255) NULL DEFAULT NULL AFTER `term_condition`;
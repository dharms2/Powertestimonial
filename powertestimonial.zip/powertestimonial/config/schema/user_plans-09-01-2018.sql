/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Jan 9, 2018
 */

ALTER TABLE `user_plans`
	ADD COLUMN `request_dt` DATE NOT NULL DEFAULT '0000-00-00' AFTER `plan_upgrade_req`,
	ADD COLUMN `approved_dt` DATE NOT NULL DEFAULT '0000-00-00' AFTER `request_dt`;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 16, 2017
 */

ALTER TABLE `survey_question` CHANGE `ans_types` `ans_types` INT(1) NOT NULL COMMENT '1=Radio, 2=Checkbox,3=Textarea';

ALTER TABLE `survey_question` CHANGE `correct_ans` `correct_ans` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL;

ALTER TABLE `survey_question` CHANGE `ans_choices` `ans_choices` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL;
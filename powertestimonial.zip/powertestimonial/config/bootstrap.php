<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         0.10.8
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */


// You can remove this if you are confident that your PHP version is sufficient.
if (version_compare(PHP_VERSION, '5.6.0') < 0) {
    trigger_error('Your PHP version must be equal or higher than 5.6.0 to use CakePHP.', E_USER_ERROR);
}

/*
 *  You can remove this if you are confident you have intl installed.
 */
if (!extension_loaded('intl')) {
    trigger_error('You must enable the intl extension to use CakePHP.', E_USER_ERROR);
}

/*
 * You can remove this if you are confident you have mbstring installed.
 */
if (!extension_loaded('mbstring')) {
    trigger_error('You must enable the mbstring extension to use CakePHP.', E_USER_ERROR);
}

/*
 * Configure paths required to find CakePHP + general filepath constants
 */
require __DIR__ . '/paths.php';

/*
 * Bootstrap CakePHP.
 *
 * Does the various bits of setup that CakePHP needs to do.
 * This includes:
 *
 * - Registering the CakePHP autoloader.
 * - Setting the default application paths.
 */
require CORE_PATH . 'config' . DS . 'bootstrap.php';

use Cake\Cache\Cache;
use Cake\Console\ConsoleErrorHandler;
use Cake\Core\App;
use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;
use Cake\Core\Plugin;
use Cake\Database\Type;
use Cake\Datasource\ConnectionManager;
use Cake\Error\ErrorHandler;
use Cake\Http\ServerRequest;
use Cake\Log\Log;
use Cake\Mailer\Email;
use Cake\Utility\Inflector;
use Cake\Utility\Security;
use Cake\Routing\Router;

/**
 * Read .env file if APP_NAME is not set.
 *
 * You can remove this block if you do not want to use environment
 * variables for configuration when deploying.
 */
if (!env('APP_NAME') && file_exists(CONFIG . '.env')) {
    $dotenv = new \josegonzalez\Dotenv\Loader([CONFIG . '.env']);
    $dotenv->parse()
        ->putenv()
        ->toEnv()
        ->toServer();
}

/*
 * Read configuration file and inject configuration into various
 * CakePHP classes.
 *
 * By default there is only one configuration file. It is often a good
 * idea to create multiple configuration files, and separate the configuration
 * that changes from configuration that does not. This makes deployment simpler.
 */
try {
    Configure::config('default', new PhpConfig());
    Configure::load('app', 'default', false);
    
    //To load Global configuration files
    Configure::load('global_config', 'default', false);
    
    //To Load Custom Form Template
    Configure::load('app_form', 'default', false);
} catch (\Exception $e) {
    exit($e->getMessage() . "\n");
}

/*
 * Load an environment local configuration file.
 * You can use a file like app_local.php to provide local overrides to your
 * shared configuration.
 */
//Configure::load('app_local', 'default');

/*
 * When debug = true the metadata cache should only last
 * for a short time.
 */
if (Configure::read('debug')) {
    Configure::write('Cache._cake_model_.duration', '+2 minutes');
    Configure::write('Cache._cake_core_.duration', '+2 minutes');
}

/*
 * Set server timezone to UTC. You can change it to another timezone of your
 * choice but using UTC makes time calculations / conversions easier.
 * Check http://php.net/manual/en/timezones.php for list of valid timezone strings.
 */
date_default_timezone_set('UTC');

/*
 * Configure the mbstring extension to use the correct encoding.
 */
mb_internal_encoding(Configure::read('App.encoding'));

/*
 * Set the default locale. This controls how dates, number and currency is
 * formatted and sets the default language to use for translations.
 */
ini_set('intl.default_locale', Configure::read('App.defaultLocale'));

/*
 * Register application error and exception handlers.
 */
$isCli = PHP_SAPI === 'cli';
if ($isCli) {
    (new ConsoleErrorHandler(Configure::read('Error')))->register();
} else {
    (new ErrorHandler(Configure::read('Error')))->register();
}

/*
 * Include the CLI bootstrap overrides.
 */
if ($isCli) {
    require __DIR__ . '/bootstrap_cli.php';
}

/*
 * Set the full base URL.
 * This URL is used as the base of all absolute links.
 *
 * If you define fullBaseUrl in your config file you can remove this.
 */
if (!Configure::read('App.fullBaseUrl')) {
    $s = null;
    if (env('HTTPS')) {
        $s = 's';
    }

    $httpHost = env('HTTP_HOST');
    if (isset($httpHost)) {
        Configure::write('App.fullBaseUrl', 'http' . $s . '://' . $httpHost);
    }
    unset($httpHost, $s);
}

Cache::setConfig(Configure::consume('Cache'));
ConnectionManager::setConfig(Configure::consume('Datasources'));
Email::setConfigTransport(Configure::consume('EmailTransport'));
Email::setConfig(Configure::consume('Email'));
Log::setConfig(Configure::consume('Log'));
Security::setSalt(Configure::consume('Security.salt'));

/*
 * The default crypto extension in 3.0 is OpenSSL.
 * If you are migrating from 2.x uncomment this code to
 * use a more compatible Mcrypt based implementation
 */
//Security::engine(new \Cake\Utility\Crypto\Mcrypt());

/*
 * Setup detectors for mobile and tablet.
 */
ServerRequest::addDetector('mobile', function ($request) {
    $detector = new \Detection\MobileDetect();

    return $detector->isMobile();
});
ServerRequest::addDetector('tablet', function ($request) {
    $detector = new \Detection\MobileDetect();

    return $detector->isTablet();
});

/*
 * Enable immutable time objects in the ORM.
 *
 * You can enable default locale format parsing by adding calls
 * to `useLocaleParser()`. This enables the automatic conversion of
 * locale specific date formats. For details see
 * @link https://book.cakephp.org/3.0/en/core-libraries/internationalization-and-localization.html#parsing-localized-datetime-data
 */
Type::build('time')
    ->useImmutable();
Type::build('date')
    ->useImmutable();
Type::build('datetime')
    ->useImmutable();
Type::build('timestamp')
    ->useImmutable();

/*
 * Custom Inflector rules, can be set to correctly pluralize or singularize
 * table, model, controller names or whatever other string is passed to the
 * inflection functions.
 */
//Inflector::rules('plural', ['/^(inflect)or$/i' => '\1ables']);
//Inflector::rules('irregular', ['red' => 'redlings']);
//Inflector::rules('uninflected', ['dontinflectme']);
//Inflector::rules('transliteration', ['/å/' => 'aa']);

/*
 * Plugins need to be loaded manually, you can either load them one by one or all of them in a single call
 * Uncomment one of the lines below, as you need. make sure you read the documentation on Plugin to use more
 * advanced ways of loading plugins
 *
 * Plugin::loadAll(); // Loads all plugins at once
 * Plugin::load('Migrations'); //Loads a single plugin named Migrations
 *
 */

/*
 * Only try to load DebugKit in development mode
 * Debug Kit should not be installed on a production system
 */
if (Configure::read('debug')) {
    //Plugin::load('DebugKit', ['bootstrap' => true]);
}

/*
 *Load ACL Plugin
 */
Plugin::load('Acl', ['bootstrap' => true]);
Plugin::load('Twilio');


/*
 * SET ALL CONSTANTS VALUE
 */
Configure::write('zilloAppID', 'X1-ZWz18zotebfwgb_8gte4');
Configure::write('baseUrl', Router::url('/', true));
Configure::write('fullBaseUrl', Router::fullBaseUrl());
Configure::write('fromEMail', 'noreply@powertestimonial.com');
Configure::write('siteTitle', 'Power Testimonial');
Configure::write('siteEmail', 'customerservice@powertestimonial.com');
Configure::write('sitePhone', '+1 907-694-4997');
Configure::write('emailSubject', 'Welcome to Power Testimonial');
Configure::write('ZillowIcon', 'img/zillow.png');
Configure::write('GoogleIcon', 'img/Google.png');
Configure::write('YelpIcon', 'img/yelp-icon.png');
Configure::write('FacebookIcon', 'img/facebook-icon.png');
Configure::write('ZillowURL', 'https://www.zillow.com/webservice/ProReviews.htm');
Configure::write('ZillowParam', '&count=10&isTeamMemberReview=true&returnTeamMemberReviews=true');
Configure::write('categoryName', 'Default Category');
Configure::write('categoryDescription', 'This is default category description.');
Configure::write('surveyQuestion', 'Default Question');
Configure::write('questionAnsChoices', 'Good Service|Best Service|Nothing|No Need');
Configure::write('questionCorrectAns', '0,1');
Configure::write('questionAnsTypes', 2);

Configure::write('surveyTemplateSurevyName', '5 Star Survey');
Configure::write('surveyTemplateSurevyDescription', '5 Star survey');
Configure::write('surveyTemplateSurevyGreeting', 'Thank you for rating your experience with us.  Client satisfaction is our #1 priority.  We would like to hear a little more about your experience and ask that you take a quick moment to answer the questions on this page and provide any additional information you may feel is important.  Your feedback helps us ensure we are providing the best service possible to our clients.  Thank you for taking the time to help us out.');
Configure::write('surveyTemplateSurevyFooter', 'Thank you!');
Configure::write('templateSurveyType', '2');

Configure::write('surveyTemplateReviewName', '5 Star review');
Configure::write('surveyTemplateReviewDescription', '5 Star review request');
Configure::write('surveyTemplateReviewGreeting', 'Step 1 of 2.  Please rate your experience.');
Configure::write('surveyTemplateReviewFooter', 'Thank you for your feedback!');
Configure::write('templateReviewType', '1');

Configure::write('surveyCreateSurveyName', '5 Star Survey');
Configure::write('surveyCreateSurveyDescription', '5 Star survey for responses below 5 stars');

Configure::write('surveyCreateReviewName', '5 Star review');
Configure::write('surveyCreateReviewDescription', '5 star review request');

Configure::write('defaultPhone', '000-000-0000');
Configure::write('defaultEmail', 'test@yopmail.com');
Configure::write('reviewSubject', 'Please rate your experience with');
Configure::write('completeSurvey', 'Survey completed');
Configure::write('completeSurveyReview', 'Survey/Review completed');
Configure::write("onlineReview", "New online Review's received");
Configure::write("forgotSubject", "Reset Password Link");
Configure::write("PlanUpgradeMail", "Plan Upgrade Successful");
Configure::write("PlanUpgradeReq", "Plan Upgrade Request");
Configure::write('zillowId', 4);
Configure::write('fiveRatings', 5);
Configure::write('fourRatings', 4);
Configure::write('threeRatings', 3);
Configure::write('twoRatings', 2);
Configure::write('oneRatings', 1);
Configure::write('surveyDone', 2);
Configure::write('surveyType', 2);
Configure::write('zero', 0);
Configure::write('one', 1);
Configure::write('two', 2);
Configure::write('RowLimit', 25);
Configure::write('AssociateGroupId', 4);
Configure::write('CompanyGroupIds', [2,3,7]);
Configure::write('CompanyAdminGroupIds', [3,7,4]);
Configure::write('LocationAdminGroupIds', [7,4]);
Configure::write('TeamleadGroupIds', [4]);
Configure::write('realtor', 'Realtor');
Configure::write('angies', 'Angies List');
Configure::write('bbb', 'Better Business Bureau');
Configure::write('zillow', 'Zillow');
Configure::write('yelp', 'Yelp');
Configure::write('google', 'Google');
Configure::write('facebook', 'Facebook');
Configure::write('googleKey', 'AIzaSyAwgUrto3xgTSoQdYk-nDYqGLmHuyFkqZk');
Configure::write('yelpClientId', 'b3N5P3WED5QQaJIliGALXA');
Configure::write('yelpClientSecret', 'zQD8zCHJMj5Q1SDM4njyhP7Rsqn2NzDgFmtzvaDHIdD-HRMc-r55sBdPJTws8PizcTOV4_vghDfA1Zm2ceYjYeoF0Y4NcNgt3KpyOKM2K_2zEMNUJwT0Mp_uw7i4WnYx');
Configure::write('yelpBusinessesUrl', 'https://api.yelp.com/v3/businesses/');
Configure::write('yelpOauth2TokenUrl', 'https://api.yelp.com/oauth2/token');
Configure::write('FacebookRatingField', '/?fields=overall_star_rating,rating_count,phone,single_line_address&access_token=');
Configure::write('FacebookAppId', '292480271261229');
Configure::write('FacebookAppSecret', 'e84dc1ec9e4e002a1dda3a4e07e00608');
Configure::write('FacebookDetailsURL', 'https://graph.facebook.com/v2.7/');
Configure::write('FacebookGraphURL', 'https://graph.facebook.com/v2.10/');
Configure::write('TwilioAcoountSID', 'ACf359579c58257397f3b172b62d07b2ff');
Configure::write('TwilioAuthToken', '4ece5f826d9a20778653af5aa15c0b86');
Configure::write('TwilioPhoneNumber', '+19073413145');

Configure::write('overall', 'overall');
Configure::write('myself', 'Myself');

/*CONSTANT FOR PLANS*/
Configure::write('PLAN_POWER', 1);
Configure::write('PLAN_POWER_PLUS', 2);
Configure::write('PLAN_ULTIMATE_POWER', 3);

/*CONSTANT FOR FEATURES*/
Configure::write('FEATURE_1_USER_ACCOUNT', 1);
Configure::write('FEATURE_5_STAR_RATING_SYSTEM', 2);
Configure::write('FEATURE_AUTO_REVIEW_REQUESTS', 3);
Configure::write('FEATURE_REAL_TIME_ALERTS', 4);
Configure::write('FEATURE_AUTO_EMAIL_REMINDERS', 5);
Configure::write('FEATURE_AT_A_GLANCE_ANALYSIS', 6);
Configure::write('FEATURE_WEB_REVIEW_WIDGETS', 7);
Configure::write('FEATURE_FREE_TECH_SUPPORT', 8);
Configure::write('FEATURE_CUSTOM_BRANDED', 9);
Configure::write('FEATURE_FULL_DEVICE_OPTIMIZATION', 10);
Configure::write('FEATURE_REVIEW_REQUEST_BUTTON', 11);
Configure::write('FEATURE_10_USER_ACCOUNTS', 12);
Configure::write('FEATURE_5_CUSTOMIZED_SURVEYS_REVIEWS', 13);
Configure::write('FEATURE_INDIVIDUAL_ACCOUNT_BRANDING', 14);
Configure::write('FEATURE_25_USER_ACCOUNTS', 15);
Configure::write('FEATURE_INDIVIDUAL_CUSTOM_BRANDING', 16);
Configure::write('FEATURE_25_CUSTOMIZED_SURVEYS_AND_REVIEWS', 17);
Configure::write('FEATURE_TEXT_INTEGRATION', 18);
Configure::write('FEATURE_REVIEW_ANALYSIS', 19);
Configure::write('FEATURE_FREE_MICROSITE', 20);

/*MAXIMUM USER PERMISSION ACCORDING TO PLANS*/
Configure::write('MAX_USER_POWER', 1);
Configure::write('MAX_USER_POWER_PLUS', 10);
Configure::write('MAX_USER_ULTIMATE_POWER', 25);

/*UP TO MAXIMUM CUSTOMIZED SURVEYS AND REVIEWS*/
Configure::write('MAX_CUSTOM_SURVEYS_POWER', 2);
Configure::write('MAX_CUSTOM_SURVEYS_POWER_PLUS', 7);
Configure::write('MAX_CUSTOM_SURVEYS_ULTIMATE_POWER', 27);

Configure::write("SUBSCRIPTION_MSG", "You don\'t have permission to access this feature. You must have to upgrade your subscription to add this feature. <br><br> <a href=\'/Users/planUpgrade\'>Click Here</a> to upgrade your plan");
Configure::write("ASSOCIATE_SUBSCRIPTION_MSG", "You don\'t have permission to access this feature. Please contact your company admin.");

$surveyReviewAll = [1,2,3];
Configure::write('survey_review_all', $surveyReviewAll);

$surveyReviewPending = [1,3];
Configure::write('survey_review_pending', $surveyReviewPending);

$surveyReviewCompleted = [2];
Configure::write('survey_review_completed', $surveyReviewCompleted);

$partiallyCompleted = [2,3];
Configure::write('partially_completed', $partiallyCompleted);

Configure::write('emailBody', '<p>Hello {Recipient_Name},</p><p>Thank you for offering to write a review about your most recent experience with <strong>{Sender_Business_Name}</strong> and <strong>{Sender_Name}</strong>. I hope you had a great experience and are satisfied with the service I provided. Your feedback is very valuable and I appreciate you taking the time to rate your experience.</p><p>{CLICK_HERE_to_rate_your_experience}</p><p>Sincerely,</p></p>{Sender_Name}<br><strong>Email:</strong> {Sender_Email}<br><strong>Phone:</strong> {Sender_Phone}</p>');

Configure::write("FACEBOOK_RELOGIN", "Login with Facebook in our system to fetch latest online reviews. <br><br> Please <a href=\'/ApiConfigurations/\'>Click Here</a> to login with facebook");
Configure::write("SMS_VERBIAGE", "Hello {Recipient_Name},\n\nThank you for offering to write a review about your most recent experience with {Sender_Business_Name} and {Sender_Name}. Your feedback is very valuable and I appreciate you taking the time to rate your experience.\n\nClick link below to rate your experience\n\n{CLICK_HERE_to_rate_your_experience}");

/*CONSTANT FOR USER ROLES*/
Configure::write('SUPER_ADMIN', 1);
Configure::write('COMPANY_REPRESENTATIVE', 2);
Configure::write('LOCATION_ADMIN', 3);
Configure::write('TEAM_LEAD', 7);
Configure::write('ASSOCIATE', 4);

Configure::write('STAR_ANS', ['1 Star', '2 Star', '3 Star', '4 Star', '5 Star']);

Configure::write('GOOGLEURL', "https://maps.googleapis.com/maps/api/place/details/json");
Configure::write('YELPDOMURL', 'https://www.yelp.com/biz/');
Configure::write('CONTACTSUB', 'Contact - Power Testimonial');

/*CONSTANT FOR PAYMENT GATEWAY*/
Configure::write('ePNAccount', '080880');
Configure::write('RestrictKey', 'yFqqXJh9Pqnugfr');
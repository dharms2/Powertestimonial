<?php
namespace App\Shell;

use Cake\Console\Shell;
use Cake\ORM\TableRegistry;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use App\Controller\Component\ReviewApiComponent;

/**
 * Simple AutoReminder Shell
 * A longer class description
 *
 */
class FetchFacebookReviewShell extends Shell
{
    public function initialize()
    {
        parent::initialize();
        $this->ReviewApi = new ReviewApiComponent(new ComponentRegistry());
    }
    
    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
    public function main()
    {
        $this->fetchFacebookReview();
    }
    
    /**
     * Display help for this console.
     * fetchFacebook, Method used for fetch latest online reviews of facebook
     *
     * @return \Cake\Console\ConsoleOptionParser
     */
    public function fetchFacebookReview()
    {
        $usersTable = TableRegistry::get('Users');
        $facebookTable = TableRegistry::get('Facebook');
        $apiConfigurationsTable = TableRegistry::get('ApiConfigurations');
        $apiUsers = $apiConfigurationsTable->find('all', ['fields' => ['user_id']])->toArray();
        
        foreach ($apiUsers as $apiUser) {
            $userData = $usersTable->findById($apiUser->user_id)->first();
            if ($userData->is_active == 1) {
                $apiConfigurations = $apiConfigurationsTable->getApiDetails(['user_id' => $apiUser->user_id]);

                //fetch and save Facebook Review data into DB
                if (!empty($apiConfigurations->facebook_page_name && !empty($apiConfigurations->facebook_app_id) && !empty($apiConfigurations->facebook_app_secret))) {
                    $facebook = $this->ReviewApi->getFacebookDetails($apiConfigurations->facebook_app_id, $apiConfigurations->facebook_app_secret);

                    if ($facebook['message'] == 'OK') {
                        $facebookData = $facebookTable->getFacebookDataByUserId($userData->id);
                        $errFlag = 1;

                        if (empty($facebook['response']->error)) {
                            foreach ($facebook['response']->data as $data) {
                                if ($data->name == $apiConfigurations->facebook_page_name) {
                                    $errFlag = 0;
                                    $profileImg = $this->ReviewApi->getFacebookProfileImg($data->id);
                                    $insertFacebook = $this->ReviewApi->insertFacebookData($data, $userData, $profileImg['response']);
                                    if (!empty($insertFacebook->page_id) && !empty($insertFacebook->access_token)) {
                                        $pullFacebookReview = $this->ReviewApi->getFacebookReviews($insertFacebook->page_id, $insertFacebook->access_token);
                                        if ($pullFacebookReview['message'] == 'OK') {
                                            $this->ReviewApi->getFacebookReviewsData($pullFacebookReview['response'], $userData, $facebookData, $apiConfigurations, $data);
                                            $this->out(print_r('Successfuly fetch facebook reviews', true));
                                        }
                                    }
                                } 
                            }
                        }
                        if ($errFlag == 1) {
                            $this->out(print_r('Page not found', true));
                        }
                    }
                } 
                else {
                    $this->out(print_r('There is no facebook api configration setting found', true));
                }
            }
        }
    }
        
}

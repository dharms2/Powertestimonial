<?php
namespace App\Shell;

use Cake\Console\Shell;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use App\Controller\Component\ReviewApiComponent;

/**
 * Simple AutoReminder Shell
 * A longer class description
 *
 */
class FetchZillowReviewShell extends Shell
{
    
    public function initialize()
    {
        parent::initialize();
        $this->ReviewApi = new ReviewApiComponent(new ComponentRegistry());
    }
    
    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
    public function main()
    {
        $this->fetchZillowReview();
    }
    
    /**
     * Display help for this console.
     * fetchZillowReview, Method used for fetch latest online reviews of zillow
     *
     * @return \Cake\Console\ConsoleOptionParser
     */
    public function fetchZillowReview()
    {
        $usersTable = TableRegistry::get('Users');
        $zillowTable = TableRegistry::get('Zillow');
        $apiConfigurationsTable = TableRegistry::get('ApiConfigurations');
        $apiUsers = $apiConfigurationsTable->find('all', ['fields' => ['user_id']])->toArray();

        foreach ($apiUsers as $apiUser) {
            $userData = $usersTable->findById($apiUser->user_id)->first();
            
            if ($userData->is_active == 1) {
                $apiConfigurations = $apiConfigurationsTable->getApiDetails(['user_id' => $apiUser->user_id]);
                //fetch and save Zillow Review data into DB
                if (!empty($apiConfigurations->zillow_screen_name)) {
                    $zillowData = $zillowTable->getZillowDetails($userData->id);

                    $url = Configure::read('ZillowURL') . '?zws-id=' . $apiConfigurations->zillow_access_Id . '&screenname=' . urlencode($apiConfigurations->zillow_screen_name) . '' . Configure::read('ZillowParam');
                    $zillowXmlData = file_get_contents($url);
                    $xml = simplexml_load_string($zillowXmlData);
                    $msgCode = (array) $xml->message->code;
                    //save Zillow API data into DB
                    if (!empty($xml) && $msgCode[0] == 0) {
                        $zillow = $this->ReviewApi->zillow($xml, $userData);
                        if (!empty($zillow)) {
                            $reviewsData = [];
                            $reviewsData['proReviews'] = (array) $xml->response->result->proReviews;
                            if (!empty($reviewsData['proReviews'])) {
                                $this->ReviewApi->zillowDetails($reviewsData['proReviews'], $userData, $zillowData, $apiConfigurations);
                                $this->out(print_r('Successfuly fetch zillow reviews', true));
                            }
                        }
                    }
                } 
                else {
                    $this->out(print_r('There is no zillow api configration setting found', true));
                }
            }
        }
    }

}

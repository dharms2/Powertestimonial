<?php
namespace App\Shell;

use Cake\Console\Shell;
use Cake\ORM\TableRegistry;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;
use App\Controller\Component\ReviewApiComponent;

/**
 * Simple AutoReminder Shell
 * A longer class description
 *
 */
class FetchYelpReviewShell extends Shell
{
    
    public function initialize()
    {
        parent::initialize();
        $this->ReviewApi = new ReviewApiComponent(new ComponentRegistry());
    }
    
    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
    public function main()
    {
        $this->fetchYelpReview();
    }
    
    /**
     * Display help for this console.
     * fetchFacebook, Method used for fetch latest online reviews of yelp
     *
     * @return \Cake\Console\ConsoleOptionParser
     */
    public function fetchYelpReview()
    {
        $usersTable = TableRegistry::get('Users');
        $yelpTable = TableRegistry::get('Yelp');
        $apiConfigurationsTable = TableRegistry::get('ApiConfigurations');
        $apiUsers = $apiConfigurationsTable->find('all', ['fields' => ['user_id']])->toArray();
        
        foreach ($apiUsers as $apiUser) {
            $userData = $usersTable->findById($apiUser->user_id)->first();
            
            if ($userData->is_active == 1) {
                $apiConfigurations = $apiConfigurationsTable->getApiDetails(['user_id' => $apiUser->user_id]);
                //fetch and save Facebook Review data into DB
                if (!empty($apiConfigurations->yelp_business_id)) {
                    $yelpData = $yelpTable->getYelpDataByUserId($userData->id);
                    $yelpAccessToken = $this->ReviewApi->getYelpAccessToken();

                    if (!empty($yelpAccessToken) && $yelpAccessToken['code'] == 200) {
                        $getYelpDetail = $this->ReviewApi->getYelpDetails($yelpAccessToken['response'], $apiConfigurations->yelp_business_id);
                        if (!empty($getYelpDetail)) {
                            $yelp = $this->ReviewApi->insertYelpData($getYelpDetail, $userData);
                            if (!empty($yelp)) {
                                $yelpReviews = $this->ReviewApi->getYelpReviews($yelpAccessToken['response'], $apiConfigurations->yelp_business_id);
                                if (!empty($yelpReviews->reviews)) {
                                    $this->ReviewApi->yelpReviewData($yelpReviews, $userData, $yelpData, $apiConfigurations);
                                    $this->out(print_r('Successfuly fetch yelp reviews', true));
                                }
                            }
                        }
                    }
                } 
                else {
                    $this->out(print_r('There is no yelp api configration setting found', true));
                    
                }
            }
        }
    }
    
}

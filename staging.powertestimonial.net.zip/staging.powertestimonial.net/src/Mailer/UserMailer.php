<?php

namespace App\Mailer;

use Cake\Mailer\Mailer;

class UserMailer extends Mailer {

    public function registered($user) {
        // attach a text file 
        pr($user);die;
        $this
//                ->attachments([
//                    'text for user.txt' => [
//                        'file' => 'files/example.txt',
//                        'mimetype' => 'plain/text',
//                        'contentId' => '3734hf38'
//                    ],
//                    // attach an image file 
//                    'edit.png' => [
//                        'file' => 'files/welcome.png',
//                        'mimetype' => 'image/png',
//                        'contentId' => '734h3r38'
//                    ]
//                ])
                ->to($user->email)
                ->emailFormat('html')
                ->subject(sprintf('Welcome %s', $user->first_name))
                ->viewVars([
                    'firstname' => $user->first_name,
                    'lastname' => $user->last_name,
                    'useremail' => $user->email
                ])
                // the template file you will use in this emial
                ->template('registered') // By default template with same name as method name is used.
                // the layout .ctp file you will use in this email
                ->layout('default');
    }

    public function resetPassword($user) {
        $this->to($user->email)
                ->subject('Reset password')
                ->set(['token' => $user->token]);
    }

}

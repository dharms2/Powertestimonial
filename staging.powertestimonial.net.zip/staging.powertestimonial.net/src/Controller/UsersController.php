<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class UsersController extends AppController 
{
    public $components = ['CommonFunction', 'ReviewApi'];

    public function initialize() 
    {
        parent::initialize();
        $this->loadComponent('Cookie');
        $this->loadComponent('Flash');
        $this->loadModel('Yelp');
        $this->loadModel('Plans');
        $this->loadModel('Groups');
        $this->loadModel('Zillow');
        $this->loadModel('Google');
        $this->loadModel('Country');
        $this->loadModel('Facebook');
        $this->loadModel('UserPlans');
        $this->loadModel('ApiReviews');
        $this->loadModel('SurveyMgmt');
        $this->loadModel('ReviewsMgmt');
        $this->loadModel('SurveyCategory');
        $this->loadModel('SurveyQuestion');
        $this->loadModel('SurveyTemplates');
        $this->loadModel('PlanFeaturesXref');
        $this->loadModel('ApiConfigurations');
        $this->loadModel('CustomEmailTemplates');
        $this->loadModel('SurveyTemplatesQuestion');
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Dashboard']);
        $baseUrl = Configure::read('baseUrl');
        
        $userId = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $companyUser = $this->Users->getUserDetails($userImg->company_id);

        $analyticsPlanFeature = $this->CommonFunction->checkPlanFeature($companyUser->plan_id, Configure::read('FEATURE_AT_A_GLANCE_ANALYSIS'));
        if ($userImg->group_id != 1) {
            $allUsersData = $this->CommonFunction->getChildUers($userImg);
            if (!empty($allUsersData)) {
                $allAssociatesList = $this->Users->getAllAssociatesUserList($allUsersData);
                $allAssociates = $allAssociatesList;
            }
            $allAssociates[$this->CommonFunction->getCurrentUserId()] = Configure::read('myself');
            $allAssociates[1] = Configure::read('overall');
        }
        
        $zillowData = $this->Zillow->getZillowDetails($userImg->id);
        $googleData = $this->Google->getGoogleDataByUserId($userImg->id);
        $yelpData = $this->Yelp->getYelpDataByUserId($userImg->id);
        $facebookData = $this->Facebook->getFacebookDataByUserId($userImg->id);
        $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $userImg->id]);
        
        include_once( ROOT.'/vendor/Facebook/facebook-php-sdk-v5/autoload.php' );
        $fb = new \Facebook\Facebook([
                'app_id' => Configure::read('FacebookAppId'), // Replace {app-id} with your app id
                'app_secret' => Configure::read('FacebookAppSecret'),
                'default_graph_version' => 'v2.10',
        ]);
        // Load Facebook redirect login helper
        $helper = $fb->getRedirectLoginHelper();
        
        // Optional permissions
        $permissions = ['business_management','email','manage_pages','public_profile','user_friends'];
        $loginUrl = $helper->getLoginUrl($baseUrl.'ApiConfigurations/fbCallback', $permissions);
        
        if (!empty($apiConfigurations->facebook_page_name)) {
            if (empty($apiConfigurations->facebook_app_id) && empty($apiConfigurations->facebook_app_secret) && !isset($_COOKIE['Facebook'])) {
                $this->Cookie->write('Facebook', "Facebook Token", true, "+1 week");
                $this->Flash->alert(__("Login with Facebook in our system to fetch latest online reviews. <br><br> Please <a href=\'".htmlspecialchars($loginUrl)."\'>Click Here</a> to login with facebook"));
            }
        }
        
        if (empty($this->request->query()) || $this->request->query('days') == 0) {
            $breadcrumb = "Lifetime";
            $months = $this->CommonFunction->allMonths();
            
            $zilloReview = $this->ApiReviews->getAllZilloReview($userImg->id, date('Y-m-d'));
            $googleReview = $this->ApiReviews->getAllGoogleReview($userImg->id, date('Y-m-d'));
            $yelpReview = $this->ApiReviews->getAllYelpReview($userImg->id, date('Y-m-d'));
            $facebookReview = $this->ApiReviews->getAllFacebookReview($userImg->id, date('Y-m-d'));
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($userImg->id, date('Y-m-d'));
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($userImg->id, date('Y-m-d'));
            $overallRatings = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'))->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'));
            
            $allReviews = $this->CommonFunction->oneYearReviews($userImg->id);
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews($userImg->id);
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews($userImg->id);
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews($userImg->id);
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews($userImg->id);

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fiveRatings'), date('Y-m-d'));
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fourRatings'), date('Y-m-d'));
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('threeRatings'), date('Y-m-d'));
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('twoRatings'), date('Y-m-d'));
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('oneRatings'), date('Y-m-d'));
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
                       
            $onlineReviews5star = $this->ApiReviews->getOnlineReviews([$userImg->id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->getOnlineReviews([$userImg->id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->getOnlineReviews([$userImg->id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->getOnlineReviews([$userImg->id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->getOnlineReviews([$userImg->id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $totalSurveyReview = $this->CommonFunction->getAllSurveyReview([$userImg->id], Configure::read('survey_review_all'));
            $totalSurveyReviewComplete = $this->CommonFunction->getAllSurveyReview([$userImg->id], Configure::read('survey_review_completed'));
            $totalSurveyReviewIncomplete = $this->CommonFunction->getAllSurveyReview([$userImg->id], Configure::read('survey_review_pending'));

            $this->set(compact(
                    'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete', 'months', 'allReviews', 'allZillowReviews', 
                    'allGoogleReviews', 'allYelpReviews', 'allFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 365) {
            $breadcrumb = "Past 12 Months";
            $months = $this->CommonFunction->allMonths();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -1 year"));
            
            $zilloReview = $this->ApiReviews->getAllZilloReview($userImg->id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($userImg->id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($userImg->id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($userImg->id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($userImg->id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($userImg->id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate);
            
            $allReviews = $this->CommonFunction->oneYearReviews($userImg->id);
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews($userImg->id);
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews($userImg->id);
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews($userImg->id);
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews($userImg->id);

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
                       
            $onlineReviews5star = $this->ApiReviews->get12MonthsOnlineReviews([$userImg->id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get12MonthsOnlineReviews([$userImg->id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get12MonthsOnlineReviews([$userImg->id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get12MonthsOnlineReviews([$userImg->id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get12MonthsOnlineReviews([$userImg->id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $past12MonthsSurveyReview = $this->CommonFunction->getPast12MonthsSurveyReview([$userImg->id], Configure::read('survey_review_all'));
            $past12MonthsSurveyReviewComplete = $this->CommonFunction->getPast12MonthsSurveyReview([$userImg->id], Configure::read('survey_review_completed'));
            $past12MonthsSurveyReviewIncomplete = $this->CommonFunction->getPast12MonthsSurveyReview([$userImg->id], Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past12MonthsSurveyReview', 'past12MonthsSurveyReviewComplete', 'past12MonthsSurveyReviewIncomplete', 
                    'months', 'allReviews', 'allZillowReviews', 'allGoogleReviews', 'allYelpReviews', 'allFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 30) {
            $breadcrumb = "Past 30 Days";
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -30 days"));

            $zilloReview = $this->ApiReviews->getAllZilloReview($userImg->id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($userImg->id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($userImg->id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($userImg->id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($userImg->id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($userImg->id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate);
            
            $past30DaysReviews = $this->CommonFunction->past30DaysReviews($userImg->id);
            $past30DaysZillowReviews = $this->CommonFunction->past30DaysZillowReviews($userImg->id);
            $past30DaysYelpReviews = $this->CommonFunction->past30DaysYelpReviews($userImg->id);
            $past30DaysGoogleReviews = $this->CommonFunction->past30DaysGoogleReviews($userImg->id);
            $past30DaysFacebookReviews = $this->CommonFunction->past30DaysFacebookReviews($userImg->id);
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get30DaysOnlineReviews([$userImg->id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get30DaysOnlineReviews([$userImg->id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get30DaysOnlineReviews([$userImg->id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get30DaysOnlineReviews([$userImg->id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get30DaysOnlineReviews([$userImg->id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past30DaysSurveyReview = $this->CommonFunction->past30DaysSurveyReview($userImg->id, Configure::read('survey_review_all'));
            $past30DaysSurveyReviewComplete = $this->CommonFunction->past30DaysSurveyReview($userImg->id, Configure::read('survey_review_completed'));
            $past30DaysSurveyReviewIncomplete = $this->CommonFunction->past30DaysSurveyReview($userImg->id, Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past30DaysSurveyReview', 'past30DaysSurveyReviewComplete', 'past30DaysSurveyReviewIncomplete', 'past30DaysReviews', 
                    'past30DaysZillowReviews', 'past30DaysYelpReviews', 'past30DaysGoogleReviews', 'past30DaysFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 7) {
            $breadcrumb = "Past 7 Days";
            $daysName = $this->CommonFunction->allDays();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -7 days"));

            $zilloReview = $this->ApiReviews->getAllZilloReview($userImg->id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($userImg->id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($userImg->id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($userImg->id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($userImg->id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($userImg->id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($userImg->id, date('Y-m-d'), $endDate);
            
            $past7DaysReviews = $this->CommonFunction->past7DaysReviews($userImg->id);
            $past7DaysZillowReviews = $this->CommonFunction->past7DaysZillowReviews($userImg->id);
            $past7DaysYelpReviews = $this->CommonFunction->past7DaysYelpReviews($userImg->id);
            $past7DaysGoogleReviews = $this->CommonFunction->past7DaysGoogleReviews($userImg->id);
            $past7DaysFacebookReviews = $this->CommonFunction->past7DaysFacebookReviews($userImg->id);
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($userImg->id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get7DaysOnlineReviews([$userImg->id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get7DaysOnlineReviews([$userImg->id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get7DaysOnlineReviews([$userImg->id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get7DaysOnlineReviews([$userImg->id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get7DaysOnlineReviews([$userImg->id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past7DaysSurveyReview = $this->CommonFunction->past7DaysSurveyReview($userImg->id, Configure::read('survey_review_all'));
            $past7DaysSurveyReviewComplete = $this->CommonFunction->past7DaysSurveyReview($userImg->id, Configure::read('survey_review_completed'));
            $past7DaysSurveyReviewIncomplete = $this->CommonFunction->past7DaysSurveyReview($userImg->id, Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past7DaysSurveyReview', 'past7DaysSurveyReviewComplete', 'past7DaysSurveyReviewIncomplete', 'past7DaysReviews', 
                    'past7DaysZillowReviews', 'past7DaysYelpReviews', 'past7DaysGoogleReviews', 'past7DaysFacebookReviews', 'daysName'
                )
            );
        }
        $glAvgRating = [];
        foreach ($googleReviewData as $glReview) {
            $glAvgRating[] = $glReview->rating;
        }
            
        $fbAvgRating = [];
        foreach ($fbReviewData as $fbReview) {
            $fbAvgRating[] = $fbReview->rating;
        }
            
        $ratingItems = [];
        foreach ($overallRatings as $overallRating) {
            $ratingItems[] = $overallRating->rating;
        }
            
        $this->set(compact(
                'breadcrumb', 'title', 'zillowData', 'apiReviewsDetails', 'googleData', 'yelpData', 'facebookData', 'months', 'ratingItems', 'fbAvgRating',
                'zilloReview', 'googleReview', 'yelpReview', 'userImg', 'glAvgRating', 'facebookReview', 'apiConfigurations', 'allAssociates', 'baseUrl', 
                'userId', 'analyticsPlanFeature', 'avgRatingAllStar', 'allOnlineStar', 'onlineReviews5star', 'onlineReviews4star', 'onlineReviews3star', 
                'onlineReviews2star', 'onlineReviews1star', 'reviewResponse1star', 'reviewResponse2star', 'reviewResponse3star', 'reviewResponse4star', 
                'reviewResponse5star', 'allStar'
            )
        );
    }
    
    /**
     * associate Review Data method
     *
     * @return \Cake\Http\Response|void
     */
    public function associateReviewData() 
    {
        $title = __('{0} power_testimonial', ['Dashboard']);
        $baseUrl = Configure::read('baseUrl');
        $id = base64_decode($this->request->query('userId'));
        
        $userId = $id;
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $analyticsPlanFeature = $this->CommonFunction->checkPlanFeature($companyUser->plan_id, Configure::read('FEATURE_AT_A_GLANCE_ANALYSIS'));
        
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        if (!empty($allUsersData)) {
            $allAssociatesList = $this->Users->getAllAssociatesUserList($allUsersData);
            $allAssociates = $allAssociatesList;
        }
        $allAssociates[$this->CommonFunction->getCurrentUserId()] = Configure::read('myself');
        $allAssociates[1] = Configure::read('overall');
        
        $zillowData = $this->Zillow->getZillowDetails($id);
        $googleData = $this->Google->getGoogleDataByUserId($id);
        $yelpData = $this->Yelp->getYelpDataByUserId($id);
        $facebookData = $this->Facebook->getFacebookDataByUserId($id);
        $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $id]);
                
        if (empty($this->request->query()) || $this->request->query('days') == 0) {
            $breadcrumb = "Lifetime";
            $months = $this->CommonFunction->allMonths();
            
            $zilloReview = $this->ApiReviews->getAllZilloReview($id, date('Y-m-d'));
            $googleReview = $this->ApiReviews->getAllGoogleReview($id, date('Y-m-d'));
            $yelpReview = $this->ApiReviews->getAllYelpReview($id, date('Y-m-d'));
            $facebookReview = $this->ApiReviews->getAllFacebookReview($id, date('Y-m-d'));
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($id, date('Y-m-d'));
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($id, date('Y-m-d'));
            $overallRatings = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'))->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'));
            
            $allReviews = $this->CommonFunction->oneYearReviews($id);
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews($id);
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews($id);
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews($id);
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews($id);

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fiveRatings'), date('Y-m-d'));
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fourRatings'), date('Y-m-d'));
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('threeRatings'), date('Y-m-d'));
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('twoRatings'), date('Y-m-d'));
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('oneRatings'), date('Y-m-d'));
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->getOnlineReviews([$id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->getOnlineReviews([$id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->getOnlineReviews([$id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->getOnlineReviews([$id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->getOnlineReviews([$id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $totalSurveyReview = $this->CommonFunction->getAllSurveyReview([$id], Configure::read('survey_review_all'));
            $totalSurveyReviewComplete = $this->CommonFunction->getAllSurveyReview([$id], Configure::read('survey_review_completed'));
            $totalSurveyReviewIncomplete = $this->CommonFunction->getAllSurveyReview([$id], Configure::read('survey_review_pending'));
            
            $this->set(compact(
                    'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete', 'months', 'allReviews', 'allZillowReviews', 
                    'allGoogleReviews', 'allYelpReviews', 'allFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 365) {
            $breadcrumb = "Past 12 Months";
            $months = $this->CommonFunction->allMonths();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -1 year"));
            
            $zilloReview = $this->ApiReviews->getAllZilloReview($id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate);
            
            $allReviews = $this->CommonFunction->oneYearReviews($id);
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews($id);
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews($id);
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews($id);
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews($id);

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get12MonthsOnlineReviews([$id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get12MonthsOnlineReviews([$id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get12MonthsOnlineReviews([$id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get12MonthsOnlineReviews([$id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get12MonthsOnlineReviews([$id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $past12MonthsSurveyReview = $this->CommonFunction->getPast12MonthsSurveyReview([$id], Configure::read('survey_review_all'));
            $past12MonthsSurveyReviewComplete = $this->CommonFunction->getPast12MonthsSurveyReview([$id], Configure::read('survey_review_completed'));
            $past12MonthsSurveyReviewIncomplete = $this->CommonFunction->getPast12MonthsSurveyReview([$id], Configure::read('survey_review_pending'));
            
            $this->set(compact(
                    'past12MonthsSurveyReview', 'past12MonthsSurveyReviewComplete', 'past12MonthsSurveyReviewIncomplete', 
                    'months', 'allReviews', 'allZillowReviews', 'allGoogleReviews', 'allYelpReviews', 'allFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 30) {
            $breadcrumb = "Past 30 Days";
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -30 days"));

            $zilloReview = $this->ApiReviews->getAllZilloReview($id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate);
                        
            $past30DaysReviews = $this->CommonFunction->past30DaysReviews($id);
            $past30DaysZillowReviews = $this->CommonFunction->past30DaysZillowReviews($id);
            $past30DaysYelpReviews = $this->CommonFunction->past30DaysYelpReviews($id);
            $past30DaysGoogleReviews = $this->CommonFunction->past30DaysGoogleReviews($id);
            $past30DaysFacebookReviews = $this->CommonFunction->past30DaysFacebookReviews($id);
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get30DaysOnlineReviews([$id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get30DaysOnlineReviews([$id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get30DaysOnlineReviews([$id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get30DaysOnlineReviews([$id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get30DaysOnlineReviews([$id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past30DaysSurveyReview = $this->CommonFunction->past30DaysSurveyReview($id, Configure::read('survey_review_all'));
            $past30DaysSurveyReviewComplete = $this->CommonFunction->past30DaysSurveyReview($id, Configure::read('survey_review_completed'));
            $past30DaysSurveyReviewIncomplete = $this->CommonFunction->past30DaysSurveyReview($id, Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past30DaysSurveyReview', 'past30DaysSurveyReviewComplete', 'past30DaysSurveyReviewIncomplete', 'past30DaysReviews', 
                    'past30DaysZillowReviews', 'past30DaysYelpReviews', 'past30DaysGoogleReviews', 'past30DaysFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 7) {
            $breadcrumb = "Past 7 Days";
            $daysName = $this->CommonFunction->allDays();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -7 days"));

            $zilloReview = $this->ApiReviews->getAllZilloReview($id, date('Y-m-d'), $endDate);
            $googleReview = $this->ApiReviews->getAllGoogleReview($id, date('Y-m-d'), $endDate);
            $yelpReview = $this->ApiReviews->getAllYelpReview($id, date('Y-m-d'), $endDate);
            $facebookReview = $this->ApiReviews->getAllFacebookReview($id, date('Y-m-d'), $endDate);
            
            $googleReviewData = $this->ApiReviews->getAvgGoogleRating($id, date('Y-m-d'), $endDate);
            $fbReviewData = $this->ApiReviews->getAvgFacebookRating($id, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate)->toArray();
            $apiReviewsDetails = $this->ApiReviews->getAllValidApiReview($id, date('Y-m-d'), $endDate);
                        
            $past7DaysReviews = $this->CommonFunction->past7DaysReviews($id);
            $past7DaysZillowReviews = $this->CommonFunction->past7DaysZillowReviews($id);
            $past7DaysYelpReviews = $this->CommonFunction->past7DaysYelpReviews($id);
            $past7DaysGoogleReviews = $this->CommonFunction->past7DaysGoogleReviews($id);
            $past7DaysFacebookReviews = $this->CommonFunction->past7DaysFacebookReviews($id);
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($id, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get7DaysOnlineReviews([$id], Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get7DaysOnlineReviews([$id], Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get7DaysOnlineReviews([$id], Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get7DaysOnlineReviews([$id], Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get7DaysOnlineReviews([$id], Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past7DaysSurveyReview = $this->CommonFunction->past7DaysSurveyReview($id, Configure::read('survey_review_all'));
            $past7DaysSurveyReviewComplete = $this->CommonFunction->past7DaysSurveyReview($id, Configure::read('survey_review_completed'));
            $past7DaysSurveyReviewIncomplete = $this->CommonFunction->past7DaysSurveyReview($id, Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past7DaysSurveyReview', 'past7DaysSurveyReviewComplete', 'past7DaysSurveyReviewIncomplete', 'past7DaysReviews', 
                    'past7DaysZillowReviews', 'past7DaysYelpReviews', 'past7DaysGoogleReviews', 'past7DaysFacebookReviews', 'daysName' 
                )
            );
        }
        $glAvgRating = [];
        foreach ($googleReviewData as $glReview) {
            $glAvgRating[] = $glReview->rating;
        }
            
        $fbAvgRating = [];
        foreach ($fbReviewData as $fbReview) {
            $fbAvgRating[] = $fbReview->rating;
        }
            
        $ratingItems = [];
        foreach ($overallRatings as $overallRating) {
            $ratingItems[] = $overallRating->rating;
        }
            
        $this->set(compact(
                'breadcrumb', 'title', 'zillowData', 'apiReviewsDetails', 'googleData', 'yelpData', 'facebookData', 'months', 'ratingItems', 
                'fbAvgRating', 'zilloReview', 'googleReview', 'yelpReview', 'userImg', 'glAvgRating', 'facebookReview', 'apiConfigurations', 
                'baseUrl', 'allAssociates', 'userId', 'analyticsPlanFeature', 'avgRatingAllStar', 'allOnlineStar', 'onlineReviews5star', 
                'onlineReviews4star', 'onlineReviews3star', 'onlineReviews2star', 'onlineReviews1star', 'reviewResponse1star', 'reviewResponse2star', 
                'reviewResponse3star', 'reviewResponse4star', 'reviewResponse5star', 'allStar'
            )
        );
    }
    
    public function overallReview($uId = null) 
    {
        $title = __('{0} power_testimonial', ['Dashboard']);
        $userId = $this->request->query('userId');

        $baseUrl = Configure::read('baseUrl');
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $analyticsPlanFeature = $this->CommonFunction->checkPlanFeature($companyUser->plan_id, Configure::read('FEATURE_AT_A_GLANCE_ANALYSIS'));
        
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
        $ids = $allUsersData;
        $ids[] = $userImg->id;
        
        $allAssociatesList = $this->Users->getAllAssociatesUserList($ids);
        $allAssociates = $allAssociatesList;
        $allAssociates[$this->CommonFunction->getCurrentUserId()] = Configure::read('myself');
        $allAssociates[$userId] = Configure::read('overall');
        
        if (empty($this->request->query()) || $this->request->query('days') == 0) {
            $breadcrumb = "Lifetime";
            $months = $this->CommonFunction->allMonths();
            
            $apiReviewsDetails = $this->ApiReviews->getOverAllApiReview($ids, date('Y-m-d'));
            $overallRatings = $this->ApiReviews->getOverAllApiRating($ids, date('Y-m-d'));
            $overallFbRatings = $this->ApiReviews->getOverAllFbRatings($ids, date('Y-m-d'));
            $overallZillowRatings = $this->ApiReviews->getOverAllZillowRatings($ids, date('Y-m-d'));
            $overallGoogleRatings = $this->ApiReviews->getOverAllGoogleRatings($ids, date('Y-m-d'));
            $overallYelpRatings = $this->ApiReviews->getOverAllYelpRatings($ids, date('Y-m-d'));
            
            $allReviews = $this->CommonFunction->oneYearReviews(implode(',', $ids));
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews(implode(',', $ids));
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews(implode(',', $ids));
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews(implode(',', $ids));
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews(implode(',', $ids));

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fiveRatings'), date('Y-m-d'));
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fourRatings'), date('Y-m-d'));
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('threeRatings'), date('Y-m-d'));
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('twoRatings'), date('Y-m-d'));
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('oneRatings'), date('Y-m-d'));
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $totalSurveyReview = $this->CommonFunction->getAllSurveyReview($ids, Configure::read('survey_review_all'));
            $totalSurveyReviewComplete = $this->CommonFunction->getAllSurveyReview($ids, Configure::read('survey_review_completed'));
            $totalSurveyReviewIncomplete = $this->CommonFunction->getAllSurveyReview($ids, Configure::read('survey_review_pending'));
            
            $this->set(compact(
                    'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete', 'reviewResponse1star', 'months', 'allReviews', 
                    'allZillowReviews', 'allGoogleReviews', 'allYelpReviews', 'allFacebookReviews' 
                )
            );
        } else if ($this->request->query('days') == 365) {
            $breadcrumb = "Past 12 Months";
            $months = $this->CommonFunction->allMonths();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -1 year"));
            
            $apiReviewsDetails = $this->ApiReviews->getOverAllApiReview($ids, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getOverAllApiRating($ids, date('Y-m-d'), $endDate);
            $overallFbRatings = $this->ApiReviews->getOverAllFbRatings($ids, date('Y-m-d'), $endDate);
            $overallZillowRatings = $this->ApiReviews->getOverAllZillowRatings($ids, date('Y-m-d'), $endDate);
            $overallGoogleRatings = $this->ApiReviews->getOverAllGoogleRatings($ids, date('Y-m-d'), $endDate);
            $overallYelpRatings = $this->ApiReviews->getOverAllYelpRatings($ids, date('Y-m-d'), $endDate);
            
            $allReviews = $this->CommonFunction->oneYearReviews(implode(',', $ids));
            $allZillowReviews = $this->CommonFunction->oneYearZillowReviews(implode(',', $ids));
            $allGoogleReviews = $this->CommonFunction->oneYearGoogleReviews(implode(',', $ids));
            $allYelpReviews = $this->CommonFunction->oneYearYelpReviews(implode(',', $ids));
            $allFacebookReviews = $this->CommonFunction->oneYearFacebookReviews(implode(',', $ids));

            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
            
            $past12MonthsSurveyReview = $this->CommonFunction->getPast12MonthsSurveyReview($ids, Configure::read('survey_review_all'));
            $past12MonthsSurveyReviewComplete = $this->CommonFunction->getPast12MonthsSurveyReview($ids, Configure::read('survey_review_completed'));
            $past12MonthsSurveyReviewIncomplete = $this->CommonFunction->getPast12MonthsSurveyReview($ids, Configure::read('survey_review_pending'));
            
            $this->set(compact(
                    'past12MonthsSurveyReview', 'past12MonthsSurveyReviewComplete', 'past12MonthsSurveyReviewIncomplete',
                    'reviewResponse1star', 'months', 'allReviews', 'allZillowReviews', 'allGoogleReviews', 'allYelpReviews', 
                    'allFacebookReviews' 
                )
            );
        } else if ($this->request->query('days') == 30) {
            $breadcrumb = "Past 30 Days";
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -30 days"));
            
            $apiReviewsDetails = $this->ApiReviews->getOverAllApiReview($ids, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getOverAllApiRating($ids, date('Y-m-d'), $endDate);
            $overallFbRatings = $this->ApiReviews->getOverAllFbRatings($ids, date('Y-m-d'), $endDate);
            $overallZillowRatings = $this->ApiReviews->getOverAllZillowRatings($ids, date('Y-m-d'), $endDate);
            $overallGoogleRatings = $this->ApiReviews->getOverAllGoogleRatings($ids, date('Y-m-d'), $endDate);
            $overallYelpRatings = $this->ApiReviews->getOverAllYelpRatings($ids, date('Y-m-d'), $endDate);
            
            $past30DaysReviews = $this->CommonFunction->past30DaysReviews(implode(',', $ids));
            $past30DaysZillowReviews = $this->CommonFunction->past30DaysZillowReviews(implode(',', $ids));
            $past30DaysYelpReviews = $this->CommonFunction->past30DaysYelpReviews(implode(',', $ids));
            $past30DaysGoogleReviews = $this->CommonFunction->past30DaysGoogleReviews(implode(',', $ids));
            $past30DaysFacebookReviews = $this->CommonFunction->past30DaysFacebookReviews(implode(',', $ids));
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past30DaysSurveyReview = $this->CommonFunction->past30DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_all'));
            $past30DaysSurveyReviewComplete = $this->CommonFunction->past30DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_completed'));
            $past30DaysSurveyReviewIncomplete = $this->CommonFunction->past30DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past30DaysSurveyReview', 'past30DaysSurveyReviewComplete', 'past30DaysSurveyReviewIncomplete', 'past30DaysReviews', 
                    'past30DaysZillowReviews', 'past30DaysYelpReviews', 'past30DaysGoogleReviews', 'past30DaysFacebookReviews'
                )
            );
        } else if ($this->request->query('days') == 7) {
            $breadcrumb = "Past 7 Days";
            $daysName = $this->CommonFunction->allDays();
            $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -7 days"));

            $apiReviewsDetails = $this->ApiReviews->getOverAllApiReview($ids, date('Y-m-d'), $endDate);
            $overallRatings = $this->ApiReviews->getOverAllApiRating($ids, date('Y-m-d'), $endDate);
            $overallFbRatings = $this->ApiReviews->getOverAllFbRatings($ids, date('Y-m-d'), $endDate);
            $overallZillowRatings = $this->ApiReviews->getOverAllZillowRatings($ids, date('Y-m-d'), $endDate);
            $overallGoogleRatings = $this->ApiReviews->getOverAllGoogleRatings($ids, date('Y-m-d'), $endDate);
            $overallYelpRatings = $this->ApiReviews->getOverAllYelpRatings($ids, date('Y-m-d'), $endDate);
            
            $past7DaysReviews = $this->CommonFunction->past7DaysReviews(implode(',', $ids));
            $past7DaysZillowReviews = $this->CommonFunction->past7DaysZillowReviews(implode(',', $ids));
            $past7DaysYelpReviews = $this->CommonFunction->past7DaysYelpReviews(implode(',', $ids));
            $past7DaysGoogleReviews = $this->CommonFunction->past7DaysGoogleReviews(implode(',', $ids));
            $past7DaysFacebookReviews = $this->CommonFunction->past7DaysFacebookReviews(implode(',', $ids));
            
            $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
            $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('fourRatings'), date('Y-m-d'), $endDate);
            $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('threeRatings'), date('Y-m-d'), $endDate);
            $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('twoRatings'), date('Y-m-d'), $endDate);
            $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse(implode(',', $ids), Configure::read('oneRatings'), date('Y-m-d'), $endDate);
            $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
            $avgRatingAllStar = ($reviewResponse5star*5) + ($reviewResponse4star*4) + ($reviewResponse3star*3) + ($reviewResponse2star*2) + ($reviewResponse1star*1);
            
            $onlineReviews5star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('fiveRatings'));
            $onlineReviews4star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('fourRatings'));
            $onlineReviews3star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('threeRatings'));
            $onlineReviews2star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('twoRatings'));
            $onlineReviews1star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('oneRatings'));
            $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;

            $past7DaysSurveyReview = $this->CommonFunction->past7DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_all'));
            $past7DaysSurveyReviewComplete = $this->CommonFunction->past7DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_completed'));
            $past7DaysSurveyReviewIncomplete = $this->CommonFunction->past7DaysSurveyReview(implode(',', $ids), Configure::read('survey_review_pending'));

            $this->set(compact(
                    'past7DaysSurveyReview', 'past7DaysSurveyReviewComplete', 'past7DaysSurveyReviewIncomplete', 'past7DaysReviews', 
                    'past7DaysZillowReviews', 'past7DaysYelpReviews', 'past7DaysGoogleReviews', 'past7DaysFacebookReviews', 'daysName'
                )
            );
        }
        
        $overallRating = [];
        foreach ($overallRatings as $allRating) {
            $overallRating[] = $allRating->rating;
        }
        
        $fbAvgRating = [];
        foreach ($overallFbRatings as $fbRatings) {
            $fbAvgRating[] = $fbRatings->rating;
        }
        
        $zillowAvgRating = [];
        foreach ($overallZillowRatings as $zillowRating) {
            $zillowAvgRating[] = $zillowRating->rating;
        }
        
        $googleAvgRating = [];
        foreach ($overallGoogleRatings as $googleRating) {
            $googleAvgRating[] = $googleRating->rating;
        }
        
        $yelpAvgRating = [];
        foreach ($overallYelpRatings as $yelpRating) {
            $yelpAvgRating[] = $yelpRating->rating;
        }
        
        $this->set(compact(
                'breadcrumb', 'title', 'userImg', 'allAssociates', 'apiReviewsDetails', 'overallRating', 'fbAvgRating', 'zillowAvgRating', 
                'googleAvgRating', 'yelpAvgRating', 'baseUrl', 'userId', 'analyticsPlanFeature', 'ids', 'avgRatingAllStar','allOnlineStar', 
                'onlineReviews5star', 'onlineReviews4star', 'onlineReviews3star', 'onlineReviews2star', 'onlineReviews1star', 'reviewResponse1star', 
                'reviewResponse2star', 'reviewResponse3star', 'reviewResponse4star', 'reviewResponse5star', 'allStar'
            )
        );
    }
    
    /**
     * register method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function register($plan_id = null) 
    {
        if (!empty($plan_id)) {
            $planId = base64_decode($plan_id);
            $title = __('{0} power_testimonial', ['User Registration']);
            $this->viewBuilder()->layout(false);
            
            $groups = $this->Groups->getGroupList()->toArray();
            $country = $this->Country->getAllCountryList()->toArray();
            $plan = $this->Plans->findById($planId)->first();
            $planFeaturesXref = $this->PlanFeaturesXref->getAllPlanFeatures($planId)->toArray();
            $date = date('Y-m-d', strtotime(date('Y-m-d') . " +1 Month"));
            $recurDate = date("m~d~Y", strtotime($date));

            $user = $this->Users->newEntity();
            
            if ($this->request->is('post')) {
                $data = $this->request->getData();
                $data['access_token'] = base64_encode($this->request->data['password']);

                if ($this->Users->addUser($data)) {
                    $users = $this->Auth->identify();
                    
                    if (!empty($users)) {
                        $this->loadModel('OrderTransactions');
                        $orderId = time().''.$user['id'];
                        $reqData = ["ePNAccount" => Configure::read('ePNAccount'), "Inv" => "report", "RestrictKey" => Configure::read('RestrictKey'), "TranType" => "Sale", "Total" => $data['amt'], "CardNo" => $data['card_number'], "CVV2Type" => "1", "CVV2" => $data['cvv'], "ExpMonth" => $data['exp_month'], "ExpYear" => $data['exp_year'], "FirstName" => $users['first_name'], "LastName" => $users['last_name'], "Email" => $users['email'], "Company" => $users['business_name'], "Address" => $users['address_line1'], "City" => $users['city'], "State" => $users['state'], "RecurMethodID" => "0", "Identifier" => $orderId, "Zip" => $users['zip_code'], "RCRRecurAmount" => $data['recur_amt'], "RCRRecurs" => "0", "RCRPeriod" => "Monthly", "RCRChargeWhen" => "OnDayOfCycle", "RCRStartOnDay" => $recurDate];
                        $tempData = ["ePNAccount" => Configure::read('ePNAccount'), "Inv" => "report", "RestrictKey" => Configure::read('RestrictKey'), "TranType" => "Sale", "Total" => $data['amt'], "CardNo" => "xxxxxxxxxxxxxxxx", "CVV2Type" => "1", "CVV2" => "xxx", "ExpMonth" => "xx", "ExpYear" => "xx", "FirstName" => $users['first_name'], "LastName" => $users['last_name'], "Email" => $users['email'], "Company" => $users['business_name'], "Address" => $users['address_line1'], "City" => $users['city'], "State" => $users['state'], "RecurMethodID" => "0", "Identifier" => $orderId, "Zip" => $users['zip_code'], "RCRRecurAmount" => $data['recur_amt'], "RCRRecurs" => "0", "RCRPeriod" => "Monthly", "RCRChargeWhen" => "OnDayOfCycle", "RCRStartOnDay" => $recurDate];

                        $transactions = $this->OrderTransactions->newEntity();
                        $transactions->order_ref = $orderId; 
                        $transactions->user_id = $users['id'];
                        $transactions->amount = $data['amt'];
                        $transactions->first_name = $users['first_name'];
                        $transactions->last_name = $users['last_name'];
                        $transactions->plan_id = $users['plan_id'];
                        $transactions->transaction_status = "Pending";
                        $transactions->payment_type = "Credit Card";
                        $transactions->auth_request = json_encode($tempData);
                        $this->OrderTransactions->save($transactions);
                        
                        $makePayment = $this->makePayment($reqData);
                        $paymentResponse = explode(",", $makePayment);
                        $status = explode(" ", str_replace('"', '', $paymentResponse[0]));
                        $statusGet  = (string) trim($status[0]); 

                        if (strpos($statusGet, 'Y')) { 
                            
                            $transactionsData = $this->OrderTransactions->getTransactionDataByUserId($users['id'], "Pending");
                            $transactionsData->transaction_status = "Complete";
                            $transactionsData->approval_code = str_replace('"', '', $paymentResponse[0]);
                            $transactionsData->invoice_id = str_replace('"', '', $paymentResponse[3]);
                            $transactionsData->transaction_id = str_replace('"', '', $paymentResponse[4]);
                            $transactionsData->recur_id = preg_replace("/[^0-9]/", '', str_replace('"', '', $paymentResponse[5]));
                            $transactionsData->auth_response = $makePayment;
                            $transactionsData->recur_amt = $data['recur_amt'];
                            $transactionsData->expiry_date = date('Y-m-d', strtotime(date('Y-m-d') . " +1 Month"));
                            $this->OrderTransactions->save($transactionsData);
                            
                            $this->UserPlans->addUserPlan(['user_id' => $users['id']], $data);
                        
                            $user = $this->Users->get($users['id']);
                            $user->company_id = $user['id'];
                            $this->Users->save($user);

                            $this->CustomEmailTemplates->addDefaultEmailTemplate(['user_id' => $users['id']]);
                            //Category will change when super admin create
                            $surveyCategory = $this->SurveyCategory->addSurveyCategory(['user_id' => $users['id']]);
                            //Insert Default Custom data for Question Data
                            $surveyQuestion = $this->SurveyQuestion->addSurveyQuestion(['user_id' => $users['id']], $surveyCategory->id);
                            //Insert Default Custom data for Question Data
                            $surveyTemplate = $this->SurveyTemplates->addSurveyTemplate(['user_id' => $users['id']]);
                            $surveyReviewTemplate = $this->SurveyTemplates->addReviewDefaultTemplate(['user_id' => $users['id']]);

                            $this->SurveyTemplatesQuestion->addSurveyTemplateQuestion(['template_id'=>$surveyTemplate->id],$surveyQuestion->id);
                            $this->SurveyTemplatesQuestion->addReviewDefaultTemplateQuestion(['template_id'=>$surveyReviewTemplate->id],$surveyQuestion->id);

                            $this->SurveyMgmt->addSurveyDafault(['user_id' => $users['id']],$surveyTemplate->id);
                            $this->SurveyMgmt->addReviewSurveyDafault(['user_id' => $users['id']],$surveyReviewTemplate->id);
                            //Insert Default Custom data for Zillow Data
                            $this->Zillow->addZillow(['user_id' => $users['id']]);
                            //Insert Default Custom data for Google Data
                            $this->Google->addGoogle(['user_id' => $users['id']]);
                            //Insert Default Custom data for Yelp
                            $this->Yelp->addYelp(['user_id' => $users['id']]);
                            //Insert Default Custom data for Facebook
                            $this->Facebook->addFacebook(['user_id' => $users['id']]);
                            //Insert Default Custom Api Configuration Data
                            $this->ApiConfigurations->addApiConfigurations(['user_id' => $users['id']]);
                            
                            $this->CommonFunction->sendEmail($data, $emailCondition = 'registered');
                            return $this->redirect(['controller' => 'Indexes', 'action' => 'confirmSignup', base64_encode($users['id'])]);
                        } else {
                            $transactionsData = $this->OrderTransactions->getTransactionDataByUserId($users['id'], "Pending");
                            $transactionsData->auth_response = $makePayment;
                            $this->OrderTransactions->save($transactionsData);
                            
                            $user = $this->Users->get($users['id']);
                            $this->Users->delete($user);
                            $this->Flash->alert(__(str_replace('"', '', $paymentResponse[0])));
                        }
                    } else {
                        $this->Flash->alert(__('signup_error'));
                    }
                }
            }

            $this->set(compact('user', 'groups', 'title', 'planFeaturesXref', 'country', 'planId'));
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * Function to makePayment using curl
     *
     * @param array $reqData array of post data
     *
     * @return json
     */
    public function makePayment($reqData)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://www.eprocessingnetwork.com/cgi-bin/tdbe/transact.pl",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $reqData,
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: multipart/form-data"
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);

        if ($err) {
          return "cURL Error #:" . $err;
        } else {
          return $response;
        }
    }

    /**
     * Login method
     *
     * @return void Redirects on successful login, renders view otherwise.
     */
    public function login() 
    {
        $title = __('{0} power_testimonial', ['User Login']);
        $user = "";
        $this->viewBuilder()->layout(false);
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if (empty($user) && isset($this->request->data['login_as_user']) && $this->request->data['login_as_user'] == 1) {
                if (empty($this->request->data['password'])) {
                    $user = $this->Users->get($this->request->data['id']);
                }
            }
            
            if ($user && $user['is_active'] == 1) {
                $this->Auth->setUser($user);

                $this->Auth->user();
                if ($this->request->data['remember_me'] == 1) {
                    $cookie = array();
                    $cookie['email'] = $this->request->data['email'];
                    $cookie['password'] = $this->request->data['password'];
                    $this->Cookie->write('remember_me', $cookie, true, "+1 week");
                    unset($this->request->data['remember_me']);
                }
                if (empty($this->request->data)) {
                    $cookie = $this->Cookie->read('remember_me');
                    if (!is_null($cookie)) {
                        if ($user) {
                            $this->redirect($this->Auth->redirectUrl());
                        } else {
                            // delete invalid cookie
                            $this->Cookie->destroy('remember_me');
                            $this->Flash->error(__('invalid_cookie'));
                            $this->redirect('User/login');
                        }
                    }
                }
                return $this->redirect($this->Auth->redirectUrl());
            } else if (isset($user['is_active']) && $user['is_active'] == 0) {
                return $this->redirect(['controller' => 'Indexes', 'action' => 'accountSuspended']);
            } else {
                $this->Flash->alert(__('login_error'));
            }
        }
        $this->set(compact('user', 'title'));
    }

    /**
     * Logout method
     *
     * @return void Redirects to the logout redirect location defined in the AuthComponent
     */
    public function logout() 
    {
        // clear the cookie (if it exists) when logging out
        $this->Cookie->delete('remember_me');
        $this->Cookie->delete('Facebook');
        $this->redirect($this->Auth->logout());
    }

    /**
     * Associate Dashboard method
     *
     * @return \Cake\Http\Response|void
     */
    public function associateDashboard() 
    {
        $title = __('{0} power_testimonial', ['Company Associates']);
        $user = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($user['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $allUsersData = $this->CommonFunction->getChildUers($userImg);
                
        if (!empty($allUsersData)) {
            $conditions = [
                'Users.group_id IN' => Configure::read('CompanyAdminGroupIds'),
                'Users.id IN' => $allUsersData,
                'Users.is_deleted' => Configure::read('zero'),
            ];
        } else {
            $conditions = [
                'Users.group_id IN' => Configure::read('CompanyAdminGroupIds'),
                'Users.parent_id' => $userImg->id,
                'Users.is_deleted' => Configure::read('zero'),
            ];
        }

        $this->paginate = [
            'limit' => Configure::read('RowLimit'),
            'order' => ['Users.created' => 'desc'],
            'contain' => ['Groups', 'ProfileImages'],
        ];
        
        $users = $this->paginate($this->Users->find('all', ['conditions' => $conditions]));

        $this->set(compact('users', 'title', 'userImg'));
        $this->set('_serialize', ['users']);
    }

    /**
     * Add Associate method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function addAssociate() 
    {
        $title = __('{0} power_testimonial', ['Add Associate']);
        $loginUserDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($loginUserDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $allAssociates = $this->Users->getParentUserForAssociate($userImg->company_id);
        
        if (($companyUser->plan_id == Configure::read('PLAN_POWER')) && (count($allAssociates) >= Configure::read('MAX_USER_POWER'))) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else {
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
        } else if (($companyUser->plan_id == Configure::read('PLAN_POWER_PLUS')) && (count($allAssociates) >= Configure::read('MAX_USER_POWER_PLUS'))) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else {
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
        } else if (($companyUser->plan_id == Configure::read('PLAN_ULTIMATE_POWER')) && (count($allAssociates) >= Configure::read('MAX_USER_ULTIMATE_POWER'))) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else {
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
        }
        
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $postData = $this->request->getData();
            $postData['access_token'] = base64_encode($this->request->data['password']);
            if ($result = $this->Users->addAssociateUser($postData, $loginUserDetail)) {
                $email = $this->CommonFunction->sendEmail($postData, $emailCondition = 'associate', $userImg);
                if (!empty($result) && $email) {
                    
                    $userData = $this->Users->get($result->id);
                    $userData->company_id = $userImg->company_id;
                    $this->Users->save($userData);
                    
                    //Insert Default Custom data for Zillow Data
                    $this->Zillow->addZillow(['user_id' => $result->id]);
                    //Insert Default Custom data for Google Data
                    $this->Google->addGoogle(['user_id' => $result->id]);
                    //Insert Default Custom data for Yelp
                    $this->Yelp->addYelp(['user_id' => $result->id]);
                    //Insert Default Custom data for Facebook
                    $this->Facebook->addFacebook(['user_id' => $result->id]);
                    //Insert Default Custom Api Configuration Data
                    $this->ApiConfigurations->addApiConfigurations(['user_id' => $result->id]);
                    
                    $this->Flash->success(__('add_user_success'));
                    return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
                } else if (!empty($result)) {
                    $userData = $this->Users->get($result->id);
                    $this->Users->delete($userData);
                }
            }
            $this->Flash->error(__('add_user_error'));
        }
        
        if ($userImg->group_id == 2) {
            $ids = [1, $userImg->group_id];
        } else if ($userImg->group_id == 3) {
            $ids = [1, 2, $userImg->group_id];
        } else if ($userImg->group_id == 7) {
            $ids = [1, 2, 3, $userImg->group_id];
        }
        
        $this->loadModel('Groups');
        $groups = $this->Groups->getGroupFields($ids);
        
        $this->set(compact('user', 'groups', 'title', 'userImg'));
    }
    
    /**
     * getAllParentUsers Method to get all list of LoactionAdmin/TeamLead
     *
     * @return json
     */
    public function getAllParentUsers() 
    {
//        $result = $this->Users->getParentUserList($this->request->data);
        $result = $this->Users->getParentUserForAssociate($this->request->data['companyId']);
        echo json_encode($result);
        die;
    }

    /**
     * Edit Associate method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function editAssociate($uId = null) 
    {
        $id = base64_decode($uId);
        $title = __('{0} power_testimonial', ['Edit Associate']);
        $loginUserDetail = $this->Auth->user();
        $userImg = $this->Users->getUserDetails($loginUserDetail['id']);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $user = $this->Users->get($id, [
            'contain' => []
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['id'] = $id;
            if ($this->Users->addAssociateUser($this->request->data(), $this->Auth->user())) {
                $this->Flash->success(__('edit_user_success'));
                return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
            }
            $this->Flash->error(__('edit_user_error'));
        }
        if ($userImg->group_id == 2) {
            $ids = [1, $userImg->group_id];
        } else if ($userImg->group_id == 3) {
            $ids = [1, 2, $userImg->group_id];
        } else if ($userImg->group_id == 7) {
            $ids = [1, 2, 3, $userImg->group_id];
        }
        
        $this->loadModel('Groups');
        $groups = $this->Groups->getGroupFields($ids);
        
        $parentUser = $this->Users->getParentUserForAssociate($user->company_id);
//        pr($parentUser->toArray());die;
        $this->set(compact('user', 'groups', 'title', 'userImg', 'parentUser'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($uId = null) 
    {
        $id = base64_decode($uId);
        $this->request->allowMethod(['put', 'delete', 'get']);
        $user = $this->Users->get($id);
        
        $user->is_active = Configure::read('zero');
        $user->is_deleted = Configure::read('one');
        
        if ($this->Users->save($user)) {
            $this->Flash->success(__('delete_user_success'));
        } else {
            $this->Flash->error(__('delete_user_error'));
        }
        return $this->redirect(['controller' => 'Users', 'action' => 'associateDashboard']);
    }

    /**
     * updateStatus method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus() 
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('Users');
                try {
                    $user = $this->Users->get($this->request->data['uid'], ['contain' => []]);

                    if (!empty($user) && $user->is_active == Configure::read('zero')) {
                        $user->is_active = Configure::read('one');
                    } else {
                        $user->is_active = Configure::read('zero');
                    }
                    $data = array('is_active' => $user->is_active);
                    if ($data) {
                        $user = $this->Users->patchEntity($user, $data);
                        $result = $this->Users->save($user);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        }
    }
    
    /**
     * apiConfigForAssociate method, setting for the business or main account holder to have a setting in 
     * their account to either ALLOW agents to put in their own API credentials or NOT ALLOW 
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function apiConfigForAssociate() 
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('Users');
                try {
                    $user = $this->Users->get($this->request->data['uid'], ['contain' => []]);
                    if (!empty($user) && $user->api_config == Configure::read('zero')) {
                        $user->api_config = Configure::read('one');
                    } else {
                        $user->api_config = Configure::read('zero');
                    }
                    $data = array('api_config' => $user->api_config);
                    if ($data) {
                        $user = $this->Users->patchEntity($user, $data);
                        $result = $this->Users->save($user);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * checkEmailIsUnique Method to check input code is unique
     *
     * @return json
     */
    public function checkEmailIsUnique() 
    {
        if ($this->request->is('ajax')) {
            $result['count'] = $this->Users->checkUniqueEmailId($this->request->data, 1);
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }
    
     /**
     * checkAddionalEmailIsUnique Method to check input code is unique
     *
     * @return json
     */
    public function checkAddionalEmailIsUnique() 
    {
        if ($this->request->is('ajax')) {
            if(!empty($this->request->data('email'))) {
                $user = $this->CommonFunction->getUser();
                $this->request->data['userId'] = $user['id'];
                $result['count'] = $this->Users->checkUniqueEmailId($this->request->data, 2);
            } else {
                $result['count'] = 0;
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * Profile Method
     *
     * @param string $userID id of current login user
     *
     * @return void
     * 
     */
    public function profile($userID = null)
    {
        $title = __('{0} power_testimonial', ['User Profile']);
        $user_id = base64_decode($userID);
        
        $country = $this->Country->getAllCountryList()->toArray();
        $userImg = $this->Users->getUserDetails($user_id);
        $baseUrl = Configure::read('baseUrl');
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        if ($userImg->group_id == 2) {
            $upgradePlan = $this->UserPlans->getUserPlans($userImg->id, $userImg->plan_id);
            $currentPlan = $this->Plans->getPlanDetails($userImg->plan_id);
            $upgradePlanData = [];
            if ($upgradePlan) {
                $upgradePlanData = $this->Plans->getPlanDetails($upgradePlan->plan_upgrade_req);
            }
            
            $this->loadModel('OrderTransactions');
            $orderSub = $this->OrderTransactions->getTransactionDataByUserId($userImg->id, 'Complete');
        }
        
        $this->set(compact('profile', 'title', 'userImg', 'country', 'currentPlan', 'upgradePlanData', 'upgradePlan', 'orderSub', 'baseUrl'));
    }

    /**
     * forgotPassword Method
     *
     * @param null
     * @return void
     * 
     */
    public function forgotPassword()
    {
        $title = __('{0} power_testimonial', ['Forgot Password']);
        $this->viewBuilder()->layout(false);
        $user = "";
        $data = array();

        if ($this->request->is(['patch', 'post', 'put'])) {
            $userDatails = $this->Users->find('all', [
                        'conditions' => [
                            'email' => $this->request->data['email'],
                        ]
                    ])->first();

            $data['passkey'] = $userDatails->id . uniqid();
            $data['email'] = $this->request->data['email'];

            if ($result = $this->Users->updateUserToken($data)) {
                $email = $this->CommonFunction->sendEmail($data, $emailCondition = 'forgot', $userDatails);
                if ($email) {
                    $this->Flash->alert(__('reset_link_success'));
                    return $this->redirect(['controller' => 'Users', 'action' => 'forgotPassword']);
                }
                $this->Flash->alert(__('reset_link_error'));
            }
        }
        $this->set(compact('title', 'user'));
    }

    /**
     * resetPassword Method
     *
     * @param string $token user unique token
     *
     * @return void
     * 
     */
    public function resetPassword($token = null)
    {
        $title = __('{0} power_testimonial', ['Reset Password']);
        $user = "";
        $this->viewBuilder()->layout(false);
        $getToken = base64_decode($token);
        $userDatails = $this->Users->find('all', [
                        'conditions' => [
                            'token' => $getToken,
                        ]
                    ])->first();
        
        if (!empty($userDatails)) {
            if ($this->request->is(['patch', 'post', 'put'])) {
                if ($result = $this->Users->changeUserPassword($this->request->data(), $userDatails->id)) {
                    $this->Flash->alert(__('reset_password_success'));
                    return $this->redirect(['controller' => 'Users', 'action' => 'login']);
                }
                $this->Flash->alert(__('reset_password_success'));
            }
        } else {
            $this->Flash->alert(__('reset_password__token_error'));
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }

        $this->set(compact('title', 'user'));
    }

    /**
     * Edit Profile
     *
     * @param string $userID id current login user account
     *
     * @return void
     * 
     */
    public function editProfile($userID = null)
    {
        $title = __('{0} power_testimonial', ['Edit Profile']);
        $user_id = base64_decode($userID);
        $userImg = $this->Users->getUserDetails($user_id);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $country = $this->Country->getAllCountryList()->toArray();
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if (!empty($this->request->data['img_url']['name'])) {
                $img_url = $this->CommonFunction->getImageNameByProfile($this->request->data['img_url'], $user_id, $imageCondition = 'profile');
               
                if($img_url != null) {
                    $this->request->data['img_url'] = $img_url;
                } else {
                    $this->Flash->error(__('edit_profile_image_size_error'));
                    return $this->redirect(['controller' => 'Users', 'action' => 'profile', $userID]);
                }
            } else {
                $this->request->data['img_url'] = $this->request->data['profile_images_val'];
            }

            if ($result = $this->Users->editAssociate($this->request->data())) {
                if (!empty($result->profile_images)) {
                    $this->Users->updateUserImages($this->request->data['img_url'], 1, $user_id);
                } else {
                    $this->Users->insertUserImages($this->request->data['img_url'], 1, $user_id);
                }
                $this->Flash->success(__('edit_profile_success'));
                return $this->redirect(['controller' => 'Users', 'action' => 'profile', $userID]);
            }
            $this->Flash->error(__('edit_profile_error'));
        }

        $this->set(compact('userImg', 'editprofile', 'title', 'country'));
    }

    /**
     * editCompanyProfile Method
     *
     * @param string $userID id of current login user
     *
     * @return void
     * 
     */
    public function editCompanyProfile($userID = null) 
    {
        $title = __('{0} power_testimonial', ['Edit Profile']);
        $user_id = base64_decode($userID);
        $userImg = $this->Users->getUserDetails($user_id);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $country = $this->Country->getAllCountryList()->toArray();
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if (!empty($this->request->data['business_img_url']['name'])) {
                $business_img_url = $this->CommonFunction->getImageNameByProfile($this->request->data['business_img_url'], $user_id,$imageCondition = 'company');
                if($business_img_url != null) {
                    $this->request->data['business_img_url'] = $business_img_url;
                } else {
                    $this->Flash->error(__('edit_profile_image_size_error'));
                    return $this->redirect(['controller' => 'Users', 'action' => 'profile', $userID]);
                }
            } else {
                $this->request->data['business_img_url'] = $this->request->data['business_img_url_val'];
            }

            if ($result = $this->Users->editAssociate($this->request->data())) {
                
                if (!empty($result->profile_images)) {
                    $this->Users->updateUserImages($this->request->data['business_img_url'], 2, $user_id);
                } else {
                    $this->Users->insertUserImages($this->request->data['business_img_url'], 2, $user_id);
                }

                $this->Flash->success(__('edit_profile_success'));
                return $this->redirect(['controller' => 'Users', 'action' => 'profile', $userID]);
            }
            $this->Flash->error(__('edit_profile_error'));
        }

        $this->set(compact('title', 'userImg','country'));
    }

    /**
     * changePassword Method
     *
     * @param string $userID id of current login user
     *
     * @return void
     * 
     */
    public function changePassword($userID = null) 
    {
        $title = __('{0} power_testimonial', ['Change Password']);

        $user_id = base64_decode($userID);
        $userImg = $this->Users->getUserDetails($user_id);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        //Password change
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->Users->changeUserPassword($this->request->data(), $user_id)) {
                $this->Flash->success(__('change_password_success'));
                return $this->redirect(['controller' => 'Users', 'action' => 'changePassword', $userID]);
            }
            $this->Flash->error(__('change_password_error'));
        }

        $this->set(compact('changepassword', 'title', 'userImg'));
    }

    /**
     * checkPassword Method
     *
     * @param null
     *
     * @return json
     * 
     */
    public function checkPassword()
    {
        if ($this->request->is('ajax')) {
            $loginUserDetail = $this->Auth->user();
            $userId = $loginUserDetail['id'];
            $result['count'] = $this->Users->checkoldPassword($this->request->data, $userId);
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * plan planUpgrade Method is used for upgrade your plan for better service.
     *
     * @param NULL
     * @return void
     */
    public function planUpgrade() 
    {
        $title = __('{0} power_testimonial', ['Plan Upgradation']);
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $baseUrl = Configure::read('baseUrl');
        $planDetails = $this->UserPlans->getUserPlanDetails($userImg->id);
                
        $this->set(compact('title', 'userImg', 'planDetails', 'baseUrl'));
    }
    
    /**
     * plan Upgrade Req Method is used for upgrade your plan request.
     *
     * @param NULL
     *
     * @return json
     */
    public function planUpgradeReq() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $PlansTable = TableRegistry::get('Plans');

                    $UserPlansTable = TableRegistry::get('UserPlans');
                    $UserPlan = $UserPlansTable->getUserPlans($this->request->data('userId'), $this->request->data('currentPlanId'));

                    $UserPlan->plan_upgrade_req = $this->request->data('upgradePlanId');
                    $UserPlan->request_dt = date('Y-m-d');
                    $result = $UserPlansTable->save($UserPlan);

                    if ($result) {
                        $UsersTable = TableRegistry::get('Users');
                        $UserData = $UsersTable->getUserData($this->request->data('userId'));
                        $currentPlan = $PlansTable->getPlanDetails($this->request->data('currentPlanId'));
                        $upgradePlan = $PlansTable->getPlanDetails($this->request->data('upgradePlanId'));

                        $email = $this->CommonFunction->sendEmail($upgradePlan, $emailCondition = 'planUpgradeReq', $UserData, $currentPlan);
                    } else {
                        throw new CustomException('Record could not be updated.');
                    }
                } else {
                    throw new CustomException('Record could not be updated.');
                }
                if ($result && $email) {
                    $result['status'] = 'ok';
                } else {
                    $result['status'] = 'error';
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * onlineReviewBreakdown Method is used for get all online review channel rating breakdown.
     *
     * @param NULL
     * @return json
     */
    public function onlineReviewBreakdown() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    if ($this->request->data('overall') == 'overall') {
                        $ids = explode(",", $this->request->data('userId'));
                    } else {
                        $ids = [$this->request->data('userId')];
                    }
                    if ($this->request->data('breadcrumb') == 'Lifetime') {
                        $onlineReviews5star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('fiveRatings'));
                        $onlineReviews4star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('fourRatings'));
                        $onlineReviews3star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('threeRatings'));
                        $onlineReviews2star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('twoRatings'));
                        $onlineReviews1star = $this->ApiReviews->getOnlineReviews($ids, Configure::read('oneRatings'));
                        $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
                    
                    } else if ($this->request->data('breadcrumb') == 'Past 12 Months') {
                        $onlineReviews5star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('fiveRatings'));
                        $onlineReviews4star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('fourRatings'));
                        $onlineReviews3star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('threeRatings'));
                        $onlineReviews2star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('twoRatings'));
                        $onlineReviews1star = $this->ApiReviews->get12MonthsOnlineReviews($ids, Configure::read('oneRatings'));
                        $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
                        
                    } else if ($this->request->data('breadcrumb') == 'Past 30 Days') {
                        $onlineReviews5star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('fiveRatings'));
                        $onlineReviews4star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('fourRatings'));
                        $onlineReviews3star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('threeRatings'));
                        $onlineReviews2star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('twoRatings'));
                        $onlineReviews1star = $this->ApiReviews->get30DaysOnlineReviews($ids, Configure::read('oneRatings'));
                        $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
                        
                    } else if ($this->request->data('breadcrumb') == 'Past 7 Days') {
                        $onlineReviews5star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('fiveRatings'));
                        $onlineReviews4star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('fourRatings'));
                        $onlineReviews3star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('threeRatings'));
                        $onlineReviews2star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('twoRatings'));
                        $onlineReviews1star = $this->ApiReviews->get7DaysOnlineReviews($ids, Configure::read('oneRatings'));
                        $allOnlineStar = $onlineReviews5star + $onlineReviews4star + $onlineReviews3star + $onlineReviews2star + $onlineReviews1star;
                    }
                    if ($allOnlineStar) {
                        $result['online5Star'] = $allOnlineStar ? number_format(($onlineReviews5star / $allOnlineStar) * 100, 2) : 0;
                        $result['online4Star'] = $allOnlineStar ? number_format(($onlineReviews4star / $allOnlineStar) * 100, 2) : 0;
                        $result['online3Star'] = $allOnlineStar ? number_format(($onlineReviews3star / $allOnlineStar) * 100, 2) : 0;
                        $result['online2Star'] = $allOnlineStar ? number_format(($onlineReviews2star / $allOnlineStar) * 100, 2) : 0;
                        $result['online1Star'] = $allOnlineStar ? number_format(($onlineReviews1star / $allOnlineStar) * 100, 2) : 0;
                    }
                    
                } else {
                    throw new CustomException('Record could not be updated.');
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * internalReviewBreakdown Method is used for get all internal review rating breakdown.
     *
     * @param NULL
     * @return json
     */
    public function internalReviewBreakdown() 
    {
        if ($this->request->is('ajax')) {
            try {
                if ($this->request->is('post')) {
                    $result = [];
                    $ids = $this->request->data('userId');
                    if ($this->request->data('breadcrumb') == 'Lifetime') {
                        $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fiveRatings'), date('Y-m-d'));
                        $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fourRatings'), date('Y-m-d'));
                        $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('threeRatings'), date('Y-m-d'));
                        $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('twoRatings'), date('Y-m-d'));
                        $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('oneRatings'), date('Y-m-d'));
                        $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
                    
                    } else if ($this->request->data('breadcrumb') == 'Past 12 Months') {
                        $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -1 year"));
                        $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
                        $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
                        
                    } else if ($this->request->data('breadcrumb') == 'Past 30 Days') {
                        $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -30 days"));
                        $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
                        $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
                        
                    } else if ($this->request->data('breadcrumb') == 'Past 7 Days') {
                        $endDate = date('Y-m-d', strtotime(date('Y-m-d') . " -7 days"));
                        $reviewResponse5star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fiveRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse4star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('fourRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse3star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('threeRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse2star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('twoRatings'), date('Y-m-d'), $endDate);
                        $reviewResponse1star = $this->ReviewsMgmt->getCompletedReviewResponse($ids, Configure::read('oneRatings'), date('Y-m-d'), $endDate);
                        $allStar = $reviewResponse5star + $reviewResponse4star + $reviewResponse3star + $reviewResponse2star + $reviewResponse1star;
                    }
                    
                    if ($allStar) {
                        $result['internal5Star'] = $allStar ? number_format(($reviewResponse5star / $allStar) * 100, 2) : 0;
                        $result['internal4Star'] = $allStar ? number_format(($reviewResponse4star / $allStar) * 100, 2) : 0;
                        $result['internal3Star'] = $allStar ? number_format(($reviewResponse3star / $allStar) * 100, 2) : 0;
                        $result['internal2Star'] = $allStar ? number_format(($reviewResponse2star / $allStar) * 100, 2) : 0;
                        $result['internal1Star'] = $allStar ? number_format(($reviewResponse1star / $allStar) * 100, 2) : 0;
                    }
                    
                } else {
                    throw new CustomException('Record could not be updated.');
                }
            } catch (\Exception $e) {
                $this->throwException($e);
            }
            
            echo json_encode($result);
            die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    public function applyCoupon()
    {
        if ($this->request->is('ajax')) {
            $this->loadModel('Coupons');
            $couponData = $this->Coupons->find('all', [
                'conditions' => [
                    'code' => $this->request->data('couponCode')
                ]
            ])->first();
            $this->loadModel('Plans');
            $planData = $this->Plans->get($this->request->data('planId'));
            if (!empty($couponData)) {
                if ($couponData->discount_type == 'per') {
                    $per = strstr($couponData->discount, '%', true);
                    $discountAmt = ceil(($planData->amt / 100) * $per);
                } else {
                    $discountAmt = ceil(substr($couponData->discount, 1));
                }
                
                $result['totalAmount'] = ($planData->amt + $planData->setup_fee) - $discountAmt;
                $result['disAmount'] = $discountAmt;
                $result['response'] = 'OK';

            } else {
                $result['response'] = 'ERROR';
            }
            echo json_encode($result);
            die;
        } else {
            $this->Flash->alert(__('page_not_access'));
            return $this->redirect(['controller' => 'Users', 'action' => 'index']);
        }
    }
    
    public function updatePaymentInfo($userID)
    {
        $title = __('{0} power_testimonial', ['Update Payment Info']);
        $user_id = base64_decode($userID);
        
        $userImg = $this->Users->getUserDetails($user_id);
        $baseUrl = Configure::read('baseUrl');
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $this->loadModel('OrderTransactions');
        $orderSub = $this->OrderTransactions->getTransactionDataByUserId($user_id, 'Complete');
        
        $this->loadModel('UpdatePaymentLog');
        $paymentUpdateInfo = $this->UpdatePaymentLog->newEntity();
        
        if ($this->request->is('post')) {
            $data = $this->request->data();

            $reqData = ['ePNAccount' => Configure::read('ePNAccount'), "RestrictKey" => Configure::read('RestrictKey'), "RecurID" => $orderSub->recur_id, "TranType" => "ModifyCreditCard", "CardNo" => $data['card_number'], "ExpMonth" => $data['exp_month'], "ExpYear" => $data['exp_year']];
            $tempData = ['ePNAccount' => Configure::read('ePNAccount'), "RestrictKey" => Configure::read('RestrictKey'), "RecurID" => $orderSub->recur_id, "TranType" => "ModifyCreditCard", "CardNo" => "xxxxxxxxxxxxxxxx", "ExpMonth" => "xx", "ExpYear" => "xx"];

            $paymentUpdateInfo->user_id = $user_id;
            $paymentUpdateInfo->recur_id = $orderSub->recur_id;
            $paymentUpdateInfo->status = 'Error';
            $paymentUpdateInfo->update_request = json_encode($tempData);

            $res = $this->UpdatePaymentLog->save($paymentUpdateInfo);

            $paymentUpdate = $this->paymentUpdate($reqData);
            $paymentUpdateResponse = explode(",", $paymentUpdate);
            $status = str_replace('"', '', $paymentUpdateResponse[0]);
            $msg = str_replace('"', '', $paymentUpdateResponse[1]);

            if ($status == 'Y') {
                $paymentUpdateData = $this->UpdatePaymentLog->get($res->id);
                $paymentUpdateData->status = 'Success';
                $paymentUpdateData->update_response = $paymentUpdate;
                $this->UpdatePaymentLog->save($paymentUpdateData);
                
                $this->Flash->success(__('update_payment_success'));
                return $this->redirect(['controller' => 'Users', 'action' => 'profile', base64_encode($user_id)]);
            } else if ($status == 'N') {
                $paymentUpdateData = $this->UpdatePaymentLog->get($res->id);
                $paymentUpdateData->status = 'Error';
                $paymentUpdateData->update_response = $paymentUpdate;
                $this->UpdatePaymentLog->save($paymentUpdateData);
                
                $this->Flash->error(__($msg));
            }
        }
        
        $this->set(compact('title', 'userImg', 'orderSub', 'baseUrl', 'paymentUpdateInfo'));
    }
    
    /**
     * Function to makePayment using curl
     *
     * @param array $reqData array of post data
     * @return json
     */
    public function paymentUpdate($reqData) 
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://www.eprocessingnetwork.com/cgi-bin/tdbe/Recur.pl",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $reqData,
            CURLOPT_HTTPHEADER => array(
              "cache-control: no-cache",
              "content-type: multipart/form-data",
              "postman-token: e58a4939-1e8d-4aa9-700f-9261c2a499ab"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
          return "cURL Error #:" . $err;
        } else {
          return $response;
        }
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\Mailer\MailerAwareTrait;
use Cake\Mailer\Email;
use Cake\Core\Configure;

/**
 * Indexes Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class IndexesController extends AppController
{
    use MailerAwareTrait;
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Cookie');
    }
    
     /**
     * index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
       
        $title = __('{0} power_testimonial', ['Home']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * Price method
     *
     * @return \Cake\Http\Response|void
     */
    public function price() 
    {
        $title = __('{0} power_testimonial', ['Price']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * How It Work method
     *
     * @return \Cake\Http\Response|void
     */
    public function howItWork() 
    {
        $title = __('{0} power_testimonial', ['How It Work']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * How It Work method
     *
     * @return \Cake\Http\Response|void
     */
    public function privacyPolicy() 
    {
        $title = __('{0} power_testimonial', ['Privacy Policy']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * Contact method
     *
     * @return \Cake\Http\Response|void
     */
    public function contact() 
    {
        $title = __('{0} power_testimonial', ['Contact Us']);
        $this->viewBuilder()->layout(false);
        $this->loadModel('ContactUs');
        $contact = $this->ContactUs->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->getData();
            $contact = $this->ContactUs->patchEntity($contact, $data);
            if ($result = $this->ContactUs->save($contact)) {
                $email = $this->emailContact($data);
                if ($email && $result) {
                    return $this->redirect(['controller' => 'Indexes', 'action' => 'contactSuccess']);
                }
            }
            $this->Flash->alert(__('contact_error'));
        }     
        
        $this->set(compact('title', 'contact'));
    }
    
    /**
     * contact Success method
     *
     * @return \Cake\Http\Response|void
     */
    public function contactSuccess() 
    {
        $title = __('{0} power_testimonial', ['Contact Successful']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * Email Contact method
     *
     * @param Array|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful send email, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When email not send.
     * 
     */
    public function emailContact($user = null) 
    {
        $email = new Email('default');
        $email->from([$user['email'] => $user['name']]) // sender email
                ->to(Configure::read('siteEmail')) // receiver email
                ->subject(Configure::read('CONTACTSUB'))  	// message subjetc
                ->replyTo(Configure::read('fromEMail')) // emial to reply toll ll
                ->emailFormat('html')
                ->viewVars([
                    'name' => $user['name'],
                    'phone' => $user['phone'],
                    'email' => $user['email'],
                    'content' => $user['content'],
                    'baseUrl' => Configure::read('baseUrl'),
                ])
                ->template('contact') //Sending Templated Emails
                ->send(); // send function take the message content parameter
        return $email;
    }
    
    /**
     * Confirm Signup method
     *
     * @return \Cake\Http\Response|void
     */
    public function confirmSignup($id = null) 
    {
        $uId = base64_decode($id);
        $this->loadModel('Users');
        $user = $this->Users->get($uId, [
            'contain' => ['UserPlans']
        ]);
        
        $this->loadModel('OrderTransactions');
        $transaction = $this->OrderTransactions->getTransactionDataByUserId($uId, 'Complete');
        
        $title = __('{0} power_testimonial', ['Confirm Signup']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title', 'user', 'transaction'));
    }
    
    /**
     * Confirm Signup method
     *
     * @return \Cake\Http\Response|void
     */
    public function accountSuspended() 
    {
        $title = __('{0} power_testimonial', ['Account Suspended']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title'));
    }
    
    /**
     * Invoice method
     *
     * @return \Cake\Http\Response|void
     */
    public function invoice($id = null) 
    {
        $this->loadModel('Users');
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        $title = __('{0} power_testimonial', ['Invoice']);
        $this->viewBuilder()->layout(false);
        $this->set(compact('title', 'user'));
    }
}


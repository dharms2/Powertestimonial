<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\Core\App;
use Cake\Datasource\Exception\CustomException;

/**
 * CustomEmailTemplates Controller
 *
 * @property \App\Model\Table\CustomEmailTemplatesTable $CustomEmailTemplates
 *
 * @method \App\Model\Entity\CustomEmailTemplate[] paginate($object = null, array $settings = [])
 */
class CustomEmailTemplatesController extends AppController
{
    public $components = ['CommonFunction'];

    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $title = __('{0} power_testimonial', ['Create Review Request']);
        $this->loadModel('Users');
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        $defaultSmsVerbiage = Configure::read("SMS_VERBIAGE");
        $customEmailTemplate = $this->CustomEmailTemplates->getEmailTemplateByUserId($userImg->id);

        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->CustomEmailTemplates->addEmailTemplate($this->request->getData())) {
                $this->Flash->success(__('The custom email template has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The custom email template could not be saved. Please, try again.'));
        }

        $this->set(compact('customEmailTemplate', 'title', 'userImg', 'defaultSmsVerbiage'));
        $this->set('_serialize', ['customEmailTemplates']);
    }
}

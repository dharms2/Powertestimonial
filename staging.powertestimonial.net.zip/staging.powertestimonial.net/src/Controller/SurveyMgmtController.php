<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;

/**
 * SurveyMgmt Controller
 *
 * @property \App\Model\Table\SurveyMgmtTable $SurveyMgmt
 *
 * @method \App\Model\Entity\SurveyMgmt[] paginate($object = null, array $settings = [])
 */
class SurveyMgmtController extends AppController 
{
    public $components = ['CommonFunction'];
    
    public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Survey List']);
        $this->loadModel('Users');

        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $surveyMgmts = $this->SurveyMgmt->getAllSurveyReviewByUserIds($userIds);

        $this->loadModel('ReviewsMgmt');
        foreach ($surveyMgmts as $surveyMgmtdata) {
            $surveyResponseData = $this->ReviewsMgmt->getAllSurveyReviewResponse($surveyMgmtdata->id, $currentUserID);
            $surveyResponse[] = $surveyResponseData->count();
        }
        
        $this->set(compact('surveyMgmts', 'title', 'surveyResponse', 'userImg'));
        $this->set('_serialize', ['surveyMgmt']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() 
    {
        $title = __('{0} power_testimonial', ['Add New Survey']);
        $this->loadModel('Users');
        $this->loadModel('SurveyTemplates');
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);

        $getAllSurvey = $this->SurveyMgmt->getAllSurveyReviewByUserId($userIds);

        if (($companyUser->plan_id === Configure::read('PLAN_POWER')) && ($getAllSurvey >= Configure::read('MAX_CUSTOM_SURVEYS_POWER'))) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else { 
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
        } else if ($companyUser->plan_id === Configure::read('PLAN_POWER_PLUS') && $getAllSurvey >= Configure::read('MAX_CUSTOM_SURVEYS_POWER_PLUS')) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else { 
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
        } else if (($companyUser->plan_id === Configure::read('PLAN_ULTIMATE_POWER')) && ($getAllSurvey >= Configure::read('MAX_CUSTOM_SURVEYS_ULTIMATE_POWER'))) {
            if ($userImg->group_id == 2) {
                $this->Flash->alert(__(Configure::read('SUBSCRIPTION_MSG')));
            } else { 
                $this->Flash->alert(__(Configure::read('ASSOCIATE_SUBSCRIPTION_MSG')));
            }
            return $this->redirect(['controller' => 'SurveyMgmt', 'action' => 'index']);
        }
        
        $surveyMgmt = $this->SurveyMgmt->newEntity();
        
        if ($this->request->is('post')) {
            $this->request->data['user_id'] = $userImg->id;
            $surveyMgmt = $this->SurveyMgmt->patchEntity($surveyMgmt, $this->request->getData());
            if ($this->SurveyMgmt->save($surveyMgmt)) {
                $this->Flash->success(__('The survey management has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The survey management could not be saved. Please, try again.'));
        }
        
        $users = $this->SurveyMgmt->Users->find('list', ['limit' => 200]);
        
        $surveyTemplates = $this->SurveyTemplates->getTemplateList($userImg->id);

        $this->set(compact('surveyMgmt', 'users', 'surveyTemplates', 'title', 'userImg'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Survey Mgmt id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) 
    {
        $title = __('{0} power_testimonial', ['Edit New Survey']);
        $this->loadModel('Users');
        $this->loadModel('SurveyTemplates');
        
        $userImg = $this->Users->getUserDetails($this->CommonFunction->getCurrentUserId());
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $companyUser = $this->Users->getUserDetails($userImg->company_id);

        $surveyMgmt = $this->SurveyMgmt->get($id, ['contain' => []]);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            $surveyMgmt = $this->SurveyMgmt->patchEntity($surveyMgmt, $this->request->getData());
            if ($this->SurveyMgmt->save($surveyMgmt)) {
                $this->Flash->success(__('The survey management has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The survey management could not be saved. Please, try again.'));
        }
        
        $users = $this->SurveyMgmt->Users->find('list', ['limit' => 200]);
        $surveyTemplates = $this->SurveyTemplates->getTemplateList($userImg->company_id);
        
        $this->set(compact('surveyMgmt', 'users', 'surveyTemplates', 'title', 'userImg'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Survey Mgmt id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) 
    {
        $this->request->allowMethod(['post', 'delete', 'get']);

        //Load Model for check survey ids exist or not in review mgmt table
        $this->loadModel('ReviewsMgmt');
        $reviewSurvey = $this->ReviewsMgmt->find('all', [
                            'conditions' => [
                                'survey_id' => $id,
                            ]
                        ])->count();

        if ($reviewSurvey > 0) {
            $this->Flash->error(__('You do not have permission to delete this survey'));
        } else {
            $surveyMgmt = $this->SurveyMgmt->get($id);
            $surveyMgmt->is_deleted = 1;
            if ($this->SurveyMgmt->save($surveyMgmt)) {
                $this->Flash->success(__('The survey management has been deleted.'));
            } else {
                $this->Flash->error(__('The survey management could not be deleted. Please, try again.'));
            }
        }
        return $this->redirect(['action' => 'index']);
    }

    /**
     * getOwnerContractByCode method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus() 
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('SurveyMgmt');
                try {
                    $category = $this->SurveyMgmt->get($this->request->data['uid'], [
                        'contain' => []
                    ]);

                    if (!empty($category) && $category->status == 0) {
                        $category->status = 1;
                    } else {
                        $category->status = 0;
                    }
                    $data = array('status' => $category->status);

                    if ($data) {
                        $category = $this->SurveyMgmt->patchEntity($category, $data);

                        $result = $this->SurveyMgmt->save($category);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * getAnalyzeData method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function getAnalyzeData() 
    {
        $this->loadModel('Users');
        $currentUserId = $this->request->data['userId'];
        $user = $this->CommonFunction->getUser();

        if ($this->request->is('ajax')) {
            if ($this->request->data['surveyid']) {
                $this->loadModel('ReviewsMgmt');
                try {
                    //Load Model for get template id.
                    $this->loadModel('SurveyMgmt');
                    $survey = $this->SurveyMgmt->find('all', [
                                    'conditions' => [
                                        'id' => $this->request->data['surveyid'],
                                        'user_id' => $user['id']
                                    ]
                                ])->first();
                    $templateId = $survey->survey_template_id;

                    //Load Model for get type is survey or review
                    $this->loadModel('SurveyTemplatesQuestion');
                    $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->find('all', [
                                                    'conditions' => [
                                                        'survey_templates_id' => $templateId,
                                                    ]
                                                ])->first();

                    $result['type'] = $surveyTemplatesQuestions->type;

                    $result['data'] = $this->ReviewsMgmt->find('all', [
                                            'conditions' => [
                                                'survey_id' => $this->request->data['surveyid'],
                                                'user_id' => $currentUserId,
                                                'is_deleted' => 0,
                                            ], 
                                            'order' => [
                                                'created' => 'desc'
                                            ],
                                        ]);
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * getAnalyzeData method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function surveysUserAns() 
    {
        $this->loadModel('ReviewsMgmt');
        if ($this->request->is('ajax')) {
            if ($this->request->data['userid']) {
                try {
                    //Load Model for get template id.
                    $this->loadModel('SurveyMgmt');
                    $survey = $this->SurveyMgmt->find('all', [
                                'conditions' => [
                                    'id' => $this->request->data['surveyid'],
                                ]
                            ])->first();
                    $templateId = $survey->survey_template_id;

                    $this->loadModel('SurveyAns');
                    $surveyAns = $this->SurveyAns->find('all', [
                                    'conditions' => [
                                        'survey_mgmt_id' => $this->request->data['surveyid'],
                                        'user_id' => $this->request->data['userid'],
                                        'review_mgmt_id' => $this->request->data['reviewid']
                                    ]
                                ])->toArray();
                    $this->loadModel('SurveyTemplatesQuestion');
                    $this->loadModel('SurveyQuestion');
                    $result = array();
                    foreach ($surveyAns as $surveyAnsData) {
                        $surveyQuestion = $this->SurveyQuestion->find('all', [
                                            'conditions' => [
                                                'id' => $surveyAnsData->survey_qus_id,
                                            ]
                                        ])->first();

                        $surveyTemplatesQuestions = $this->SurveyTemplatesQuestion->find('all', [
                                                        'conditions' => [
                                                            'survey_templates_id' => $templateId,
                                                            'question' => $surveyAnsData->survey_qus_id
                                                        ]
                                                    ])->first();
                        $result[] = array(
                                    'question' => $surveyQuestion->questions, 
                                    'type' => $surveyQuestion->ans_types, 
                                    'ans_choices' => $surveyQuestion->ans_choices, 
                                    'correct_ans' => $surveyAnsData->answers
                                );
                        
                    }
                    
                } catch (RecordNotFoundException $ex) {
                    $result = 'Somthing went wrong.';
                }
                echo json_encode($result);die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * getTemplate exist or not
     *
     * @param string|null.
     * @return json
     */
    public function checkTemplateExist() 
    {
        if ($this->request->is('ajax')) {
            //Load Model for get template id.
            $this->loadModel('SurveyMgmt');
            $this->loadModel('SurveyTemplates');

            //Load Model for get template id.
            $survey = $this->SurveyMgmt->find('all', [
                        'conditions' => [
                            'id' => $this->request->data['survey_id'],
                        ]
                    ])->first();
            $template = $this->SurveyTemplates->find('all', [
                            'conditions' => [
                                'id' => $survey->survey_template_id,
                                'is_deleted' => 0,
                            ]
                        ])->count();
            $result['count'] = $template;
            echo json_encode($result);die;
        } else {
            die("You can not access this function directly from URL.");
        }
    }

}

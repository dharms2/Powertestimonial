<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\Network\Session\DatabaseSession;

/**
 * SurveyTemplates Controller
 *
 * @property \App\Model\Table\SurveyTemplatesTable $SurveyTemplates
 *
 * @method \App\Model\Entity\SurveyTemplate[] paginate($object = null, array $settings = [])
 */
class SurveyTemplatesController extends AppController 
{
    public $components = ['CommonFunction'];
    
     public function initialize() {
        parent::initialize();
        $this->loadComponent('Cookie');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Templates List']);
        $this->loadModel('Users');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
       
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);

        $this->paginate = [
            'limit' => 25,
            'order' => [
                'created' => 'desc'
            ],
            'conditions' => [
                'user_id IN' => $userIds,
                'is_deleted' => 0,
            ],
        ];

        $surveyTemplates = $this->paginate($this->SurveyTemplates);
        
        $this->set(compact('surveyTemplates', 'title', 'userImg'));
        $this->set('_serialize', ['surveyTemplates']);
    }


    /**
     * Add method
     *
     * @param null
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     * @return void.
     */
    public function add() 
    {
        $title = __('{0} power_testimonial', ['Add New Templates']);
        $uniqId = abs(crc32(uniqid()));
        $this->request->session()->write('Config.uniqid', $uniqId);
        $this->Cookie->write('uniqid', $uniqId, true, "+1 week");
        $this->loadModel('Users');
        $this->loadModel('SurveyMgmt');
        $this->loadModel('SurveyQuestion');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $starRatingPlanFeature = $this->CommonFunction->checkPlanFeature($companyUser->plan_id, Configure::read('FEATURE_5_STAR_RATING_SYSTEM'));
        
        $surveyTemplate = $this->SurveyTemplates->newEntity();
        
        $data = $this->SurveyQuestion->find('all', [
                    'contain' => [
                        'SurveyCategory' => [
                            'conditions' => [
                                'SurveyCategory.is_deleted' => 0,
                                'SurveyCategory.user_id IN' => $userIds
                            ],
                        ],
                    ],
                    'conditions' => [
                        'SurveyQuestion.user_id IN' => $userIds,
                        'SurveyQuestion.is_deleted' => 0
                    ],
                    'group' => [
                        'SurveyQuestion.category_id'
                    ]
                ]);
                
        if (!$data->isEmpty()) {
            foreach ($data as $dt) {
                $categoryNameByquestion[$dt->survey_category->name] = $this->SurveyQuestion->find('all', [
                    'conditions' => [
                        'category_id' => $dt->survey_category->id,
                        'is_deleted' => 0,
                        'status' => 1
                    ]
                ])->toArray();
            }
        } else {
            $categoryNameByquestion = 0;
        }

        if ($this->request->is('post')) {
            $data = array(
                    'name' => $this->request->data['name'],
                    'user_id' => $currentUserID,
                    'description' => $this->request->data['description'],
                    'greeting' => $this->request->data['greeting'],
                    'footer' => $this->request->data['footer']
                );

            $surveyTemplate = $this->SurveyTemplates->patchEntity($surveyTemplate, $data);
            if ($result = $this->SurveyTemplates->save($surveyTemplate)) {
                if ($this->request->data['qus_types'] == 1) {
                    if (!empty($this->request->data['select_qusetion_id'])) {
                        
                        $questionInert = $this->request->data['select_qusetion_id'];

                        foreach ($questionInert as $key => $questionInertFinal) {
                            if ($key != 5 && $key != 4) {
                                $this->recursiveDataInsert(0, $questionInertFinal, $this->request->data(), $key, $result->id, $name = "select_qusetion_id[".$key."]");
                            
                            } else if ($key == 4 && $this->request->data('fouroption') == 1) {
                                $this->recursiveDataInsert(0, $questionInertFinal, $this->request->data(), $key, $result->id, $name = "select_qusetion_id[".$key."]");
                            
                            } else {
                                foreach ($questionInertFinal as $questionInertFinalData) {
                                    $dataTemplateSave[] = [
                                        'type' => $this->request->data['qus_types'],
                                        'fouroption'=> $this->request->data['fouroption'],
                                        'star' => $key,
                                        'survey_templates_id' => $result->id,
                                        'question' => $questionInertFinalData,
                                    ];
                                }
                            }
                        }
                    } else {
                        $dataTemplateSave[] = [
                            'type' => $this->request->data['qus_types'],
                            'survey_templates_id' => $result->id
                        ];
                    }
                    $survbeyTemplateQuestionsave = TableRegistry::get('SurveyTemplatesQuestion');
                    $entities = $survbeyTemplateQuestionsave->newEntities($dataTemplateSave);

                    $results = $survbeyTemplateQuestionsave->saveMany($entities);

                } elseif ($this->request->data['qus_types'] == 2) {
                    if (!empty($this->request->data['select_qusetion_id'])) {
                        $questionInert = $this->request->data['select_qusetion_id'];
                        foreach ($questionInert as $key => $questionInertFinal) {
                            if ($key == 0) {
                                $this->recursiveDataInsert(0, $questionInertFinal, $this->request->data(), $key, $result->id, $name = "select_qusetion_id[".$key."]");

                            }
                        }
                    } else {
                        $dataTemplateSave[] = [
                            'type' => $this->request->data['qus_types'],
                            'survey_templates_id' => $result->id
                        ];
                        $survbeyTemplateQuestionsave = TableRegistry::get('SurveyTemplatesQuestion');
                        $entities = $survbeyTemplateQuestionsave->newEntities($dataTemplateSave);

                        $results = $survbeyTemplateQuestionsave->saveMany($entities);

                    }
                }
                
                $this->Flash->success(__('The survey template has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The survey template could not be saved. Please, try again.'));
        }
        
        //Fetch Survey Template list from SurveyTemplatesQuestion table.
        $getSurveyTemplateList = $this->SurveyTemplates->getSurveyTemplateList($userIds);

        $this->loadModel('ApiConfigurations');
        $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $currentUserID]);
      
        $this->set(compact(
            'surveyTemplate', 'title', 'categoryNameByquestion', 'userImg', 'getSurveyList', 
            'getSurveyTemplateList', 'apiConfigurations', 'starRatingPlanFeature', 'uniqId'
        ));
    }
    
    public function recursiveDataInsert($logicId, $questionInertFinalData, $insertData, $starVal, $surveyTempId, $name) 
    {   
        if (!empty($questionInertFinalData)) {
            $index = 1;
            foreach ($questionInertFinalData as $ques_key => $questionInertData) {
                
                $temp_name = $name.'['.$ques_key.']';
                if (array_key_exists('q', $questionInertData)) {
                    $q_name = $temp_name;
                }
                
                $surveyTemplatesQuestionTable = TableRegistry::get('SurveyTemplatesQuestion');
                $templateData = $surveyTemplatesQuestionTable->newEntity();
                $templateData->type = $insertData['qus_types'];
                $templateData->fouroption = $insertData['fouroption'];
                $templateData->star = $starVal;
                $templateData->survey_templates_id = $surveyTempId;
                $templateData->question = $ques_key;
                if (array_key_exists('ans', $questionInertData)) {
                    $templateData->has_question_logic = 1;
                }
                $templateData->q_level = $q_name;
                $templateData->question_ordering = $index;
                $templateData->question_logic_id = $logicId;
                
                $insertTemplateData = $surveyTemplatesQuestionTable->save($templateData);
                if (!empty($questionInertData['ans'])) {
                    $ans_name = $q_name.'[ans]';
                    
                    foreach ($questionInertData['ans'] as $logicKey => $logicData) {
                        $curr_ans_name = $ans_name.'['.$logicKey.']';
                        $surveyTemplatesQuestionLogicTable = TableRegistry::get('SurveyTemplatesQuestionLogic');
                        $questionLogicData = $surveyTemplatesQuestionLogicTable->newEntity();
                        $questionLogicData->survey_template_question_id = $insertTemplateData->id;
                        $questionLogicData->ans_option = $logicKey;
                        $questionLogicData->survey_template_id = $surveyTempId;
                        
                        $insertquestionLogicData = $surveyTemplatesQuestionLogicTable->save($questionLogicData);
                        
                        $this->recursiveDataInsert($insertquestionLogicData->id, $logicData, $insertData, $starVal, $surveyTempId, $curr_ans_name);
                    }
                }
                $index++;
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Edit method
     *
     * @param string $id Survey Template id.
     * 
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @return void.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $title = __('{0} power_testimonial', ['Edit New Templates']);
        $this->loadModel('Users');
        $this->loadModel('SurveyMgmt');
        $this->loadModel('SurveyQuestion');
        $this->loadModel('SurveyCategory');
        
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }

        $companyUser = $this->Users->getUserDetails($userImg->company_id);
        $userIds = $this->CommonFunction->getAllUserIds($userImg->company_id);
        
        $starRatingPlanFeature = $this->CommonFunction->checkPlanFeature($companyUser->plan_id, Configure::read('FEATURE_5_STAR_RATING_SYSTEM'));
        
        $surveyTemplate = $this->SurveyTemplates->find('all', [
            'conditions' => [
                'SurveyTemplates.id' => $id
            ],
            'contain' => [
                'SurveyTemplatesQuestion' => function($query){
                    return $query->order(['SurveyTemplatesQuestion.question_ordering' => 'asc']);
                }
            ]
        ])->first();
            
//        $this->loadModel('SurveyTemplatesQuestion');
//        $questionDetails = $this->SurveyTemplatesQuestion->findQuestionDetailsById($surveyTemplate->survey_templates_question, $surveyTemplate->id);
//        pr($questionDetails);die;

        //Fetch Question Details from question table by survey template question.
        $questionDetails = $this->SurveyQuestion->findQuestionDetailsById($surveyTemplate->survey_templates_question);
        
        $keyVal = [];
        foreach ($questionDetails as $key => $surveyQuestion) {
            if ($key == 5) {
                $keyVal = $surveyQuestion;
            }
        }

        //Four star :if 
        $keyFourVal = [];
        foreach ($questionDetails as $key => $surveyQuestion) {
            if ($key == 4) {
                $keyFourVal = $surveyQuestion;
            }
        }

        //Fetch Question Details from question table accroding to category.
        $categoryNameByquestion = $this->SurveyQuestion->findQuestionListByUserId($userIds);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
          
            //Pass Template Id for update template data.
            $this->request->data['template_id'] = $id;
            //Calling Edit Method for save template data into database.
            if ($this->SurveyTemplates->editTemplate($this->request->getData())) {
                $this->Flash->success(__('template_success'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('template_error'));  
        }
        
        //Fetch Survey Template list from SurveyTemplatesQuestion table.
        $getSurveyTemplateList = $this->SurveyTemplates->getSurveyTemplateList($userIds);
        
        $this->loadModel('ApiConfigurations');
        $apiConfigurations = $this->ApiConfigurations->getApiDetails(['user_id' => $currentUserID]);
        
        $this->set(compact(
            'surveyTemplate', 'userImg', 'title','questionDetails', 'categoryNameByquestion', 
            'getSurveyList', 'getSurveyTemplateList', 'apiConfigurations', 'starRatingPlanFeature',
            'keyVal', 'keyFourVal'
        ));
    }

    /**
     * Delete method
     *
     * @param string|null $id Survey Template id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete', 'get']);

        //Load Model for check category ids exist or not in template question table
        $this->loadModel('SurveyMgmt');
        $surveyTemplate = $this->SurveyMgmt->find('all', [
                            'conditions' => [
                                'survey_template_id' => $id,
                            ]
                        ])->count();

        if ($surveyTemplate > 0) {
            $this->Flash->error(__('You do not have permission to delete this template'));
        } else {
            $surveyTemplate = $this->SurveyTemplates->get($id);
            $surveyTemplate->is_deleted = 1;

            if ($this->SurveyTemplates->save($surveyTemplate)) {
                $this->Flash->success(__('The survey template has been deleted.'));
            } else {
                $this->Flash->error(__('The survey template could not be deleted. Please, try again.'));
            }
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * getOwnerContractByCode method
     *
     * @param string|null.
     * @return \Cake\Network\Response|null Redirects to add|edit.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function updateStatus() 
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['uid']) {
                $this->loadModel('SurveyTemplates');
                try {
                    $category = $this->SurveyTemplates->get($this->request->data['uid'], [
                        'contain' => []
                    ]);

                    if (!empty($category) && $category->status == 0) {
                        $category->status = 1;
                    } else {
                        $category->status = 0;
                    }
                    $data = array('status' => $category->status);

                    if ($data) {
                        $category = $this->SurveyTemplates->patchEntity($category, $data);

                        $result = $this->SurveyTemplates->save($category);
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * chooseQuestion method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function chooseQuestion()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['qid']) {
                $this->loadModel('SurveyQuestion');
                try {
                    $questionIds = $this->request->data['qid'];
//                    pr($questionIds);
//                    pr($this->request->data);
//                    die;
                    $this->loadModel('SurveyTemplatesQuestion');
//                    foreach ($questionIds as $questionId) {
                        //pr($questionIds);die;
                        $surveyTemplates = $this->SurveyTemplatesQuestion->find('all', [
                            'conditions' => [
                                'question IN' => $questionIds,
                                'star' => $this->request->data('star'),
                                'survey_templates_id' => $this->request->data('tempId'),
//                                'q_level' => $this->request->data('q_level')."[".$questionId."]"
                            ]
                        ])->toArray();
//                    }
//                    pr($surveyTemplates);die;
                    $qusIds = [];
                    $qusOrdering = [];
                    foreach ($surveyTemplates as $surveyTemplate) {
                        array_push($qusIds, $surveyTemplate->question);
                    }
                    foreach ($surveyTemplates as $surveyTemplate) {
                        array_push($qusOrdering, $surveyTemplate->question_ordering);
                    }
                    $diffQues = array_diff($questionIds, $qusIds);
//                    pr($diffQues);die;
                    if (!empty($diffQues) && !empty($surveyTemplates)) {
//                        die('if');
                        $index = 1;
                        foreach ($diffQues as $diffQue) {
                            $templateSaveQuestion = $this->SurveyTemplatesQuestion->newEntity();
                            $templateSaveQuestion->star = $this->request->data('star');
                            if ($this->request->data('fourOption') == '') {
                                $templateSaveQuestion->fouroption = 3;
                            } else {
                                $templateSaveQuestion->fouroption = $this->request->data('fourOption');
                            }
                            $templateSaveQuestion->type = $this->request->data('type');
                            $templateSaveQuestion->survey_templates_id = $this->request->data('tempId');
                            $templateSaveQuestion->question = $diffQue;
                            $templateSaveQuestion->question_ordering = (max($qusOrdering) + $index);
                            $templateSaveQuestion->q_level = $this->request->data('q_level')."[".$diffQue."]";
//                            pr($templateSaveQuestion);die('if');
                            $this->SurveyTemplatesQuestion->save($templateSaveQuestion);
                            $index++;
                        }
                    } else {
//                        die('else');
                        $index = 1;
                        foreach ($questionIds as $questionId) {
                            $defaultTemplates = $this->SurveyTemplatesQuestion->find('all', [
                                'conditions' => [
                                    'question' => $questionId,
                                    'star' => $this->request->data('star'),
                                    'survey_templates_id' => $this->request->data('tempId'),
                                    'q_level' => $this->request->data('q_level')."[".$questionId."]"
                                ]
                            ])->first();
//                    pr($defaultTemplates);die;
                            if (empty($defaultTemplates)) {
                                $templateSaveQuestion = $this->SurveyTemplatesQuestion->newEntity();
                                $templateSaveQuestion->star = $this->request->data('star');
                                if ($this->request->data('fourOption') == '') {
                                    $templateSaveQuestion->fouroption = 3;
                                } else {
                                    $templateSaveQuestion->fouroption = $this->request->data('fourOption');
                                }
                                $templateSaveQuestion->type = $this->request->data('type');
                                $templateSaveQuestion->survey_templates_id = $this->request->data('tempId');
                                $templateSaveQuestion->question = $questionId;
                                $templateSaveQuestion->question_ordering = $index;
                                $templateSaveQuestion->q_level = $this->request->data('q_level')."[".$questionId."]";
//                                pr($templateSaveQuestion);die('else');
                                $this->SurveyTemplatesQuestion->save($templateSaveQuestion);
                            }
                            $index++;
                        }

                    }
                    
                    foreach ($questionIds as $questionId) {
                        $surveyTemplatesQus[] = $this->SurveyTemplatesQuestion->find('all', [
                            'fields' => ['question', 'question_ordering'],
                            'conditions' => [
                                'question' => $questionId,
                                'star' => $this->request->data('star'),
                                'survey_templates_id' => $this->request->data('tempId'),
                                'q_level' => $this->request->data('q_level')."[".$questionId."]"
                            ],
                            'order' => ['question_ordering' => 'asc']
                        ])->first();
                    }
//                    pr($surveyTemplatesQus);die;
                    $updateQusOrdering = [];
                    /* @var $surveyTemplatesQus array type */
                    foreach ($surveyTemplatesQus as $data) {
                        if (!empty($data)) {
                            array_push($updateQusOrdering, $data->question);
                        }
                    }
//                    pr($updateQusOrdering);die; 
                    $questionDetailsById = array();
                    foreach ($updateQusOrdering as $id) {
                        $questionDetailsById[] = $this->SurveyQuestion->find('all', array('conditions' => array('id' => $id)))->toArray();
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }

                echo json_encode($questionDetailsById);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }

    /**
     * importSurveyTempalteQuestion method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function importSurveyTempalteQuestion()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data['template_id']) {
                $this->loadModel('SurveyTemplatesQuestion');
                try {
                   $template_id = $this->request->data['template_id'];               
                    //Fetch Question Details from Survey Template question.
                   $getQuestionIdByTemplate = $this->SurveyTemplatesQuestion->getTemplateQuestionAllDetails($template_id);
                
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }

                echo json_encode($getQuestionIdByTemplate);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * questionOrderingUp method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function questionOrderingUp()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data()) {
                $this->loadModel('SurveyTemplatesQuestion');
                try {               
                    //Fetch Question Details from Survey Template question.
                    $templatesQuestionData = $this->SurveyTemplatesQuestion->find('all',[
                       'conditions' => [
                           'survey_templates_id' => $this->request->data('tempId'),
                           'question' => $this->request->data('queId'),
                           'star' => $this->request->data('starVal')
                       ]
                    ])->first();

                    $templatesQuestionData->question_ordering = $templatesQuestionData->question_ordering - 1;
                    $res = $this->SurveyTemplatesQuestion->save($templatesQuestionData);
                    if ($res) {
                        $preTemplatesQuestionData = $this->SurveyTemplatesQuestion->find('all',[
                            'conditions' => [
                                'survey_templates_id' => $this->request->data('tempId'),
                                'question !=' => $this->request->data('queId'),
                                'star' => $this->request->data('starVal'),
                                'question_ordering' => $res->question_ordering
                            ]
                        ])->first();

                        $preTemplatesQuestionData->question_ordering = $preTemplatesQuestionData->question_ordering + 1;
                        $result = $this->SurveyTemplatesQuestion->save($preTemplatesQuestionData);
                        if ($result) {
                            $result->success = 'ok';
                        }
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * questionOrderingDown method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function questionOrderingDown()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data()) {
                $this->loadModel('SurveyTemplatesQuestion');
                try {               
                    //Fetch Question Details from Survey Template question.
                    $templatesQuestionData = $this->SurveyTemplatesQuestion->find('all',[
                       'conditions' => [
                           'survey_templates_id' => $this->request->data('tempId'),
                           'question' => $this->request->data('queId'),
                           'star' => $this->request->data('starVal')
                       ]
                    ])->first();

                    $templatesQuestionData->question_ordering = $templatesQuestionData->question_ordering + 1;
                    $res = $this->SurveyTemplatesQuestion->save($templatesQuestionData);
                    if ($res) {
                        $preTemplatesQuestionData = $this->SurveyTemplatesQuestion->find('all',[
                            'conditions' => [
                                'survey_templates_id' => $this->request->data('tempId'),
                                'question !=' => $this->request->data('queId'),
                                'star' => $this->request->data('starVal'),
                                'question_ordering' => $res->question_ordering
                            ]
                        ])->first();
                        
                        $preTemplatesQuestionData->question_ordering = $preTemplatesQuestionData->question_ordering - 1;
                        $result = $this->SurveyTemplatesQuestion->save($preTemplatesQuestionData);
                        if ($result) {
                            $result->success = 'ok';
                        }
                    }
                } catch (RecordNotFoundException $ex) {
                    $result = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($result);
                die;
            }
        } else {
            die("You can not access this function directly from URL.");
        }
    }
    
    /**
     * questionOrderingDown method
     *
     * @param string|null.
     * @return json.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeQuestion()
    {
        if ($this->request->is('ajax')) {
            if ($this->request->data()) {
                $results = [];
                $this->loadModel('SurveyTemplatesQuestion');
                try {               
                    //Fetch Question Details from Survey Template question.
                    $question = $this->SurveyTemplatesQuestion->find('all',[
                       'conditions' => [
                           'survey_templates_id' => $this->request->data('tempId'),
                           'question' => $this->request->data('queId'),
                           'star' => $this->request->data('starVal'),
                           'q_level' => $this->request->data('q_level').'['.$this->request->data('queId').']'
                       ]
                    ])->first();
                    $res = $this->SurveyTemplatesQuestion->delete($question);
                    
                    if ($res) {
                        $templatesQuestions = $this->SurveyTemplatesQuestion->find('all', [
                            'conditions' => [
                                'survey_templates_id' => $this->request->data('tempId'),
                                'star' => $this->request->data('starVal')
                            ],
                            'order' => [
                                'question_ordering' => 'asc'
                            ]
                        ])->toArray();

                        if (!empty($templatesQuestions)) {
                            $index = 1;
                            foreach ($templatesQuestions as $templatesQuestion) {
                                $templatesQuestion->question_ordering = $index;
                                $result = $this->SurveyTemplatesQuestion->save($templatesQuestion);
                                $index++;
                            }
                        } else {
                            $result = 1;
                        }
                    }
                    if ($result) {
                        $results['success'] = 'ok';
                    }
                } catch (RecordNotFoundException $ex) {
                    $results = ['error' => 'Somthing went wrong.'];
                }
                echo json_encode($results);
                die;
            }
        }
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\Exception\RecordNotFoundException;
use Cake\Http\Response;
use Cake\Core\Configure;
use Cake\Datasource\ConnectionManager;

/**
 * Reports Controller
 *
 * @property \App\Model\Table
 *
 * @method \App\Model\Entity paginate($object = null, array $settings = [])
 */
class ReportsController extends AppController
{
    public $components = ['CommonFunction'];
    
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Cookie');
    }
    
    /**
     * index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() 
    {
        $title = __('{0} power_testimonial', ['Reports']);
        $this->loadModel('Users');
        $currentUserID = $this->CommonFunction->getCurrentUserId();
        $userImg = $this->Users->getUserDetails($currentUserID);
        if (empty($userImg)) {
            return $this->redirect(['controller' => 'Indexes', 'action' => 'index']);
        }
        
        $user = $this->CommonFunction->getUser();
        $parentUser = $this->Users->getUserDetails($user['id']);
        $userIds = $this->CommonFunction->getAllUserIds($currentUserID, $parentUser->id, $userImg->group_id);
        if ($userImg->group_id == Configure::read('two')) {
            $userIds = $userIds;
        } else {
            $userIds = [$userImg->id];
        }

        //Get All Monts With Full Name
        $months = [];
        $currentMonth = date('F');
        $preMonth1 = date('F', strtotime($currentMonth . "last month"));
        $preMonth2 = date('F', strtotime($preMonth1 . "last month"));
        $preMonth3 = date('F', strtotime($preMonth2 . "last month"));
        $preMonth4 = date('F', strtotime($preMonth3 . "last month"));
        $preMonth5 = date('F', strtotime($preMonth4 . "last month"));
        
        $months[] = $preMonth5;
        $months[] = $preMonth4;
        $months[] = $preMonth3;
        $months[] = $preMonth2;
        $months[] = $preMonth1;
        $months[] = $currentMonth;
        
        //Get All Monts With Start and end date
        $currentDay = date('d');
        $currentStartDate = date('Y-m-01');     
        $currentDate = date('Y-m-d');     
        $lastDate1 = date('Y-m-d', time() - (24*60*60*$currentDay));
        $lastDate2 = date('Y-m-d', strtotime($lastDate1 . " -1 month"));
        $lastDate3 = date('Y-m-d', strtotime($lastDate2 . " -1 month"));
        $lastDate4 = date('Y-m-d', strtotime($lastDate3 . " -1 month"));
        $lastDate5 = date('Y-m-d', strtotime($lastDate4 . " -1 month"));
        $lastDate6 = date('Y-m-d', strtotime($lastDate5 . " -1 month"));
        $lastDate7 = date('Y-m-d', strtotime($lastDate6 . " -1 month"));
        $lastDate8 = date('Y-m-d', strtotime($lastDate7 . " -1 month"));
        $lastDate9 = date('Y-m-d', strtotime($lastDate8 . " -1 month"));
        $lastDate10 = date('Y-m-d', strtotime($lastDate9 . " -1 month"));
        $lastDate11 = date('Y-m-d', strtotime($lastDate10 . " -1 month"));
        $lastDate12 = date('Y-m-d', strtotime($lastDate11 . " -1 month"));
        
        $currentMonthSurveysTotal = $this->monthSurvey($userIds, $currentStartDate, $currentDate, Configure::read('survey_review_all'));
        $currentMonthSurveysCompleted = $this->monthSurvey($userIds, $currentStartDate, $currentDate, Configure::read('survey_review_completed'));
        $currentMonthReviewsTotal = $this->monthReview($userIds, $currentStartDate, $currentDate, Configure::read('survey_review_all'));
        $currentMonthReviewsCompleted = $this->monthReview($userIds, $currentStartDate, $currentDate, Configure::read('survey_review_completed'));

        $preMonthSurveys1Total = $this->monthSurvey($userIds, $lastDate2, $lastDate1, Configure::read('survey_review_all'));
        $preMonthSurveys1Completed = $this->monthSurvey($userIds, $lastDate2, $lastDate1, Configure::read('survey_review_completed'));
        $preMonthReviews1Total = $this->monthReview($userIds, $lastDate2, $lastDate1, Configure::read('survey_review_all'));
        $preMonthReviews1Completed = $this->monthReview($userIds, $lastDate2, $lastDate1, Configure::read('survey_review_completed'));
        
        $preMonthSurveys2Total = $this->monthSurvey($userIds, $lastDate3, date("Y-m-t", strtotime($lastDate3)), Configure::read('survey_review_all'));
        $preMonthSurveys2Completed = $this->monthSurvey($userIds, $lastDate3, date("Y-m-t", strtotime($lastDate3)), Configure::read('survey_review_completed'));
        $preMonthReviews2Total = $this->monthReview($userIds, $lastDate3, date("Y-m-t", strtotime($lastDate3)), Configure::read('survey_review_all'));
        $preMonthReviews2Completed = $this->monthReview($userIds, $lastDate3, date("Y-m-t", strtotime($lastDate3)), Configure::read('survey_review_completed'));
        
        $preMonthSurveys3Total = $this->monthSurvey($userIds, $lastDate4, date("Y-m-t", strtotime($lastDate4)), Configure::read('survey_review_all'));
        $preMonthSurveys3Completed = $this->monthSurvey($userIds, $lastDate4, date("Y-m-t", strtotime($lastDate4)), Configure::read('survey_review_completed'));
        $preMonthReviews3Total = $this->monthReview($userIds, $lastDate4, date("Y-m-t", strtotime($lastDate4)), Configure::read('survey_review_all'));
        $preMonthReviews3Completed = $this->monthReview($userIds, $lastDate4, date("Y-m-t", strtotime($lastDate4)), Configure::read('survey_review_completed'));

        $preMonthSurveys4Total = $this->monthSurvey($userIds, $lastDate5, date("Y-m-t", strtotime($lastDate5)), Configure::read('survey_review_all'));
        $preMonthSurveys4Completed = $this->monthSurvey($userIds, $lastDate5, date("Y-m-t", strtotime($lastDate5)), Configure::read('survey_review_completed'));
        $preMonthReviews4Total = $this->monthReview($userIds, $lastDate5, date("Y-m-t", strtotime($lastDate5)), Configure::read('survey_review_all'));
        $preMonthReviews4Completed = $this->monthReview($userIds, $lastDate5, date("Y-m-t", strtotime($lastDate5)), Configure::read('survey_review_completed'));
        
        $preMonthSurveys5Total = $this->monthSurvey($userIds, $lastDate6, date("Y-m-t", strtotime($lastDate6)), Configure::read('survey_review_all'));
        $preMonthSurveys5Completed = $this->monthSurvey($userIds, $lastDate6, date("Y-m-t", strtotime($lastDate6)), Configure::read('survey_review_completed'));
        $preMonthReviews5Total = $this->monthReview($userIds, $lastDate6, date("Y-m-t", strtotime($lastDate6)), Configure::read('survey_review_all'));
        $preMonthReviews5Completed = $this->monthReview($userIds, $lastDate6, date("Y-m-t", strtotime($lastDate6)), Configure::read('survey_review_completed'));
        
        $totalSurveyReview = $this->getAllSurveyReview($userIds, Configure::read('survey_review_all'));
        $totalSurveyReviewComplete = $this->getAllSurveyReview($userIds, Configure::read('survey_review_completed'));
        $totalSurveyReviewIncomplete = $this->getAllSurveyReview($userIds, Configure::read('survey_review_pending'));
        
        $this->set(compact(
                'title', 'userImg', 'currentMonthReviews', 'currentMonthSurveys', 'months',
                'currentMonthSurveysTotal', 'currentMonthSurveysCompleted', 'currentMonthReviewsTotal', 'currentMonthReviewsCompleted',
                'preMonthSurveys1Total', 'preMonthSurveys1Completed', 'preMonthReviews1Total', 'preMonthReviews1Completed',
                'preMonthSurveys2Total', 'preMonthSurveys2Completed', 'preMonthReviews2Total', 'preMonthReviews2Completed',
                'preMonthSurveys3Total', 'preMonthSurveys3Completed', 'preMonthReviews3Total', 'preMonthReviews3Completed',
                'preMonthSurveys4Total', 'preMonthSurveys4Completed', 'preMonthReviews4Total', 'preMonthReviews4Completed',
                'preMonthSurveys5Total', 'preMonthSurveys5Completed', 'preMonthReviews5Total', 'preMonthReviews5Completed',
                'totalSurveyReview', 'totalSurveyReviewComplete', 'totalSurveyReviewIncomplete'
        ));
    }
    
     /**
     * monthSurvey Function to get month wise Survey
     *
     * @param array $userIds userids of all associate and its representative
     * @param string $startDate month start date
     * @param string $endDate month end date
     * @param array $completed combine array of survey completed, pending and sent request
     *
     * @return array
     */
    public function monthSurvey($userIds = null, $startDate = null, $endDate = null, $completed = null) 
    {
        $this->loadModel('ReviewsMgmt');
        $getSurveyReviews = $this->ReviewsMgmt->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->bind(':start', new \DateTime($startDate.'00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($endDate.'23:59:59'), 'datetime')
                            ->toArray();

        $surveys = [];
        if ($getSurveyReviews) {
            $this->loadModel('SurveyMgmt');
            foreach ($getSurveyReviews as $surveyReview) {

                $survey = $this->SurveyMgmt->find('all', [
                            'conditions' => [
                                'id' => $surveyReview->survey_id,
                            ]
                        ])->first();
                $templateIds[] = $survey->survey_template_id;
            }

            foreach ($templateIds as $templateId) {
                $this->loadModel('SurveyTemplatesQuestion');
                $surveyTemplates[] = $this->SurveyTemplatesQuestion->find('all', [
                                        'conditions' => [
                                            'survey_templates_id' => $templateId,
                                        ]
                                    ])->first();
            }

            foreach ($surveyTemplates as $surveyTemplate) {
                if (!empty($surveyTemplate)) {
                    if ($surveyTemplate->type == Configure::read('two')) {
                        $surveys[] = $this->SurveyMgmt->find('all', [
                                        'conditions' => [
                                            'user_id IN' => $userIds,
                                            'survey_template_id' => $surveyTemplate->survey_templates_id,
                                        ]
                                    ])->first();
                    }
                }
            }
        }
        
        return $surveys;
    }
    
    /**
     * monthReview Function to get month wise Review
     *
     * @param array $userIds userids of all associate and its representative
     * @param string $startDate month start date
     * @param string $endDate month end date
     * @param array $completed combine array of Review completed, pending and sent request
     *
     * @return array
     */    
    public function monthReview($userIds = null, $startDate = null, $endDate = null, $completed = null) 
    {
        $this->loadModel('ReviewsMgmt');
        $getSurveyReviews = $this->ReviewsMgmt->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                    'created BETWEEN :start AND :end'
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->bind(':start', new \DateTime($startDate.'00:00:00'), 'datetime')
                            ->bind(':end', new \DateTime($endDate.'23:59:59'), 'datetime')
                            ->toArray();
        
        $reviews = [];
        if ($getSurveyReviews) {
            $this->loadModel('SurveyMgmt');
            foreach ($getSurveyReviews as $surveyReview) {

                $survey = $this->SurveyMgmt->find('all', [
                            'conditions' => [
                                'id' => $surveyReview->survey_id,
                            ]
                        ])->first();
                $templateIds[] = $survey->survey_template_id;
            }

            foreach ($templateIds as $templateId) {
                $this->loadModel('SurveyTemplatesQuestion');
                $surveyTemplates[] = $this->SurveyTemplatesQuestion->find('all', [
                                        'conditions' => [
                                            'survey_templates_id' => $templateId,
                                        ]
                                    ])->first();
            }
            
            foreach ($surveyTemplates as $surveyTemplate) {
                if (!empty($surveyTemplate)) {
                    if ($surveyTemplate->type == Configure::read('one')) {
                        $reviews[] = $this->SurveyMgmt->find('all', [
                                        'conditions' => [
                                            'user_id IN' => $userIds,
                                            'survey_template_id' => $surveyTemplate->survey_templates_id,
                                        ]
                                    ])->first();
                    }
                }
            }
        }
        
        return $reviews;
    }
    
    /**
     * getAllSurveyReview Function to get all Surveys/Reviews
     *
     * @param array $userIds userids of all associate and its representative
     * @param array $completed combine array for all "completed, pending and sent" request Survey/Review 
     *
     * @return array
     */ 
    public function getAllSurveyReview($userIds, $completed) 
    {
        $this->loadModel('ReviewsMgmt');
        $getSurveyReviews = $this->ReviewsMgmt->find('all', [
                                'conditions' => [
                                    'user_id IN' => $userIds,
                                    'survey_done IN' => $completed,
                                    'is_deleted' => Configure::read('zero'),
                                ], 
                                'order' => [
                                    'created' => "desc"
                                ]
                            ])
                            ->toArray();
        
        return $getSurveyReviews;
    }
}
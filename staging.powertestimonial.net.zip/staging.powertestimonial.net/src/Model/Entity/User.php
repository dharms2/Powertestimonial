<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Cake\ORM\TableRegistry;

/**
 * User Entity
 *
 * @property int $id
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $password
 * @property int $phone
 * @property string $business_name
 * @property int $group_id
 * @property bool $is_active
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Group $group
 * @property \App\Model\Entity\Post[] $posts
 * @property \App\Model\Entity\ProfileImage[] $profile_images
 */
class User extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'first_name' => true,
        'last_name' => true,
        'email' => true,
        'additional_email' => true,
        'password' => true,
        'phone' => true,
        'business_name' => true,
        'group_id' => true,
        'is_active' => true,
        'created' => true,
        'modified' => true,
        'group' => true,
        'posts' => true,
        'profile_images' => true,
        'address_line1' => true,
        'address_line2' => true,
        'city' => true,
        'state' => true,
        'country' => true,
        'zip_code' => true,
        'term_condition' => true,
        'billing_address' => true,
        'business_name' => true,
        'business_phone' => true,
        'business_address_line1' => true,
        'business_address_line2' => true,
        'business_city' => true,
        'business_state' => true,
        'business_country' => true,    
        'business_zip_code' => true, 
        'token' => true, 
        'plan_id' => true, 
        'access_token' => true,
        'review_fetch_date' => true,
        'company_id' => true,
        'location' => true
    ];

    /**
     * Fields that are excluded from JSON versions of the entity.
     *
     * @var array
     */
    protected $_hidden = [
        'password'
    ];
    
    public function parentNode()
    {
        if (!$this->id) {
                return null;
        }
        if (isset($this->group_id)) {
                $groupId = $this->group_id;
        } else {
                $Users = TableRegistry::get('Users');
                $user = $Users->find('all', ['fields' => ['group_id']])->where(['id' => $this->id])->first();
                $groupId = $user->group_id;
        }
        if (!$groupId) {
                return null;
        }
        return ['Groups' => ['id' => $groupId]];
    }
}

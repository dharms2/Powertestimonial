<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SurveyMgmt Entity
 *
 * @property int $id
 * @property int $user_id
 * @property string $name
 * @property string $description
 * @property int $survey_template_id
 * @property bool $status
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\SurveyTemplate $survey_template
 * @property \App\Model\Entity\SurveyAn[] $survey_ans
 * @property \App\Model\Entity\SurveyQus[] $survey_qus
 */
class SurveyMgmt extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'name' => true,
        'description' => true,
        'survey_template_id' => true,
        'status' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'survey_template' => true,
        'survey_ans' => true,
        'survey_qus' => true,
		'is_edited' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Google Entity
 *
 * @property int $id
 * @property int $user_id
 * @property string $place_id
 * @property string $name
 * @property string $rating
 * @property string $adr_address
 * @property string $formatted_address
 * @property float $location_lat
 * @property float $location_lng
 * @property string $formatted_phone_number
 * @property string $international_phone_number
 * @property string $reference
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Place $place
 */
class Google extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'place_id' => true,
        'name' => true,
        'rating' => true,
        'adr_address' => true,
        'formatted_address' => true,
        'location_lat' => true,
        'location_lng' => true,
        'formatted_phone_number' => true,
        'international_phone_number' => true,
        'reference' => true,
        'map_url' => true,
        'website' => true,
        'created' => true,
        'modified' => true,
    ];
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * CustomEmailTemplate Entity
 *
 * @property int $id
 * @property int $user_id
 * @property string $subject
 * @property string $body
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 */
class CustomEmailTemplate extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'init_subject' => true,
        'init_body' => true,
        'first_reminder_days' => true,
        'first_subject' => true,
        'first_body' => true,
        'second_reminder_days' => true,
        'second_subject' => true,
        'second_body' => true,
        'sms_verbiage' => true,
        'created' => true,
        'modified' => true,
    ];
}

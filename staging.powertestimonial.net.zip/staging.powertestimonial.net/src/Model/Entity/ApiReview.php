<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ApiReview Entity
 *
 * @property int $id
 * @property int $user_id
 * @property string $review_id
 * @property int $rating
 * @property string $source_img
 * @property string $reviewer_name
 * @property string $review_date
 * @property string $review_url
 * @property string $review_desc
 * @property string $reviewer_profile_url
 * @property string $google_relative_time
 * @property string $zillow_review_summary
 * @property bool $deleted
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Review $review
 */
class ApiReview extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'review_id' => true,
        'rating' => true,
        'source_img' => true,
        'reviewer_name' => true,
        'review_date' => true,
        'review_url' => true,
        'review_desc' => true,
        'reviewer_profile_url' => true,
        'google_relative_time' => true,
        'zillow_review_summary' => true,
        'zillow_review_id' => true,
        'google_review_id' => true,
        'yelp_review_id' => true,
        'facebook_review_id' => true,
        'deleted' => true,
    ];
}

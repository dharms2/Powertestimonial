<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ReviewsMgmt Entity
 *
 * @property int $id
 * @property string $recipient_first_name
 * @property string $recipient_last_name
 * @property string $recipient_email
 * @property int $recipient_phone
 * @property int $survey_id
 * @property int $user_id
 * @property bool $status
 * @property bool $user_action
 * @property int $ratings
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\SurveyMgmt $survey_mgmt
 * @property \App\Model\Entity\User $user
 */
class ReviewsMgmt extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'recipient_first_name' => true,
        'recipient_last_name' => true,
        'recipient_email' => true,
        'recipient_phone' => true,
        'survey_id' => true,
        'user_id' => true,
        'sender_id' => true,
        'send_type' => true,
        'status' => false,
        'user_action' => false,
        'ratings' => false,
        'created' => true,
        'survey_done' => false,
        'modified' => true,
        'is_deleted' => true,
        'first_reminder_send' => true,
        'first_reminder_dt' => true,
        'second_reminder_dt' => true,
        'second_reminder_send' => true,
        'survey_mgmt' => false,
    ];
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * UserPlans Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\PlansTable|\Cake\ORM\Association\BelongsTo $Plans
 * @property \App\Model\Table\TransactionsTable|\Cake\ORM\Association\BelongsTo $Transactions
 *
 * @method \App\Model\Entity\UserPlan get($primaryKey, $options = [])
 * @method \App\Model\Entity\UserPlan newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\UserPlan[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\UserPlan|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\UserPlan patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\UserPlan[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\UserPlan findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UserPlansTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('user_plans');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Plans', [
            'foreignKey' => 'plan_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['plan_id'], 'Plans'));

        return $rules;
    }
    
    /**
    * add User Plan Method used to add user plan data with start date to end date for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @param Array $postData, post user data
    * @return void
    */
    public function addUserPlan($data = array(), $postData = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $userPlan = $this->newEntity();
        } else {
            $userPlan = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $userPlan = $this->patchEntity($userPlan, $data);

        $userPlan->user_id = $data['user_id'];
        $userPlan->plan_id = $postData['plan_id'];
        $userPlan->start_dt = date("Y-m-d");
        $userPlan->amt = $postData['amt'];
        
        // save data in the table
        $result = $this->save($userPlan);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
    * get User Plan Details Method used to get user plan data
    *
    * @access public
    * @param int $userId, login user ID
    * @return void
    */
    public function getUserPlanDetails($userId = null) 
    {
        return $this->find('all', [
            'conditions' => [
                'user_id' => $userId,
                'status' => 0
            ]
        ])->first();
    }
    
    /**
     * getUserPlanByPlanID method
     *
     * @param string $id.
     * @param string $planId.
     * @param string $reqPlanId.
     * @return void
     */
    public function getUserPlanByUpgradePlanID($id = null, $planId = null, $reqPlanId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $id,
                        'plan_id' => $planId,
                        'plan_upgrade_req' => $reqPlanId,
                        'status' => 0
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getUserPlanByPlanID method
     *
     * @param string $id.
     * @param string $planId.
     * @return void
     */
    public function getUserPlanByPlanId($id = null, $planId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $id,
                        'plan_id' => $planId
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getUserPlanByPlanID method
     *
     * @param string $id.
     * @param string $planId.
     * @return void
     */
    public function getUserPlans($id = null, $planId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $id,
                        'plan_id' => $planId,
                        'status' => 0
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getSuperAdminUserPlans method
     *
     * @param NULL.
     * @return void
     */
    public function getSuperAdminUserPlans() 
    {
        $result = $this->find('all', [
                    'order' => [
                        'UserPlans.approved_dt' => 'asc',
                        'UserPlans.request_dt' => 'desc'
                    ],
                    'conditions' => [
                        'OR' => [
                            'request_dt !=' => "0000-00-00",
                            'approved_dt !=' => "0000-00-00"
                        ]
                    ],
                    'contain' => ['users'],
                ])->toArray();
        return $result;
    }
}

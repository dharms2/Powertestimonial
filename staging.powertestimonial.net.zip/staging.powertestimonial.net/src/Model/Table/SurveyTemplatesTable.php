<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;

/**
 * SurveyTemplates Model
 *
 * @property \App\Model\Table\SurveyMgmtTable|\Cake\ORM\Association\HasMany $SurveyMgmt
 *
 * @method \App\Model\Entity\SurveyTemplate get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyTemplate newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyTemplate[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplate|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyTemplate patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplate[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplate findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyTemplatesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_templates');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

       $this->hasMany('SurveyTemplatesQuestion', [
            'foreignKey' => 'survey_templates_id'
       ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('name')
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->scalar('description')
            ->requirePresence('description', 'create')
            ->notEmpty('description');

        $validator
            ->scalar('greeting')
            ->requirePresence('greeting', 'create')
            ->notEmpty('greeting');

        $validator
            ->scalar('footer')
            ->requirePresence('footer', 'create')
            ->notEmpty('footer');

        return $validator;
    }
    
    
    /**
     * Function to get all Template List
     *
     * @param int $surveyId content of Survey id
     * @return void
     */
    public function getTemplateList($userId = null) 
    {
        $result = $this->find('list', [
                    'conditions' => [
                        'user_id' => $userId,
                        'status' =>1,
                        'is_deleted' => 0
                    ]
                ])->toArray();
        
        return $result;
    }
    
    
    /**
     * Function to get Template Details
     *
     * @param int $templateId, Template id content
     * @return void
     */
    public function getTemplateDetails($templateId = null) 
    {
        $result = $this->find('all', ['conditions' => ['id' => $templateId]])->first();
        return $result;
    }
    
    /**
     * Function to add Template Details
     *
     * @param array $data
     * @return void
     */
    public function editTemplate($data = array())
    {   
        $surveyTemplatesQuestion = TableRegistry::get('SurveyTemplatesQuestion');
        $existing_q = array();
        
        if (!$data) {  // no data submitted
            return false;
        }
        
        $surveyTemplate = $this->get($data['template_id'], [
            'contain' => ['surveyTemplatesQuestion']
        ]);
        
        $surveyTemplate = $this->patchEntity($surveyTemplate, $data);
        //Save data in the table
        $result = $this->save($surveyTemplate);
        if (!$result) { // problem saving the data
            return false;
        } else {
            //If getting ques type then key value remove from array.
            if ($data['ques_type'] == 1) {
                $questionInert = $data['select_qusetion_id'];
                 
                /* @var $questionInert array */
                if (array_key_exists(0, $questionInert)) {
                    unset($questionInert[0]);
                }

                $surveyTemplatesQuestion->deleteAll([ 'star' => 0, 'survey_templates_id' => $data['template_id']]);
                
            } else {
                $questionInert = $data['select_qusetion_id'];
              
                foreach ($questionInert as $key=> $val) {
                    if (array_key_exists($key, $questionInert)) {
                        if ($key != 0) {
                           $surveyTemplatesQuestion->deleteAll([
                                'star' => $key,
                                'survey_templates_id' => $data['template_id']
                            ]);
                            unset($questionInert[$key]);
                        }
                    }
                }
            }
            
            foreach ($questionInert as $key => $questionInertFinal) {
                foreach ($questionInertFinal as $questionInertFinalId) {
                    $resultCount = $surveyTemplatesQuestion->find('all', [
                        'conditions' => [
                            'question' => $questionInertFinalId,
                            'star' => $key,
                            'survey_templates_id' => $data['template_id']
                            ]
                    ])->count();
                    if ($resultCount > 0) {
                        $resultCountFetch = $surveyTemplatesQuestion->find('all', [
                            'conditions' => [
                                'question' => $questionInertFinalId,
                                'star' => $key,
                                'survey_templates_id' => $data['template_id']
                                ]
                        ])->first();
                        
                        //Update Quesry.
                        $templateSaveQuestion = $surveyTemplatesQuestion->get($resultCountFetch->id); 
                        $templateSaveQuestion->type = $data['ques_type'];
                        $templateSaveQuestion->star = $key;
                        $templateSaveQuestion->fouroption = $data['fouroption'];
                        $templateSaveQuestion->survey_templates_id = $data['template_id'];
                        $templateSaveQuestion->question = $questionInertFinalId;
                        $result = $surveyTemplatesQuestion->save($templateSaveQuestion);
                        
                    } else {
                        $qusOrderring = $surveyTemplatesQuestion->find('all', [
                            'fields' => ['question_ordering', 'question'],
                            'conditions' => [
                                'star' => $key,
                                'survey_templates_id' => $data['template_id']
                            ],
                            'order' => ['question_ordering' => 'asc']
                        ])->toArray();
                        
                        $questionIds = array();
                        foreach($qusOrderring as $value){
                            array_push($questionIds, $value->question_ordering);
                        }
                        
                        if ($key != 5 && $key != 4) {
                            $templateSaveQuestion = $surveyTemplatesQuestion->newEntity();
                            $templateSaveQuestion->type = $data['ques_type'];
                            $templateSaveQuestion->star = $key;
                            $templateSaveQuestion->fouroption = $data['fouroption'];
                            $templateSaveQuestion->survey_templates_id = $data['template_id'];
                            $templateSaveQuestion->question = $questionInertFinalId;
                            if (!empty($questionIds)) {
                                $templateSaveQuestion->question_ordering = (max($questionIds) + 1);
                            } else {
                                $templateSaveQuestion->question_ordering = 1;
                            }
                            $result = $surveyTemplatesQuestion->save($templateSaveQuestion);
                            
                        } else if ($key == 4 && $data['fouroption'] == 1) {
                            $templateSaveQuestion = $surveyTemplatesQuestion->newEntity();
                            $templateSaveQuestion->type = $data['ques_type'];
                            $templateSaveQuestion->star = $key;
                            $templateSaveQuestion->fouroption = $data['fouroption'];
                            $templateSaveQuestion->survey_templates_id = $data['template_id'];
                            $templateSaveQuestion->question = $questionInertFinalId;
                            if (!empty($questionIds)) {
                                $templateSaveQuestion->question_ordering = (max($questionIds) + 1);
                            } else {
                                $templateSaveQuestion->question_ordering = 1;
                            }
                            $result = $surveyTemplatesQuestion->save($templateSaveQuestion);
                            
                        } else {
                            $templateSaveQuestion = $surveyTemplatesQuestion->newEntity();
                            $templateSaveQuestion->type = $data['ques_type'];
                            $templateSaveQuestion->star = $key;
                            $templateSaveQuestion->fouroption = $data['fouroption'];
                            $templateSaveQuestion->survey_templates_id = $data['template_id'];
                            $templateSaveQuestion->question = $questionInertFinalId;

                            $result = $surveyTemplatesQuestion->save($templateSaveQuestion);
                        }
                   }
                }
          
                //Delete records if star exist but question not exist.
                $resultallrecords = $surveyTemplatesQuestion->find('all', [
                                    'conditions' => [
                                        'star'=>$key,
                                        'survey_templates_id'=>$data['template_id']
                                        ]
                                ])->toArray(); 
               
                foreach ($resultallrecords as $result) {
                    //Delete query
                    if (!in_array($result->question, $questionInertFinal)) {
                        $surveyTemplatesQuestion->deleteAll([
                                'star' => $key,
                                'survey_templates_id'=>$data['template_id'],
                                'question' => $result->question
                        ]);   
                    }
                }     
            } 
        }
        return $result; 
    }
    
//    public function recursiveDataInsert($logicId, $questionInertFinalData, $insertData, $starVal, $surveyTempId) 
//    {   
//        return false;
//        if (!empty($questionInertFinalData)) {
//            $index = 1;
//            foreach ($questionInertFinalData as $questionInertData) {
//
//                $surveyTemplatesQuestionTable = TableRegistry::get('SurveyTemplatesQuestion');
//                $templateData = $surveyTemplatesQuestionTable->newEntity();
//                $templateData->type = $insertData['qus_types'];
//                $templateData->fouroption = $insertData['fouroption'];
//                $templateData->star = $starVal;
//                $templateData->survey_templates_id = $surveyTempId;
//                $templateData->question = $questionInertData['q'];
//                $templateData->question_ordering = $index;
//                $templateData->has_question_logic = ($logicId == null) ? 0 : 1;
//                $templateData->question_logic_id = $logicId;
//               
//                $insertTemplateData = $surveyTemplatesQuestionTable->save($templateData);
//                if (!empty($questionInertData['ans'])) {
//
//                    foreach ($questionInertData['ans'] as $logicKey => $logicData) {
//                        $surveyTemplatesQuestionLogicTable = TableRegistry::get('SurveyTemplatesQuestionLogic');
//                        $questionLogicData = $surveyTemplatesQuestionLogicTable->newEntity();
//                        $questionLogicData->survey_template_question_id = $insertTemplateData->id;
//                        $questionLogicData->ans_option = $logicKey;
//                        
//                        $insertquestionLogicData = $surveyTemplatesQuestionLogicTable->save($questionLogicData);
//                        
//                        $this->recursiveDataInsert($insertquestionLogicData->id, $logicData, $insertData, $starVal, $surveyTempId);
//                    }
//                }
//                $index++;
//            }
//            return true;
//        } 
//    }
    
    /**
     * Function to get Survey Template Only 
     *
     * @param int $templateId, Template id content
     * @return void
     */
    public function getSurveyTemplateList($userIds = null) 
    {
        $result = [];
        $resultDataFinal = $this->find('all', [
                            'conditions' => [
                                'user_id IN' => $userIds
                            ],
                            'contain' => [
                                'SurveyTemplatesQuestion' => [
                                    'conditions' => [
                                        'SurveyTemplatesQuestion.type' => 2,
                                    ],
                                ],
                            ]
                        ])->toArray();
   
        foreach ($resultDataFinal as $resultData) {
            if (!empty($resultData->survey_templates_question)) {
               $result[] = $resultData;
            }
        }
        return $result;
    }
    
    /**
    * Add Survey Template Method used to add default Survey Template data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addSurveyTemplate($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyTemplate = $this->newEntity();
        } else {
            $surveyTemplate = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyTemplate = $this->patchEntity($surveyTemplate, $data);

        $surveyTemplate->user_id = $data['user_id'];
        $surveyTemplate->name = Configure::read('surveyTemplateSurevyName');
        $surveyTemplate->description = Configure::read('surveyTemplateSurevyDescription');
        $surveyTemplate->greeting = Configure::read('surveyTemplateSurevyGreeting');
        $surveyTemplate->footer = Configure::read('surveyTemplateSurevyFooter');
        $surveyTemplate->is_edited = 1;
        
        // save data in the table
        $result = $this->save($surveyTemplate);
       
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
    * Add Reviw Template Method used to add default Reviw Template data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addReviewDefaultTemplate($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $surveyTemplate = $this->newEntity();
        } else {
            $surveyTemplate = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $surveyTemplate = $this->patchEntity($surveyTemplate, $data);

        $surveyTemplate->user_id = $data['user_id'];
        $surveyTemplate->name = Configure::read('surveyTemplateReviewName');
        $surveyTemplate->description = Configure::read('surveyTemplateReviewDescription');
        $surveyTemplate->greeting = Configure::read('surveyTemplateReviewGreeting');
        $surveyTemplate->footer = Configure::read('surveyTemplateReviewFooter');
        $surveyTemplate->is_edited = 1;
        
        // save data in the table
        $result = $this->save($surveyTemplate);
       
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
}

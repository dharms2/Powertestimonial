<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SurveyTemplatesQuestionLogic Model
 *
 * @property \App\Model\Table\SurveyTemplateQuestionsTable|\Cake\ORM\Association\BelongsTo $SurveyTemplateQuestions
 *
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestionLogic findOrCreate($search, callable $callback = null, $options = [])
 */
class SurveyTemplatesQuestionLogicTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_templates_question_logic');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('SurveyTemplateQuestions', [
            'foreignKey' => 'survey_template_question_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        return $rules;
    }
}

<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use App\Model\Entity\User;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Core\Configure;

/**
 * Users Model
 *
 * @property \App\Model\Table\GroupsTable|\Cake\ORM\Association\BelongsTo $Groups
 * @property \App\Model\Table\PostsTable|\Cake\ORM\Association\HasMany $Posts
 * @property \App\Model\Table\ProfileImagesTable|\Cake\ORM\Association\HasMany $ProfileImages
 *
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UsersTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('users');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->addBehavior('Acl.Acl', ['type' => 'requester']);
        $this->addBehavior('Timestamp');
        
        $this->belongsTo('Groups', [
            'foreignKey' => 'group_id',
            'joinType' => 'INNER'
        ]);
        
        $this->hasMany('Posts', [
            'foreignKey' => 'user_id'
        ]);
        
        $this->hasMany('ProfileImages', [
            'foreignKey' => 'user_id'
        ]);
        
        $this->hasMany('ApiReviews', [
            'foreignKey' => 'user_id'
        ]);
        
        $this->hasMany('UserPlans', [
            'foreignKey' => 'user_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) 
    {
        $validator
                ->integer('id')
                ->allowEmpty('id', 'create');

        $validator
                ->scalar('first_name')
                ->allowEmpty('first_name');

        $validator
                ->scalar('last_name')
                ->allowEmpty('last_name');

        $validator
                ->scalar('password')
                ->requirePresence('password', 'create')
                ->notEmpty('password');

        $validator
                ->email('email')
                ->requirePresence('email', 'create')
                ->notEmpty('email')
                ->add('email', 'unique', [
                    'rule' => 'validateUnique',
                    'provider' => 'table',
                    'message' => 'This email id is already exist.',
        ]);

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['email']));
        $rules->add($rules->existsIn(['group_id'], 'Groups'));

        return $rules;
    }

    /**
     * beforeSave Method
     * update User model to hash passwords before they go into the database
     *
     * @access public
     * @param List of data to set at run-time
     * @return boolean 
     */
    public function beforeSave(\Cake\Event\Event $event, \Cake\ORM\Entity $entity, \ArrayObject $options) 
    {
        $hasher = new DefaultPasswordHasher;

        if (!empty($entity->id)) {
            // get current saved password
            $result = $this->find('all', [
                        'conditions' => [
                            'id' => $entity->id
                        ]
                    ])->first();

            if ($entity->password == $result->password) {
                $entity->password = $result->password;
            } else {
                $entity->password = $hasher->hash($entity->password);
            }
        } else {
            $entity->password = $hasher->hash($entity->password);
        }

        return true;
    }

    /**
     * Add User Method used to add/edit new User at run-time
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function addUser($data = array(), $current_user = array()) 
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['id'])) {
            $user = $this->get($data['id'], ['contain' => ['ProfileImages']]);
        } else {
            $user = $this->newEntity();
        }

        $user = $this->patchEntity($user, $data);
        $user->parent_id = 0;
        
        // save data in the table
        $result = $this->save($user);

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }
    
    /**
     * addAssociateUser Method used to add/edit new associate User at run-time
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function addAssociateUser($data = array(), $current_user = array()) 
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['id'])) {
            $user = $this->get($data['id'], ['contain' => ['ProfileImages']]);
        } else {
            $user = $this->newEntity();
        }

        $user = $this->patchEntity($user, $data);

        $user->term_condition = 1;
        
        if (isset($data['id'])) {
            if ($data['add_parent_id'] != '') {
                $user->parent_id = $data['add_parent_id'];
                $user->location = '';
            } else {
                $user->parent_id = $data['parent_id'];
                $user->location = '';
            }
            if ($data['add_location'] != '') {
                $user->location = $data['add_location'];
            }
        } else {
            if (!empty($current_user) && empty($data['add_parent_id'])) {
                $user->parent_id = $current_user['id'];
            } else {
                $user->parent_id = $data['add_parent_id'];
            }
        }

        // save data in the table
        $result = $this->save($user);

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }
    
    /**
     * Edit Associate Method used to edit associate user at run-time
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function editAssociate($data = array()) 
    {
        if (!$data) {  // no data submitted
            return false;
        }
        if (isset($data['id'])) {
            $user = $this->get($data['id'], ['contain' => ['ProfileImages']]);
        } else {
            $user = $this->newEntity();
        }
        $user = $this->patchEntity($user, $data);
        $result = $this->save($user);
        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }

    /**
     * Method for insert user image
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function updateUserImages($usrImg = NULL, $imgtype = NULL, $userId = NULL)
    {
        if ($imgtype == 1) {
            $data = ['img_url' => $usrImg];
        } else {
            $data = ['business_img_url' => $usrImg];
        }

        $result = $this->ProfileImages->query()
                ->update()
                ->set($data)
                ->where(['user_id' => $userId])
                ->execute();

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }

    /**
     * Method for insert user image
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function insertUserImages($usrImg = NULL, $imgtype = NULL, $userId = NULL) 
    {
        $profileImage = $this->ProfileImages->newEntity();
        $profileImage->user_id = $userId;
        if ($imgtype == 1) {
            $profileImage->img_url = $usrImg;
        } else {
            $profileImage->business_img_url = $usrImg;
        }

        $result = $this->ProfileImages->save($profileImage);

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }

    /**
     * check old password method
     *
     * @param string|null The configuration for the Table.
     * @return array(count)
     */
    public function checkoldPassword($data = null, $userId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'id' => $userId
                    ]
                ])->first();

        if ((new DefaultPasswordHasher)->check($data['password'], $result->password)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * checkUniqueEmailId method
     *
     * @param string|null The configuration for the Table.
     * @return array(count)
     */
    public function checkUniqueEmailId($data = null, $requestID = null) 
    {
        if($requestID == 2){
            //Fisrt Check primary email id.
            $resCount = $this->find('all', [
                'conditions' => [
                    'email' => $data['email'],
                    'is_deleted' => 0
                ]
            ])->count();
    
            //If additionali email is not found from primary email
            //then check from additional email
            if($resCount == 0){
                $resAddCount = $this->find('all', [
                    'conditions' => [
                        'additional_email' => $data['email'],
                            'id' => $data['userId'],
                        ]
                ])->count();
        
                if($resAddCount > 0) {
                    $result = 0;
                } else {
                    $result = $this->find('all', [
                            'conditions' => [
                                'additional_email' => $data['email'],
                                'id !=' => $data['userId'],
                             ]
                    ])->count();   
                }
            } else {
                 $result = $resCount;
            }

        } else {
            $result = $this->find('all', [
                'conditions' => [
                    'email' => $data['email'],
                    'is_deleted' => 0
                ]
            ])->count();
        }

        return $result;
    }

    /**
     * getAllCountryList method
     *
     * @param string|null The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getAllUserList($id = null)
    {
        return $this->find('list', [
                    'keyField' => 'id',
                    'valueField' => function ($row) {
                        return $row['first_name'] . ' ' . $row['last_name'];
                    }
                ])->where(['id' => $id, 'is_deleted' => 0]);
    }
    
    /**
     * getAllAssociatesUserList method
     *
     * @param array|$ids The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getAllAssociatesUserList($ids = array())
    {
        if (is_array($ids)) {
            return $this->find('list', [
                        'keyField' => 'id',
                        'valueField' => function ($row) {
                            return $row['first_name'] . ' ' . $row['last_name'];
                        }
                    ])->where(['id IN' => $ids, 'is_deleted' => 0])->toArray();
        } else {
            return $this->find('list', [
                        'keyField' => 'id',
                        'valueField' => function ($row) {
                            return $row['first_name'] . ' ' . $row['last_name'];
                        }
                    ])->where(['parent_id' => $ids, 'is_deleted' => 0])->toArray();
        }                                                        
    }
    
    /**
     * getAllUsersList method
     *
     * @param string|null The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getAllUsersList($id = null)
    {
        return $this->find('list', [
                    'keyField' => 'id',
                    'valueField' => function ($row) {
                        return $row['first_name'] . ' ' . $row['last_name'];
                    }
                ])->where(['company_id' => $id, 'is_deleted' => 0])->toArray();
    }

    /**
     * getUserDetails method
     *
     * @param string $id.
     * @return void
     */
    public function getUserDetails($id = null)
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'id' => $id
                    ],
                    'contain' => [
                        'ProfileImages', 'UserPlans'
                    ]
                ])->first();
        return $result;
    }
    
    /**
     * getAllAssociates method
     *
     * @param string $id.
     * @return void
     */
    public function getAllAssociates($id = null)
    {
        $result = $this->find('all', [
                    'fields' => ['id', 'parent_id'],
                    'conditions' => [
                        'is_deleted' => 0,
                        'OR' => [['parent_id' => $id], ['id' => $id]]
                    ]
                ])->toArray();
        return $result;
    }
    
    /**
     * getAllChildAssociates method
     *
     * @param string $companyId.
     * @return void
     */
    public function getAllChildAssociates($companyId = null)
    {
        $result = $this->find('all', [
                    'fields' => ['id', 'parent_id', 'company_id'],
                    'conditions' => [
                        'is_deleted' => 0,
                        'OR' => [['company_id' => $companyId], ['id' => $companyId]]
//                        'company_id' => $companyId
                    ]
                ])->toArray();
        return $result;
    }

    /**
     * change user password method
     *
     * @param string $id.
     * @return void
     */
    public function changeUserPassword($data = null, $userId = null) 
    {
        $user = $this->get($userId); // Return article with id 12
        $user->access_token = base64_encode($data['new_password']);
        $user->password = $data['new_password'];
        $result = $this->save($user);

        return $result;
    }

    /**
     * Method update reset password tokem
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function updateUserToken($data = NULL)
    {
        $result = $this->query()
                ->update()
                ->set(['token' => $data['passkey']])
                ->where(['email' => $data['email']])
                ->execute();

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }
    
    /**
     * get User Data method
     *
     * @param string $id.
     * @return void
     */
    public function getUserData($id = null)
    {
         $result = $this->find('all', [
                    'conditions' => [
                        'id' => $id
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getUserDataByPlanId method
     *
     * @param string $id.
     * @param string $planId.
     * @return void
     */
    public function getUserDataByPlanId($id = null, $planId = null)
    {
         $result = $this->find('all', [
                    'conditions' => [
                        'id' => $id,
                        'plan_id' => $planId,
                    ],
                ])->first();
        return $result;
    }
    
    /**
     * getSuperUserData method
     *
     * @param NULL.
     * @return void
     */
    public function getSuperUserData()
    {
         $result = $this->find('all', [
                    'order' => [
                        'created' => 'desc'
                    ],
                    'conditions' => [
                        'is_deleted' => 0,
                        'group_id IN' => [2,3,4,7],
                    ],
                ])->toArray();
        return $result;
    }
    
    /**
     * getParentUserList method
     *
     * @param Array|$postData The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getParentUserList($postData) 
    {
        if ($postData['rollId'] == 4) {
            $condition = ['is_deleted' => '0',
                            'group_id' => 7,
                            'company_id' => $postData['companyId']
                        ];
        } elseif ($postData['rollId'] == 7) {
            $condition = ['is_deleted' => '0',
                            'group_id' => 3,
                            'company_id' => $postData['companyId']
                        ];
        } 
        
        return $this->find('list', [
                    'keyField' => 'id',
                    'valueField' => function ($row) {
                            return $row['first_name'] . ' ' . $row['last_name'];
                        }
                ])->where($condition);
    }
    
    /**
     * getParentUserList method
     *
     * @param Array|$postData The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getParentUser($groupId, $companyId) 
    {
        if ($groupId == 4) {
            $condition = ['is_deleted' => '0',
                            'group_id' => 7,
                            'company_id' => $companyId
                        ];
        } else if ($groupId == 7) {
            $condition = ['is_deleted' => '0',
                            'group_id' => 3,
                            'company_id' => $companyId
                        ];
        } else {
            $condition = [];
        }
        
        return $this->find('list', [
                    'keyField' => 'id',
                    'valueField' => function ($row) {
                            return $row['first_name'] . ' ' . $row['last_name'];
                        }
                ])->where($condition);
    }
    
    /**
     * getParentUserList method
     *
     * @param Array|$postData The configuration for the Table.
     * @return array([key]=>[value])
     */
    public function getParentUserForAssociate($companyId) 
    {
        $condition = ['is_deleted' => '0',
                        'group_id IN' => Configure::read('CompanyGroupIds'),
                        'company_id' => $companyId
                    ];
        
        return $this->find('list', [
                    'keyField' => 'id',
                    'valueField' => function ($row) {
                            return $row['first_name'] . ' ' . $row['last_name'];
                        }
                ])->where($condition);
    }
    
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

/**
 * ReviewsMgmt Model
 *
 * @property \App\Model\Table\SurveyMgmtTable|\Cake\ORM\Association\BelongsTo $SurveyMgmt
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 *
 * @method \App\Model\Entity\ReviewsMgmt get($primaryKey, $options = [])
 * @method \App\Model\Entity\ReviewsMgmt newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ReviewsMgmt[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ReviewsMgmt|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ReviewsMgmt patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ReviewsMgmt[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ReviewsMgmt findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ReviewsMgmtTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('reviews_mgmt');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('SurveyMgmt', [
            'foreignKey' => 'survey_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('recipient_first_name')
            ->requirePresence('recipient_first_name', 'create')
            ->notEmpty('recipient_first_name');

        $validator
            ->scalar('recipient_last_name')
            ->requirePresence('recipient_last_name', 'create')
            ->notEmpty('recipient_last_name');

        $validator
            ->scalar('recipient_email')
            ->requirePresence('recipient_email', 'create')
            ->notEmpty('recipient_email');

        $validator
            ->requirePresence('recipient_phone', 'create')
            ->notEmpty('recipient_phone');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['survey_id'], 'SurveyMgmt'));
        $rules->add($rules->existsIn(['user_id'], 'Users'));

        return $rules;
    }
    
    /**
    * Add Survey Review Method used to request Survey/Review
    *
    * @access public
    * @param array $data List of data to set at run-time
    * @return boolean 
    */
    public function addSurveyReview($data = array(), $customEmailTemplate = array())
    {
        if (!$data) {  
            // no data submitted
            return false;
        }
        
        if (isset($data['id'])) {
            $reviewsMgmt = $this->get($data['id']);
        } else {
            $reviewsMgmt = $this->newEntity();
        }
        if (empty($data['recipient_phone'])) {
            $data['recipient_phone'] = 'N/A';
        }
        if (empty($data['recipient_email'])) {
            $data['recipient_email'] = 'N/A';
        }
        
        $today = date('Y-m-d H:i:s');
        $reviewsMgmt = $this->patchEntity($reviewsMgmt, $data);
        $usersTable = TableRegistry::get('Users');
        $user = $usersTable->findById($data['sender_id'])->first();
        if ($user->group_id == 2) {
            if ($customEmailTemplate) {
                $reviewsMgmt->first_reminder_dt = date('Y-m-d', strtotime($today . " +" . $customEmailTemplate->first_reminder_days . " days"));
                $reviewsMgmt->second_reminder_dt = date('Y-m-d', strtotime($today . " +" . $customEmailTemplate->second_reminder_days . " days"));
            } else {
                $reviewsMgmt->first_reminder_dt = date('Y-m-d', strtotime($today . " +3 days"));
                $reviewsMgmt->second_reminder_dt = date('Y-m-d', strtotime($today . " +7 days"));
            }
        }
        $reviewsMgmt->send_type = implode(',', $data['send_type']);
        
        // save data in the table
        $result = $this->save($reviewsMgmt);
        
        if (!$result) { 
            // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
    * updateAutoReminder, Method to be used for update auto reminder date
    *
    * @access public
    * @param array $data List of data to set at run-time
    * @return boolean 
    */
    public function updateAutoReminder($data = array())
    {
        if (!$data) {  
            // no data submitted
            return false;
        }
        if (isset($data['id'])) {
            $reviewsMgmt = $this->get($data['id']);
        } else {
            return false;
        }
        
        $reviewsMgmt = $this->patchEntity($reviewsMgmt, $data);
        
        $activation_date = date_create_from_format('m-d-Y', $data['firstDate']);
        $reviewsMgmt->first_reminder_dt = date_format($activation_date, 'Y-m-d');

        $deactivation_date = date_create_from_format('m-d-Y', $data['secondDate']);
        $reviewsMgmt->second_reminder_dt = date_format($deactivation_date, 'Y-m-d');

        // save data in the table
        $result = $this->save($reviewsMgmt);
        
        if (!$result) { 
            // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * Function to get Review Details
     *
     * @param int $reviewId content of review id
     * @return void
     */
    public function getReviewDetails($reviewId = null) 
    {
        $result = $this->find('all', [
                    'fields' => ['id', 'recipient_first_name', 'recipient_last_name', 'recipient_email', 
                                'recipient_phone', 'send_type', 'survey_id', 'user_id', 'sender_id', 
                                'status', 'user_action', 'ratings', 'survey_done', 'is_deleted', 
                                'first_reminder_dt', 'second_reminder_dt', 'created'],
                    'conditions' => [
                        'id' => $reviewId,
                        'is_deleted' => 0
                    ]
                ])->first();
        return $result;
    }
    
    
    /**
     * Function to get Review Details on behalf of user
     *
     * @param int $userId content of userId
     * @return void
     */
    public function getReviewUserDetails($userId = null) 
    {
       
        $result = $this->find('all', [
                'conditions' => [
                    'sender_id' => $userId,
                    'survey_done' => 2,
                    'is_deleted' => 0
                ]])->toArray();
       
        return $result;
        
    }
    
    /**
     * getAllIncomleteReview, Function to get all incomplete Review Details of current login user
     *
     * @param int $userId, current login user id
     * 
     * @return array|object
     */
    public function getAllIncomleteReview($userId = null) 
    {
        $result = $this->find('all', [
            'order' => [
                'ReviewsMgmt.id' => 'desc',
            ],
            'conditions' => [
                'ReviewsMgmt.sender_id' => $userId,
                'ReviewsMgmt.recipient_email !=' => 'N/A',
                'ReviewsMgmt.survey_done IN' => Configure::read('survey_review_pending'),
                'ReviewsMgmt.is_deleted' => Configure::read('zero')
            ]
        ])->toArray();
       
        return $result;
    }
    
    /**
     * getAllSurveyReviewResponse, Function to get all Survey/Review response details that is given by requested user.
     *
     * @param int $userId, current login user id
     * @param int $surveyId
     * 
     * @return array|object
     */
    public function getAllSurveyReviewResponse($surveyId, $userId) 
    {
        return $this->find('all', [
                    'conditions' => [
                        'survey_id' => $surveyId,
                        'user_id' => $userId,
                        'is_deleted' => Configure::read('zero'),
                    ],
                ]);
    }
    
    /**
     * getCompletedReviewResponse, Function to get all Completed having star of current login user
     *
     * @param int $userId, current login user id
     * @param int $rating
     * 
     * @return integer
     */
    public function getCompletedReviewResponse($userId = null, $rating = null, $start = null, $end = null) 
    {
        if ($end == '') {
            $end = '1970-01-01';
        }
        return $this->find('all', [
                        'conditions' => [
                            'user_id IN' => [$userId],
                            'survey_done IN' => Configure::read('partially_completed'),
                            'is_deleted' => Configure::read('zero'),
                            'ratings' => $rating,
                            'created BETWEEN :start AND :end'
                        ]
                ])
                ->bind(':start', new \DateTime($end.' 00:00:00'), 'datetime')
                ->bind(':end', new \DateTime($start.' 23:59:59'), 'datetime')    
                ->count();
    }
    
    /**
     * getAllStarReview, Function to get all Completed having all star of current login user
     *
     * @param int $userId, current login user id
     * 
     * @return integer
     */
    public function getAllStarReview($userId = null) 
    {
        return $this->find('all', [
                        'conditions' => [
                            'user_id IN' => [$userId],
                            'survey_done IN' => Configure::read('survey_review_completed'),
                            'is_deleted' => Configure::read('zero'),
                            'ratings IN' => [1,2,3,4,5]
                        ]
                    ])->count();
    }
}

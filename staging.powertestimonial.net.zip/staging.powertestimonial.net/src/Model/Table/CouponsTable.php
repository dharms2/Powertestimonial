<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Coupons Model
 *
 * @method \App\Model\Entity\Coupon get($primaryKey, $options = [])
 * @method \App\Model\Entity\Coupon newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Coupon[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Coupon|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Coupon patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Coupon[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Coupon findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CouponsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('coupons');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('code')
            ->requirePresence('code', 'create')
            ->notEmpty('code');

        $validator
            ->scalar('discount_type')
            ->requirePresence('discount_type', 'create')
            ->notEmpty('discount_type');

        $validator
            ->scalar('discount')
            ->requirePresence('discount', 'create')
            ->notEmpty('discount');

        $validator
            ->date('valid_from')
            ->requirePresence('valid_from', 'create')
            ->notEmpty('valid_from');

        $validator
            ->date('valid_to')
            ->requirePresence('valid_to', 'create')
            ->notEmpty('valid_to');

        $validator
            ->scalar('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }
    
    /**
     * addCoupon Method used to add/edit new coupon at run-time
     *
     * @access public
     * @param array $data List of data to set at run-time
     * @return boolean 
     */
    public function addCoupon($data = array()) 
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['id'])) {
            $coupon = $this->get($data['id']);
        } else {
            $coupon = $this->newEntity();
        }
        $coupon = $this->patchEntity($coupon, $data);
        if ($data['discount_type'] == 'per') {
            $coupon->discount = $data['discount'].'%';
        } else if ($data['discount_type'] == 'amt') {
            $coupon->discount = '$'.$data['discount'].'.00';
        }
        
        $valid_from = date_create_from_format('m-d-Y', $data['valid_from']);
        $coupon->valid_from = date_format($valid_from, 'Y-m-d');

        $valid_to = date_create_from_format('m-d-Y', $data['valid_to']);
        $coupon->valid_to = date_format($valid_to, 'Y-m-d');
        
        // save data in the table
        $result = $this->save($coupon);

        if (!$result) { // problem saving the data
            return false;
        }
        return $result;
    }
    
    public function getCouponData()
    {
        return $this->find('all', [
            'conditions' => [
                
            ],
            'order' => [
                'created' => 'desc'
            ]
        ])->toArray();
    }
    
    /**
     * checkUniqueCode method
     *
     * @param array|$data The configuration for the Table.
     * @return string(count)
     */
    public function checkUniqueCode($data = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'code' => $data['code'],
                    ]
                ])->count();
        
        return $result;
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Google Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\PlacesTable|\Cake\ORM\Association\BelongsTo $Places
 *
 * @method \App\Model\Entity\Google get($primaryKey, $options = [])
 * @method \App\Model\Entity\Google newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Google[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Google|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Google patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Google[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Google findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class GoogleTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('google');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        return $rules;
    }
    
    /**
     * Function to get Details By User Id
     *
     * @param int $userId, get User id content
     * @return void
     */
    public function getGoogleDataByUserId($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]])->first();
        return $result;
    }
    
    /**
    * Add Google Method used to add default Google data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addGoogle($data = array())
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['user_id'])) {
            $google = $this->newEntity();
        } else {
            $google = $this->get($data['user_id'], [ 'contain' => [] ]);
        }
        
        $google = $this->patchEntity($google, $data);

        $google->user_id = $data['user_id'];
        // save data in the table
        $result = $this->save($google);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    /**
     * Function to get Google Data By Place Id
     *
     * @param int $userId array of User id
     * @param string $placeId, content of Google place id
     * 
     * @return void
     */
    public function getGoogleDataByPlaceId($userId = null, $placeId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'user_id' => $userId,
                        'place_id' => $placeId
                    ]
                ])->first();
        return $result;
    }
}

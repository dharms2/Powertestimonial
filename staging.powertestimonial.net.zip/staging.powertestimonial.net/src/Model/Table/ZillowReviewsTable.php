<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ZillowReviews Model
 *
 * @property \App\Model\Table\ReviewsTable|\Cake\ORM\Association\BelongsTo $Reviews
 *
 * @method \App\Model\Entity\ZillowReview get($primaryKey, $options = [])
 * @method \App\Model\Entity\ZillowReview newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ZillowReview[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ZillowReview|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ZillowReview patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ZillowReview[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ZillowReview findOrCreate($search, callable $callback = null, $options = [])
 */
class ZillowReviewsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('zillow_reviews');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        return $rules;
    }
    
    /**
     * Function to get Zillow Review Details
     *
     * @param int $userId id of current user
     * @return void
     */
    public function getZillowReviewDetails($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId, 'deleted' => 0]]);
        return $result;
    }
    
    /**
     * Function to get All Zillow Review Data
     *
     * @param int $userId, id of current user
     * @return void
     */
    public function getAllZillowReviewData($userId = null) 
    {
        $result = $this->find('all', ['conditions' => ['user_id' => $userId]]);
        return $result;
    }
    
    /**
     * Function to update Zillow Review
     *
     * @param int $reviewId, review_id of current review
     * @param int $userId, id of current user
     * @return void
     */
    public function updateZillowReview($reviewId = null, $userId = null) 
    {
        $result = $this->query()
                            ->update()
                            ->set(['deleted' => 0])
                            ->where(['review_id' => $reviewId, 'user_id' => $userId])
                            ->execute();
        return $result;
    }
}

<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;

/**
 * SurveyTemplatesQuestion Model
 *
 * @property \App\Model\Table\SurveyTemplatesTable|\Cake\ORM\Association\BelongsTo $SurveyTemplates
 *
 * @method \App\Model\Entity\SurveyTemplatesQuestion get($primaryKey, $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SurveyTemplatesQuestion findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SurveyTemplatesQuestionTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('survey_templates_question');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('SurveyTemplates', [
            'foreignKey' => 'survey_templates_id',
            'joinType' => 'INNER'
        ]);
        
        $this->hasMany('SurveyTemplatesQuestionLogic', [
            'foreignKey' => 'survey_template_question_id',
        ]);
        
        $this->belongsTo('SurveyQuestion', [
            'foreignKey' => 'question',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->integer('star')
            ->allowEmpty('star');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->existsIn(['survey_templates_id'], 'SurveyTemplates'));
        return $rules;
    }
    
    /**
     * Function to get Template Question Details
     *
     * @param int $templateId, Template id content
     * @return void
     */
    public function getTemplateQuestionDetails($templateId = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'survey_templates_id' => $templateId
                    ]
                ])->first();
        
        return $result;
    }
    
    /**
     * Function to get Template Question Details
     *
     * @param int $templateId, Template id content
     * @param int $type, Review/Suevey Type content
     * @param int $star, star content
     * @return void
     */
    public function getSurveyTemplatesQuestions($templateId = null, $type = null, $star = null) 
    {
        $result = $this->find('all', [
                    'conditions' => [
                        'survey_templates_id' => $templateId,
                        'type' => $type,
                        'star' => $star,
                    ],
                    'contain' => [
                        'SurveyTemplatesQuestionLogic', 
                        'SurveyQuestion'
                    ]
                ]);
        return $result;
    }
    
    /**
     * Function to get Template All Question Details
     *
     * @param int $templateId, Template id content
     * @return void
     */
    public function getTemplateQuestionAllDetails($templateId = null) 
    {
        $result = $this->find('all', [
                'conditions' => [
                    'survey_templates_id' => $templateId,
                    'type' => 2
                    ]
                ])->toArray();
        
        return $result;
    }
 
    
    
    /**
    * Add Survey Template Question Method used to add default Survey Template Question data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addSurveyTemplateQuestion($data = array(),$questionId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['template_id'])) {
            $surveyTemplatesQuestion = $this->newEntity();
        } else {
            $surveyTemplatesQuestion = $this->get($data['template_id'], [ 'contain' => [] ]);
        }
        
        $surveyTemplatesQuestion = $this->patchEntity($surveyTemplatesQuestion, $data);
    
        $surveyTemplatesQuestion->survey_templates_id = $data['template_id'];
        $surveyTemplatesQuestion->type = Configure::read('templateSurveyType');
        $surveyTemplatesQuestion->question = $questionId;
        $surveyTemplatesQuestion->star = 0;    
        
        // save data in the table
        $result = $this->save($surveyTemplatesQuestion);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    
     /**
    * Add Review Template Question Method used to add default Review Template Question data for new registered user
    *
    * @access public
    * @param Array $data, new registered user ID
    * @return void
    */
    public function addReviewDefaultTemplateQuestion($data = array(),$questionId = null)
    {
        if (!$data) {  // no data submitted
            return false;
        }

        if (isset($data['template_id'])) {
            $surveyTemplatesQuestion = $this->newEntity();
        } else {
            $surveyTemplatesQuestion = $this->get($data['template_id'], [ 'contain' => [] ]);
        }
        
        $surveyTemplatesQuestion = $this->patchEntity($surveyTemplatesQuestion, $data);
    
        $surveyTemplatesQuestion->survey_templates_id = $data['template_id'];
        $surveyTemplatesQuestion->type = Configure::read('templateReviewType');
        $surveyTemplatesQuestion->star = '-1';
        $surveyTemplatesQuestion->question = $questionId;
        $surveyTemplatesQuestion->fouroption = 1;
        
        // save data in the table
        $result = $this->save($surveyTemplatesQuestion);
        
        if (!$result) { // problem saving the data
            return false;
        }
        return $result; 
    }
    
    public function findQuestionDetailsById($survey_templates_question, $templateId)
    {
        if (!$survey_templates_question) {  // no data submitted
            return false;
        }
        foreach ($survey_templates_question as $templateQuestion) {
            $surveyTemplatesQuestionTable = TableRegistry::get('SurveyTemplatesQuestion');
            if ($templateQuestion->star== 5) {
                $surveyQuestion[5][] = $templateQuestion->question;
            }
            if ($templateQuestion->star == 4) {
                if($templateQuestion->fouroption== 2) {
                    $surveyQuestion[4][] = $dataVal->question;
                } else {
                    $surveyQuestion[4] = $surveyTemplatesQuestionTable->find('all', [
                                                'conditions' => [
                                                    'survey_templates_id' => $templateId,
                                                    'type' => $templateQuestion->type,
                                                    'star' => $templateQuestion->star,
                                                ],
                                                'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                            ])->toArray();
                }
            }
            if($templateQuestion->star== 3){
                $surveyQuestion[3] = $surveyTemplatesQuestionTable->find('all', [
                                            'conditions' => [
                                                'survey_templates_id' => $templateId,
                                                'type' => $templateQuestion->type,
                                                'star' => $templateQuestion->star,
                                            ],
                                            'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                        ])->toArray();
            } 
            if($templateQuestion->star== 2){
                $surveyQuestion[2] = $surveyTemplatesQuestionTable->find('all', [
                                            'conditions' => [
                                                'survey_templates_id' => $templateId,
                                                'type' => $templateQuestion->type,
                                                'star' => $templateQuestion->star,
                                            ],
                                            'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                        ])->toArray();
            } 
            if($templateQuestion->star== 1){
                $surveyQuestion[1] = $surveyTemplatesQuestionTable->find('all', [
                                            'conditions' => [
                                                'survey_templates_id' => $templateId,
                                                'type' => $templateQuestion->type,
                                                'star' => $templateQuestion->star,
                                            ],
                                            'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                        ])->toArray();
            }
            //0 for survey
            if($templateQuestion->star== 0){
                $surveyQuestion[0] = $surveyTemplatesQuestionTable->find('all', [
                                            'conditions' => [
                                                'survey_templates_id' => $templateId,
                                                'type' => $templateQuestion->type,
                                                'star' => $templateQuestion->star,
                                            ],
                                            'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                        ])->toArray();
            }
            if ($templateQuestion->star== -1) {
                $surveyQuestion[-1] = $surveyTemplatesQuestionTable->find('all', [
                                            'conditions' => [
                                                'survey_templates_id' => $templateId,
                                                'type' => $templateQuestion->type,
                                                'star' => $templateQuestion->star,
                                            ],
                                            'contain' => [ 'SurveyTemplatesQuestionLogic', 'SurveyQuestion']
                                        ])->toArray();
            }
        }
        return $surveyQuestion;
    }
}

<?php
namespace App\View\Helper;

use Cake\View\Helper;
use Cake\View\View;

/**
 * Users helper
 */
class UsersHelper extends Helper
{

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];
    
    /**
     * Star Rating.
     *
     * @var array
     */    
    public function starRating($rate)
    {
        $html = '';

            switch ($rate) {
                case 1:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 4:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 5:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i>';
                    break;
                case 4.9:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i>';
                    break;
                case 4.8:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.7:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.6:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.5:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.4:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.3:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i>';
                    break;
                case 4.2:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 4.1:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.9:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.8:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.7:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.6:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.5:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.4:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.3:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.2:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 3.1:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.9:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.8:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.7:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.6:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.5:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.4:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.3:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.2:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 2.1:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.9:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.8:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.7:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.6:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.5:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.4:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.3:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.2:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 1.1:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.9:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.8:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.7:
                    $html .= '<i class="fa fa-star fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.6:
                    $html .= '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.5:
                    $html .= '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.4:
                    $html .= '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.3:
                    $html .= '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                case 0.2:
                    $html .= '<i class="fa fa-star-half-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
                default:
                    $html .= '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i> '
                            . '<i class="fa fa-star-o fa-2x star-color"></i>';
                    break;
            }
        return $html;
    }
    
    public function reviewIcon($source_img) 
    {
        switch ($source_img) {
            case "img/Google.png":
                $icon = 'Google';
                break;
            case "img/zillow.png":
                $icon = 'Zillow';
                break;
            case "img/yelp-icon.png":
                $icon = 'Yelp';
                break;
            case "img/facebook-icon.png":
                $icon = 'Facebook';
                break;
            default:
                break;
        }
        
        return $icon;
    }
    
    public function ratingValue($rating) 
    {
        switch ($rating) {
            case 5:
                $value = $rating;
                break;
            case 4:
                $value = $rating;
                break;
            case 3:
                $value = $rating;
                break;
            case 2:
                $value = $rating;
                break;
            case 1:
                $value = $rating;
                break;
            case 0:
                $value = $rating;
                break;
            default:
                break;
        }
        
        return $value;
    }
    
    public function apiConfigToAssociate($configVal) 
    {
        switch ($configVal) {
            case 1:
                $value = 'Allow';
                break;
            default:
                $value = 'Not Allow';
                break;
        }
        
        return $value;
    }
    
    public function status($status) 
    {
        switch ($status) {
            case 1:
                $value = 'Active';
                break;
            default:
                $value = 'Inactive';
                break;
        }
        
        return $value;
    }

}

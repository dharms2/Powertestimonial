<?php
namespace App\View\Helper;

use Cake\View\Helper;
use Cake\View\View;

/**
 * SurveyTemplates helper
 */
class SurveyTemplatesHelper extends Helper
{

    /**
     * Default configuration.
     *
     * @var array
     */
    protected $_defaultConfig = [];
   
    /**
     * showQuestionsForStar() method for showing html on the basis of star(3,2,1,-1).
     *
     * @var array
     */
    public function showQuestionsForStar($questionDetails, $starVal, $templateId)
    {
        $html = '';
        $html .= '<ul class="qus_list" style="padding: 0">';
            foreach ($questionDetails as $key => $surveyQuestion) {
                $questCnt = 1;
                
                if ($key == $starVal) {    
                    $totalQus = count($surveyQuestion);
                    foreach ($surveyQuestion as $dataQuestion) {
                        $html .= '<li class="myLi" value="'.$dataQuestion->id.'" style="display: unset">';
                        $html .= '<div class="row">';
                        $html .= '<div class="col-md-11 col-sm-10">';
                        $html .= '<div class="form-group">';
                        $html .= '<h6 class="card-title">'. $dataQuestion->questions;
                        $html .= '</h6>';
                        $html .= '<input type="hidden" name="select_qusetion_name['.$starVal.']" class="form-control">';
                        $html .= '<input type="hidden" name="select_qusetion_id['.$starVal.'][]" class="form-control" value="'.$dataQuestion->id.'">';
                        $html .= '<div class="row answers">';
                        if ($dataQuestion->ans_types == 3 || $dataQuestion->ans_types == 4 || $dataQuestion->ans_types == 5) {
                            if ($dataQuestion->ans_types == 3) {
                                $html .= '<div class="col-md-12">';
                                $html .= '<textarea class="form-control text-mute';
                                $html .= ' tempalteQuestionAnswerarea" disabled>';
                                $html .= '</textarea>';
                                $html .= '</div>';
                            } else if ($dataQuestion->ans_types == 4) {
                                $starValues = ['1','2','3','4','5'];
                                foreach ($starValues as $key => $val) {
                                    if ($val == 1) {
                                        $html .= '<div class="col-md-8 star-color">';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '</div>';
                                    } else if ($val == 2) {
                                        $html .= '<div class="col-md-8 star-color">';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '</div>';
                                    } else if ($val == 3) {
                                        $html .= '<div class="col-md-8 star-color">';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '</div>';
                                    } else if ($val == 4) {
                                        $html .= '<div class="col-md-8 star-color">';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '</div>';
                                    } else if ($val == 5) {
                                        $html .= '<div class="col-md-8 star-color">';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '<i class="fa fa-star-o fa-2x" aria-hidden="true"></i>';
                                        $html .= '</div>';
                                    }
                                    $html .= '<div class="col-md-2 float-right logic_btn">';
                                    $html .= '<div class="float-right">';
                                    $html .= '<a class="btn btn-outline-primary btn-sm toggle_logic_btn" style="padding: 2px 5px;line-height: normal" onclick="toggleLogic('.$starVal.', this);">';
                                    $html .= 'Question Logic</a>';
                                    $html .= '</div>';
                                    $html .= '</div>';
                                }
                            } else if ($dataQuestion->ans_types == 5) {
                                $html .= '<div class="col-md-3">';
                                $html .= '<textarea type="text" class="form-control" disabled>Address</textarea>';
                                $html .= '</div><div class="col-md-3">';
                                $html .= '<input type="text" class="form-control" value="City" disabled>';
                                $html .= '</div><div class="col-md-3">';
                                $html .= '<input type="text" class="form-control" value="State" disabled>';
                                $html .= '</div><div class="col-md-3">';
                                $html .= '<input type="text" class="form-control" value="Zipcode" disabled>';
                                $html .= '</div>';
                            }
                        } else {
                            $ansCount = 0;
                            $choice = explode('|', $dataQuestion->ans_choices);
                            while ($ansCount < count($choice)) {
                                if ($dataQuestion->ans_types == 1) {
                                    $html .= '<div class="col-md-10">';
                                    $html .= '<span class="radio-button-display"></span>';
                                    $html .= '<label for="test1" class="tempalteQuestionAnswerLabel">';
                                    $html .= $choice[$ansCount];
                                    $html .= '</label></div>';
                                    $html .= '<div class="col-md-2 float-right logic_btn">';
                                    $html .= '<div class="float-right">';
                                    $html .= '<a class="btn btn-outline-primary btn-sm toggle_logic_btn" style="padding: 2px 5px;line-height: normal" onclick="toggleLogic('.$starVal.', this);">';
                                    $html .= 'Question Logic</a>';
                                    $html .= '</div>';
                                    $html .= '</div>';
                                } else if ($dataQuestion->ans_types == 2) {
                                    $html .= '<div class="col-md-6">';
                                    $html .= '<span class="checkbox-button-display "></span>';
                                    $html .= '<label for="test1" class="tempalteQuestionAnswerLabel">';
                                    $html .= $choice[$ansCount];
                                    $html .= '</label></div>';
                                }
                                $ansCount++;
                            }
                        }
                        $html .= '</div>';
                        $html .= '</div>';
                        $html .= '</div>';
                        $html .= '<div class="col-md-1 col-sm-2">';
                        $html .= '<a href="#" class="btn btn-danger float-right remove_field" temp_id="'.$templateId.'" que_id="'.$dataQuestion->id.'" star_val="'.$starVal.'">';
                        $html .= '<i class="fa fa-trash"></i>';
                        $html .= '</a>';
                        $html .= '</div>';
                        $html .= '<div class="col-md-12 col-sm-12">';
                        $html .= '<hr style="margin-top: 0px">';
                        $html .= '</div>';
                        $html .= '</div>';
                        $html .= '</li>';
                        $questCnt++;
                    }               
                }
            }
            $html .= '</ul>';
            
        return $html;
    } 
    
    /**
     * showChannelForFiveStar() method for showing html on the basis of star(5,4).
     *
     * @var array
     */
    public function showReviewChannelForStar($apiConfigurations, $keyVals, $starVal)
    {
        $html = '';
        $cutomClassF = $cutomClassY = $cutomClassZ = $cutomClassG = $cutomClassA = $cutomClassBBB = $cutomClassRealtor = '';
        if (empty($apiConfigurations->facebook_page_name)) { 
            $cutomClassF = 'custom-disable"'; 
        } 
        if (empty($apiConfigurations->yelp_business_id)) { 
            $cutomClassY = 'custom-disable';
        }
        if (empty($apiConfigurations->zillow_screen_name)) { 
            $cutomClassZ = 'custom-disable';
        }
        if (empty($apiConfigurations->google_place_id)) { 
            $cutomClassG = 'custom-disable';
        }
        if (empty($apiConfigurations->angies_business_id)) { 
            $cutomClassA = 'custom-disable';
        }
        if (empty($apiConfigurations->bbb_business_name)) { 
            $cutomClassBBB = 'custom-disable';
        }
        if (empty($apiConfigurations->realtor_business_name)) { 
            $cutomClassRealtor = 'custom-disable';
        }
        
        
        $checked1 = $checked2 = $checked3 = $checked4 = $checked5 = $checked6 = $checked7 = '';
        if (!empty($keyVals)) {
            foreach ($keyVals as $keyVal) {
                if (!is_object($keyVal)) {
                    if ($keyVal == 1) { 
                        $checked1 = 'checked';
                    } else if ($keyVal == 2) { 
                        $checked2 = 'checked';
                    } else if ($keyVal == 3) {
                        $checked3 = 'checked';
                    } else if ($keyVal == 4) { 
                        $checked4 = 'checked';
                    } else if ($keyVal == 5) { 
                        $checked5 = 'checked';
                    } else if ($keyVal == 6) { 
                        $checked6 = 'checked';
                    } else if ($keyVal == 7) { 
                        $checked7 = 'checked';
                    } 
                }
            }
        }

        $html .= '<div class="col text-center '. $cutomClassF .'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="1" id="facebook'.$starVal.'" type="checkbox" '. $checked1 .'>';                
        $html .= '<label for="facebook'. $starVal .'"></label>';
        $html .= '<div class="social-box-templates facebook">';
        $html .= '<i class="fa fa-facebook"></i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '. $cutomClassY .'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['. $starVal .'][]" value="2" id="yelp'.$starVal.'" type="checkbox" '.$checked2.'>'; 
        $html .= '<label for="yelp'. $starVal .'"></label>';
        $html .= '<div class="social-box-templates yelp">';
        $html .= '<i class="fa">';
        $html .= '<img src="/img/yelp.png">';
        $html .= '</i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '. $cutomClassZ .'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="3" id="zillow'.$starVal.'" type="checkbox" '.$checked3.'>'; 
        $html .= '<label for="zillow'.$starVal.'"></label>';
        $html .= '<div class="social-box-templates zillow">';
        $html .= '<i class="fa">';
        $html .= '<img src="/img/zillow_icon.png" height="60">';
        $html .= '</i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '.$cutomClassG.'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="4" id="google'.$starVal.'" type="checkbox" '.$checked4.'>'; 
        $html .= '<label for="google'.$starVal.'"></label>';
        $html .= '<div class="social-box-templates google-plus">';
        $html .= '<i class="fa fa-google"></i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '.$cutomClassA.'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="5" id="angies'.$starVal.'" type="checkbox" '.$checked5.'>'; 
        $html .= '<label for="angies'.$starVal.'"></label>';
        $html .= '<div class="social-box-templates angies">';
        $html .= '<i class="fa">';
        $html .= '<img src="/img/angies-logo.png" height="60">';
        $html .= '</i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '.$cutomClassBBB.'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="6" id="bbb'.$starVal.'" type="checkbox" '.$checked6.'>'; 
        $html .= '<label for="bbb'.$starVal.'"></label>';
        $html .= '<div class="social-box-templates bbb-business">';
        $html .= '<i class="fa">';
        $html .= '<img src="/img/logo.svg" height="55">';
        $html .= '</i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="col text-center '.$cutomClassRealtor.'">';
        $html .= '<label class="width-100">';
        $html .= '<input class="custom-check" name="select_qusetion_id['.$starVal.'][]" value="7" id="realtor'.$starVal.'" type="checkbox" '.$checked7.'>'; 
        $html .= '<label for="realtor'.$starVal.'"></label>';
        $html .= '<div class="social-box-templates realtor">';
        $html .= '<i class="fa">';
        $html .= '<img src="/img/realtor.png" height="60">';
        $html .= '</i>';
        $html .= '</div>';
        $html .= '</label>';
        $html .= '</div>';
        
        return $html;
    }
       
}

<?PHP
return [
    /**
     * Configure basic information about the application.
     *
     * - namespace - The namespace to find app classes under.
     * - encoding - The encoding used for HTML + database connections.
     * - base - The base directory the app resides in. If false this
     *   will be auto detected.
     * - dir - Name of app directory.
     * - webroot - The webroot directory.
     * - wwwRoot - The file path to webroot.
     * - baseUrl - To configure CakePHP to *not* use mod_rewrite and to
     *   use CakePHP pretty URLs, remove these .htaccess
     *   files:
     *      /.htaccess
     *      /webroot/.htaccess
     *   And uncomment the baseUrl key below.
     * - fullBaseUrl - A base URL to use for absolute links.
     * - imageBaseUrl - Web path to the public images directory under webroot.
     * - cssBaseUrl - Web path to the public css directory under webroot.
     * - jsBaseUrl - Web path to the public js directory under webroot.
     * - paths - Configure paths for non class based resources. Supports the
     *   `plugins`, `templates`, `locales` subkeys, which allow the definition of
     *   paths for plugins, view templates and locale files respectively.
     */
    'App' => [
        'namespace' => 'App',
        'encoding' => 'UTF-8',
        'base' => false,
        'dir' => 'src',
        'webroot' => 'webroot',
        'wwwRoot' => WWW_ROOT,
        'fullBaseUrl' => false,
        'imageBaseUrl' => 'img/',
        'documentBaseUrl' => 'uploads/',
        'cssBaseUrl' => 'css/',
        'jsBaseUrl' => 'js/',
        'paths' => [
            'plugins' => [ROOT . DS . 'plugins' . DS],
            'templates' => [APP . 'Template' . DS],
            'locales' => [APP . 'Locale' . DS],
        ],
    ],

    /**
     * Apply timestamps with the last modified time to static assets (js, css, images).
     * Will append a querystring parameter containing the time the file was modified.
     * This is useful for busting browser caches.
     *
     * Set to true to apply timestamps when debug is true. Set to 'force' to always
     * enable timestamping regardless of debug value.
     */
    'Asset' => [
        // 'timestamp' => true,
    ],

    /**
     * Configure the cache adapters.
     */
    'Cache' => [
        'default' => [
            'className' => 'File',
            'path' => CACHE,
            'duration' => '+180 minutes',
        ],
        'rctoken' => [
            'className' => 'File',
            'path' => CACHE . 'ringcentral/',
            'duration' => '+1 minutes',
        ],
        'rc_phone_logs' => [
            'className' => 'File',
            'path' => CACHE . 'ringcentral/',
            'duration' => '+3 minutes',
        ],
        'rc_sms_logs' => [
            'className' => 'File',
            'path' => CACHE . 'ringcentral/',
            'duration' => '+10 seconds',
        ],
        'rc_phone_recorded' => [
            'className' => 'File',
            'path' => CACHE . 'ringcentral/',
            'duration' => '+10000 minutes',
        ],

        /**
         * Configure the cache used for general framework caching. Path information,
         * object listings, and translation cache files are stored with this
         * configuration.
         */
        '_cake_core_' => [
            'className' => 'File',
            'prefix' => 'myapp_cake_core_',
            'path' => CACHE . 'persistent/',
            'serialize' => true,
            'duration' => '+180 minutes',
            'mask' => 0775
        ],

        /**
         * Configure the cache for model and datasource caches. This cache
         * configuration is used to store schema descriptions, and table listings
         * in connections.
         */
        '_cake_model_' => [
            'className' => 'File',
            'prefix' => 'myapp_cake_model_',
            'path' => CACHE . 'models/',
            'serialize' => true,
            'duration' => '+180 minutes',
            'mask' => 0775
        ],

        'very_short' => [
            'className' => 'File',
            'duration' => '+5 minutes',
            'path' => CACHE,
            'prefix' => 'cake_very_short_'
        ],
    ],

    /**
     * Configure the Error and Exception handlers used by your application.
     *
     * By default errors are displayed using Debugger, when debug is true and logged
     * by Cake\Log\Log when debug is false.
     *
     * In CLI environments exceptions will be printed to stderr with a backtrace.
     * In web environments an HTML page will be displayed for the exception.
     * With debug true, framework errors like Missing Controller will be displayed.
     * When debug is false, framework errors will be coerced into generic HTTP errors.
     *
     * Options:
     *
     * - `errorLevel` - int - The level of errors you are interested in capturing.
     * - `trace` - boolean - Whether or not backtraces should be included in
     *   logged errors/exceptions.
     * - `log` - boolean - Whether or not you want exceptions logged.
     * - `exceptionRenderer` - string - The class responsible for rendering
     *   uncaught exceptions.  If you choose a custom class you should place
     *   the file for that class in src/Error. This class needs to implement a
     *   render method.
     * - `skipLog` - array - List of exceptions to skip for logging. Exceptions that
     *   extend one of the listed exceptions will also be skipped for logging.
     *   E.g.:
     *   `'skipLog' => ['Cake\Network\Exception\NotFoundException', 'Cake\Network\Exception\UnauthorizedException']`
     */
    'Error' => [
        'errorLevel' => E_ERROR,
        'exceptionRenderer' => 'Cake\Error\ExceptionRenderer',
        'skipLog' => [],
        'log' => true,
        'trace' => true,
    ],

    /**
     * Configures logging options
     */
    'Log' => [
        'debug' => [
            'className' => 'Cake\Log\Engine\FileLog',
            'path' => LOGS,
            'file' => 'debug',
            'levels' => ['notice', 'info', 'debug'],
        ],
        'error' => [
            'className' => 'Cake\Log\Engine\FileLog',
            'path' => LOGS,
            'file' => 'error',
            'levels' => ['warning', 'error', 'critical', 'alert', 'emergency'],
        ],
    ],

    /**
     * Session configuration.
     *
     * Contains an array of settings to use for session configuration. The
     * `defaults` key is used to define a default preset to use for sessions, any
     * settings declared here will override the settings of the default config.
     *
     * ## Options
     *
     * - `cookie` - The name of the cookie to use. Defaults to 'CAKEPHP'.
     * - `cookiePath` - The url path for which session cookie is set. Maps to the
     *   `session.cookie_path` php.ini config. Defaults to base path of app.
     * - `timeout` - The time in minutes the session should be valid for.
     *    Pass 0 to disable checking timeout.
     * - `defaults` - The default configuration set to use as a basis for your session.
     *    There are four built-in options: php, cake, cache, database.
     * - `handler` - Can be used to enable a custom session handler. Expects an
     *    array with at least the `engine` key, being the name of the Session engine
     *    class to use for managing the session. CakePHP bundles the `CacheSession`
     *    and `DatabaseSession` engines.
     * - `ini` - An associative array of additional ini values to set.
     *
     * The built-in `defaults` options are:
     *
     * - 'php' - Uses settings defined in your php.ini.
     * - 'cake' - Saves session files in CakePHP's /tmp directory.
     * - 'database' - Uses CakePHP's database sessions.
     * - 'cache' - Use the Cache class to save sessions.
     *
     * To define a custom session handler, save it at src/Network/Session/<name>.php.
     * Make sure the class implements PHP's `SessionHandlerInterface` and set
     * Session.handler to <name>
     *
     * To use database sessions, load the SQL file located at config/Schema/sessions.sql
     */
    'Session' => [
        'defaults' => 'database',
        'timeout' => 120, // The session will timeout after 30 minutes of inactivity
        'cookieTimeout' => 1440, // The session cookie will live for at most 24 hours, this does not effect session timeouts
        'checkAgent' => false,
        'autoRegenerate' => true
    ],
    
    // Ringcentral app and secret Api key
    'Ringcentral' => [
        'sandbox_server' => 'https://platform.devtest.ringcentral.com', // sandbox
        'sandbox_appKey' => 'N8qGeeGlRUOx1QirO4MTZw',
        'sandbox_appSecret' => 'sujen0HsSa6bdQNpiIMOAAyHXLZKBYQQSDCNQ4x_RO1A',
        'sandbox_media_server' => 'https://media.devtest.ringcentral.com:443',
        'sandbox_admin_username' => '16505496136',
        'sandbox_admin_extension' => '101',
        'sandbox_admin_password' => 'CFYSoftwarePhone2016',
        
        'production_server' => 'https://platform.ringcentral.com', // production 
        'production_appKey' => '',
        'production_appSecret' => '',
        'production_media_server' => 'https://media.ringcentral.com:443',
        'production_admin_username' => '16505496136',
        'production_admin_extension' => '101',
        'production_admin_password' => 'CFYSoftwarePhone2016',
        
        'mode' => 'sandbox', // sandbox | production
        'version' => '/restapi/v1.0'
    ],
    
    // Demo Api key for SMS url shortner
    // Get API key from : http://code.google.com/apis/console/
    'UrlShortener' => [
        'apiKey' => 'AIzaSyDVuoZGyjr1mgV89SF19W3zPFxdZIyERM8'
    ],
	
	// Image upload directory
	
	'directory' => [
		'floor_plan' 			=> 'img' . DS. 'uploads' . DS. 'troubleshooting',
		'troubleshooting' 		=> 'img' . DS. 'uploads' . DS. 'troubleshooting',
		'workorder_image' 		=> 'img' . DS. 'uploads' . DS,
		'line_item_image'		=> 'img' . DS. 'uploads' . DS. 'line-items' . DS,
		'assigned_user_image'           => 'img' . DS. 'uploads' . DS. 'tasks-assigned-images' . DS,
		'comment_image'			=> 'img' . DS. 'comments' . DS,
		'contract_file'			=> 'uploads' . DS . 'contracts' . DS,
		'insurance_file'		=> 'uploads' . DS . 'property-insurance' . DS
	]
];
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Nov 21, 2017
 */

ALTER TABLE `survey_templates_question` CHANGE `star` `star` INT(1) NOT NULL COMMENT '-1=>Default,0=>survey,4=>4 star,3=>3 star,2=>2 star,1=>1 star';
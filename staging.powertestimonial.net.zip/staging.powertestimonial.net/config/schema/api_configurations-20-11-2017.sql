/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 20, 2017
 */

ALTER TABLE `api_configurations`
	CHANGE COLUMN `facebook_details` `facebook_page_name` VARCHAR(500) NULL AFTER `yelp_business_id`;
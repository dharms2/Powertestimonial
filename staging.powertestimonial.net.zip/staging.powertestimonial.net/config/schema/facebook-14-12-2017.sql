/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Dec 14, 2017
 */

ALTER TABLE `facebook`
	DROP COLUMN `avg_rating`,
	DROP COLUMN `rating_count`,
	DROP COLUMN `phone`,
	DROP COLUMN `address`;
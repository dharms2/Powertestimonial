/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Jan 10, 2018
 */

ALTER TABLE `users`
	CHANGE COLUMN `email` `email` VARCHAR(50) NOT NULL AFTER `password`,
	CHANGE COLUMN `additional_email` `additional_email` VARCHAR(50) NULL AFTER `email`;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 23, 2017
 */

ALTER TABLE `reviews_mgmt`
	CHANGE COLUMN `user_action` `user_action` INT(1) NULL DEFAULT NULL COMMENT '1=Google Review, 2=Facebook Review, 3=Yelp Review, 4=PowerTest Review, 5=Survey, 6=Realtor Review, 7=Zillow Review, ' AFTER `status`;
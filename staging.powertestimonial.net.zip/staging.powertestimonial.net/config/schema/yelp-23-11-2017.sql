/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 23, 2017
 */

ALTER TABLE `yelp`
	ADD COLUMN `request_url` VARCHAR(500) NULL DEFAULT NULL AFTER `display_address`;
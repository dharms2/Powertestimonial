/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Dec 13, 2017
 */

ALTER TABLE `users`
	CHANGE COLUMN `phone` `phone` VARCHAR(16) NULL DEFAULT NULL AFTER `additional_email`,
	CHANGE COLUMN `business_phone` `business_phone` VARCHAR(16) NULL DEFAULT NULL AFTER `business_name`;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  meenah
 * Created: Jan 2, 2018
 */

ALTER TABLE `reviews_mgmt` ADD `is_deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '0=>not delete, 1=> delete' AFTER `survey_done`;
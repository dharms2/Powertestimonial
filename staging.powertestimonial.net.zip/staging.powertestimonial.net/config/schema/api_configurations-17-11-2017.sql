/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 17, 2017
 */

ALTER TABLE `api_configurations`
	CHANGE COLUMN `zillow_details` `default_zillow_Id` TEXT NULL AFTER `yelp_include_in_survey`,
	CHANGE COLUMN `zillow_include_in_survey` `zillow_include_in_survey` TINYINT(1) NOT NULL DEFAULT '1' AFTER `zillow_screen_name`;
	
ALTER TABLE `api_configurations`
	CHANGE COLUMN `yelp_details` `yelp_business_id` VARCHAR(500) NULL AFTER `facebook_include_in_survey`;
	
ALTER TABLE `api_configurations`
	ALTER `user_id` DROP DEFAULT,
	ALTER `yelp_business_id` DROP DEFAULT,
	ALTER `zillow_screen_name` DROP DEFAULT;
ALTER TABLE `api_configurations`
	CHANGE COLUMN `user_id` `user_id` INT(11) NULL AFTER `id`,
	CHANGE COLUMN `default_zillow_Id` `zillow_access_Id` VARCHAR(500) NULL AFTER `user_id`,
	CHANGE COLUMN `zillow_screen_name` `zillow_screen_name` VARCHAR(500) NULL AFTER `zillow_access_Id`,
	CHANGE COLUMN `google_place_id` `google_place_id` VARCHAR(500) NULL AFTER `zillow_screen_name`,
	CHANGE COLUMN `yelp_business_id` `yelp_business_id` VARCHAR(500) NULL AFTER `google_place_id`,
	CHANGE COLUMN `yelp_include_in_survey` `yelp_include_in_survey` TINYINT(1) NOT NULL DEFAULT '1' AFTER `realtor_details`,
	CHANGE COLUMN `zillow_include_in_survey` `zillow_include_in_survey` TINYINT(1) NOT NULL DEFAULT '1' AFTER `yelp_include_in_survey`,
	CHANGE COLUMN `facebook_include_in_survey` `facebook_include_in_survey` TINYINT(1) NULL DEFAULT '1' AFTER `realtor_include_in_survey`,
	CHANGE COLUMN `google_include_in_survey` `google_include_in_survey` TINYINT(1) NOT NULL DEFAULT '1' AFTER `facebook_include_in_survey`;
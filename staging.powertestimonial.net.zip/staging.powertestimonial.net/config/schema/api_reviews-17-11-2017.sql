/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 17, 2017
 */

ALTER TABLE `api_reviews`
	ADD COLUMN `yelp_review_id` VARCHAR(50) NULL DEFAULT NULL AFTER `google_review_id`;

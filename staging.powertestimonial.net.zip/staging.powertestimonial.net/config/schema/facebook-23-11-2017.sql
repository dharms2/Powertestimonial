/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  dharms2
 * Created: Nov 23, 2017
 */

ALTER TABLE `facebook`
	ADD COLUMN `phone` VARCHAR(50) NULL DEFAULT NULL AFTER `rating_count`;
	ADD COLUMN `address` VARCHAR(500) NULL DEFAULT NULL AFTER `phone`;
	ADD COLUMN `image_url` VARCHAR(500) NULL DEFAULT NULL AFTER `address`;
	CHANGE COLUMN `page_id` `page_id` VARCHAR(50) NULL DEFAULT NULL AFTER `user_id`;
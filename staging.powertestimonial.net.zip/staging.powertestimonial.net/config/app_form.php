<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
    'Templates' => [
        'Form' => [
            // Used for button elements in button().
            'button' => '<button{{attrs}}>{{text}}</button>',
            // Used for checkboxes in checkbox() and multiCheckbox().
            'checkbox' => '<input type="checkbox" name="{{name}}" value="{{value}}"{{attrs}}>',
            // Input group wrapper for checkboxes created via control().
            'checkboxFormGroup' => '{{label}}',
            // Wrapper container for checkboxes.
            'checkboxWrapper' => '<div class="checkbox">{{label}}</div>',
            // Widget ordering for date/time/datetime pickers.
            'dateWidget' => '{{year}}{{month}}{{day}}{{hour}}{{minute}}{{second}}{{meridian}}',
            // Error message wrapper elements.
            'error' => '<div class="error-message">{{content}}</div>',
            // Container for error items.
            'errorList' => '<ul>{{content}}</ul>',
            // Error item wrapper.
            'errorItem' => '<li>{{text}}</li>',
            // File input used by file().
            'file' => '<input type="file" name="{{name}}"{{attrs}}>',
            // Fieldset element used by allControls().
            'fieldset' => '<fieldset{{attrs}}>{{content}}</fieldset>',
            // Open tag used by create().
            'formStart' => '<form{{attrs}}>',
            // Close tag used by end().
            'formEnd' => '</form>',
            // General grouping container for control(). Defines input/label ordering.
            'formGroup' => '{{label}}{{input}}',
            // Wrapper content used to hide other content.
            'hiddenBlock' => '<div style="display:none;">{{content}}</div>',
            // Generic input element.
            'input' => '<input type="{{type}}" name="{{name}}"{{attrs}}/>',
            // Submit input element.
            'inputSubmit' => '<input type="{{type}}"{{attrs}}/>',
            // Container element used by control().
            'inputContainer' => '<div class="form-group col-md-6{{required}}">{{content}}</div>',
            // Container element used by control() when a field has an error.
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
            // Label element when inputs are not nested inside the label.
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
            // Label element used for radio and multi-checkbox inputs.
            'nestingLabel' => '{{hidden}}<label{{attrs}}>{{input}}{{text}}</label>',
            // Legends created by allControls()
            'legend' => '<legend>{{text}}</legend>',
            // Multi-Checkbox input set title element.
            'multicheckboxTitle' => '<legend>{{text}}</legend>',
            // Multi-Checkbox wrapping container.
            'multicheckboxWrapper' => '<fieldset{{attrs}}>{{content}}</fieldset>',
            // Option element used in select pickers.
            'option' => '<option value="{{value}}"{{attrs}}>{{text}}</option>',
            // Option group element used in select pickers.
            'optgroup' => '<optgroup label="{{label}}"{{attrs}}>{{content}}</optgroup>',
            // Select element,
            'select' => '<select name="{{name}}"{{attrs}}>{{content}}</select>',
            // Multi-select element,
            'selectMultiple' => '<select name="{{name}}[]" multiple="multiple"{{attrs}}>{{content}}</select>',
            // Radio input element,
            'radio' => '<input type="radio" name="{{name}}" value="{{value}}"{{attrs}}>',
            // Wrapping container for radio input/label,
            'radioWrapper' => '{{label}}',
            // Textarea input element,
            'textarea' => '<textarea name="{{name}}"{{attrs}}>{{value}}</textarea>',
            // Container for submit buttons.
            'submitContainer' => '<div class="submit">{{content}}</div>',
        ],
        'CustomForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}</div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
            
        ],
        'Discount' => [
            'inputContainer' => '<div class="form-group col-md-6{{required}}">'
            . '<label class="form-control-label" for="discount">Discount</label>'
            . '<div class="input-group" id="discount">{{content}}'
            . '<span class="input-group-addon" id="per" style="display: block">%</span>'
            . '<span class="input-group-addon" id="amt" style="display: none">$</span>'
            . '</div></div>',
            
        ],
        'ValidTo' => [
            'inputContainer' => '<div class="form-group col-md-6{{required}}">'
            . '<label class="form-control-label" for="valid-to">Valid To</label>'
            . '<div class="input-group date" id="valid-to-dt"><span class="input-group-addon"><i class="fa fa-calendar"></i></span>'
            . '{{content}}</div></div>',
            
        ],
        'ValidFrom' => [
            'inputContainer' => '<div class="form-group col-md-6{{required}}">'
            . '<label class="form-control-label" for="valid-to">Valid From</label>'
            . '<div class="input-group date" id="valid-from-dt"><span class="input-group-addon"><i class="fa fa-calendar"></i></span>'
            . '{{content}}</div></div>',
            
        ],
        'EditParentList' => [
            'inputContainer' => '<div id="user-list" class="edit-parent-list form-group col-md-6{{required}}">{{content}}</div>',
            
        ],
        'UserList' => [
            'inputContainer' => '<div id="user-list" class="list-block form-group col-md-6{{required}}">{{content}}</div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
            
        ],
        'LocationForm' => [
            'inputContainer' => '<div id="user-list" class="text-block form-group col-md-6{{required}}">{{content}}</div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
            
        ],
        'EditLocationForm' => [
            'inputContainer' => '<div id="user-list" class="edit-location form-group col-md-6{{required}}">{{content}}</div>',
            
        ],
        'CardForm' => [
            'inputContainer' => '<div class="form-group col-md-4{{required}}">{{content}}</div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
            
        ],
        'UpdateCardForm' => [
            'inputContainer' => '<div class="form-group col-md-2{{required}}">{{content}}</div>',
            
        ],
        'ContactName' => [
            'inputContainer' => '<div class="form-group" {{required}}"><div class="input-group">'
            . '<span class="input-group-addon"><i class="fa fa-fw fa-user"></i></span>{{content}}</div></div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
        ],
        'ContactEmail' => [
            'inputContainer' => '<div class="form-group" {{required}}"><div class="input-group">'
            . '<span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>{{content}}</div></div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
        ],
        'ContactPhone' => [
            'inputContainer' => '<div class="form-group" {{required}}"><div class="input-group">'
            . '<span class="input-group-addon"><i class="fa fa-phone fa-fw"></i></span>{{content}}</div></div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
        ],
        'ContactDesc' => [
            'inputContainer' => '<div class="form-group" {{required}}"><div class="input-group">'
            . '<span class="input-group-addon"><i class="fa fa-file-text fa-fw"></i></span>{{content}}</div></div>',
            'textarea' => '<textarea name="{{name}}"{{attrs}}>{{value}}</textarea>',
        ],
        'LoginPassword' => [
            'inputContainer' => '<div class="form-group" {{required}}"><div class="input-group">'
            . '<span class="input-group-addon"><i class="fa fa-lock fa-fw"></i></span>{{content}}</div></div>',
            'inputContainerError' => '<div class="input {{type}}{{required}} error">{{content}}{{error}}</div>',
        ],
        'YelpConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="yelp-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'ZillowConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="zillow-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'FacebookConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12" {{required}}">{{content}}<div id="facebook-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'FacebookUserIdForm' => [
            'inputContainer' => '<div class="form-group col-md-12" {{required}}">{{content}}<div id="facebook-userid-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'FacebookTokenForm' => [
            'inputContainer' => '<div class="form-group col-md-12" {{required}}">{{content}}<div id="facebook-token-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'RecipientEmail' => [
            'inputContainer' => '<div class="form-group col-md-6{{required}}" id="email-div">{{content}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'RecipientPhone' => [
            'inputContainer' => '<div class="form-group col-md-6{{required}}" id="sms-div">{{content}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'FacebookPageForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="facebook-page-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'GoogleConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="google-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'AngiesConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="angies-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'BBBConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="bbb-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'RealtorConfigForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}<div id="realtor-error" class="error"></div></div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'SubjectForm' => [
            'inputContainer' => '<div class="form-group col-md-12{{required}}">{{content}}</div>',
            'label' => '<label class="form-control-label" {{attrs}}>{{text}}</label>',
        ],
        'InitialBody' => [
            'inputContainer' => '{{content}}',
            'textarea' => '<div class="form-group col-md-12{{required}}">'
            . '<label class="form-control-label" for="init-body">Email Body</label>'
            . '<textarea name="{{name}}"{{attrs}}>{{value}}</textarea>'
            . '</div>'
        ],
        'SMSVerbiageBody' => [
            'inputContainer' => '{{content}}',
            'textarea' => '<div class="form-group col-md-12 required">'
            . '<label class="form-control-label" for="sms-verbiage">Verbiage Body</label>'
            . '<textarea name="{{name}}"{{attrs}}>{{value}}</textarea>'
            . '</div>'
        ],
        'FirstDatepicker' => [
            'inputContainer' => '<div class="col-sm-6 form-group{{required}}">{{content}}</div>',
            'input' => '<div class="input-group date" id="ReportDate"><div id="txtdatefrom"><input type="{{type}}" name="{{name}}"{{attrs}}/></div><span class="input-group-addon text-pointer"><i class="fa fa-calendar"></i></span></div></div><div class="clearfix"></div>',
        ],
    ]
];
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var ERROR_MESSAGES = {
    /*COMMON ERROR MESSAGE*/
    ALERT: 'Alert',
    ALPHANUMERIC_ONLY: "Alphanumeric characters only",
    FAILED_ERROR_MESSAGE: 'Something went wrong.',
    
    CONFIRM_DELETE_TITLE: 'Confirm Delete',
    CONFIRM_DELETE_MESSAGE: 'Are you sure you want to Delete?',
    
    CONFIRM_APPROVE_TITLE: 'Confirm Approval',
    CONFIRM_APPROVE_MESSAGE: 'Are you sure you want to Approve?',
    
    CONFIRM_USER_STATUS_UPDATE: 'The user has been updated',
    ERROR_USER_STATUS_UPDATE: 'The User could not be updated. Please, try again',

    /*ADD ASSOCIATE AND MANAGER ERROR MESSAGE*/
    FIRST_NAME: 'Please enter your firstname',
    FIRST_NAME_MINLENGTH: 'Your first name must consist of at least 2 characters',

    LAST_NAME: 'Please enter your lastname',
    LAST_NAME_MINLENGTH: 'Your last name must consist of at least 2 characters',
    
    PHONE_NUMBER: 'Please enter your phone number',

    USER_GROUP: 'Please select user role',

    PASSWORD: 'Please enter a password',
    PASSWORD_VALIDATE: 'Passwords are 6-20 characters with at least one uppercase or lowercase and at least one number',

    CONFIRM_PASSWORD: 'Please provide a password',
    CONFIRM_PASSWORD_MINLENGTH: 'Your password must be at least 6 characters long',
    CONFIRM_PASSWORD_EQUALTO: 'Please enter the same password as above',

    EMAIL: 'Please enter a email address',
    EMAIL_VALIDATE: 'Please enter a valid email address',
    EMAIL_EXISTS: 'This email address is already exist',

    ADDRESS_LINE1_REQUIRED: 'Please enter your address',

    CITY_REQUIRED: 'Please enter your city name',
    PHONE_REQUIRED: 'Please enter your phone number',

    STATE_REQUIRED: 'Please enter your state name',

    COUNTRY_REQUIRED: 'Please enter your country name',

    ZIP_CODE_REQUIRED: 'Please enter your zip code',
    ZIP_CODE_VALIDATE: 'Zip code based on your country',

    TERM_CONDITION_REQUIRED: 'Please select terms & conditions',
    
    PARENT_ID: 'Please select parent user for this user role',
    LOCATION: 'Please enter location for this user role',
    
    BUSINESS_NAME: 'Please enter your compay name',
    
    
    /*Credit card valition*/
    CARD_NUMBER: 'Please enter a valid credit card number',
    EXP_MONTH: 'Please enter card exp month',
    EXP_MONTH_MIN: 'Exp month must be 2 digit',
    EXP_YEAR: 'Please enter card exp Year',
    EXP_YEAR_MIN: 'Exp year must be 2 digit',
    CVV_NO: 'Please enter card CVV no.',
    CVV_NO_MIN: 'Card CVV must be 3 digit',

    TEMPLATE_SELECT: 'Selected Survey should have template ',

    /*CONTACT FORM VALIDATION*/
    NAME: 'Please enter your name.',
    NAME_MINLENGTH: 'Your name must consist of at least 2 characters.',

    NAME: 'Please enter your phone number.',
    PHONE_VALIDATE: 'Phone Number must be at least 10 digit and not more than 14 digit.',

    CONTENT: 'Please write youe query.',
    CONTENT_VALIDATE: 'Description must be at least 50 characters.',

    /*USER_UPDATE MESSAGE*/
    CONFIRM_UPDATE: 'The user has been updated',
    ERROR_UPDATE: 'The user could not be updated. Please, try again',
    SURVEY_ANALYZE_ERROR_UPDATE : 'Some problem occured, please try again.',
    
    /*USER_UPDATE MESSAGE*/
    CONFIRM_SURVEY_UPDATE: 'The Survey has been updated',
    ERROR_SURVEY_UPDATE: 'The Survey could not be updated. Please, try again',
    
     /*USER_UPDATE MESSAGE*/
    CONFIRM_TEMPLATE_UPDATE: 'The Template has been updated',
    ERROR_TEMPLATE_UPDATE: 'The Template could not be updated. Please, try again',
    
     /*USER_UPDATE MESSAGE*/
    CONFIRM_QUESTION_UPDATE: 'The Question has been updated',
    ERROR_QUESTION_UPDATE: 'The Question could not be updated. Please, try again',
    
     /*USER_UPDATE MESSAGE*/
    CONFIRM_CATEGORY_UPDATE: 'The Category has been updated',
    ERROR_CATEGORY_UPDATE: 'The Category could not be updated. Please, try again',

    /*RATING VALIDATION*/
    RATING_VALIDATION: 'Please rate your experience by clicking the star rating you would like to give.',
    RATING_SUCCESS: 'Thank you for taking the time to complete our survey!',
    RATING_ERROR: 'Some problem occured, please try again.',

    /*SURVEY VALIDATION*/
    SURVEY_NAME_REQUIRED: 'Please enter survey name',
    SURVEY_DISCRIPTION_REQUIRED: 'Please enter survey description',
    SURVEY_TEMPLATE_REQUIRED: 'Please select one of template',
    SURVEY_VALIDATION: 'Please select one of these options.',
    SURVEY_TEXTAREA_VALIDATION: 'Please enter your answer here.',
    SURVEY_TEXTAREA_LENGTH_VALIDATION: 'Answer must be at least 1 characters.',
    SUCCESS_SUBMIT_SURVEY: 'Thanks, You have successful submited your survey.',

    /*CATEGORY VALIDATION*/
    CATEGORY_NAME_EXISTS: 'This name already exists, please try another.',
    NAME_REQUIRED: 'Please enter category name',
    DISCRIPTION_REQUIRED: 'Please enter category description',

    /*QUESTION VALIDATION*/
    QUESTION_CATEGORY_REQUIRED: 'Please select one of these categories',
    QUESTIONS_REQUIRED: 'Please enter your question',
    ANS_TYPES_REQUIRED: 'Please select answer types',
    ANS_CHOICES_REQUIRED: 'Please enter answer choice options',

    /*TEMPLATE VALIDATION*/
    TEMPLATE_NAME_REQUIRED: 'Please enter template name',
    TEMPLATE_DISCRIPTION_REQUIRED: 'Please enter template description',
    TEMPLATE_GREETING_REQUIRED: 'Please enter greeting text',
    TEMPLATE_FOOTER_REQUIRED: 'Please enter footer text',
    TEMPLATE_QUESTIONTYPE_REQUIRED: 'Please select one of question type',

    /*TEMPLATE VALIDATION*/
    REVIEWER_FNAME: 'Please enter your reviewer first name',
    REVIEWER_FNAME_MINLENGTH: 'Reviewer first name must consist of at least 2 characters',
    REVIEWER_LNAME: 'Please enter your reviewer last name',
    REVIEWER_LNAME_MINLENGTH: 'Reviewer last name must consist of at least 2 characters',
    REVIEWER_EMAIL: 'Please enter reviewer email address',
    REVIEWER_PHONE: 'Please enter reviewer phone number',
    VALID_PHONE_NUMBER: 'Please specify a valid US phone number',
    SURVEY_REQUIRED: 'Please select one of these survey',
    TYPE_REQUIRED: 'Please select at least one survey sending medium type',
    REVIEW_USER_ID: 'Please select one of these Assosiate/Agent',

    
    /*LOGIN VALIDATION*/
    LOGIN_EMAIL: 'Please enter your Email',
    LOGIN_PASSWORD: 'Please enter your password',

    /*Change Password*/
    OLD_PASSWORD: 'Please enter your old password',
    PASSWORD_EXISTS: 'The old password does not match. Please, try again',
    
    EMAIL_NOT_EXISTS:'Email Id is not exist.Please, try with different email id ',
    
    BUSINESS_NAME: 'Please enter your Business name',
    BUSINESS_PHONE: 'Please enter your Business Phone Number',
    BUSINESS_ADDRESS_LINE1_REQUIRED: 'Please enter your Business Address',
    BUSINESS_COUNTRY_REQUIRED: 'Please enter your Business Country',
    BUSINESS_CITY_REQUIRED: 'Please enter your Business City',
    BUSINESS_STATE_REQUIRED: 'Please enter your Business State',

    /*SET ZILLOW ID*/
    ZILLOW_SCREEN_NAME: 'Please enter zillow screen name',
    WRONG_ZILLOW_SCREEN_NAME: 'You have entered invalid screenname parameter',
    ZILLOW_API_DETAILS: 'You have not configured Zillow screen name, Please set your valid Zillow Screen Name in API configration setting.',
    
    /*SET FACEBOOK PAGE NAME*/
    FACEBOOK_APP_ID: 'Please enter facebook page id.',
    FACEBOOK_APP_SECRET: 'Please enter facebook app secret code',
    FACEBOOK_USER_ID: 'Please get facebook response for User Id',
    FACEBOOK_ACCESS_TOKEN: 'Please get facebook response for Access Token',
    FACEBOOK_PAGE_NAME: 'Please enter facebook page name',
    WRONG_FACEBOOK_PAGE: 'You have entered invalid page name',
    FACEBOOK_API_DETAILS: 'You have not configured Facebook page name, Please set your valid Facebook Page Name in API configration setting.',
    
    /*SET GOOGLE PAGE NAME*/
    GOOGLE_PLACE_ID: 'Please enter google place id',
    WRONG_GOOGLE_PLACE_ID: 'You have entered invalid place id Or You have exceeded your daily request quota for this API',
    GOOGLE_API_DETAILS: 'You have not configured Google Place ID, Please set your valid Google place ID in API configration setting.',
    
    /*SET YELP PAGE NAME*/
    YELP_BUSINESS_ID: 'Please enter yelp business name',
    WRONG_YELP_BUSSINESS_NAME: 'You have entered invalid business name!',
    YELP_API_DETAILS: 'You have not configured Yelp Business Name, Please set your valid Yelp Business Name in API configration setting.',

    /*SET YELP PAGE NAME*/
    ANGIES_BUSINESS_ID: 'Please enter angies business id',
    ANGIES_API_DETAILS: 'You have not configured angies list business id, Please set your valid angies list business id in API configration setting.',
    
    /*SET BBB PAGE NAME*/
    BBB_BUSINESS_NAME: 'Please enter BBB business name',
    BBB_API_DETAILS: 'You have not configured BBB business name, Please set your valid BBB business name in API configration setting.',
    
    /*SET REALTOR PAGE NAME*/
    REALTOR_BUSINESS_NAME: 'Please enter realtor business name',
    REALTOR_API_DETAILS: 'You have not configured realtor business name, Please set your valid realtor business name in API configration setting.',
    
    /*QUESTION TEMPLATES*/
    QUESTION_NAME_REQUIRED: 'Please enter survey question',
    QUESTION_ANS_REQUIRED: 'Please select answer type',
    
    /*NEW PASS*/
    PASSWORD_EXISTS_MATCH:'Your can not save old password',
  
    /*SURVEY VALIDATION*/
    SURVEY_ADDRESS_VALIDATION : 'Please enter your address.',
    SURVEY_STATE_VALIDATION : 'Please enter your state.',
    SURVEY_CITY_VALIDATION : 'Please enter your city.',
    SURVEY_ZIPCODE_VALIDATION : 'Please enter your zipcode.',
    SURVEY_RATING_VALIDATION : 'Please select at least one star.',
    
    /*PLAN UPGRADATION*/
    CONFIRM_UPGRADE: 'Confirm Upgrade',
    CONFIRM_UPGRADE_MSG: 'Are you sure you want to upgrade plan?',
    PLAN_UPGRADATION: 'You have selected current using plan.',
    PLAN_UPGRADATION_REQ: 'Your request for a plan upgrade has been successfully submitted.',
    
    /*PLAN UPGRADATION APPROVED*/
    PLAN_UPGRADATION_APPROVED: 'User plan upgrade has been approved.',
    PLAN_UPGRADATION_ERROR: 'User plan upgrade could not be approved, please try again.',
    
    /*CANCEL RECURING TRANSACTION*/
    SUCCESS_RECUR: 'You have successful cancel this Subscription.',
    
    /*ASSOCIATE API SETTING ALLOW AND NOT ALLOW*/
    CONFIRM_API_SETTING: 'API setting of associate user has been updated',
    ERROR_API_SETTING: 'API setting of associate user could not be updated. Please, try again',
    
    /*SURVEY REVIEW TEMPLATE VALIDATION*/
    FOUR_STAR_REVIEW_QUESTION: 'Please choose any one of question for 4 Star.',
    FOUR_STAR_REVIEW_CHANNEL: 'Please choose any one of review channel for 4 Star.',
    CHOOSE_QUESTION: 'Please choose any one of question.',
    ADD_QUESTION: 'Please add at least one default question for other than 5 Star template.',
    SELECT_QUESTION: 'Please select at least one question.',
    FIVE_STAR_REVIEW_CHANNEL: 'Please select any one of review channel for 5 Star.',
    
    /*CUSTOM EMAIL TeEMPLATES VALIDATION*/
    REMINDER_DAYS: 'Please set how many days for reminder',
    EMAIL_SUBJECT: 'Please set your email subject',
    EMAIL_BODY: 'Please enter email body content',
    
    /*AUTO EMAIL REMINDER VALIDATION*/
    FIRST_REMINDER_DATE: 'Please enter first reminder date',
    SECOND_REMINDER_DATE: 'Please enter second reminder date',
    AUTO_REMINDER_SUCCESS: 'Auto reminder date has been successfully submitted.',
    
    SMS_VERBIAGE: 'Please enter sms verbiage content',
    SMS_VERBIAGE_LENGTH: 'SMS verbiage content not more than 12000 characters',
    
    /*SURVEY SUBMISSION VALIDATION*/
    ALREADY_FILL_SURVEY: 'You have already submitted this survey.',
    
    
    DELETE_QUESTION: 'Question has been removed successfuly.',
    
    /*FETCH ONLINE REVIEW VALIDATION*/
    FETCH_ONLINE_REVIEW: 'You have successful fetch your latest reviews from online channels.',
    FACEBOOK_FETCH_REVIEW: "You need to relogin and update the facebook api setting for fetching latest facebook reviews.<br><br> <a href=\'/ApiConfigurations\'>Click Here</a> to go setting page",
    
    /*VALIDATION OF COUPON FORM*/
    CODE: 'Please enter a valid coupon code',
    CODE_EXISTS: 'This code is already exist',
    DISCOUNT_TYPE: 'Please select descount type',
    DISCOUNT: 'Please enter descount value',
    STATUS: 'Please select coupon current status',
    VALID_FROM: 'Please enter valid start date',
    VALID_TO: 'Please enter valid end date',
    
    REQUIRED_COUPON_CODE: 'Please enter coupn code.',
    EXP_COUPON_CODE: 'This code is no longer validate.'
};

/*SET TINYMCE EDITOR MODE AND SELECTER*/
var TINYMCE = {
    MODE : "specific_textareas",
    EDITOR_SELECTOR  : 'mce-textarea'
};

/*SET TINYMCE EDITOR PLUGINS*/
var TINYMCE_PLUGINS = {
    PLUGINS_1 : 'advlist autolink lists link charmap print preview hr anchor pagebreak',
    PLUGINS_2 :'searchreplace wordcount visualblocks visualchars code fullscreen',
    PLUGINS_3 : 'insertdatetime media nonbreaking save table contextmenu directionality',
    PLUGINS_4 :'emoticons template paste textcolor colorpicker textpattern toc help'
};

/*SET TINYMCE EDITOR TOOLBAR*/
var TINYMCE_TOOLBAR = {
    TOOLBAR_1 : 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview | forecolor backcolor emoticons | codesample help',
    TOOLBAR_2 : 'print preview | forecolor backcolor emoticons | codesample help'
};

/*SET TINYMCE EDITOR STYLES*/
var TINYMCE_CONTENT_CSS = {
    FOUNT : '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    CODEPEM_MIN : '//www.tinymce.com/css/codepen.min.css'
}
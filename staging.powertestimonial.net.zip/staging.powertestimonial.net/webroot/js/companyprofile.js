/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global ERROR_MESSAGES */

$(function () {
    
    jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
	phone_number = phone_number.replace(/\s+/g, "");
	return this.optional(element) || phone_number.length > 9 &&
		phone_number.match(/^(\+?1-?)?(\([2-9]\d{2}\)|[2-9]\d{2})-?[2-9]\d{2}-?\d{4}$/);
    }, ERROR_MESSAGES.VALID_PHONE_NUMBER);
    
    $.validator.addMethod("ZIP_CODE", function (value, element) {
        var cval = $('#country').val();
        switch (cval) {
            case "US":
                postalCodeRegex = /^([0-9]{5})(?:[-\s]*([0-9]{4}))?$/;
                break;
            case "CA":
                postalCodeRegex = /^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$/;
                break;
            default:
                postalCodeRegex = /^(?:[A-Z0-9]+([- ]?[A-Z0-9]+)*)?$/;
        }
        return this.optional(element) || postalCodeRegex.test(value);
    }, ERROR_MESSAGES.ZIP_CODE_VALIDATE);
    
    /*Check Category Form Validation*/
    $('#company-profile-form').validate({
        rules: {
            business_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            business_phone: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                phoneUS: true
            },
            business_address_line1: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            business_country: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            business_city: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            business_state: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            business_zip_code: {
                 required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                ZIP_CODE: true
            }
        },
        messages: {
            business_name: {
                required: ERROR_MESSAGES.BUSINESS_NAME
            },
            business_phone: {
                required: ERROR_MESSAGES.BUSINESS_PHONE
            },
            business_address_line1: {
                required: ERROR_MESSAGES.BUSINESS_ADDRESS_LINE1_REQUIRED
            },
            business_country: {
                required: ERROR_MESSAGES.BUSINESS_COUNTRY_REQUIRED
            },
            business_city: {
                required: ERROR_MESSAGES.BUSINESS_CITY_REQUIRED
            },
            business_state: {
                required: ERROR_MESSAGES.BUSINESS_STATE_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
});
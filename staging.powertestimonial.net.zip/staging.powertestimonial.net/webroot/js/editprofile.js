/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global ERROR_MESSAGES */

$(function () {
    
    jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
	phone_number = phone_number.replace(/\s+/g, "");
	return this.optional(element) || phone_number.length > 9 &&
		phone_number.match(/^(\+?1-?)?(\([2-9]\d{2}\)|[2-9]\d{2})-?[2-9]\d{2}-?\d{4}$/);
    }, ERROR_MESSAGES.VALID_PHONE_NUMBER);
    
    $.validator.addMethod("ZIP_CODE", function (value, element) {
        var cval = $('#country').val();
        switch (cval) {
            case "US":
                postalCodeRegex = /^([0-9]{5})(?:[-\s]*([0-9]{4}))?$/;
                break;
            case "CA":
                postalCodeRegex = /^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$/;
                break;
            default:
                postalCodeRegex = /^(?:[A-Z0-9]+([- ]?[A-Z0-9]+)*)?$/;
        }
        return this.optional(element) || postalCodeRegex.test(value);
    }, ERROR_MESSAGES.ZIP_CODE_VALIDATE);
    
    /*Check Edit Profile Form Validation*/
    $('#profile-form').validate({
        rules: {
            first_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            last_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            additional_email: {
                required: false,
                EMAIL: true,
                checkAdditionalEmail: function () {
                    return [
                        $('[name=additional_email]').val()
                    ];
                }
            },
            phone: {
                required: {
                    depends:function(){
                        $(this).val($.trim($(this).val()));
                        return true;
                    }
                },
                phoneUS: true
            },
            address_line1: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            city: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            state: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            country: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            zip_code: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                ZIP_CODE: true
            }
        },
        messages: {
            first_name: {
                required: ERROR_MESSAGES.FIRST_NAME,
                minlength: ERROR_MESSAGES.FIRST_NAME_MINLENGTH
            },
            last_name: {
                required: ERROR_MESSAGES.LAST_NAME,
                minlength: ERROR_MESSAGES.LAST_NAME_MINLENGTH
            },
            phone: {
                required: ERROR_MESSAGES.PHONE_NUMBER
            },
            address_line1: {
                required: ERROR_MESSAGES.ADDRESS_LINE1_REQUIRED
            },
            city: {
                required: ERROR_MESSAGES.CITY_REQUIRED
            },
            state: {
                required: ERROR_MESSAGES.STATE_REQUIRED
            },
            country: {
                required: ERROR_MESSAGES.COUNTRY_REQUIRED
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

    
    /*Check Additional Email where additional Email and Primary Email are unique or not*/
    $.validator.addMethod("checkAdditionalEmail", function (value, element) 
    {
        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/Users/checkAddionalEmailIsUnique", // script to validate in server side
            data: {email: value},
            dataType: 'JSON',
            success: function (data) 
            {
                result = (data.count == 0) ? true : false;
            }
        });
        // return true if Code is exist in database
        return result;
    },
        ERROR_MESSAGES.EMAIL_EXISTS
    );
});

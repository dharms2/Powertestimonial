/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global ERROR_MESSAGES */

$(function () {
    
    $.validator.addMethod("PASSWORD", function (value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/i.test(value);
    }, ERROR_MESSAGES.PASSWORD_VALIDATE);

    $.validator.addMethod("EMAIL", function (value, element) {
        return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
    }, ERROR_MESSAGES.EMAIL_VALIDATE);

    $('#login-form').validate({
        rules: {
            email: {
                required: true,
                EMAIL: true
            },
            password: {
                required: true
            }
        },
        messages: {
            email: {
                required: ERROR_MESSAGES.LOGIN_EMAIL
            },
            password: {
                required: ERROR_MESSAGES.LOGIN_PASSWORD
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element.parents('.input-group'));
            }
        }
    });

    /*Check validation for forget password */
    $('#forgot-form').validate({
        rules: {
            email: {
                required: true,
                EMAIL: true,
                checkEmail: function () {
                    return [
                        $('[name=email]').val()
                    ];
                }
            }
        },
        messages: {
            email: {
                required: ERROR_MESSAGES.LOGIN_EMAIL
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) 
        {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element.parents('.input-group'));
            }
        }
    });
    
    /*Check validation for reset password */
    $('#reset-password-save').validate({
        rules: {
            new_password: {
                required: true,
                PASSWORD: true
            },
            confirm_password: {
                required: true,
                equalTo: '#new-password'
            }
        },
        messages: {
            new_password: {
                required: ERROR_MESSAGES.PASSWORD
            },
            confirm_password: {
                required: ERROR_MESSAGES.CONFIRM_PASSWORD,
                equalTo: ERROR_MESSAGES.CONFIRM_PASSWORD_EQUALTO
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) 
        {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element.parents('.input-group'));
            }
        }
    });
    
    /*Check email where user email are in database or not */
    $.validator.addMethod("checkEmail", function (value, element) 
    {
        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/Users/checkEmailIsUnique", // script to validate in server side
            data: {email: value},
            dataType: 'JSON',
            success: function (data) {
                result = (data.count === 1) ? true : false;
            }
        });
        // return true if Code is exist in database
        return result;
    },
    ERROR_MESSAGES.EMAIL_NOT_EXISTS
    );
    
    
});
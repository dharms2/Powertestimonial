/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global ERROR_MESSAGES, alertify, id */

$(function () {
        
    $('#update-payment-info').validate({
        rules: {
            card_number: {
                required: true,
                creditcard: true
            },
            exp_month: {
                required: true,
                minlength: 2
            },
            exp_year: {
                required: true,
                minlength: 2
            }
        },
        messages: {
            card_number: {
                required: ERROR_MESSAGES.CARD_NUMBER
            },
            exp_month: {
                required: ERROR_MESSAGES.EXP_MONTH,
                minlength: ERROR_MESSAGES.EXP_MONTH_MIN
            },
            exp_year: {
                required: ERROR_MESSAGES.EXP_YEAR,
                minlength: ERROR_MESSAGES.EXP_YEAR_MIN
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    // NOTICE: Modified version of Castle.Components.Validator.CreditCardValidator
    // Valid Types: mastercard, visa, amex, dinersclub, enroute, discover, jcb, unknown, all (overrides all other settings)
    $.validator.addMethod("creditcard", function (val, el) {

        var card_no = $("#card-number").val();
        var pattern_american = /^(?:3[47][0-9]{13})$/;
        var pattern_visa = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
        var pattern_master = /^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/;
        var pattern_discover = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
        var pattern_dinner = /^(?:3(?:0[0-5]|[68][0-9])[0-9]{11})$/;
        var pattern_jcb = /^(?:(?:2131|1800|35\d{3})\d{11})$/;
        var pattern_maestro = /^(5018|5020|5038|6304|6759|676[1-3])/;

        var card_type = false;

        if (card_no.match(pattern_american)) {
            $(".card-icon").hide();
            $("#card-amex").show();
            return true;
        } else if (card_no.match(pattern_visa)) {
            $(".card-icon").hide();
            $("#card-visa").show();
            return true;
        } else if (card_no.match(pattern_master)) {
            $(".card-icon").hide();
            $("#card-mastercard").show();
            return true;
        } else if (card_no.match(pattern_discover)) {
            $(".card-icon").hide();
            $("#card-discover").show();
            return true;
        } else if (card_no.match(pattern_dinner)) {
            $(".card-icon").hide();
            $("#card-diners").show();
            return true;
        } else if (card_no.match(pattern_jcb)) {
            $(".card-icon").hide();
            $("#card-jcb").show();
            return true;
        } else if (card_no.match(pattern_maestro)) {
            $(".card-icon").hide();
            $("#card-maestro").show();
            return true;
        } else {
            return false;
        }
    }, ERROR_MESSAGES.CARD_NUMBER );
});


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global alertify, ERROR_MESSAGES */

function fourStarOptionFunction(a) { 
    if (a.value == 2) {    
        $("#fourStarQuestionChannel").hide();
        $("#fourStarReviewChannel").show();
        $('#fourStarReviewChannelInput').attr('name', 'select_qusetion_id[4][]'); 
        $(".addSurveyQuestion4").html('');
       
    } else if (a.value == 1) {  
        $("#fourStarQuestionChannel").show();
        $("#fourStarReviewChannel").hide();
        $('#fourStarReviewChannelInput').removeAttr('name', 'select_qusetion_id[4][]'); 
        $('#fourStarReviewChannel input:checked').each(function() {
            $(this).prop('checked',false);
        });

    } else {
        $("#fourStarQuestionChannel").hide();
        $("#fourStarReviewChannel").hide();
        $('#fourStarReviewChannelInput').removeAttr('name', 'select_qusetion_id[4][]'); 
        $('#fourStarReviewChannel input:checked').each(function() {
            $(this).prop('checked',false);
        });
    }
}

function myTemplatetypeFunction() {
    var x = document.getElementById("mySelectTemplate").value;   
    if (x == 2) {    
        $(".reviewSection").css("display", "none");
        $(".surveySection").css("display", "block");
        $('#fourOptionSelect').val(0);
        $('#onchangeSetFouroptionvalue').attr('name', 'fouroption'); 
    } else {
        $(".reviewSection").css("display", "block");
        $(".surveySection").css("display", "none");
        $("#fourStarQuestionChannel").show();
        $("#fourStarReviewChannel").hide();
        $('#onchangeSetFouroptionvalue').removeAttr('name', 'fouroption'); 
    }
}

$(".addTesmplatesubmit").on("click", function (e) {
    if ($('#fourOptionSelect').val() == 1) {
        if ($("input[name='select_qusetion_name[4]']").length == 0) {
            e.preventDefault();
            alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.FOUR_STAR_REVIEW_QUESTION);
        }
    }

    if ($('#fourOptionSelect').val() == 2) {
        if ($("input[name='select_qusetion_id[4][]']:checked").length == 0) {
            e.preventDefault();
            alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.FOUR_STAR_REVIEW_CHANNEL);
        }
    }

    if ($('#mySelectTemplate').val() == 2) {
        if ($("input[name='select_qusetion_name[0]']").length == 0) {
            e.preventDefault();
            alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.CHOOSE_QUESTION);
        }
    }

    if ($('#mySelectTemplate').val() == 1) {
        if ($("input[name='select_qusetion_name[-1]']").length == 0) {
            e.preventDefault();
            alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.ADD_QUESTION);
        }
        
        var flag = 0;
        $("input[name='select_qusetion_id[5][]']").each(function(){
            if ($(this).is(':checked') == true) {
                flag = 1;
            }
        });
        
        if (flag == 0) {
            e.preventDefault();
            alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.FIVE_STAR_REVIEW_CHANNEL);
        }
    }
});

function getStarOnPopUp(val, el) {
    var $this = $(el);
    var cur_scope = $this.siblings("div.question");
    $('#selectSurveyTemplateSelect').val("Import Survey Question");
    // reset q_level
    resetQuesNames($this);
   
    
    if ($("input[name='select_qusetion_name["+val+"]']", $(cur_scope)).length > 0) { 
        $('input[name=ques_select]').prop('checked',false);
        
        //$("input[name='select_qusetion_id["+val+"][]']").each(function() {  
        $("ul:first > li", cur_scope).each(function() {  
            var editQuestionVal = $(this).find("input[name^='select_qusetion_id["+val+"]']:first").val();
            //var editQuestionVal = $(this).val();
            $('input[type=checkbox]').each(function() {
                var removeOnValue = $(this).val();
                if (removeOnValue != 'on') {
                    if (editQuestionVal == $(this).val()) {
                        $('input[type=checkbox][value='+$(this).val()+']').prop('checked', true);
                    }
                }           
            });
        });      
    } else {
        $('input[name=ques_select]').prop('checked',false);
    }      
    $('#myModal').modal('show');
    $('#onclickGetquestion').val(val);
    $('#onclickGetquestion').data('cur_scope', cur_scope);
}

//******************Add More Question*******************//
$("#onclickGetquestion").click(function (e) {
    var $this = $(this);
    var cur_scope = $this.data("cur_scope");
    
    var q_level = cur_scope.find('ul:first').data('q_level');
    
    var starNumber = $('#onclickGetquestion').val();
    var tempType = $('#mySelectTemplate').val();
    var fourOpt = $('#fourOptionSelect').val();
    e.preventDefault();
    var ck_box = $('input[name=ques_select]:checked').length;
    var tempId = $('#template-id').val();
    
    // NOTE: all crawling will be in current parent div only
    var all_selected = $('input[name=ques_select]:checked').map(function (_, el) {
        return $(el).val();
    }).get();
    
    // loop through the questions in html
    // check if current question id is not in all_selected array of ids
        // remove current question in html by clicking on its delete btn
    // else
        // push current id in html_questions 
    $("ul:first > li", cur_scope).each(function(i, el) {  
        var htmlQuestionVal = $(this).find("input[name^='select_qusetion_id["+starNumber+"]']:first").val();
        //var htmlQuestionVal = $(this).val();
        if (all_selected.indexOf(htmlQuestionVal) >= 0) {
            //alert(htmlQuestionVal);
        } else {
            // remove question from html
            $(el).find("a.remove_field:last").trigger('click');
        }
    });
    
    var html_questions = new Array();
    var ul = $(".qus_list:first", $(cur_scope));
    if (!!ul.length) {
        $(ul).children(".myLi").each(function(){
            html_questions.push($(this).val());
        });
    }
    
    if (ck_box > 0) {
//        alert(all_selected);
//        alert(html_questions);
        var qid = $('input[name=ques_select]:checked').map(function (_, el) {
            // check if current selected question id is not in html_questions array
            if (html_questions.indexOf(parseInt($(el).val())) >= 0) {
                //
            } else {
                return $(el).val();
            }
        }).get();
        
        // if qid is not empty
        if (qid.length > 0) {
            $.ajax({
                url: "/SurveyTemplates/chooseQuestion",
                type: "post",
                beforeSend: function(xhr){
                                if (qid.length == 0) {
                                    xhr.abort();
                                }
                            },
                data: {'qid': qid, tempId: tempId, star: starNumber, type: tempType, fourOption: fourOpt, q_level: q_level},
                success: function (response) {            
                    var jsonData = JSON.parse(response);
                    if (jsonData.length >= 0) {
                        var qustioncount = 1;
                        var res = '';
                        var i = 0;
                        $.each(jsonData, function (index, value) {
                            var ans_choices = value[0].ans_choices.split('|');

                            res += '<li class="myLi" value="' + value[0].id + '" style="display: unset"><div class="row">';
                            res += '<div class="col-md-11 col-sm-10">\n\
                                    <div class="form-group">'
                                +  '<h6 class="card-title">' + value[0].questions + '</h6>\n\
                                   <input type="hidden" name="select_qusetion_name['+starNumber+']">\n\
                                   <input type="hidden" name="select_qusetion_id['+starNumber+'][]" value="' + value[0].id + '">'
                                +  '<div class="row answers">';
                            if (value[0].ans_types == 3 || value[0].ans_types == 4 || value[0].ans_types == 5) {
                                if (value[0].ans_types == 3) {
                                    res += '<div class="col-md-12">\n\
                                            <textarea class="form-control tempalteQuestionAnswerarea" disabled></textarea>\n\
                                            </div>';
                                } else if (value[0].ans_types == 4) {
                                    var star = ['1','2','3','4','5'];
                                    $.each(star, function (i, el) {
                                        if (el == 1) {
                                            res += '<div class="col-md-10 star-color">\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    </div>';
                                        } else if (el == 2) {
                                            res += '<div class="col-md-10 star-color">\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    </div>';
                                        } else if (el == 3) {
                                            res += '<div class="col-md-10 star-color">\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    </div>';
                                        } else if (el == 4) {
                                            res += '<div class="col-md-10 star-color">\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    </div>';
                                        } else if (el == 5) {
                                            res += '<div class="col-md-10 star-color">\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>\n\
                                                    </div>';
                                        }
                                        res += '<div class="col-md-2 float-right logic_btn">'
                                            + '<div class="float-right">'
                                            + '<a class="btn btn-outline-primary btn-sm toggle_logic_btn" style="padding: 2px 5px;line-height: normal" onclick="toggleLogic('+starNumber+', this);">'
                                            + 'Question Logic</a>'
                                            + '</div>'
                                            + '</div>';
                                    });
                                } else if (value[0].ans_types == 5) {
                                    res += '<div class="col-md-3">\n\
                                            <textarea type="text" class="form-control" disabled>Address</textarea>\n\
                                            </div><div class="col-md-3">\n\
                                            <input type="text" class="form-control" value="City" disabled>\n\
                                            </div><div class="col-md-3">\n\
                                            <input type="text" class="form-control" value="State" disabled>\n\
                                            </div><div class="col-md-3">\n\
                                            <input type="text" class="form-control" value="Zipcode" disabled>\n\
                                            </div>';
                                }
                            } else {
                                   $.each(ans_choices, function (i) {

                                        if (value[0].ans_types == 1) {
                                            res += '<div class="col-md-10">';
                                            res += '<span class="radio-button-display"></span>'
                                                + '<label for="test1" class="tempalteQuestionAnswerLabel">'
                                                + ans_choices[i]
                                                + '</label></div>';
                                            res += '<div class="col-md-2 float-right logic_btn">'
                                                + '<div class="float-right">'
                                                + '<a class="btn btn-outline-primary btn-sm toggle_logic_btn" style="padding: 2px 5px;line-height: normal" onclick="toggleLogic('+starNumber+', this);">'
                                                + 'Question Logic</a>'
                                                + '</div>'
                                                + '</div>';
                                        } else {
                                            res += '<div class="col-md-6">';
                                            res += '<span class="checkbox-button-display "></span>'
                                                + '<label for="test1" class="tempalteQuestionAnswerLabel">'
                                                + ans_choices[i]
                                                + '</label></div>';
                                        }
                                });
                            }
                            res += '</div></div></div><div class="col-md-1 col-sm-2">\n\
                                    <a href="javascript:void(0)" class="btn btn-danger float-right remove_field" temp_id="'+tempId+'" que_id="'+value[0].id+'" star_val="'+starNumber+'">\n\
                                    <i class="fa fa-trash"></i></a>\n\
                                    </div><div class="col-md-12">\n\
                                    <hr style="margin-top: 0px">\n\
                                    </div></div></li>';
                            i++;
                            qustioncount++;
                        });
                        
                        $('ul:first', $(cur_scope)).append(res);
                        $('#onclickGetquestionClose').click();
                        resetQuesNames($(cur_scope));

                    } else {
                        console.log('question has no record');
                    }
                },
                error: function (response) {
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 5, function () {
                        console.log('dismissed');
                    });
                }
            });
        }else{
            $('#onclickGetquestionClose').click();
        }
    } else {
        alertify.alert(ERROR_MESSAGES.ALERT, ERROR_MESSAGES.SELECT_QUESTION);
    }
    
});

$(function() {
    $('div.question[data-ques_block]').each(function(i, el) {
       var tmp = $(el).data('ques_block');
       $(el).removeAttr('data-ques_block');
       $(el).data('ques_block', tmp);
    }); 
});
 
function resetQuesNames(el) {
    var first_name = 'select_qusetion_id['+ $(el).closest('div.card.ques_block').find('div.question:first').data('ques_block') + ']';
    reset_names($(el).closest('div.card.ques_block'), first_name);
}

function reset_names(el, el_name) {
    $('ul.qus_list:first', $(el)).data('q_level', el_name);
    $('ul.qus_list:first > li.myLi', $(el)).each(function(i, elm) {
        var new_name = el_name +'['+ $(elm).attr('value') +']';
        //console.log(new_name);
        $('input[name^="select_qusetion_id"]:first', $(elm)).attr('name', new_name + '[q]');
        // if it has sub question logic div
        if (!!$('div.answers:first > div.logic_div', $(elm)) && $('div.answers:first > div.logic_div', $(elm)).length > 0 ) {
            $('div.answers:first > div.logic_div', $(elm)).each(function(ld_i, ld_el){
                reset_names(ld_el, new_name + '[ans]['+ld_i+']');
            });
        }
    });
}

function toggleLogic(str_val, el){
    var div = $(el).closest('div.logic_btn').next('.logic_div');
    
    if (div.length) {
       $(el).closest('div.logic_btn').next('.logic_div').hide('slow');
       $(el).closest('div.logic_btn').next('.logic_div').find("a.remove_field").each(function(i, elm){
           // check if current logic div has internal logics as well
           if(!! $('div.logic_div', $(elm)) && $('div.logic_div', $(elm)).length > 0){
               $('div.logic_div', $(elm)).each(function(j, l_div){
                   $(l_div).prev("div.logic_btn .toggle_logic_btn").trigger('click');
               });
           }
           $(elm).trigger('click');
       });
       $(el).closest('div.logic_btn').next('.logic_div').remove();
       
    } else {

        var res = '<div class="col-md-12 logic_div"> <div class="card card-body">'
                    + '<div class="card-block">'
                    + '<div class="question addSurveyQuestion'+str_val+'"><ul class="qus_list" style="padding: 0"></ul></div>'
                    + '<button type="button" class="btn btn-outline-primary" onclick="getStarOnPopUp('+str_val+', this);">'
                    + 'Add Question'
                    + '</button>'
                    + '</div>'
                    + '</div>'
                    + '</div>';

        $(el).closest('div.logic_btn').after(res).show('slow');
    }
}


$(document).ready(function() {
    $(document).on("click", ".remove_field", function(e) { //user click on remove field
        e.preventDefault();
        var bdy = $(this).closest('li.myLi');
        
//        resetQuesNames($(this));
        var qlevel = $(bdy).closest('ul.qus_list').data("q_level");
        
        var tempId = $(this).attr('temp_id');
        var queId = $(this).attr('que_id');
        var starVal = $(this).attr('star_val');
        if (tempId != '' && queId != '' && starVal != '') {
            
            if(!! $('div.logic_div', $(bdy)) && $('div.logic_div', $(bdy)).length > 0){
               $('div.logic_div', $(bdy)).each(function(j, l_div){
                   $(l_div).prev("div.logic_btn .toggle_logic_btn").trigger('click');
               });
            }
            
            $.ajax({
                url: "/SurveyTemplates/removeQuestion",
                type: "post",
                data: {tempId: tempId, queId: queId, starVal: starVal, q_level: qlevel},
                success: function (response) {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == 'ok') {
                            bdy.remove();
                            resetQuesNames($(bdy));
                    } else {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 5, function () {
                            console.log('dismissed');
                        });
                    }
                }
            });
        } else {
            return false;
        }
    });
    
    $(document).on("click", ".fa-chevron-circle-up", function() {
        var $current = $(this).closest('li')
        var $previous = $current.prev('li');
        
        if ($previous.length !== 0) {
            var tempId = $(this).attr('temp_id');
            var queId = $(this).attr('que_id');
            var starVal = $(this).attr('star_val');

            $.ajax({
                url: "/SurveyTemplates/questionOrderingUp",
                type: "post",
                data: {tempId: tempId, queId: queId, starVal: starVal},
                success: function (response) {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == 'ok') {
                        $current.insertBefore($previous);
                    } else {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 5, function () {
                            console.log('dismissed');
                        });
                    }
                }
            });
        }
        return false;
    });

    $(document).on("click", ".fa-chevron-circle-down", function() {
        var $current = $(this).closest('li')
        var $next = $current.next('li');

        if ($next.length !== 0) {
            var tempId = $(this).attr('temp_id');
            var queId = $(this).attr('que_id');
            var starVal = $(this).attr('star_val');

            $.ajax({
                url: "/SurveyTemplates/questionOrderingdown",
                type: "post",
                data: {tempId: tempId, queId: queId, starVal: starVal},
                success: function (response) {
                    var jsonData = JSON.parse(response);
                    if (jsonData.success == 'ok') {
                        $current.insertAfter($next);
                    } else {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 5, function () {
                            console.log('dismissed');
                        });
                    }
                }
            });
        }
        return false;
    });
});



/*
 * Function for import survey template question.
 */
function selectSurveyTemplate(id) {
    $('input[type=checkbox]').prop('checked',false);
    var template_id = id.value; 
    $.ajax({
        url: "/SurveyTemplates/importSurveyTempalteQuestion",
        type: "post",
        data: {'template_id': template_id},
        success: function (response) {            
            var jsonData = JSON.parse(response);
            if (jsonData.length != 0) {
                $.each(jsonData, function (index, value) {
                     $('input[type=checkbox]').each(function() {
                       var removeOnValue = $(this).val();
                       if (removeOnValue != 'on') {
                           if (value.question == $(this).val()) {
                               $('input[type=checkbox][value='+$(this).val()+']').prop('checked', true);
                           }
                       }           
                   })            
                });
            } else {
                $('input[type=checkbox]').prop('checked',false);
            }
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.ERROR_UPDATE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
}


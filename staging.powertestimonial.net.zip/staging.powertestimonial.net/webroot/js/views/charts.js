$(function (){
  'use strict';

//  var randomScalingFactor = function(){ return Math.round(Math.random()*100)};
//  var lineChartData = {
//    labels : ['January','February','March','April','May','June','July'],
//    datasets : [
//      {
//        label: 'My First dataset',
//        backgroundColor : 'rgba(220,220,220,0.2)',
//        borderColor : 'rgba(220,220,220,1)',
//        pointBackgroundColor : 'rgba(220,220,220,1)',
//        pointBorderColor : '#fff',
//        data : [randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor()]
//      },
//      {
//        label: 'My Second dataset',
//        backgroundColor : 'rgba(151,187,205,0.2)',
//        borderColor : 'rgba(151,187,205,1)',
//        pointBackgroundColor : 'rgba(151,187,205,1)',
//        pointBorderColor : '#fff',
//        data : [randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor(),randomScalingFactor()]
//      }
//    ]
//  }

//  var ctx = document.getElementById('canvas-1');
//  var chart = new Chart(ctx, {
//    type: 'line',
//    data: lineChartData,
//    options: {
//      responsive: true
//    }
//  });

  var months = document.getElementById('months').value;
  
  var currentMonthReviewTotal = document.getElementById('current-month-review-total').value;
  var currentMonthReviewCompleted = document.getElementById('current-month-review-completed').value;
  
  var preMonthReview1Total = document.getElementById('pre-month-review1-total').value;
  var preMonthReview1Completed = document.getElementById('pre-month-review1-completed').value;
  
  var preMonthReview2Total = document.getElementById('pre-month-review2-total').value;
  var preMonthReview2Completed = document.getElementById('pre-month-review2-completed').value;
  
  var preMonthReview3Total = document.getElementById('pre-month-review3-total').value;
  var preMonthReview3Completed = document.getElementById('pre-month-review3-completed').value;
  
  var preMonthReview4Total = document.getElementById('pre-month-review4-total').value;
  var preMonthReview4Completed = document.getElementById('pre-month-review4-completed').value;
  
  var preMonthReview5Total = document.getElementById('pre-month-review5-total').value;
  var preMonthReview5Completed = document.getElementById('pre-month-review5-completed').value;
  
//  var randomScalingFactor = function(){ return Math.round(Math.random()*100)};
  var barChartData = {
//    labels : ["August", "September", 'October', 'November', 'December', 'January'],
    labels : months.split(','),
    datasets : [
      {
        label: 'Total',
        backgroundColor : 'rgba(54,162,235,0.5)',
        borderColor : 'rgba(54,162,235,0.8)',
        highlightFill: 'rgba(54,162,235,0.75)',
        highlightStroke: 'rgba(54,162,235,1)',
        data : [preMonthReview5Total,preMonthReview4Total,preMonthReview3Total,preMonthReview2Total,preMonthReview1Total,currentMonthReviewTotal]
      },
      {
        label: 'Completed',
        backgroundColor : 'rgba(255,206,86,0.5)',
        borderColor : 'rgba(255,206,86,0.8)',
        highlightFill : 'rgba(255,206,86,0.75)',
        highlightStroke : 'rgba(255,206,86,1)',
        data : [preMonthReview5Completed,preMonthReview4Completed,preMonthReview3Completed,preMonthReview2Completed,preMonthReview1Completed,currentMonthReviewCompleted]
      }
    ]
  }
  var ctx = document.getElementById('canvas-review');
  var chart = new Chart(ctx, {
    type: 'bar',
    data: barChartData,
    options: {
      responsive: true
    }
  });
  
  var currentMonthSurveyTotal = document.getElementById('current-month-survey-total').value;
  var currentMonthSurveyCompleted = document.getElementById('current-month-survey-completed').value;
  
  var preMonthSurvey1Total = document.getElementById('pre-month-survey1-total').value;
  var preMonthSurvey1Completed = document.getElementById('pre-month-survey1-completed').value;
  
  var preMonthSurvey2Total = document.getElementById('pre-month-survey2-total').value;
  var preMonthSurvey2Completed = document.getElementById('pre-month-survey2-completed').value;
  
  var preMonthSurvey3Total = document.getElementById('pre-month-survey3-total').value;
  var preMonthSurvey3Completed = document.getElementById('pre-month-survey3-completed').value;
  
  var preMonthSurvey4Total = document.getElementById('pre-month-survey4-total').value;
  var preMonthSurvey4Completed = document.getElementById('pre-month-survey4-completed').value;
  
  var preMonthSurvey5Total = document.getElementById('pre-month-survey5-total').value;
  var preMonthSurvey5Completed = document.getElementById('pre-month-survey5-completed').value;
  
  var barChartData = {
    labels : months.split(','),
    datasets : [
      {
        label: 'Total',
        backgroundColor : 'rgba(54,162,235,0.5)',
        borderColor : 'rgba(54,162,235,0.8)',
        highlightFill: 'rgba(54,162,235,0.75)',
        highlightStroke: 'rgba(54,162,235,1)',
        data : [preMonthSurvey5Total,preMonthSurvey4Total,preMonthSurvey3Total,preMonthSurvey2Total,preMonthSurvey1Total,currentMonthSurveyTotal]
      },
      {
        label: 'Completed',
        backgroundColor : 'rgba(255,206,86,0.5)',
        borderColor : 'rgba(255,206,86,0.8)',
        highlightFill : 'rgba(255,206,86,0.75)',
        highlightStroke : 'rgba(255,206,86,1)',
        data : [preMonthSurvey5Completed,preMonthSurvey4Completed,preMonthSurvey3Completed,preMonthSurvey2Completed,preMonthSurvey1Completed,currentMonthSurveyCompleted]
      }
    ]
  }
  var ctx = document.getElementById('canvas-survey');
  var chart = new Chart(ctx, {
    type: 'bar',
    data: barChartData,
    options: {
      responsive: true
    }
  });


//  var doughnutData = {
//    labels: [
//      'Red',
//      'Green',
//      'Yellow'
//    ],
//    datasets: [{
//      data: [300, 50, 100],
//      backgroundColor: [
//        '#FF6384',
//        '#36A2EB',
//        '#FFCE56'
//      ],
//      hoverBackgroundColor: [
//        '#FF6384',
//        '#36A2EB',
//        '#FFCE56'
//      ]
//    }]
//  };
//  var ctx = document.getElementById('canvas-3');
//  var chart = new Chart(ctx, {
//    type: 'doughnut',
//    data: doughnutData,
//    options: {
//      responsive: true
//    }
//  });
//
//
//  var radarChartData = {
//    labels: ['Eating', 'Drinking', 'Sleeping', 'Designing', 'Coding', 'Cycling', 'Running'],
//    datasets: [
//      {
//        label: 'My First dataset',
//        backgroundColor: 'rgba(220,220,220,0.2)',
//        borderColor: 'rgba(220,220,220,1)',
//        pointBackgroundColor: 'rgba(220,220,220,1)',
//        pointBorderColor: '#fff',
//        pointHighlightFill: '#fff',
//        pointHighlightStroke: 'rgba(220,220,220,1)',
//        data: [65,59,90,81,56,55,40]
//      },
//      {
//        label: 'My Second dataset',
//        backgroundColor: 'rgba(151,187,205,0.2)',
//        borderColor: 'rgba(151,187,205,1)',
//        pointBackgroundColor: 'rgba(151,187,205,1)',
//        pointBorderColor: '#fff',
//        pointHighlightFill: '#fff',
//        pointHighlightStroke: 'rgba(151,187,205,1)',
//        data: [28,48,40,19,96,27,100]
//      }
//    ]
//  };
//  var ctx = document.getElementById('canvas-4');
//  var chart = new Chart(ctx, {
//    type: 'radar',
//    data: radarChartData,
//    options: {
//      responsive: true
//    }
//  });
//
//

  var Total = document.getElementById('total').value;
  var Complete = document.getElementById('complete').value;
  var Incomplete = document.getElementById('incomplete').value;
  
  var pieData = {
    labels: [
      'Total',
      'Complete',
      'Incomplete'
    ],
    datasets: [{
      data: [Total, Complete, Incomplete],
      backgroundColor: [
        '#FF6384',
        '#36A2EB',
        '#FFCE56'
      ],
      hoverBackgroundColor: [
        '#FF6384',
        '#36A2EB',
        '#FFCE56'
      ]
    }]
  };
  var ctx = document.getElementById('canvas-5');
  var chart = new Chart(ctx, {
    type: 'pie',
    data: pieData,
    options: {
      responsive: true
    }
  });
//
//
//  var polarData = {
//    datasets: [{
//      data: [
//        11,
//        16,
//        7,
//        3,
//        14
//      ],
//      backgroundColor: [
//        '#FF6384',
//        '#4BC0C0',
//        '#FFCE56',
//        '#E7E9ED',
//        '#36A2EB'
//      ],
//      label: 'My dataset' // for legend
//    }],
//    labels: [
//      'Red',
//      'Green',
//      'Yellow',
//      'Grey',
//      'Blue'
//    ]
//  };
//  var ctx = document.getElementById('canvas-6');
//  var chart = new Chart(ctx, {
//    type: 'polarArea',
//    data: polarData,
//    options: {
//      responsive: true
//    }
//  });
});

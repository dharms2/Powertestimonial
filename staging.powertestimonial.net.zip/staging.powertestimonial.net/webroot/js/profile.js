/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global alertify, ERROR_MESSAGES */
$(".profileImageType").on("click", function (e) {
   if($('#img-url').val() != '')
   {
         var ext = $('#img-url').val().split('.').pop().toLowerCase();
    if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
        e.preventDefault();
        alertify.alert("Alert", 'JPEG,PNG and GIF images are supported');
    }
   }
  
   
});

$(".profileCompanyImageType").on("click", function (e) {
 if($('#business-img-url').val() != '')
   {
        var ext = $('#business-img-url').val().split('.').pop().toLowerCase();
    if($.inArray(ext, ['gif','png','jpg','jpeg']) == -1) {
        e.preventDefault();
        alertify.alert("Alert", 'JPEG,PNG and GIF images are supported');
    }
   }
   
    
});
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global ERROR_MESSAGES, alertify, id */

$(function () {
    
    /*Capitalize fields */
    $('input[capitalize="YES"]').keyup(function (event) {
        var textBox = event.target, start = textBox.selectionStart, end = textBox.selectionEnd;
        textBox.value = textBox.value.charAt(0).toUpperCase() + textBox.value.slice(1);
        textBox.setSelectionRange(start, end);
    });
    
    $.validator.addMethod("EMAIL", function (value, element) {
        return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
    }, ERROR_MESSAGES.EMAIL_VALIDATE);

    $.validator.addMethod("PASSWORD", function (value, element) {
        return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/i.test(value);
    }, ERROR_MESSAGES.PASSWORD_VALIDATE);
    
    $.validator.addMethod("ZIP_CODE", function (value, element) {
        var cval = $('#country').val();
        switch (cval) {
            case "US":
                postalCodeRegex = /^([0-9]{5})(?:[-\s]*([0-9]{4}))?$/;
                break;
            case "CA":
                postalCodeRegex = /^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$/;
                break;
            default:
                postalCodeRegex = /^(?:[A-Z0-9]+([- ]?[A-Z0-9]+)*)?$/;
        }
        return this.optional(element) || postalCodeRegex.test(value);
    }, ERROR_MESSAGES.ZIP_CODE_VALIDATE);

    $('#addSignup').validate({
        rules: {
            first_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            last_name: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                minlength: 2
            },
            username: {
                required: true,
                minlength: 4
            },
            password: {
                required: true,
                PASSWORD: true
            },
            confirm_password: {
                required: true,
                equalTo: '#password'
            },
            email: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                EMAIL: true,
                checkEmail: function () {
                    return [
                        $('[name=email]').val()
                    ];
                }
            },
            address_line1: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            city: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            state: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                }
            },
            country: {
                required: true
            },
            zip_code: {
                required: {
                    depends:function(){
                        $(this).val($(this).val().trimLeft());
                        return true;
                    }
                },
                ZIP_CODE: true
            },
            term_condition: {
                required: true
            },
            card_number: {
                required: true,
                creditcard: true
            },
            exp_month: {
                required: true,
                minlength: 2
            },
            exp_year: {
                required: true,
                minlength: 2
            },
            cvv: {
                required: true,
                minlength: 3
            },
            business_name: {
                required: true
            }
        },
        messages: {
            first_name: {
                required: ERROR_MESSAGES.FIRST_NAME,
                minlength: ERROR_MESSAGES.FIRST_NAME_MINLENGTH
            },
            last_name: {
                required: ERROR_MESSAGES.LAST_NAME,
                minlength: ERROR_MESSAGES.LAST_NAME_MINLENGTH
            },
            username: {
                required: ERROR_MESSAGES.USERNAME,
                minlength: ERROR_MESSAGES.USERNAME_MINLENGTH
            },
            password: {
                required: ERROR_MESSAGES.PASSWORD
            },
            confirm_password: {
                required: ERROR_MESSAGES.CONFIRM_PASSWORD,
                equalTo: ERROR_MESSAGES.CONFIRM_PASSWORD_EQUALTO
            },
            email: {
                required: ERROR_MESSAGES.EMAIL
            },
            address_line1: {
                required: ERROR_MESSAGES.ADDRESS_LINE1_REQUIRED
            },
            city: {
                required: ERROR_MESSAGES.CITY_REQUIRED
            },
            state: {
                required: ERROR_MESSAGES.STATE_REQUIRED
            },
            country: {
                required: ERROR_MESSAGES.COUNTRY_REQUIRED
            },
            zip_code: {
                required: ERROR_MESSAGES.ZIP_CODE_REQUIRED,
                minlength: ERROR_MESSAGES.ZIP_CODE_MINLENGTH,
                maxlength: ERROR_MESSAGES.ZIP_CODE_MAXLENGTH
            },
            term_condition: {
                required: ERROR_MESSAGES.TERM_CONDITION_REQUIRED
            },
            card_number: {
                required: ERROR_MESSAGES.CARD_NUMBER
            },
            exp_month: {
                required: ERROR_MESSAGES.EXP_MONTH,
                minlength: ERROR_MESSAGES.EXP_MONTH_MIN
            },
            exp_year: {
                required: ERROR_MESSAGES.EXP_YEAR,
                minlength: ERROR_MESSAGES.EXP_YEAR_MIN
            },
            cvv: {
                required: ERROR_MESSAGES.CVV_NO,
                minlength: ERROR_MESSAGES.CVV_NO_MIN
            },
            business_name: {
                required: ERROR_MESSAGES.CVV_NO
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element);
            }
        }
    });

    /*Check validation where rate code and hotel code are unique or not*/
    $.validator.addMethod("checkEmail", function (value, element) 
    {
        var result = false;
        $.ajax({
            type: "POST",
            async: false,
            url: "/Users/checkEmailIsUnique", // script to validate in server side
            data: {email: value},
            dataType: 'JSON',
            success: function (data) {
                result = (data.count === 0) ? true : false;
            }
        });
        // return true if Code is exist in database
        return result;
    }, ERROR_MESSAGES.EMAIL_EXISTS );
    
    // NOTICE: Modified version of Castle.Components.Validator.CreditCardValidator
    // Valid Types: mastercard, visa, amex, dinersclub, enroute, discover, jcb, unknown, all (overrides all other settings)
    $.validator.addMethod("creditcard", function (val, el) {

        var card_no = $("#card-number").val();
        var pattern_american = /^(?:3[47][0-9]{13})$/;
        var pattern_visa = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
        var pattern_master = /^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/;
        var pattern_discover = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
        var pattern_dinner = /^(?:3(?:0[0-5]|[68][0-9])[0-9]{11})$/;
        var pattern_jcb = /^(?:(?:2131|1800|35\d{3})\d{11})$/;
        var pattern_maestro = /^(5018|5020|5038|6304|6759|676[1-3])/;

        var card_type = false;

        if (card_no.match(pattern_american)) {
            $(".card-icon").hide();
            $("#card-amex").show();
            return true;
        } else if (card_no.match(pattern_visa)) {
            $(".card-icon").hide();
            $("#card-visa").show();
            return true;
        } else if (card_no.match(pattern_master)) {
            $(".card-icon").hide();
            $("#card-mastercard").show();
            return true;
        } else if (card_no.match(pattern_discover)) {
            $(".card-icon").hide();
            $("#card-discover").show();
            return true;
        } else if (card_no.match(pattern_dinner)) {
            $(".card-icon").hide();
            $("#card-diners").show();
            return true;
        } else if (card_no.match(pattern_jcb)) {
            $(".card-icon").hide();
            $("#card-jcb").show();
            return true;
        } else if (card_no.match(pattern_maestro)) {
            $(".card-icon").hide();
            $("#card-maestro").show();
            return true;
        } else {
            return false;
        }
    }, ERROR_MESSAGES.CARD_NUMBER );
});

function applyCoupon(pId) {
    var code = $('#coupon-code').val();
    if (code == '') {
        alertify.alert('error', ERROR_MESSAGES.REQUIRED_COUPON_CODE, function () {
            console.log('dismissed');
        });
    } else {
        $.ajax({
            type: 'POST',
            url: "/Users/applyCoupon",
            data: {couponCode: code, planId: pId},
            dataType: 'json',
            success: function (data) {
                if (data.response == 'OK') {
                    $('#dis-amt').find('.discount').remove();
                    $('#dis-amt').append('<td class="text-right befor-dis">- $'+data.disAmount+'.00</td>');
                    $('#total-amt').find('.total').remove();
                    $('#total-amt').append('<td class="text-right total"><strong>$'+data.totalAmount+'.00</strong></td>');
                    $('#coupon-code-section').hide();
                    $('#main-form').find('#amt').remove();
                    $('#main-form').find('.amt-section').append('<input type="hidden" id="amt" name="amt" value="'+data.totalAmount+'.00">');
                } else if (data.response == 'ERROR') {
                    alertify.alert('Notification', ERROR_MESSAGES.EXP_COUPON_CODE, function () {
                        console.log('dismissed');
                    });
                }
                //location.reload(); 
            },
            error: function (response) {
                alertify.alert('error', ERROR_MESSAGES.FAILED_ERROR_MESSAGE, function () {
                    console.log('dismissed');
                });
            }
        });
    }
}

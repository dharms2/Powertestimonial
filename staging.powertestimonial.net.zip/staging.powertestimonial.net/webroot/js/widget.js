/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global alertify */

function cancelShowHideReviewsList() 
{
    $('#formShowReviewsIframe').css('display','none');
    $('#tableHideReviewsIframe').css('display','block');
}

function tableShowHideReviews() 
{
    $('#tableShowReviewsIframe').css('display','none');
    $('#tableHideReviewsIframe').css('display','block');
}

function tableShowReviews() 
{
    $('#tableShowReviewsIframe').css('display','block');
    $('#tableHideReviewsIframe').css('display','none');
}

function clearTextareaContent() {
    $('#showWidgetCodeHere').val('');
    $('#getReviewChannelDisable').css('display', 'none');
}

function getReviewChannel() {
    var param_value = $('#getReviewSocialChannel').val();
    var select_boxtype = $('#getReviewSocialBox').val();
    if (param_value === '')
    {
        alertify.alert("Alert", 'Please Choose any one of User');
        return false;
    }
    
    if (select_boxtype === '')
    {
        alertify.alert("Alert", 'Please Choose any one of Box Type');
        return false;
    }
    
    if (select_boxtype === 's') {
        var urlControllerName = 'reviewSmall';
    } else if(select_boxtype === 'l') {
         var urlControllerName = 'largeReviewIframe';
    }
    
    $('#showLaoderHere').html('<div class="loading">Loading&#8230;</div>');
    $.ajax({
        url: "/Widgets/"+urlControllerName+"",
        type: "post",
        data: {'userId': param_value},
        success: function (response) {   
            var jsonData = JSON.parse(response);

            if (jsonData.length !== 0) {
                var htmlIframe = '<iframe src="'+jsonData+'" width="700" height="550" frameborder="0"></iframe>';
                $('#getURLByJquery').val(htmlIframe); 
                $('#showLaoderHere').html('');
                $('#getReviewChannelDisable').css('display', 'block');
                $('#showWidgetCodeHere').val($('#getURLByJquery').val());
            } else {
                $('input[type=checkbox]').prop('checked',false);
            }
        },
        error: function (response) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.notify(ERROR_MESSAGES.FAILED_ERROR_MESSAGE, 'error', 10, function () {
                console.log('dismissed');
            });
        }
    });
   
}


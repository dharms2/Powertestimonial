/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global ERROR_MESSAGES, alertify */

$(function () {
    
    $.validator.addMethod("EMAIL", function(value, element) {
        return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
    }, ERROR_MESSAGES.EMAIL_VALIDATE);
    
    $.validator.addMethod("PHONE",function(value, element){
        return this.optional(element) || /^(?=.*\d).{10,14}$/i.test(value);
    }, ERROR_MESSAGES.PHONE_VALIDATE);

    $('#contact-form').validate({
        rules: {
            name: {
                required: true,
                minlength: 2
            },
            email: {
                required: true,
                EMAIL: true
            },
            phone: {
                required: true,
                PHONE: true
            },
            content: {
                required: true,
                minlength: 50
            }            
        },
        messages: {
            name: {
                required: ERROR_MESSAGES.NAME,
                minlength: ERROR_MESSAGES.NAME_MINLENGTH
            },
            email: {
                required: ERROR_MESSAGES.EMAIL
            },
            phone: {
                required: ERROR_MESSAGES.PHONE
            },
            content: {
                required: ERROR_MESSAGES.CONTENT,
                minlength: ERROR_MESSAGES.CONTENT_VALIDATE
            }
        },
        errorElement: 'em',
        errorPlacement: function (error, element) {
            // Add the `help-block` class to the error element
            if (element.prop('type') === 'checkbox') {
                error.insertAfter(element.parents('.checkbox'));
            } else {
                error.insertAfter(element.parents('.input-group'));
            }
        }
    });

    $("#phone").text(function(i, text) {
        text = text.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
        return text;
    });
 
    /*Check validation where rate code and hotel code are unique or not*/
    $.validator.addMethod("checkEmail", function(value, element) {

            var result = false;
            $.ajax({
                type:"POST",
                async: false,
                url: "/Users/checkEmailIsUnique", // script to validate in server side
                data: { email : value },
                dataType: 'JSON',
                success: function(data) {
                    result = (data.count === 0) ? true : false;
                }
            });
            // return true if Code is exist in database
            return result; 
        }, 
        ERROR_MESSAGES.EMAIL_EXISTS
    );

});

